--DROP  PROCEDURE [DBO].[USP_DWN_H4101M1_1_KO896] (    
CREATE  PROCEDURE [DBO].[USP_DWN_H4007M3_1_KO883]   
(    
        @S_YYMMDD [NVARCHAR](10), -- ����FROM    
        @E_YYMMDD [NVARCHAR](10), -- ����TO    
        --@DEPT_CD [NVARCHAR](15), -- �μ��ڵ�    
        --@EMP_NO  [NVARCHAR](13), -- �����ȣ    
        --@USR_ID  [NVARCHAR](15), -- USER_ID    
  @MSG_CD  [NVARCHAR](6)  OUTPUT   -- ERROR MESSAGE CODE         
) AS  
/************************************************************************/      
/*****    PROC NAME  : [USP_DWN_H4101M1_1_KO896]     *****/      
/*****    ��    ��   : ����ٽð������ȸ          *****/      
/*****    VERSION    : UNIERP.NET                                   *****/      
/************************************************************************/     
--DECLARE   
--        @S_YYMMDD [NVARCHAR](10), -- ����FROM    
--        @E_YYMMDD [NVARCHAR](10), -- ����TO    
--        @DEPT_CD  [NVARCHAR](15), -- �μ��ڵ�    
--        @EMP_NO   [NVARCHAR](13), -- �����ȣ    
--        @USR_ID   [NVARCHAR](15), -- USER_ID    
--  @MSG_CD   [NVARCHAR](6)  --OUTPUT   -- ERROR MESSAGE CODE         
  
--SET  @S_YYMMDD = '20180701'  
--SET  @E_YYMMDD = '20180824'  
--SET  @DEPT_CD  = ''  
--SET  @EMP_NO   = ''  
--SET  @USR_ID   = 'UNIERP'  
--SET  @MSG_CD   = ''    
SET TRANSACTION ISOLATION LEVEL READ COMMITTED    
    
--DECLARE @EMP_FG  NVARCHAR(1) = '1'    
    
--SELECT @DEPT_CD = CASE WHEN ISNULL(@DEPT_CD,'') = '' THEN '%' ELSE @DEPT_CD + '%' END    
--SELECT @EMP_NO  = CASE WHEN ISNULL(@EMP_NO,'') = '' THEN '%' ELSE @EMP_NO + '%' END    
    
------- ���� CHECK    
IF  @S_YYMMDD > @E_YYMMDD    
 SELECT  @E_YYMMDD = @S_YYMMDD    
 --BEGIN             
 -- SET  @MSG_CD ='800069'            
 -- GOTO ERROR_RETURN            
 --END    
    
--�����ȣ, ����,�μ�,��å,����,����,����,�������,��ٽð�,�������,��ٽð�,���    

select	CONVERT (varchar,A.WORK_DT,23) as WORK_DT, A.MAIN_DEPT_NM,A.DEPT_NM, A.EMP_NO , A.NAME, A.ROLL_PSTN_NM, A.DAY_WEEK,
  CASE A.START_TIME     
    When '' THEN ''    
    ELSE convert(char(8),A.START_TIME,108)
  END as START_TIME,    
  CASE A.END_TIME     
    When '' THEN ''     
    ELSE convert(char(8),A.END_TIME,108)
  END as END_TIME, A.OT, A.HT, A.TT
from	WT_MA_KO883 A
where	A.WORK_DT >= convert(datetime , @S_YYMMDD ,121) --'2020/09/09' --@S_YYMMDD 
AND		A.WORK_DT <= convert(datetime , @E_YYMMDD ,121)
order by   A.WORK_DT,A.EMP_NO

--SELECT  C.CLOSE_FG,C.CLOSE_FG AS CLOSE_FG_OLD,  
--   @EMP_FG EMP_FG,A.EMP_NO,A.NAME,A.DEPT_CD,A.DEPT_NM,      --�����ȣ,����,�μ�    
--   A.ROLE_CD,DBO.UFN_GETCODENAME('H0026',A.ROLE_CD) ROLE_NM, --��å    
--   A.FUNC_CD,DBO.UFN_GETCODENAME('H0004',A.FUNC_CD) FUNC_NM, --����,    
--   --CONVERT(NVARCHAR(10),B.DATE,121) YYMMDD,   
--   B.DATE AS YYMMDD,   
--   DATENAME(DW,B.DATE)  WEEK_NM,        --���ϱ���    
--   CASE WHEN ISNULL(C.S_YYMMDD,'') = '' THEN NULL ELSE CONVERT(DATETIME, C.S_YYMMDD) END S_YYMMDD,       --�������    
--   CASE WHEN ISNULL(C.S_HHMM,'') = '' THEN NULL ELSE LEFT(C.S_HHMM,2) + ':' + RIGHT(C.S_HHMM,2) END S_HHMM,    
--   CASE WHEN ISNULL(C.E_YYMMDD,'') = '' THEN NULL ELSE CONVERT(DATETIME, C.E_YYMMDD) END E_YYMMDD,       --�������    
--   CASE WHEN ISNULL(C.E_HHMM,'') = '' THEN NULL ELSE LEFT(C.E_HHMM,2) + ':' + RIGHT(C.E_HHMM,2) END E_HHMM,  
--   C.DILIG_CD,D.DILIG_NM,    
--   CASE WHEN ISNULL(C.D00_TIME,'') = '' THEN NULL ELSE LEFT(C.D00_TIME,2) + ':' + RIGHT(C.D00_TIME,2) END D00_TIME, -----����      
--   CASE WHEN ISNULL(C.D31_TIME,'') = '' THEN NULL ELSE LEFT(C.D31_TIME,2) + ':' + RIGHT(C.D31_TIME,2) END D31_TIME, -----����      
--   CASE WHEN ISNULL(C.D35_TIME,'') = '' THEN NULL ELSE LEFT(C.D35_TIME,2) + ':' + RIGHT(C.D35_TIME,2) END D35_TIME, -----Ư��      
--   CASE WHEN ISNULL(C.D36_TIME,'') = '' THEN NULL ELSE LEFT(C.D36_TIME,2) + ':' + RIGHT(C.D36_TIME,2) END D36_TIME, -----Ư��      
--   CASE WHEN ISNULL(C.D34_TIME,'') = '' THEN NULL ELSE LEFT(C.D34_TIME,2) + ':' + RIGHT(C.D34_TIME,2) END D34_TIME, -----�߰�      
--   CASE WHEN ISNULL(C.D21_TIME,'') = '' THEN NULL ELSE LEFT(C.D21_TIME,2) + ':' + RIGHT(C.D21_TIME,2) END D21_TIME, -----����      
--   CASE WHEN ISNULL(C.D22_TIME,'') = '' THEN NULL ELSE LEFT(C.D22_TIME,2) + ':' + RIGHT(C.D22_TIME,2) END D22_TIME, -----����      
--   CASE WHEN ISNULL(C.D23_TIME,'') = '' THEN NULL ELSE LEFT(C.D23_TIME,2) + ':' + RIGHT(C.D23_TIME,2) END D23_TIME, -----����      
--   C.REM  
--FROM  HAA010T A(NOLOCK)    
--JOIN  HCA020T B(NOLOCK) ON B.DATE >= @S_YYMMDD AND B.DATE <= @E_YYMMDD AND B.WK_TYPE = '0'    
--JOIN  HCA041T_KO896 C(NOLOCK) ON C.YYMMDD = B.DATE AND A.EMP_NO = C.EMP_NO AND C.EMP_FG = @EMP_FG    
--LEFT JOIN HCA010T D(NOLOCK) ON C.DILIG_CD = D.DILIG_CD       
--JOIN  DBO.UFN_AUTHINTERNALCD_BYUSRID(@USR_ID) Y ON Y.INTERNAL_CD = A.INTERNAL_CD    
--WHERE  A.DEPT_CD LIKE @DEPT_CD    
--AND   A.EMP_NO LIKE @EMP_NO    
--AND   ( ISNULL(A.RETIRE_DT,'') = '' OR A.RETIRE_DT > @S_YYMMDD)    
--AND   A.ENTR_DT <= @E_YYMMDD    
--ORDER BY A.EMP_NO,B.DATE  
    
    
RETURN 1            
            
ERROR_RETURN:            
RETURN -1     
/**      
    
DECLARE @P11 VARCHAR(8)      
SET @P11=NULL    
EXEC USP_DWN_H4101M1_1_KO896 '2018-07-18','2018-07-22','','','UNIERP',@P11 OUTPUT    
SELECT @P11    
    
**/