/*
--HCA041T_RF_TEMP_KO891
/*
*/
--DROP	PROC	USP_DWN_H4101M1_KO896_EXCEL_UPLOAD
--DROP	TYPE	dbo.UTP_HR_H4101M1_KO896_EXCEL

--CREATE	TYPE	dbo.UTP_HR_H4101M1_KO896_EXCEL	AS	TABLE
--(
--	YYMMDD		nvarchar(20)
--,	DEPT1		nvarchar(50)
--,	DEPT2		nvarchar(50)
--,	DEPT3		nvarchar(50)
--,	DEPT4		nvarchar(50)
--,	NAME		nvarchar(50)
--,	EMP_NO		nvarchar(20)
--,	PAY_GRD1	nvarchar(20)
--,	SECOM_NO	nvarchar(20)
--,	WK_TYPE		nvarchar(20)
--,	WK_SCHEDUL	nvarchar(20)
--,	START_DT	nvarchar(20)
--,	END_DT		nvarchar(20)
--,	START_FG	nvarchar(20)
--,	END_FG		nvarchar(20)
--,	LATENESS	nvarchar(10)
--,	FS_TIME		nvarchar(10)
--,	EXT_TIME	nvarchar(10)
--,	LIGHT_TIME	nvarchar(10)
--,	HOLI_TIME	nvarchar(10)
--,	WK_TIME		nvarchar(10)
--,	TOTAL_TIME	nvarchar(10)
--,	STD_TIME	nvarchar(10)
--,	SLOW_FG		nvarchar(20)
--)

--DROP	PROC	USP_DWN_H4007M3_KO883_EXCEL_UPLOAD
--DROP	TYPE	dbo.UTP_HR_H4007M3_KO883_EXCEL

CREATE	TYPE	dbo.UTP_HR_H4007M3_KO883_EXCEL	AS	TABLE
(
		WORK_DT   nvarchar(10) ,
       MAIN_DEPT_NM     nvarchar(26),                       -- �����μ���
	   DEPT_NM      nvarchar(26),                       -- �μ���
	   EMP_NO       nvarchar(26),					   -- ���
	   NAME			nvarchar(26),					   -- ����
	   ROLL_PSTN_NM nvarchar(26),                      -- ����
	   DAY_WEEK     nvarchar(40),                       -- �ٹ�����
	   START_TIME	nvarchar(40),   
	   END_TIME		nvarchar(40),   
	   OT          nvarchar(26),                       -- �߰��ٹ��ð�
	   HT          nvarchar(26),                       -- ����ٹ��ð�
	   TT          nvarchar(26),                       -- ���Ͻð�
	   ETC1    nvarchar(40),                       -- ���
	   ETC2    nvarchar(40),                       -- ���2
	   ETC3    nvarchar(40)                      -- ���3
	   --ISRT_EMP_NO nvarchar(40),					   -- ������
	   --ISRT_DT     datetime,						   -- ������
	   --UPDT_EMP_NO nvarchar(40),					   -- ������
	   --UPDT_DT     datetime						   -- ��������

)


*/
/********************************************************************************************/
/*****	PROCEDURE NAME	:	USP_DWN_H4101M1_KO896_EXCEL_UPLOAD							*****/
/*****	AUTHOR			:	JIHU.KIM													*****/
/*****	CREATE DATE		:	2018-08-27												    *****/
/*****	DESCRIPTION		:	����ٽð����UPLOAD(EXCEL SAVE)						    *****/	
/*****	HISTORY			:															    *****/
/********************************************************************************************/
ALTER PROC USP_DWN_H4007M3_KO883_EXCEL_UPLOAD
(
		@TBL_DATA		UTP_HR_H4007M3_KO883_EXCEL	READONLY
	,	@DATE_FR		NVARCHAR(10)
	,	@DATE_TO		NVARCHAR(10)

	,	@USER_ID		NVARCHAR(30)
	,	@MSG_CD			NVARCHAR(06)	=	NULL	OUTPUT
	,	@MESSAGE		NVARCHAR(500)	=	NULL	OUTPUT
	,	@ERR_POS		BIGINT			=	NULL	OUTPUT
)AS
BEGIN
	SET	NOCOUNT	ON;

	DECLARE @ERROR_NUMBER INT

	/*üũ����*/
	
	DECLARE		
			   @CUR_WORK_DT   nvarchar(10) ,
			   @CUR_MAIN_DEPT_NM     nvarchar(26),                       -- �����μ���
			   @CUR_DEPT_NM      nvarchar(26),                       -- �μ���
			   @CUR_EMP_NO       nvarchar(26),					   -- ���
			   @CUR_NAME			nvarchar(26),
			   @CUR_ROLL_PSTN_NM nvarchar(26),                      -- ����
			   @CUR_DAY_WEEK     nvarchar(40),                       -- �ٹ�����
			   @CUR_START_TIME	datetime,   
			   @CUR_END_TIME		datetime,   
			   @CUR_OT          nvarchar(26),                       -- �߰��ٹ��ð�
			   @CUR_HT          nvarchar(26),                       -- ����ٹ��ð�
			   @CUR_TT          nvarchar(26),                       -- ���Ͻð�
			   --@CUR_ETC1    nvarchar(40),                       -- ���
			   --@CUR_ETC2    nvarchar(40),                       -- ���2
			   --@CUR_ETC3    nvarchar(40),                       -- ���3
	   

				@TRAN_YN		NCHAR(01)

	IF	@@TRANCOUNT	>	0
		SET	@TRAN_YN	=	'N'
	ELSE
	BEGIN
		SET	@TRAN_YN	=	'Y'
		BEGIN	TRANSACTION
	END

	BEGIN	TRY
		DECLARE Cur_WorkList CURSOR LOCAL FOR

		select	A.WORK_DT, A.MAIN_DEPT_NM,A.DEPT_NM,A.EMP_NO, A.NAME, A.ROLL_PSTN_NM, A.DAY_WEEK,
				A.START_TIME, A.END_TIME, A.OT, A.HT, A.TT
		FROM	@TBL_DATA	A
		WHERE   convert(datetime, A.WORK_DT)	BETWEEN @DATE_FR AND @DATE_TO	--UI�� ������ �ش�Ⱓ�� �ڷḸ ����� ����
	
		OPEN	Cur_WorkList

		FETCH	NEXT	FROM	Cur_WorkList
		INTO  @CUR_WORK_DT   ,@CUR_MAIN_DEPT_NM     , @CUR_DEPT_NM  , @CUR_EMP_NO    , @CUR_NAME			,@CUR_ROLL_PSTN_NM ,                      
			   @CUR_DAY_WEEK     ,@CUR_START_TIME	,@CUR_END_TIME		,@CUR_OT          ,@CUR_HT          ,@CUR_TT                                

		--001.�ش�Ⱓ�� �ڷḦ WT_MA_KO883 ����
		DELETE FROM WT_MA_KO883
		WHERE		convert(datetime,WORK_DT) BETWEEN convert(datetime , @DATE_FR ,121)   AND convert(datetime , @DATE_TO ,121) 

		WHILE(@@FETCH_STATUS = 0)
		BEGIN
				--002.�ش�Ⱓ�� �ڷḦ WT_MA_KO883 ����
				INSERT INTO WT_MA_KO883
				(
					A.WORK_DT, A.EMP_NO ,A.NAME, A.DAY_WEEK,
					A.START_TIME, A.END_TIME , TOT_TIME,A.OT, A.HT, A.TT
					, ISRT_EMP_NO , ISRT_DT ,UPDT_EMP_NO ,UPDT_DT 
				)
				VALUES
				(
					convert(datetime,@CUR_WORK_DT) ,
					--@CUR_MAIN_DEPT_NM     ,
					--(select DEPT_NM from HAA010T where name =@CUR_NAME and RETIRE_DT is null)   ,
					 (select emp_no from HAA010T where name =@CUR_NAME and RETIRE_DT is null)   ,
					  @CUR_NAME			,
					  --(select dbo.ufn_getcodename('h0002', roll_pstn) as ROLL_PSTN_NM from HAA010T where name =@CUR_NAME and RETIRE_DT is null) ,                      
					CASE @CUR_DAY_WEEK
					WHEN '����' Then '����'
					WHEN '��������' Then '����'
					WHEN '���Ĺ���' Then '����'
					WHEN '��������' Then '����'
					WHEN '�߰��ٹ�(15��)' Then '����'
					WHEN '�߰��ٹ�(21��)' Then '����'
					WHEN '�߰��ٹ�(23��)' Then '����'
					WHEN '��ü����' Then '����'
					WHEN '���ų�' Then '����'
					WHEN '�ܺα���' Then '����'
					ELSE '����'
					END   ,
					
					CASE @CUR_START_TIME
					WHEN ''
					THEN null
					ELSE @CUR_START_TIME
					END	,
					CASE @CUR_END_TIME
					WHEN ''
					THEN null
					ELSE @CUR_END_TIME
					END,
					CASE @CUR_END_TIME - @CUR_START_TIME
					WHEN ''
					THEN null
					ELSE @CUR_END_TIME - @CUR_START_TIME
					END
					
					
	--				convert(nvarchar(12),			
	--cast(					-- �ð� ����
		 
	--		 ( DATEDIFF(n,
	--						CASE @CUR_START_TIME
	--					    WHEN '' THEN ''
	--						ELSE @CUR_START_TIME
	--						END,
	--						CASE @CUR_END_TIME
	--						WHEN ''
	--						THEN ''
	--						ELSE @CUR_END_TIME
	--						END) - 60  )  
	--	 / 60 as varchar(4) ) + ':' +

 --    CASE					-- �� ����
	-- WHEN cast(
		 
	--		 ( DATEDIFF(n,
	--						CASE @CUR_START_TIME
	--					    WHEN '' THEN ''
	--						ELSE @CUR_START_TIME
	--						END,
	--						CASE @CUR_END_TIME
	--						WHEN ''
	--						THEN ''
	--						ELSE @CUR_END_TIME
	--						END) - 60  )  
	--	 % 60 as varchar(4) ) < 10
	-- THEN '0' + cast(
		 
	--		 ( DATEDIFF(n,
	--						CASE @CUR_START_TIME
	--					    WHEN '' THEN ''
	--						ELSE @CUR_START_TIME
	--						END,
	--						CASE @CUR_END_TIME
	--						WHEN ''
	--						THEN ''
	--						END )-60 )
	--	 % 60 as varchar(4) )
	-- ELSE cast(
		 
	--		 ( DATEDIFF(n,
	--						CASE @CUR_START_TIME
	--					    WHEN '' THEN ''
	--						ELSE @CUR_START_TIME
	--						END,
	--						CASE @CUR_END_TIME
	--						WHEN ''
	--						THEN ''
	--						ELSE @CUR_END_TIME
	--						END) - 60  )  
	--	 % 60 as varchar(4) )
	--  END
		 
	--	 , 114) 

							,
							CASE @CUR_OT
							WHEN '0.0'
							THEN NULL
							ELSE @CUR_OT
							END,
							CASE @CUR_HT
							WHEN '00:00'
							THEN NULL
							ELSE @CUR_HT
							END , 
							CASE @CUR_TT
							WHEN '00:00'
							THEN null
							ELSE @CUR_TT
							END
							  
					, @USER_ID, getdate(), null, getdate()
				)


				--INSERT INTO HCA041T_RF_TEMP_KO896
				--(
				--	YYMMDD, DEPT1, DEPT2, DEPT3, DEPT4
				--	, NAME, EMP_NO, PAY_GRD1, SECOM_NO, WK_TYPE, WK_SCHEDUL
				--	, START_DT, END_DT, START_FG, END_FG, LATENESS
				--	, FS_TIME, EXT_TIME, LIGHT_TIME, HOLI_TIME, WK_TIME, TOTAL_TIME, STD_TIME, SLOW_FG
				--)
				--VALUES
				--(
				--	@CUR_YYMMDD,		@CUR_DEPT1,		@CUR_DEPT2,			@CUR_DEPT3,		@CUR_DEPT4
				--	, @CUR_NAME,		@CUR_EMP_NO,	@CUR_PAY_GRD1,		@CUR_SECOM_NO,	@CUR_WK_TYPE, @CUR_WK_SCHEDUL
				--	, @CUR_START_DT,	@CUR_END_DT,	@CUR_START_FG,		@CUR_END_FG,	@CUR_LATENESS
				--	, @CUR_FS_TIME,		@CUR_EXT_TIME,	@CUR_LIGHT_TIME,	@CUR_HOLI_TIME, @CUR_WK_TIME, @CUR_TOTAL_TIME, @CUR_STD_TIME, @CUR_SLOW_FG
				--)

				--003.USP_DWN_H4101M1_2_KO896 CALL
				--DECLARE @ERROR_MSG  NVARCHAR(06)
				--,		@DEPT_CD	NVARCHAR(10)
				--,		@EMP_NO		NVARCHAR(13)

				--SET		@ERROR_MSG	= NULL

				--SELECT	@DEPT_CD = DEPT_CD, @EMP_NO = EMP_NO
				--FROM	HAA010T_012T_VIEW(NOLOCK) WHERE CARD_ID = @CUR_SECOM_NO

				--EXEC USP_DWN_H4101M1_2_KO896 @CUR_YYMMDD, @CUR_YYMMDD, @DEPT_CD, @EMP_NO, @USER_ID, @ERROR_MSG OUTPUT
				--/*
				--	@S_YYMMDD
				--	@E_YYMMDD
				--	@DEPT_CD
				--	@EMP_NO
				--	@USR_ID
				--	@MSG_CD
				--*/

				--IF(@ERROR_MSG <> NULL)
				--BEGIN
				--	SET @MSG_CD = @ERROR_MSG
				--END

				FETCH	NEXT	FROM	Cur_WorkList
				INTO	@CUR_WORK_DT   ,@CUR_MAIN_DEPT_NM     , @CUR_DEPT_NM   , @CUR_EMP_NO   , @CUR_NAME			,@CUR_ROLL_PSTN_NM ,                      
						@CUR_DAY_WEEK     ,@CUR_START_TIME	,@CUR_END_TIME		,@CUR_OT          ,@CUR_HT          ,@CUR_TT                                


				--INTO	@CUR_YYMMDD,		@CUR_DEPT1,		@CUR_DEPT2,			@CUR_DEPT3,		@CUR_DEPT4
				--		, @CUR_NAME,		@CUR_EMP_NO,	@CUR_PAY_GRD1,		@CUR_SECOM_NO,	@CUR_WK_TYPE, @CUR_WK_SCHEDUL
				--		, @CUR_START_DT,	@CUR_END_DT,	@CUR_START_FG,		@CUR_END_FG,	@CUR_LATENESS
				--		, @CUR_FS_TIME,		@CUR_EXT_TIME,	@CUR_LIGHT_TIME,	@CUR_HOLI_TIME, @CUR_WK_TIME, @CUR_TOTAL_TIME, @CUR_STD_TIME, @CUR_SLOW_FG
		END	-- WHILE END

		CLOSE	Cur_WorkList
		DEALLOCATE	Cur_WorkList

		

	END	TRY
	BEGIN	CATCH
		SET	@ERROR_NUMBER	=	ERROR_NUMBER()

		IF	@ERROR_NUMBER	=	2627		--%1! ���� ���� '%2!'��(��) �����߽��ϴ�. ��ü '%3!'�� �ߺ� Ű�� ������ �� �����ϴ�. �ߺ� Ű ���� %4!�Դϴ�.
			SET	@MSG_CD			=	'970001'	-- %1 ��(��) �̹� �����մϴ�.
		ELSE IF	@ERROR_NUMBER	=	547		-- %1! ���� %2! ���� ���� "%3!"��(��) �浹�߽��ϴ�. �����ͺ��̽� "%4!", ���̺� "%5!"%6!%7!%8!���� �浹�� �߻��߽��ϴ�.
			SET	@MSG_CD			=	'971000'	-- %1 ��(��) �����ϰ� �ִ� �����Ͱ� �ֽ��ϴ�. �۾��� ������ �� �����ϴ�.
		ELSE IF	@ERROR_NUMBER	=	1205		-- Ʈ�����(���μ��� ID %1!)�� %2! ���ҽ����� �ٸ� ���μ������� ���� ���°� �߻��Ͽ� ������ �����Ǿ����ϴ�. Ʈ������� �ٽ� �����Ͻʽÿ�.
			SET	@MSG_CD			=	'122918'	-- %1 ���忡 �����߽��ϴ�.
		ELSE	IF	ISNULL(@MESSAGE,'')	=	''
			SET	@MESSAGE		=	ERROR_MESSAGE()

		GOTO	__ERROR
	END	CATCH

	IF	@TRAN_YN	=	'Y'	AND	@@TRANCOUNT	>	0	COMMIT	TRANSACTION
	RETURN	1

__ERROR:
	IF	@TRAN_YN	=	'Y'	AND	@@TRANCOUNT	>	0	ROLLBACK	TRANSACTION

	IF	CURSOR_STATUS('local','Cur_WorkList')	>=	0
	BEGIN
		CLOSE	Cur_WorkList
		DEALLOCATE	Cur_WorkList
	END

	RETURN	-1
END
