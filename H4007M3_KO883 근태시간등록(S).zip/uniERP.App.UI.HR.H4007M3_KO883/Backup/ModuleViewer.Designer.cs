﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.HR.H4101M1_KO896
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.popEmpNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblEmpNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popDeptCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTextBox_Name = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTextBox_Code = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblDeptCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtDate = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.uniDateTimeF = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.uniDateTimeT = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.uniLabel1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDate = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblRefData = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.uniTBL_MainCondition.SuspendLayout();
            this.popEmpNo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0)).BeginInit();
            this.popDeptCd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).BeginInit();
            this.dtDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTimeF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTimeT)).BeginInit();
            this.uniTBL_MainReference.SuspendLayout();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.PathInfo;
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(1115, 630);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 97);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(1115, 501);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 0;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance1.BackColor = System.Drawing.SystemColors.Window;
            appearance1.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance1;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance2.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance2.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance2;
            appearance3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance3;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance4.BackColor2 = System.Drawing.SystemColors.Control;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance4;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance5;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance6.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance6;
            appearance7.BorderColor = System.Drawing.Color.Silver;
            appearance7.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance7;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance8.BackColor = System.Drawing.SystemColors.Control;
            appearance8.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance8.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance8.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance8;
            appearance9.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance9;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance10.BackColor = System.Drawing.SystemColors.Window;
            appearance10.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance10;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance11.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance11;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(1115, 501);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.AfterExitEditMode += new System.EventHandler(this.uniGrid1_AfterExitEditMode);
            this.uniGrid1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.uniGrid1_BeforePopupOpen);
            this.uniGrid1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.uniGrid1_AfterPopupClosed);
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.popEmpNo, 3, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblEmpNo, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popDeptCd, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblDeptCd, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.dtDate, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblDate, 0, 0);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 2;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(1115, 61);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // popEmpNo
            // 
            this.popEmpNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popEmpNo.AutoPopupCodeParameter = null;
            this.popEmpNo.AutoPopupID = null;
            this.popEmpNo.AutoPopupNameParameter = null;
            this.popEmpNo.CodeMaxLength = 13;
            this.popEmpNo.CodeName = "";
            this.popEmpNo.CodeSize = 100;
            this.popEmpNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popEmpNo.CodeTextBoxName = null;
            this.popEmpNo.CodeValue = "";
            this.popEmpNo.Controls.Add(this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef);
            this.popEmpNo.Controls.Add(this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0);
            this.popEmpNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popEmpNo.Location = new System.Drawing.Point(713, 30);
            this.popEmpNo.LockedField = false;
            this.popEmpNo.Margin = new System.Windows.Forms.Padding(0);
            this.popEmpNo.Name = "popEmpNo";
            this.popEmpNo.NameDisplay = true;
            this.popEmpNo.NameId = null;
            this.popEmpNo.NameMaxLength = 50;
            this.popEmpNo.NamePopup = false;
            this.popEmpNo.NameSize = 150;
            this.popEmpNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popEmpNo.Parameter = null;
            this.popEmpNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popEmpNo.PopupId = null;
            this.popEmpNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popEmpNo.QueryIfEnterKeyPressed = true;
            this.popEmpNo.RequiredField = false;
            this.popEmpNo.Size = new System.Drawing.Size(271, 21);
            this.popEmpNo.TabIndex = 11;
            this.popEmpNo.uniALT = "사원";
            this.popEmpNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popEmpNo.UseDynamicFormat = false;
            this.popEmpNo.ValueTextBoxName = null;
            this.popEmpNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popEmpNo_BeforePopupOpen);
            this.popEmpNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popEmpNo_AfterPopupClosed);
            this.popEmpNo.OnChange += new System.EventHandler(this.popEmpNo_OnChange);
            // 
            // object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef
            // 
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.Appearance = appearance12;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.AutoSize = false;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.Location = new System.Drawing.Point(121, 0);
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.LockedField = false;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.Margin = new System.Windows.Forms.Padding(0);
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.MaxLength = 50;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.Name = "object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef";
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.QueryIfEnterKeyPressed = true;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.ReadOnly = true;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.RequiredField = false;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.Size = new System.Drawing.Size(150, 21);
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.StyleSetName = "Lock";
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.TabIndex = 0;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.TabStop = false;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.uniALT = null;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.UseDynamicFormat = false;
            this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef.WordWrap = false;
            // 
            // object_daa6a960_b828_40b7_886e_ab7a6dbeecd0
            // 
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.Appearance = appearance13;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.AutoSize = false;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.Location = new System.Drawing.Point(0, 0);
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.LockedField = false;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.Margin = new System.Windows.Forms.Padding(0);
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.MaxLength = 13;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.Name = "object_daa6a960_b828_40b7_886e_ab7a6dbeecd0";
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.QueryIfEnterKeyPressed = true;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.RequiredField = false;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.Size = new System.Drawing.Size(100, 21);
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.StyleSetName = "Default";
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.TabIndex = 0;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.uniALT = null;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.UseDynamicFormat = false;
            this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0.WordWrap = false;
            // 
            // lblEmpNo
            // 
            appearance14.TextHAlignAsString = "Left";
            appearance14.TextVAlignAsString = "Middle";
            this.lblEmpNo.Appearance = appearance14;
            this.lblEmpNo.AutoPopupID = null;
            this.lblEmpNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmpNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblEmpNo.Location = new System.Drawing.Point(572, 29);
            this.lblEmpNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblEmpNo.Name = "lblEmpNo";
            this.lblEmpNo.Size = new System.Drawing.Size(141, 22);
            this.lblEmpNo.StyleSetName = "Default";
            this.lblEmpNo.TabIndex = 10;
            this.lblEmpNo.Text = "사원";
            this.lblEmpNo.UseMnemonic = false;
            // 
            // popDeptCd
            // 
            this.popDeptCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popDeptCd.AutoPopupCodeParameter = null;
            this.popDeptCd.AutoPopupID = null;
            this.popDeptCd.AutoPopupNameParameter = null;
            this.popDeptCd.CodeMaxLength = 15;
            this.popDeptCd.CodeName = "";
            this.popDeptCd.CodeSize = 100;
            this.popDeptCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popDeptCd.CodeTextBoxName = null;
            this.popDeptCd.CodeValue = "";
            this.popDeptCd.Controls.Add(this.uniTextBox_Name);
            this.popDeptCd.Controls.Add(this.uniTextBox_Code);
            this.popDeptCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popDeptCd.Location = new System.Drawing.Point(156, 30);
            this.popDeptCd.LockedField = false;
            this.popDeptCd.Margin = new System.Windows.Forms.Padding(0);
            this.popDeptCd.Name = "popDeptCd";
            this.popDeptCd.NameDisplay = true;
            this.popDeptCd.NameId = null;
            this.popDeptCd.NameMaxLength = 50;
            this.popDeptCd.NamePopup = false;
            this.popDeptCd.NameSize = 150;
            this.popDeptCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popDeptCd.Parameter = null;
            this.popDeptCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popDeptCd.PopupId = null;
            this.popDeptCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popDeptCd.QueryIfEnterKeyPressed = true;
            this.popDeptCd.RequiredField = false;
            this.popDeptCd.Size = new System.Drawing.Size(271, 21);
            this.popDeptCd.TabIndex = 9;
            this.popDeptCd.uniALT = "부서";
            this.popDeptCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popDeptCd.UseDynamicFormat = false;
            this.popDeptCd.ValueTextBoxName = null;
            this.popDeptCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDeptCd_BeforePopupOpen);
            this.popDeptCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDeptCd_AfterPopupClosed);
            this.popDeptCd.OnChange += new System.EventHandler(this.popDeptCd_OnChange);
            // 
            // uniTextBox_Name
            // 
            this.uniTextBox_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.Appearance = appearance15;
            this.uniTextBox_Name.AutoSize = false;
            this.uniTextBox_Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Name.Location = new System.Drawing.Point(121, 0);
            this.uniTextBox_Name.LockedField = false;
            this.uniTextBox_Name.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Name.MaxLength = 50;
            this.uniTextBox_Name.Name = "uniTextBox_Name";
            this.uniTextBox_Name.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Name.ReadOnly = true;
            this.uniTextBox_Name.RequiredField = false;
            this.uniTextBox_Name.Size = new System.Drawing.Size(150, 21);
            this.uniTextBox_Name.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Name.StyleSetName = "Lock";
            this.uniTextBox_Name.TabIndex = 0;
            this.uniTextBox_Name.TabStop = false;
            this.uniTextBox_Name.uniALT = null;
            this.uniTextBox_Name.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.uniTextBox_Name.UseDynamicFormat = false;
            this.uniTextBox_Name.WordWrap = false;
            // 
            // uniTextBox_Code
            // 
            this.uniTextBox_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.Appearance = appearance16;
            this.uniTextBox_Code.AutoSize = false;
            this.uniTextBox_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox_Code.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Code.Location = new System.Drawing.Point(0, 0);
            this.uniTextBox_Code.LockedField = false;
            this.uniTextBox_Code.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Code.MaxLength = 15;
            this.uniTextBox_Code.Name = "uniTextBox_Code";
            this.uniTextBox_Code.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Code.RequiredField = false;
            this.uniTextBox_Code.Size = new System.Drawing.Size(100, 21);
            this.uniTextBox_Code.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Code.StyleSetName = "Default";
            this.uniTextBox_Code.TabIndex = 0;
            this.uniTextBox_Code.uniALT = null;
            this.uniTextBox_Code.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox_Code.UseDynamicFormat = false;
            this.uniTextBox_Code.WordWrap = false;
            // 
            // lblDeptCd
            // 
            appearance17.TextHAlignAsString = "Left";
            appearance17.TextVAlignAsString = "Middle";
            this.lblDeptCd.Appearance = appearance17;
            this.lblDeptCd.AutoPopupID = null;
            this.lblDeptCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDeptCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDeptCd.Location = new System.Drawing.Point(15, 29);
            this.lblDeptCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDeptCd.Name = "lblDeptCd";
            this.lblDeptCd.Size = new System.Drawing.Size(141, 22);
            this.lblDeptCd.StyleSetName = "Default";
            this.lblDeptCd.TabIndex = 8;
            this.lblDeptCd.Text = "부서";
            this.lblDeptCd.UseMnemonic = false;
            // 
            // dtDate
            // 
            this.dtDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtDate.Controls.Add(this.uniDateTimeF);
            this.dtDate.Controls.Add(this.uniDateTimeT);
            this.dtDate.Controls.Add(this.uniLabel1);
            this.dtDate.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.YYYYMMDD;
            this.dtDate.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtDate.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtDate.Location = new System.Drawing.Point(156, 7);
            this.dtDate.Margin = new System.Windows.Forms.Padding(0);
            this.dtDate.Name = "dtDate";
            this.dtDate.Size = new System.Drawing.Size(225, 21);
            this.dtDate.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.dtDate.TabIndex = 5;
            this.dtDate.uniFromALT = "조회시간(시작)";
            this.dtDate.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtDate.uniTabSameValue = false;
            this.dtDate.uniToALT = "조회시간(종료)";
            this.dtDate.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // uniDateTimeF
            // 
            this.uniDateTimeF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance18.TextHAlignAsString = "Center";
            this.uniDateTimeF.Appearance = appearance18;
            this.uniDateTimeF.AutoSize = false;
            this.uniDateTimeF.DateTime = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.uniDateTimeF.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.YYYYMMDD;
            this.uniDateTimeF.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.uniDateTimeF.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniDateTimeF.Location = new System.Drawing.Point(0, 2);
            this.uniDateTimeF.LockedField = false;
            this.uniDateTimeF.Margin = new System.Windows.Forms.Padding(0);
            this.uniDateTimeF.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.uniDateTimeF.Name = "uniDateTimeF";
            this.uniDateTimeF.QueryIfEnterKeyPressed = true;
            this.uniDateTimeF.RequiredField = false;
            this.uniDateTimeF.Size = new System.Drawing.Size(100, 21);
            this.uniDateTimeF.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.uniDateTimeF.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.uniDateTimeF.StyleSetName = "Default";
            this.uniDateTimeF.TabIndex = 0;
            this.uniDateTimeF.uniALT = "조회시간(시작)";
            this.uniDateTimeF.uniValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.uniDateTimeF.Value = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // uniDateTimeT
            // 
            this.uniDateTimeT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance19.TextHAlignAsString = "Center";
            this.uniDateTimeT.Appearance = appearance19;
            this.uniDateTimeT.AutoSize = false;
            this.uniDateTimeT.DateTime = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.uniDateTimeT.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.YYYYMMDD;
            this.uniDateTimeT.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.uniDateTimeT.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniDateTimeT.Location = new System.Drawing.Point(125, 2);
            this.uniDateTimeT.LockedField = false;
            this.uniDateTimeT.Margin = new System.Windows.Forms.Padding(0);
            this.uniDateTimeT.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.uniDateTimeT.Name = "uniDateTimeT";
            this.uniDateTimeT.QueryIfEnterKeyPressed = true;
            this.uniDateTimeT.RequiredField = false;
            this.uniDateTimeT.Size = new System.Drawing.Size(100, 21);
            this.uniDateTimeT.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.uniDateTimeT.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.uniDateTimeT.StyleSetName = "Default";
            this.uniDateTimeT.TabIndex = 1;
            this.uniDateTimeT.uniALT = "조회시간(종료)";
            this.uniDateTimeT.uniValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.uniDateTimeT.Value = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // uniLabel1
            // 
            appearance20.TextHAlignAsString = "Center";
            appearance20.TextVAlignAsString = "Middle";
            this.uniLabel1.Appearance = appearance20;
            this.uniLabel1.AutoPopupID = null;
            appearance21.TextHAlignAsString = "Center";
            appearance21.TextVAlignAsString = "Middle";
            this.uniLabel1.HotTrackAppearance = appearance21;
            this.uniLabel1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Default_NoStyle;
            this.uniLabel1.Location = new System.Drawing.Point(104, 2);
            this.uniLabel1.Margin = new System.Windows.Forms.Padding(0);
            this.uniLabel1.Name = "uniLabel1";
            this.uniLabel1.Size = new System.Drawing.Size(21, 21);
            this.uniLabel1.StyleSetName = "uniLabel_NoStyle";
            this.uniLabel1.TabIndex = 2;
            this.uniLabel1.Text = "~";
            this.uniLabel1.UseAppStyling = false;
            this.uniLabel1.UseMnemonic = false;
            // 
            // lblDate
            // 
            appearance22.TextHAlignAsString = "Left";
            appearance22.TextVAlignAsString = "Middle";
            this.lblDate.Appearance = appearance22;
            this.lblDate.AutoPopupID = null;
            this.lblDate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDate.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDate.Location = new System.Drawing.Point(15, 6);
            this.lblDate.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(141, 22);
            this.lblDate.StyleSetName = "Default";
            this.lblDate.TabIndex = 1;
            this.lblDate.Text = "조회기간";
            this.lblDate.UseMnemonic = false;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.Controls.Add(this.lblRefData, 1, 0);
            this.uniTBL_MainReference.DefaultRowSize = 23;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(1115, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblRefData
            // 
            appearance23.TextHAlignAsString = "Left";
            appearance23.TextVAlignAsString = "Middle";
            this.lblRefData.Appearance = appearance23;
            this.lblRefData.AutoPopupID = null;
            this.uniTBL_MainReference.SetColumnSpan(this.lblRefData, 2);
            this.lblRefData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRefData.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblRefData.Location = new System.Drawing.Point(915, 3);
            this.lblRefData.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblRefData.Name = "lblRefData";
            this.lblRefData.Size = new System.Drawing.Size(200, 15);
            this.lblRefData.StyleSetName = "uniLabel_Reference";
            this.lblRefData.TabIndex = 0;
            this.lblRefData.Text = "RF DATA 불러오기";
            this.lblRefData.UseMnemonic = false;
            this.lblRefData.Click += new System.EventHandler(this.lblRefData_Click);
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 5;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.DefaultRowSize = 23;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 601);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(1115, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(1126, 650);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.popEmpNo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_daa6a960_b828_40b7_886e_ab7a6dbeecd0)).EndInit();
            this.popDeptCd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).EndInit();
            this.dtDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTimeF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTimeT)).EndInit();
            this.uniTBL_MainReference.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popEmpNo;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_efa6af5c_d1cd_4a9e_9352_fad6ff5137ef;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_daa6a960_b828_40b7_886e_ab7a6dbeecd0;
        private uniERP.AppFramework.UI.Controls.uniLabel lblEmpNo;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popDeptCd;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Name;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Code;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDeptCd;
        private uniERP.AppFramework.UI.Controls.uniDateTerm dtDate;
        private uniERP.AppFramework.UI.Controls.uniDateTime uniDateTimeF;
        private uniERP.AppFramework.UI.Controls.uniDateTime uniDateTimeT;
        private uniERP.AppFramework.UI.Controls.uniLabel uniLabel1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDate;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRefData;

    }
}
