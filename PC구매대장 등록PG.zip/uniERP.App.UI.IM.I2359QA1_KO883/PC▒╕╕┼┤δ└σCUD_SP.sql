

--���̺� ���� ����� ����
--  CREATE TYPE UTP_I2359QA1_KO883 AS TABLE
--(
--    EMP_NO   NVARCHAR(26) NULL                       
--  , EMP_NM   NVARCHAR(26) NULL
--  , PC_NAME  NVARCHAR(40) NULL
--  , Pur_Day  NVARCHAR(40) NULL           
--  , TV_1     NVARCHAR(40) NULL
--  , TV_2     NVARCHAR(40) NULL
--  , PRICE_1  NVARCHAR(40) NULL
--  , PRICE_2  NVARCHAR(40) NULL
--  , PRICE_3  NVARCHAR(40) NULL
--  , CUD_CHAR NVARCHAR(2)  NULL          
--  , ROW_NUM  INT          NULL    
  
--); 
          
CREATE PROCEDURE [dbo].[USP_I2359QA1_KO883_CUD]            
(             
  @TBL_DATA   UTP_I2359QA1_KO883 READONLY            
, @USER_ID    NVARCHAR(13)            
, @MSG_CD     NVARCHAR(06)  OUTPUT            
, @MESSAGE    NVARCHAR(200)  OUTPUT            
, @ERR_POS    INT     OUTPUT            
)            
AS            
            
BEGIN            
 SET NOCOUNT ON            
            
 DECLARE                  
    @EMP_NO   NVARCHAR(26)                        
  , @EMP_NM   NVARCHAR(26) 
  , @PC_NAME  NVARCHAR(40) 
  , @Pur_Day  NVARCHAR(40)            
  , @TV_1     NVARCHAR(40) 
  , @TV_2     NVARCHAR(40) 
  , @PRICE_1  NVARCHAR(40) 
  , @PRICE_2  NVARCHAR(40) 
  , @PRICE_3  NVARCHAR(40) 
  , @CUD_CHAR NVARCHAR(2)            
  , @ROW_NUM  INT            
  , @ERROR_NUMBER INT           
  
            
  BEGIN TRY            
  BEGIN TRANSACTION            
            
             
  DECLARE CUR_I2359QA1_KO883 CURSOR LOCAL FOR            
            
  SELECT            
    EMP_NO                     
  , EMP_NM   
  , PC_NAME  
  , Pur_Day        
  , TV_1     
  , TV_2     
  , PRICE_1  
  , PRICE_2  
  , PRICE_3  
  , CUD_CHAR      
  , ROW_NUM  
   FROM @TBL_DATA            
            
  OPEN CUR_I2359QA1_KO883             
  FETCH NEXT FROM CUR_I2359QA1_KO883            
  INTO             
    @EMP_NO                          
  , @EMP_NM   
  , @PC_NAME  
  , @Pur_Day             
  , @TV_1     
  , @TV_2     
  , @PRICE_1  
  , @PRICE_2  
  , @PRICE_3  
  , @CUD_CHAR           
  , @ROW_NUM  
  
                  
  WHILE(@@FETCH_STATUS=0)            
  BEGIN            
   SET @ERR_POS = @ROW_NUM            
            
  IF (@CUD_CHAR = 'C')            
  BEGIN            
     
    INSERT INTO PC_Purchase            
    (            
     EMP_NO, EMP_NM, PC_NAME, Pur_Day, TV_1, TV_2, PRICE_1, PRICE_2, PRICE_3, ISRT_DT, UPDT_EMP_NO, UPDT_DT
                
    )            
    VALUES            
    (            
      @EMP_NO, @EMP_NM, @PC_NAME, @Pur_Day, @TV_1, @TV_2, @PRICE_1, @PRICE_2, @PRICE_3, GETDATE(), @USER_ID, GETDATE()
                
    )            
  END            
  ELSE IF (@CUD_CHAR = 'U')   
   --IF (@CUD_CHAR = 'U')               
  BEGIN            
    UPDATE PC_Purchase            
    SET                  
     PC_NAME = @PC_NAME
	,Pur_Day = @Pur_Day
	,TV_1 = @TV_1
	,TV_2 = @TV_2
	,PRICE_1 = @PRICE_1
	,PRICE_2 = @PRICE_2
	,PRICE_3 = @PRICE_3          
    ,UPDT_EMP_NO = @USER_ID            
    ,UPDT_DT   = GETDATE()            
    WHERE            
       EMP_NO = @EMP_NO            
                
            
  END            
  ELSE IF (@CUD_CHAR = 'D')            
  BEGIN            
                
    DELETE FROM PC_Purchase             
    WHERE            
      EMP_NO = @EMP_NO         
    
            
  END            
        
     
             
  FETCH NEXT FROM CUR_I2359QA1_KO883            
  INTO             
    @EMP_NO                          
  , @EMP_NM   
  , @PC_NAME  
  , @Pur_Day             
  , @TV_1     
  , @TV_2     
  , @PRICE_1  
  , @PRICE_2  
  , @PRICE_3  
  , @CUD_CHAR           
  , @ROW_NUM          
            
            
  END --WHILE END            
             
            
 CLOSE CUR_I2359QA1_KO883            
 DEALLOCATE CUR_I2359QA1_KO883                       
            
 END TRY            
 BEGIN CATCH            
             
 SET @ERROR_NUMBER = ERROR_NUMBER()            
              
  IF @ERROR_NUMBER = 2627  --%1! ���� ���� '%2!'��(��) �����߽��ϴ�. ��ü '%3!'�� �ߺ� Ű�� ������ �� �����ϴ�. �ߺ� Ű ���� %4!�Դϴ�.            
   BEGIN            
    SET @MSG_CD   = '970001' -- %1 ��(��) �̹� �����մϴ�.               
   END            
            
  ELSE IF @ERROR_NUMBER = 547  -- %1! ���� %2! ���� ���� "%3!"��(��) �浹�߽��ϴ�. �����ͺ��̽� "%4!", ���̺� "%5!"%6!%7!%8!���� �浹�� �߻��߽��ϴ�.            
   BEGIN            
    SET @MSG_CD   = '971000' -- %1 ��(��) �����ϰ� �ִ� �����Ͱ� �ֽ��ϴ�. �۾��� ������ �� �����ϴ�.                 
   END            
            
  ELSE IF @ERROR_NUMBER = 1205  -- Ʈ�����(���μ��� ID %1!)�� %2! ���ҽ����� �ٸ� ���μ������� ���� ���°� �߻��Ͽ� ������ �����Ǿ����ϴ�. Ʈ������� �ٽ� �����Ͻʽÿ�.            
   BEGIN            
    SET @MSG_CD   = '122918' -- %1 ���忡 �����߽��ϴ�.                    
   END            
            
  ELSE            
   SET @MESSAGE  = ERROR_MESSAGE()            
            
  GOTO __ERROR            
 END CATCH            
            
 IF @@TRANCOUNT > 0 COMMIT TRANSACTION            
 RETURN 1            
            
 __ERROR:            
 IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION            
 RETURN -1            
END 