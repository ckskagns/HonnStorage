--exec USP_I2359QA1_KO883 @EMP_NO=N'',@Pur_FROM=N'1900-01-01',@Pur_TO=N'2999-12-31',@PC_NAME=N'',@TV_NAME=N''

ALTER PROCEDURE [dbo].[USP_I2359QA1_KO883]            
 (                        
	  @EMP_NO    NVARCHAR(26) --���                
    , @Pur_From  NVARCHAR(10) --������ ����
	, @Pur_To    NVARCHAR(10) --������ ����                     
	, @PC_NAME   NVARCHAR(40) --PC��
	, @TV_NAME   NVARCHAR(40) --����� ��
 ) AS                      
                
 BEGIN                                          
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                    
                                       
SET NOCOUNT ON                    
             
    
select 
    A.EMP_NO,
	B.EMP_NM,
	B.PC_NAME,
	B.PRICE_1,
	B.TV_1,
	B.PRICE_2,
	B.TV_2,
	B.PRICE_3,
	B.Pur_Day

 from HAA010T A(NOLOCK)
 join PC_Purchase B(NOLOCK) on A.EMP_NO = B.EMP_NO  
 where 
 (@EMP_NO ='' or A.EMP_NO = @EMP_NO ) 
 and B.Pur_Day between ISNULL(@Pur_From,'1900-01-01') and ISNULL(@Pur_To,'2999-12-31')
 and (@PC_NAME='' or (B.PC_NAME like '%'+ISNULL(@PC_NAME,'')+'%') )
 and (@TV_NAME='' or (B.TV_1 like '%'+@TV_NAME+'%') or (B.TV_2 like '%'+@TV_NAME+'%') )
  order by   A.EMP_NO    
            
 END 
