﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.HR.H4007M9_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance62 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance63 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance64 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance65 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance66 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance68 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance69 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance78 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance79 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance80 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance81 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance70 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance71 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance72 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance73 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance74 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance82 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance83 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance84 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance85 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance86 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance87 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance75 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance76 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance77 = new Infragistics.Win.Appearance();
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.popEmpNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.popDeptCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniDateTime2 = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.uniLabel4 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniLabel3 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniLabel1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDeptCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtPerFromTo = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.uniDateTimeF = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.uniDateTimeT = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.object_31d70455_9565_4632_a8e2_2b122587e87b = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popFlexSys = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTextBox_Name = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTextBox_Code = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblEmpNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniLabel2 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniDateTime1_bak = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnConfirm = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.uniDateTime1 = new uniERP.AppFramework.UI.Controls.uniMaskedEdit(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            this.uniTBL_MainCondition.SuspendLayout();
            this.popEmpNo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b)).BeginInit();
            this.popDeptCd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_a5d65465_24ca_4a0f_b577_82820a1da092)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTime2)).BeginInit();
            this.dtPerFromTo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTimeF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTimeT)).BeginInit();
            this.popFlexSys.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTime1_bak)).BeginInit();
            this.uniTBL_MainBatch.SuspendLayout();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.PathInfo;
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance59.BackColor = System.Drawing.SystemColors.Window;
            appearance59.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance59;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance60.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance60.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance60.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance60;
            appearance61.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance61;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance62.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance62.BackColor2 = System.Drawing.SystemColors.Control;
            appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance62.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance62;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance63.BackColor = System.Drawing.SystemColors.Window;
            appearance63.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance63;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance64.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance64;
            appearance65.BorderColor = System.Drawing.Color.Silver;
            appearance65.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance65;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance66.BackColor = System.Drawing.SystemColors.Control;
            appearance66.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance66.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance66.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance66;
            appearance67.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance67;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance68.BackColor = System.Drawing.SystemColors.Window;
            appearance68.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance68;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance69.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance69;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(936, 345);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.uniGrid1_BeforePopupOpen);
            this.uniGrid1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.uniGrid1_AfterPopupClosed);
            this.uniGrid1.AfterCellUpdate += new Infragistics.Win.UltraWinGrid.CellEventHandler(this.uniGrid1_AfterCellUpdate);
            this.uniGrid1.AfterExitEditMode += new System.EventHandler(this.uniGrid1_AfterExitEditMode);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 12);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 9;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 113F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(936, 593);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            this.uniTBL_OuterMost.Paint += new System.Windows.Forms.PaintEventHandler(this.uniTBL_OuterMost_Paint);
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 176);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 2;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(936, 365);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 0;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.popEmpNo, 4, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popDeptCd, 4, 0);
            this.uniTBL_MainCondition.Controls.Add(this.uniDateTime2, 1, 3);
            this.uniTBL_MainCondition.Controls.Add(this.uniLabel4, 0, 3);
            this.uniTBL_MainCondition.Controls.Add(this.uniLabel3, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.uniLabel1, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblDeptCd, 2, 0);
            this.uniTBL_MainCondition.Controls.Add(this.dtPerFromTo, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popFlexSys, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblEmpNo, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.uniLabel2, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.uniDateTime1_bak, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.textBox1, 3, 2);
            this.uniTBL_MainCondition.Controls.Add(this.uniDateTime1, 3, 3);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 4;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(936, 113);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // popEmpNo
            // 
            this.popEmpNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popEmpNo.AutoPopupCodeParameter = null;
            this.popEmpNo.AutoPopupID = null;
            this.popEmpNo.AutoPopupNameParameter = null;
            this.popEmpNo.CodeMaxLength = 13;
            this.popEmpNo.CodeName = "";
            this.popEmpNo.CodeSize = 100;
            this.popEmpNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popEmpNo.CodeTextBoxName = null;
            this.popEmpNo.CodeValue = "";
            this.popEmpNo.Controls.Add(this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce);
            this.popEmpNo.Controls.Add(this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b);
            this.popEmpNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popEmpNo.Location = new System.Drawing.Point(598, 34);
            this.popEmpNo.LockedField = false;
            this.popEmpNo.Margin = new System.Windows.Forms.Padding(0);
            this.popEmpNo.Name = "popEmpNo";
            this.popEmpNo.NameDisplay = true;
            this.popEmpNo.NameId = null;
            this.popEmpNo.NameMaxLength = 50;
            this.popEmpNo.NamePopup = false;
            this.popEmpNo.NameSize = 150;
            this.popEmpNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popEmpNo.Parameter = null;
            this.popEmpNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popEmpNo.PopupId = null;
            this.popEmpNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popEmpNo.QueryIfEnterKeyPressed = true;
            this.popEmpNo.RequiredField = false;
            this.popEmpNo.Size = new System.Drawing.Size(271, 21);
            this.popEmpNo.TabIndex = 20;
            this.popEmpNo.uniALT = "Emp No";
            this.popEmpNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popEmpNo.UseDynamicFormat = false;
            this.popEmpNo.ValueTextBoxName = null;
            this.popEmpNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popEmpNo_BeforePopupOpen);
            this.popEmpNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popEmpNo_AfterPopupClosed);
            this.popEmpNo.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popEmpNo_OnExitEditCode);
            // 
            // object_e672e9b7_7026_49fb_953a_0c55d47b23ce
            // 
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance78.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.Appearance = appearance78;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.AutoSize = false;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.Location = new System.Drawing.Point(121, 0);
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.LockedField = false;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.Margin = new System.Windows.Forms.Padding(0);
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.MaxLength = 50;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.Name = "object_e672e9b7_7026_49fb_953a_0c55d47b23ce";
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.QueryIfEnterKeyPressed = true;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.ReadOnly = true;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.RequiredField = false;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.Size = new System.Drawing.Size(150, 21);
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.StyleSetName = "Lock";
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.TabIndex = 0;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.TabStop = false;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.uniALT = null;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.UseDynamicFormat = false;
            this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce.WordWrap = false;
            // 
            // object_62cf2b38_78bd_4bef_b5aa_1443b014543b
            // 
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance79.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.Appearance = appearance79;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.AutoSize = false;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.Location = new System.Drawing.Point(0, 0);
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.LockedField = false;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.Margin = new System.Windows.Forms.Padding(0);
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.MaxLength = 13;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.Name = "object_62cf2b38_78bd_4bef_b5aa_1443b014543b";
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.QueryIfEnterKeyPressed = true;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.RequiredField = false;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.Size = new System.Drawing.Size(100, 21);
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.StyleSetName = "Default";
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.TabIndex = 0;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.uniALT = null;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.UseDynamicFormat = false;
            this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b.WordWrap = false;
            // 
            // popDeptCd
            // 
            this.popDeptCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popDeptCd.AutoPopupCodeParameter = null;
            this.popDeptCd.AutoPopupID = null;
            this.popDeptCd.AutoPopupNameParameter = null;
            this.popDeptCd.CodeMaxLength = 10;
            this.popDeptCd.CodeName = "";
            this.popDeptCd.CodeSize = 100;
            this.popDeptCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDeptCd.CodeTextBoxName = null;
            this.popDeptCd.CodeValue = "";
            this.popDeptCd.Controls.Add(this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044);
            this.popDeptCd.Controls.Add(this.object_a5d65465_24ca_4a0f_b577_82820a1da092);
            this.popDeptCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popDeptCd.Location = new System.Drawing.Point(598, 9);
            this.popDeptCd.LockedField = false;
            this.popDeptCd.Margin = new System.Windows.Forms.Padding(0);
            this.popDeptCd.Name = "popDeptCd";
            this.popDeptCd.NameDisplay = true;
            this.popDeptCd.NameId = null;
            this.popDeptCd.NameMaxLength = 50;
            this.popDeptCd.NamePopup = false;
            this.popDeptCd.NameSize = 150;
            this.popDeptCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDeptCd.Parameter = null;
            this.popDeptCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popDeptCd.PopupId = null;
            this.popDeptCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popDeptCd.QueryIfEnterKeyPressed = true;
            this.popDeptCd.RequiredField = false;
            this.popDeptCd.Size = new System.Drawing.Size(271, 21);
            this.popDeptCd.TabIndex = 19;
            this.popDeptCd.uniALT = "Dept";
            this.popDeptCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popDeptCd.UseDynamicFormat = false;
            this.popDeptCd.ValueTextBoxName = null;
            this.popDeptCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDeptCd_BeforePopupOpen);
            this.popDeptCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDeptCd_AfterPopupClosed);
            this.popDeptCd.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popDeptCd_OnExitEditCode);
            // 
            // object_d9fcbe89_f0d3_4187_9be7_328ecada0044
            // 
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Appearance = appearance80;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.AutoSize = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Location = new System.Drawing.Point(121, 0);
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.LockedField = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Margin = new System.Windows.Forms.Padding(0);
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.MaxLength = 50;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Name = "object_d9fcbe89_f0d3_4187_9be7_328ecada0044";
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.QueryIfEnterKeyPressed = true;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.ReadOnly = true;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.RequiredField = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Size = new System.Drawing.Size(150, 21);
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.StyleSetName = "Lock";
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.TabIndex = 0;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.TabStop = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.uniALT = null;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.UseDynamicFormat = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.WordWrap = false;
            // 
            // object_a5d65465_24ca_4a0f_b577_82820a1da092
            // 
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Appearance = appearance81;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.AutoSize = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Location = new System.Drawing.Point(0, 0);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.LockedField = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Margin = new System.Windows.Forms.Padding(0);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.MaxLength = 10;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Name = "object_a5d65465_24ca_4a0f_b577_82820a1da092";
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.QueryIfEnterKeyPressed = true;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.RequiredField = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Size = new System.Drawing.Size(100, 21);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.StyleSetName = "Default";
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.TabIndex = 0;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.uniALT = null;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.UseDynamicFormat = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.WordWrap = false;
            // 
            // uniDateTime2
            // 
            this.uniDateTime2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance70.TextHAlignAsString = "Center";
            this.uniDateTime2.Appearance = appearance70;
            this.uniDateTime2.DateTime = new System.DateTime(2021, 2, 10, 0, 0, 0, 0);
            this.uniDateTime2.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.uniDateTime2.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.uniDateTime2.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniDateTime2.Location = new System.Drawing.Point(131, 81);
            this.uniDateTime2.LockedField = false;
            this.uniDateTime2.Margin = new System.Windows.Forms.Padding(0);
            this.uniDateTime2.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.uniDateTime2.Name = "uniDateTime2";
            this.uniDateTime2.QueryIfEnterKeyPressed = true;
            this.uniDateTime2.RequiredField = false;
            this.uniDateTime2.Size = new System.Drawing.Size(100, 24);
            this.uniDateTime2.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.uniDateTime2.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.HHMMSS;
            this.uniDateTime2.StyleSetName = "Default";
            this.uniDateTime2.TabIndex = 18;
            this.uniDateTime2.uniALT = null;
            this.uniDateTime2.uniValue = new System.DateTime(2021, 2, 10, 0, 0, 0, 0);
            this.uniDateTime2.Value = new System.DateTime(2021, 2, 10, 0, 0, 0, 0);
            // 
            // uniLabel4
            // 
            appearance71.TextHAlignAsString = "Left";
            appearance71.TextVAlignAsString = "Middle";
            this.uniLabel4.Appearance = appearance71;
            this.uniLabel4.AutoPopupID = null;
            this.uniLabel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniLabel4.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.uniLabel4.Location = new System.Drawing.Point(15, 81);
            this.uniLabel4.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.uniLabel4.Name = "uniLabel4";
            this.uniLabel4.Size = new System.Drawing.Size(116, 24);
            this.uniLabel4.StyleSetName = "Default";
            this.uniLabel4.TabIndex = 15;
            this.uniLabel4.Text = "퇴근시간";
            this.uniLabel4.UseMnemonic = false;
            // 
            // uniLabel3
            // 
            appearance72.TextHAlignAsString = "Left";
            appearance72.TextVAlignAsString = "Middle";
            this.uniLabel3.Appearance = appearance72;
            this.uniLabel3.AutoPopupID = null;
            this.uniLabel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniLabel3.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.uniLabel3.Location = new System.Drawing.Point(15, 56);
            this.uniLabel3.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.uniLabel3.Name = "uniLabel3";
            this.uniLabel3.Size = new System.Drawing.Size(116, 24);
            this.uniLabel3.StyleSetName = "Default";
            this.uniLabel3.TabIndex = 14;
            this.uniLabel3.Text = "출근시간";
            this.uniLabel3.UseMnemonic = false;
            // 
            // uniLabel1
            // 
            appearance73.TextHAlignAsString = "Left";
            appearance73.TextVAlignAsString = "Middle";
            this.uniLabel1.Appearance = appearance73;
            this.uniLabel1.AutoPopupID = null;
            this.uniLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniLabel1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.uniLabel1.Location = new System.Drawing.Point(15, 31);
            this.uniLabel1.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.uniLabel1.Name = "uniLabel1";
            this.uniLabel1.Size = new System.Drawing.Size(116, 24);
            this.uniLabel1.StyleSetName = "Default";
            this.uniLabel1.TabIndex = 10;
            this.uniLabel1.Text = "기준일";
            this.uniLabel1.UseMnemonic = false;
            // 
            // lblDeptCd
            // 
            appearance74.TextHAlignAsString = "Left";
            appearance74.TextVAlignAsString = "Middle";
            this.lblDeptCd.Appearance = appearance74;
            this.lblDeptCd.AutoPopupID = null;
            this.lblDeptCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDeptCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDeptCd.Location = new System.Drawing.Point(482, 6);
            this.lblDeptCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDeptCd.Name = "lblDeptCd";
            this.lblDeptCd.Size = new System.Drawing.Size(116, 24);
            this.lblDeptCd.StyleSetName = "Default";
            this.lblDeptCd.TabIndex = 4;
            this.lblDeptCd.Text = "부서";
            this.lblDeptCd.UseMnemonic = false;
            // 
            // dtPerFromTo
            // 
            this.dtPerFromTo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtPerFromTo.Controls.Add(this.uniDateTimeF);
            this.dtPerFromTo.Controls.Add(this.uniDateTimeT);
            this.dtPerFromTo.Controls.Add(this.object_31d70455_9565_4632_a8e2_2b122587e87b);
            this.dtPerFromTo.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.YYYY_MM_DD;
            this.dtPerFromTo.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtPerFromTo.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtPerFromTo.Location = new System.Drawing.Point(131, 34);
            this.dtPerFromTo.Margin = new System.Windows.Forms.Padding(0);
            this.dtPerFromTo.Name = "dtPerFromTo";
            this.dtPerFromTo.Size = new System.Drawing.Size(225, 21);
            this.dtPerFromTo.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtPerFromTo.TabIndex = 11;
            this.dtPerFromTo.uniFromALT = "Project Period(FROM)";
            this.dtPerFromTo.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtPerFromTo.uniTabSameValue = false;
            this.dtPerFromTo.uniToALT = "Project Period(TO)";
            this.dtPerFromTo.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // uniDateTimeF
            // 
            this.uniDateTimeF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance82.TextHAlignAsString = "Center";
            this.uniDateTimeF.Appearance = appearance82;
            this.uniDateTimeF.AutoSize = false;
            this.uniDateTimeF.DateTime = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.uniDateTimeF.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.uniDateTimeF.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.uniDateTimeF.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.uniDateTimeF.Location = new System.Drawing.Point(0, 2);
            this.uniDateTimeF.LockedField = false;
            this.uniDateTimeF.Margin = new System.Windows.Forms.Padding(0);
            this.uniDateTimeF.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.uniDateTimeF.Name = "uniDateTimeF";
            this.uniDateTimeF.QueryIfEnterKeyPressed = true;
            this.uniDateTimeF.RequiredField = false;
            this.uniDateTimeF.Size = new System.Drawing.Size(100, 21);
            this.uniDateTimeF.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.uniDateTimeF.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.uniDateTimeF.StyleSetName = "Default";
            this.uniDateTimeF.TabIndex = 0;
            this.uniDateTimeF.uniALT = "Project Period(FROM)";
            this.uniDateTimeF.uniValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.uniDateTimeF.Value = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // uniDateTimeT
            // 
            this.uniDateTimeT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance83.TextHAlignAsString = "Center";
            this.uniDateTimeT.Appearance = appearance83;
            this.uniDateTimeT.AutoSize = false;
            this.uniDateTimeT.DateTime = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.uniDateTimeT.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.uniDateTimeT.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.uniDateTimeT.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.uniDateTimeT.Location = new System.Drawing.Point(125, 2);
            this.uniDateTimeT.LockedField = false;
            this.uniDateTimeT.Margin = new System.Windows.Forms.Padding(0);
            this.uniDateTimeT.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.uniDateTimeT.Name = "uniDateTimeT";
            this.uniDateTimeT.QueryIfEnterKeyPressed = true;
            this.uniDateTimeT.RequiredField = false;
            this.uniDateTimeT.Size = new System.Drawing.Size(100, 21);
            this.uniDateTimeT.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.uniDateTimeT.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.uniDateTimeT.StyleSetName = "Default";
            this.uniDateTimeT.TabIndex = 1;
            this.uniDateTimeT.uniALT = "Project Period(TO)";
            this.uniDateTimeT.uniValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.uniDateTimeT.Value = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // object_31d70455_9565_4632_a8e2_2b122587e87b
            // 
            appearance84.TextHAlignAsString = "Center";
            appearance84.TextVAlignAsString = "Middle";
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.Appearance = appearance84;
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.AutoPopupID = null;
            appearance85.TextHAlignAsString = "Center";
            appearance85.TextVAlignAsString = "Middle";
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.HotTrackAppearance = appearance85;
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Default_NoStyle;
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.Location = new System.Drawing.Point(104, 2);
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.Margin = new System.Windows.Forms.Padding(0);
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.Name = "object_31d70455_9565_4632_a8e2_2b122587e87b";
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.Size = new System.Drawing.Size(21, 21);
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.StyleSetName = "uniLabel_NoStyle";
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.TabIndex = 2;
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.Text = "~";
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.UseAppStyling = false;
            this.object_31d70455_9565_4632_a8e2_2b122587e87b.UseMnemonic = false;
            // 
            // popFlexSys
            // 
            this.popFlexSys.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popFlexSys.AutoPopupCodeParameter = null;
            this.popFlexSys.AutoPopupID = null;
            this.popFlexSys.AutoPopupNameParameter = null;
            this.popFlexSys.CodeMaxLength = 13;
            this.popFlexSys.CodeName = "";
            this.popFlexSys.CodeSize = 100;
            this.popFlexSys.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popFlexSys.CodeTextBoxName = null;
            this.popFlexSys.CodeValue = "";
            this.popFlexSys.Controls.Add(this.uniTextBox_Name);
            this.popFlexSys.Controls.Add(this.uniTextBox_Code);
            this.popFlexSys.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popFlexSys.Location = new System.Drawing.Point(131, 9);
            this.popFlexSys.LockedField = false;
            this.popFlexSys.Margin = new System.Windows.Forms.Padding(0);
            this.popFlexSys.Name = "popFlexSys";
            this.popFlexSys.NameDisplay = true;
            this.popFlexSys.NameId = null;
            this.popFlexSys.NameMaxLength = 50;
            this.popFlexSys.NamePopup = false;
            this.popFlexSys.NameSize = 150;
            this.popFlexSys.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popFlexSys.Parameter = null;
            this.popFlexSys.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popFlexSys.PopupId = null;
            this.popFlexSys.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popFlexSys.QueryIfEnterKeyPressed = true;
            this.popFlexSys.RequiredField = false;
            this.popFlexSys.Size = new System.Drawing.Size(271, 21);
            this.popFlexSys.TabIndex = 12;
            this.popFlexSys.uniALT = "근무구분";
            this.popFlexSys.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popFlexSys.UseDynamicFormat = false;
            this.popFlexSys.ValueTextBoxName = null;
            this.popFlexSys.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popFlexSys_BeforePopupOpen);
            this.popFlexSys.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popFlexSys_AfterPopupClosed);
            // 
            // uniTextBox_Name
            // 
            this.uniTextBox_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance86.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.Appearance = appearance86;
            this.uniTextBox_Name.AutoSize = false;
            this.uniTextBox_Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Name.Location = new System.Drawing.Point(121, 0);
            this.uniTextBox_Name.LockedField = false;
            this.uniTextBox_Name.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Name.MaxLength = 50;
            this.uniTextBox_Name.Name = "uniTextBox_Name";
            this.uniTextBox_Name.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Name.ReadOnly = true;
            this.uniTextBox_Name.RequiredField = false;
            this.uniTextBox_Name.Size = new System.Drawing.Size(150, 21);
            this.uniTextBox_Name.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Name.StyleSetName = "Lock";
            this.uniTextBox_Name.TabIndex = 0;
            this.uniTextBox_Name.TabStop = false;
            this.uniTextBox_Name.uniALT = null;
            this.uniTextBox_Name.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.uniTextBox_Name.UseDynamicFormat = false;
            this.uniTextBox_Name.WordWrap = false;
            // 
            // uniTextBox_Code
            // 
            this.uniTextBox_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.Appearance = appearance87;
            this.uniTextBox_Code.AutoSize = false;
            this.uniTextBox_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox_Code.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Code.Location = new System.Drawing.Point(0, 0);
            this.uniTextBox_Code.LockedField = false;
            this.uniTextBox_Code.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Code.MaxLength = 13;
            this.uniTextBox_Code.Name = "uniTextBox_Code";
            this.uniTextBox_Code.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Code.RequiredField = false;
            this.uniTextBox_Code.Size = new System.Drawing.Size(100, 21);
            this.uniTextBox_Code.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Code.StyleSetName = "Default";
            this.uniTextBox_Code.TabIndex = 0;
            this.uniTextBox_Code.uniALT = null;
            this.uniTextBox_Code.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox_Code.UseDynamicFormat = false;
            this.uniTextBox_Code.WordWrap = false;
            // 
            // lblEmpNo
            // 
            appearance75.TextHAlignAsString = "Left";
            appearance75.TextVAlignAsString = "Middle";
            this.lblEmpNo.Appearance = appearance75;
            this.lblEmpNo.AutoPopupID = null;
            this.lblEmpNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmpNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblEmpNo.Location = new System.Drawing.Point(482, 31);
            this.lblEmpNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblEmpNo.Name = "lblEmpNo";
            this.lblEmpNo.Size = new System.Drawing.Size(116, 24);
            this.lblEmpNo.StyleSetName = "Default";
            this.lblEmpNo.TabIndex = 6;
            this.lblEmpNo.Text = "사번";
            this.lblEmpNo.UseMnemonic = false;
            // 
            // uniLabel2
            // 
            appearance76.TextHAlignAsString = "Left";
            appearance76.TextVAlignAsString = "Middle";
            this.uniLabel2.Appearance = appearance76;
            this.uniLabel2.AutoPopupID = null;
            this.uniLabel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniLabel2.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.uniLabel2.Location = new System.Drawing.Point(15, 6);
            this.uniLabel2.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.uniLabel2.Name = "uniLabel2";
            this.uniLabel2.Size = new System.Drawing.Size(116, 24);
            this.uniLabel2.StyleSetName = "Default";
            this.uniLabel2.TabIndex = 13;
            this.uniLabel2.Text = "근무구분";
            this.uniLabel2.UseMnemonic = false;
            // 
            // uniDateTime1_bak
            // 
            this.uniDateTime1_bak.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance77.TextHAlignAsString = "Center";
            this.uniDateTime1_bak.Appearance = appearance77;
            this.uniDateTime1_bak.CausesValidation = false;
            this.uniDateTime1_bak.DateTime = new System.DateTime(2021, 2, 17, 0, 0, 0, 0);
            this.uniDateTime1_bak.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.DateTime;
            this.uniDateTime1_bak.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.uniDateTime1_bak.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniDateTime1_bak.Location = new System.Drawing.Point(131, 56);
            this.uniDateTime1_bak.LockedField = false;
            this.uniDateTime1_bak.Margin = new System.Windows.Forms.Padding(0);
            this.uniDateTime1_bak.MaskInput = "{time}";
            this.uniDateTime1_bak.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.uniDateTime1_bak.Name = "uniDateTime1_bak";
            this.uniDateTime1_bak.QueryIfEnterKeyPressed = true;
            this.uniDateTime1_bak.RequiredField = false;
            this.uniDateTime1_bak.ShowInkButton = Infragistics.Win.ShowInkButton.Never;
            this.uniDateTime1_bak.Size = new System.Drawing.Size(100, 24);
            this.uniDateTime1_bak.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.uniDateTime1_bak.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.HHMMSS;
            this.uniDateTime1_bak.StyleSetName = "Default";
            this.uniDateTime1_bak.TabIndex = 17;
            this.uniDateTime1_bak.uniALT = null;
            this.uniDateTime1_bak.uniValue = new System.DateTime(2021, 2, 17, 0, 0, 0, 0);
            this.uniDateTime1_bak.Value = new System.DateTime(2021, 2, 17, 0, 0, 0, 0);
            this.uniDateTime1_bak.ValueChanged += new System.EventHandler(this.uniDateTime1_ValueChanged);
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.DefaultRowSize = 23;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(936, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 5;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.Controls.Add(this.btnConfirm, 0, 0);
            this.uniTBL_MainBatch.DefaultRowSize = 23;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 544);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(936, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnConfirm
            // 
            this.btnConfirm.AutoPopupID = null;
            this.btnConfirm.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnConfirm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnConfirm.Location = new System.Drawing.Point(0, 1);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.PopupID = null;
            this.btnConfirm.Size = new System.Drawing.Size(97, 24);
            this.btnConfirm.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnConfirm.TabIndex = 1;
            this.btnConfirm.Text = "입력";
            this.btnConfirm.UserDefinedText = null;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(601, 58);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(128, 25);
            this.textBox1.TabIndex = 21;
            // 
            // uniDateTime1
            // 
            this.uniDateTime1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.uniDateTime1.EditAs = Infragistics.Win.UltraWinMaskedEdit.EditAsType.UseSpecifiedMask;
            this.uniDateTime1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniDateTime1.InputMask = "{LOC}hh:mm";
            this.uniDateTime1.Location = new System.Drawing.Point(598, 80);
            this.uniDateTime1.LockedField = false;
            this.uniDateTime1.Margin = new System.Windows.Forms.Padding(0);
            this.uniDateTime1.Name = "uniDateTime1";
            this.uniDateTime1.RequiredField = false;
            this.uniDateTime1.Size = new System.Drawing.Size(100, 25);
            this.uniDateTime1.TabIndex = 22;
            this.uniDateTime1.Text = "uniMaskedEdit1";
            this.uniDateTime1.uniALT = null;
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(948, 617);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainCondition.PerformLayout();
            this.popEmpNo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_e672e9b7_7026_49fb_953a_0c55d47b23ce)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_62cf2b38_78bd_4bef_b5aa_1443b014543b)).EndInit();
            this.popDeptCd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_a5d65465_24ca_4a0f_b577_82820a1da092)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTime2)).EndInit();
            this.dtPerFromTo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTimeF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTimeT)).EndInit();
            this.popFlexSys.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniDateTime1_bak)).EndInit();
            this.uniTBL_MainBatch.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblEmpNo;
        private uniERP.AppFramework.UI.Controls.uniButton btnConfirm;
        private uniERP.AppFramework.UI.Controls.uniLabel uniLabel1;
        private AppFramework.UI.Controls.uniDateTerm dtPerFromTo;
        private AppFramework.UI.Controls.uniDateTime uniDateTimeF;
        private AppFramework.UI.Controls.uniDateTime uniDateTimeT;
        private AppFramework.UI.Controls.uniLabel object_31d70455_9565_4632_a8e2_2b122587e87b;
        private AppFramework.UI.Controls.uniLabel uniLabel3;
        private AppFramework.UI.Controls.uniOpenPopup popFlexSys;
        private AppFramework.UI.Controls.uniTextBox uniTextBox_Name;
        private AppFramework.UI.Controls.uniTextBox uniTextBox_Code;
        private AppFramework.UI.Controls.uniLabel uniLabel2;
        private AppFramework.UI.Controls.uniLabel uniLabel4;
        private AppFramework.UI.Controls.uniDateTime uniDateTime2;
        private AppFramework.UI.Controls.uniDateTime uniDateTime1_bak;
        private AppFramework.UI.Controls.uniOpenPopup popEmpNo;
        private AppFramework.UI.Controls.uniTextBox object_e672e9b7_7026_49fb_953a_0c55d47b23ce;
        private AppFramework.UI.Controls.uniTextBox object_62cf2b38_78bd_4bef_b5aa_1443b014543b;
        private AppFramework.UI.Controls.uniOpenPopup popDeptCd;
        private AppFramework.UI.Controls.uniTextBox object_d9fcbe89_f0d3_4187_9be7_328ecada0044;
        private AppFramework.UI.Controls.uniTextBox object_a5d65465_24ca_4a0f_b577_82820a1da092;
        private AppFramework.UI.Controls.uniLabel lblDeptCd;
        private System.Windows.Forms.TextBox textBox1;
        private AppFramework.UI.Controls.uniMaskedEdit uniDateTime1;

    }
}
