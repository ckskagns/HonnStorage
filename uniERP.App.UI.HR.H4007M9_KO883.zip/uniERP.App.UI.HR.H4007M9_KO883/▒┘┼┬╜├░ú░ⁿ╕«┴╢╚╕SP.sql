              
                
ALTER PROCEDURE [dbo].[USP_H4007M2_KO883]                
 (      
 @EMP_NO nvarchar(26), -- ���    
 @DEPT_NO nvarchar(26), -- �μ���ȣ    
 @Work_From nvarchar(26), -- �ٹ�����From       
    @Work_To  nvarchar(26)  -- �ٹ�����To    
                 
 ) AS                          
                    
 BEGIN                                              
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                        
                                           
SET NOCOUNT ON                        
    
  IF @Work_From IS NULL OR @Work_From = '' SET @Work_From ='1900-01-01'         
  IF @Work_To IS NULL OR @Work_To = '' SET @Work_To ='2099-12-31'     
    
select  distinct    
    
  A.EMP_NO    ,     
  A.NAME      ,    
  B.DEPT_NM     ,
  dbo.ufn_getcodename('h0002', roll_pstn) as ROLL_PSTN_NM,
  CONVERT (varchar,A.WORK_DT,23) as WORK_DT ,    
  A.DAY_WEEK   ,    
  CASE A.DAY_WEEK
  WHEN '����'
  THEN	CASE ISNULL(A.START_TIME,'')
		WHEN ''
		THEN NULL
		ELSE convert(char(8),A.START_TIME,108) 
		END
  WHEN '����'
  THEN CASE E.APPROVAL_RTN
       WHEN '1'
	   THEN convert(char(8), dateadd(hh,C.DILIG_HH_FR, 0),108)
	   ELSE NULL
	   END
  END
  as START_TIME,    
   CASE A.DAY_WEEK
   WHEN '����'   -- ����,���� ���� CASE��
   THEN
		  CASE ISNULL(A.END_TIME,'')
			  WHEN ''
			  THEN 
			  CASE D.DILIG_NM   -- ���Ĺ��� ���� CASE��
			     WHEN '����(����)'
			  THEN  convert(char(8),'14:00:00',108)
			  ELSE  convert(char(8),'18:00:00',108)
			  END
		         ELSE convert(char(8),A.END_TIME,108)
			  END
		  WHEN '����'
		  THEN   CASE E.APPROVAL_RTN
				 WHEN '1'
				 THEN convert(char(8), dateadd(hh,C.DILIG_HH_TO, 0),108)
				 ELSE NULL
				 END
		  
	--ELSE null
	 END

 as END_TIME,
     CASE A.DAY_WEEK
	 WHEN '����'  -- ����,���� ���� CASE��
	 THEN
		 CASE ISNULL(A.END_TIME,'')
				 WHEN ''
				 THEN
				 CASE D.DILIG_NM
			     WHEN '����(����)' -- ���� �����϶� �ٹ��ð� ��� CASE��
				 THEN  convert(char(8),'13:00' -
													CASE								-- ��ٽð��� 9�� �����϶��� ��ٽð��� 9�÷� �����ϴ� CASE��
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END
													,108)
				 ELSE  convert(char(8),'17:00' -    CASE 
													WHEN convert(char(8),A.START_TIME,108)< '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END,108)
				 END
		        ELSE CASE 
				     WHEN convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:00:00',108) > '08:00:00'   -- ��ٽð��� ����6�ø� �Ѿ����� 30�� ���� CASE��
					 THEN CASE
						  WHEN convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:00:00',108) <= '08:30:00'
						  THEN '08:00:00'
						  ELSE convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:30:00',108)
						  END
					 ELSE convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:00:00',108)
					 END
				 END
	 WHEN '����'
	 THEN 
	    CASE ISNULL(D.DILIG_NM,'')
		WHEN ''
		THEN NULL
		ELSE CASE D.DILIG_NM
		     WHEN '���ϱٹ�1'
			 THEN CASE E.APPROVAL_RTN
			      WHEN '1'
				  THEN 
						CASE
						WHEN C.DILIG_HH_TO < C.DILIG_HH_FR
						THEN CASE
						     WHEN ( (C.DILIG_HH_TO + 24) - C.DILIG_HH_FR ) >= 5
								THEN convert(char(8),dateadd(hh, ( (C.DILIG_HH_TO + 24) - C.DILIG_HH_FR ) - 1 ,0),108)
								ELSE convert(char(8),dateadd(hh, (C.DILIG_HH_TO + 24) - C.DILIG_HH_FR,0),108)
								END
						ELSE CASE 
						     WHEN ( C.DILIG_HH_TO - C.DILIG_HH_FR ) >= 5
								THEN convert(char(8),dateadd(hh, (C.DILIG_HH_TO - C.DILIG_HH_FR)  -1,0),108)
								ELSE convert(char(8),dateadd(hh, C.DILIG_HH_TO - C.DILIG_HH_FR , 0),108)
						END
					END
				  ELSE NULL
				  END
             END
		END
	ELSE null
	 END

		 as TOT_TIME,  
CASE
WHEN
   (CASE A.DAY_WEEK
	 WHEN '����'  -- ����,���� ���� CASE��
	 THEN
		 CASE ISNULL(A.END_TIME,'')
		 WHEN ''
		 THEN ''
		 ELSE
				 CASE 
				     WHEN convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:00:00',108) > '08:00:00'   -- ��ٽð��� ����6�ø� �Ѿ����� 30�� ���� CASE��
					 THEN CASE
						  WHEN convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:00:00',108) <= '08:30:00'
						  THEN '08:00:00'
						  ELSE convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:30:00',108)
						  END
					 ELSE convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:00:00',108)
					 END
				 END 
	 
	 END ) > '08:00:00'   -- �ٹ��ð��� 8�ð��� �ʰ��ϴ� ��� �߰��ٹ� ���
	 THEN  (CASE A.DAY_WEEK
	 WHEN '����'  -- ����,���� ���� CASE��
	 THEN
		 CASE ISNULL(A.END_TIME,'')
		 WHEN ''
		 THEN ''
		 ELSE
				 CASE 
				     WHEN convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:00:00',108) > '08:00:00'   -- ��ٽð��� ����6�ø� �Ѿ����� 30�� ���� CASE��
					 THEN CASE
						  WHEN convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '01:00:00',108) <= '08:30:00'
						  THEN NULL
						  ELSE convert(char(8),A.END_TIME - CASE 
													WHEN convert(char(8),A.START_TIME,108) < '09:00:00'
													THEN '09:00:00'
													ELSE A.START_TIME
													END - '09:30:00',108)
						  END
					 ELSE NULL
					 END
				 END 
	 
	 END ) 
ELSE null
END  as OT      ,  
			   CASE D.DILIG_NM
			   WHEN '���ϱٹ�1'
			   THEN		
			           CASE E.APPROVAL_RTN
					   WHEN '1'
					   THEN CASE
							WHEN C.DILIG_HH_TO < C.DILIG_HH_FR
							THEN CASE
							     WHEN ( (C.DILIG_HH_TO + 24) - C.DILIG_HH_FR ) >= 5
									THEN convert(char(8),dateadd(hh, ( (C.DILIG_HH_TO + 24) - C.DILIG_HH_FR ) - 1 ,0),108)
									ELSE convert(char(8),dateadd(hh, (C.DILIG_HH_TO + 24) - C.DILIG_HH_FR,0),108)
									END
							ELSE CASE 
							     WHEN ( C.DILIG_HH_TO - C.DILIG_HH_FR ) >= 5
									THEN convert(char(8),dateadd(hh, (C.DILIG_HH_TO - C.DILIG_HH_FR)  -1,0),108)
									ELSE convert(char(8),dateadd(hh, C.DILIG_HH_TO - C.DILIG_HH_FR , 0),108)
									END
							END
						END
				END  as HT,    
  CASE A.DAY_WEEK
  WHEN '����'
  THEN	CASE
		WHEN D.DILIG_NM <> '����(����)'
		THEN
			CASE 
			WHEN convert(char(8),A.START_TIME,108) > '09:00:00'
			THEN CASE 
				 WHEN convert(char(8),A.START_TIME,108) < '12:00:00'
				 THEN convert(char(8),A.START_TIME - '09:00:00',108) 
				 END
			ELSE NULL 
			END
		END
  END as TT  ,    
  A.ISRT_EMP_NO     ,     
  A.UPDT_EMP_NO ,    
  A.UPDT_DT,    
  CASE isnull(D.DILIG_NM,'')
  WHEN ''
  THEN ''
  ELSE CASE E.APPROVAL_RTN
	   WHEN '1'
	   THEN D.DILIG_NM
	   END
  END
   as ETC1    
      
  from WT_MA_KO883 A            
 join HAA010T B on A.EMP_NO = B.EMP_NO    
LEFT OUTER join H4006M3_D_KO883 C on A.EMP_NO = C.DILIG_EMP_NO and A.WORK_DT = C.DILIG_DT_FR
LEFT OUTER join HCA010T D on D.DILIG_CD = C.DILIG_CD
LEFT OUTER join ERP_IF_APPROVAL E on C.DILIG_REQ_NO = E.DOC_NO 

-- from WT_MA_KO883 A            
--join HAA010T B on A.EMP_NO = B.EMP_NO      
--left outer join HCA060T C on A.EMP_NO = C.EMP_NO and A.WORK_DT=C.DILIG_DT    
--left outer join hca010t E on E.DILIG_CD = C.DILIG_CD    
    
where     
( @EMP_NO ='' or A.EMP_NO = @EMP_NO )    
and (@DEPT_NO = '' or B.DEPT_CD = @DEPT_NO)        
and CONVERT (DATETIME, A.WORK_DT) BETWEEN  CONVERT (DATETIME, @Work_From) AND  CONVERT (DATETIME, @Work_To )          
    
    
 order by WORK_DT ASC    
                
 END 

 --select * from WT_MA_KO883