-- DROP TABLE WT_FLEX_KO883
CREATE TABLE WT_FLEX_KO883(
    WORK_DT      nvarchar(20) 
   ,EMP_NO       nvarchar(13)
   ,DEPT_CD      nvarchar(10)
   ,FLEX_SYS     nvarchar(12)
   ,START_TIME   nvarchar(8)
   ,END_TIME	 nvarchar(8)
   ,TOT_TIME	 nvarchar(8)
   ,ISRT_EMP_NO   nvarchar(24)
   ,ISRT_DT      datetime
   ,UPDT_EMP_NO   nvarchar(24)
   ,UPDT_DT      datetime
   ,ETC1          nvarchar(24)
   ,ETC2          nvarchar(24)
   ,ETC3          nvarchar(24)


   PRIMARY KEY (WORK_DT,EMP_NO)

)