﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Common.Exceptions;
using uniERP.AppFramework.DataBridge;
//using System.Xml.Linq;
using System.Linq;


#endregion

namespace uniERP.App.UI.HR.H4007M9_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①uniERP.App.UI.HR.H4007M2_KO883</NameSpace>
        /// <Module>②PS</Module>
        /// <Class>③ModuleViewer name</Class>
        /// <Desc>④
        ///   This part describe the summary information about class 
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="KSK" Date="2018-07-26">Make …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        #endregion

        #region ■ 1.4 Class global constants (grid)


        #endregion

        #region ■ 1.5 Class global variables (grid)

        // change your code
        private tdsY8101M2_KO883 cstdsY8101M2_KO883 = new tdsY8101M2_KO883();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(this.cstdsY8101M2_KO883);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T06_SingleMultiMulti);
            //uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.Common);  // Load company numeric format. I: Input Program, *: All Module
            //uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Query, enumDef.ModuleInformation.Purchase);  // Load company numeric format. I: Input Program, *: All Module

            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format
        }

        protected override void Form_Load_Completed()
        {
           // popProject.Focus();                // Set focus
            //dtYYYYMM.Value = uniBase.UDate.GetDBServerDateTime();
            //dtDocumentDt.Value = uniBase.UDate.GetDBServerDateTime();

            //uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.DeleteRow, false);

            //uniBase.UCommon.DisableButton(btnConfirm, true);

            //uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, false);
            //uniBase.UCommon.SetToolBarMultiAll(false);
            //uniBase.UCommon.SetToolBarSingleAll(false);

            //uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, false);
            ////uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Copy, false);
            //uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Delete, false);
            //uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.First,false);
            //uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Last, false);
            //uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Next, false);
            //uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Prev, false);
            //////uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.Cancel, false);
            ////uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.CopyRow, false);
            //uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.DeleteAll, false);
            //uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.DeleteRow, false);
            //uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.InsertRow, false);


            DateTime today = uniBase.UDate.GetDBServerDateTime();

            dtPerFromTo.uniFromValue = today.AddMonths(-1);
            dtPerFromTo.uniToValue = today;
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            // init Dataset Row : change your code
            cstdsY8101M2_KO883.Clear();
        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            //uniBase.UCommon.SetToolBarMultiAll(false);
            //uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, false);

            // Assign default value to controls
            return;
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
                        // Example: Set ComboBox List (Column Name, Select, From, Where)

            //sdf
            uniBase.UData.ComboMajorAdd("MINOR_NM", "XH004");
            //uniBase.UData.ComboCustomAdd("DAY_WEEK", " w_day ", " ( select	'평일' as w_day union all select	'휴일' as w_day ) a ", "1=1");
            //uniBase.UData.ComboCustomAdd("DefaultFilePath", " MINOR_NM ", " B_MINOR ", " MAJOR_CD = 'ZH006' ");
        

            // Example: Set ComboBox List (Column Name, Select, From, Where)
            //uniBase.UData.ComboMajorAdd("TaxPolicy", "B0004");
            //uniBase.UData.ComboCustomAdd("DAY_WEEK", "MINOR_CD , MINOR_NM ", "B_MINOR", "MAJOR_CD='XH004'");
        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆
            base.viewTB19029.ggUserDefined6.DecPoint = 1;
            base.viewTB19029.ggUserDefined6.Integeral = 18;
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            tdsY8101M2_KO883.E_WT_MADataTable uniGridTB1 = cstdsY8101M2_KO883.E_WT_MA;

            uniGrid1.SSSetEdit(uniGridTB1.EMP_NOColumn.ColumnName, "사번", 90, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left, 13);
            uniGrid1.SSSetEdit(uniGridTB1.NAMEColumn.ColumnName, "성명", 70, enumDef.FieldType.ReadOnly);

            uniGrid1.SSSetEdit(uniGridTB1.FLEX_SYSColumn.ColumnName, "근태구분", 90, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left, 13);
            //uniGrid1.SSSetEdit(uniGridTB1.FLEX_SYSColumn.ColumnName, "근태구분", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.MINOR_NMColumn.ColumnName, "근태구분명", 100, enumDef.FieldType.ReadOnly);
            
            uniGrid1.SSSetDate(uniGridTB1.WORK_DTColumn.ColumnName, "근무일자", enumDef.FieldType.NotNull, CommonVariable.gDateFormat, enumDef.HAlign.Center);

            uniGrid1.SSSetMask(uniGridTB1.START_TIMEColumn.ColumnName, "출근시간", 90, enumDef.FieldType.Default, "hh:mm", enumDef.HAlign.Center);
            uniGrid1.SSSetMask(uniGridTB1.END_TIMEColumn.ColumnName, "퇴근시간", 90, enumDef.FieldType.Default, "hh:mm", enumDef.HAlign.Center);



            


            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);
            //this.uniGrid2.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);

            #endregion

            #region ■■ 3.1.3 Setting etc grid
            //this.uniGrid1.SSSetColHidden(uniGridTB1.YYYYColumn.ColumnName);
            //this.uniGrid1.SSSetColHidden(uniGridTB1.DILIG_DTColumn.ColumnName);

            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
            // TO-DO: 컨트롤을 초기화(또는 초기값)할때 할일 
            // SetDefaultVal과의 차이점은 전자는 Form_Load 시점에 콘트롤에 초기값을 세팅하는것이고
            // 후자는 특정 시점(조회후 또는 행추가후 등 특정이벤트)에서 초기값을 셋팅한다.
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            // Grid binding with global dataset variable.
            this.InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(this.cstdsY8101M2_KO883.E_WT_MA);
            //this.uniGrid2.uniGridSetDataBinding(this.cstdsY8101M2_KO883.E_PMS_PROJECT_RATE_Common);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //TO-DO : code business oriented logic
            if ((dtPerFromTo.uniDateTimeF.Value != null) && (dtPerFromTo.uniDateTimeT.Value != null))    //date값이 필수가 아닐 경우
            {
                if (!uniBase.UDate.CompareDateBetween(dtPerFromTo.uniDateTimeF, dtPerFromTo.uniDateTimeT, "970023"))    //%1 은(는) %2 보다 크거나 같아야합니다.
                {
                    dtPerFromTo.Focus();
                    return false;
                }
            }

            return DBQuery();
        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)

        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic
           string strCloseFlag = "";

            try
            {
                StringBuilder iSQL = new StringBuilder();
                iSQL.Remove(0, iSQL.Length);

                if (iSQL.Length > 0)
                {                    
                    uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetSqlStringCommand(iSQL.ToString());
                    DataSet dsCloseStatus = uniBase.UDatabase.ExecuteDataSet(uniCmd);

                    if (dsCloseStatus != null && dsCloseStatus.Tables[0].Rows.Count > 0)
                    {
                        strCloseFlag = dsCloseStatus.Tables[0].Rows[0][0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }

            //if (strCloseFlag == "I")
            //{
            //    uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "해당월에 수불마감되어 자료를 \n 저장/삭제/변경 할 수 없습니다.");
            //    //236002 --해당월의 수불마감이 이미 되었습니다.
            //    return false;
            //}


            return DBSave();
        
        }

        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            


            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)


        protected override bool OnPreFncInsertRow()
        {
            //if (uniTabControl1.ActiveTab.Index != 0)
            //{
            //    return false;
            //}

            return base.OnPreFncInsertRow();



        }

        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic           
            
            if (this.uniGrid1.ActiveRow != null)
            {
                this.uniGrid1.ActiveRow.Cells["work_dt"].Value = uniBase.UDate.GetDBServerDateTime(); // dtYYYYMM.uniValue.ToString("yyyy");


            }

         

            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            cstdsY8101M2_KO883.Clear();

            DataSet dsResult = null;

            //uniBase.UMessage.DisplayMessageBox("Test01", MessageBoxButtons.OK, "테스트 메세지");

            string dtPerFr = uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD, false);
            string dtPerTo = uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeT, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD, false);


            try
            {
                //using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_H4007M2_KO883"))
                using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_H4007M9_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(uniCommand, "@EMP_NO", SqlDbType.NVarChar, popEmpNo.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@DEPT_NO", SqlDbType.NVarChar, popDeptCd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@FLEX_SYS", SqlDbType.NVarChar, popFlexSys.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@Work_From", SqlDbType.NVarChar, dtPerFr);
                    uniBase.UDatabase.AddInParameter(uniCommand, "@Work_To", SqlDbType.NVarChar, dtPerTo);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Start_Time", SqlDbType.NVarChar, dtStartTime);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@End_Time", SqlDbType.NVarChar, dtEndTime);



                    dsResult = uniBase.UDatabase.ExecuteDataSet(uniCommand);

                    //uniGrid1.ActiveRow.Cells["emp_name"].Value = dsResult.Tables[0].Rows[0]["name"].ToString().Trim();


                }

                if (dsResult == null || dsResult.Tables.Count == 0 || dsResult.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return false;
                }

                cstdsY8101M2_KO883.E_WT_MA.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);

                //sbSQL.Append("   INSERT WT_MA_KO883 (WORK_DT, EMP_NO , NAME, DAY_WEEK, START_TIME, END_TIME , TOT_TIME, OT, HT, TT, ISRT_EMP_NO , ISRT_DT ,UPDT_EMP_NO ,UPDT_DT ) VALUES(").Append(uniBase.UCommon.FilterVariable(row["WORK_DT"].ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));
                        

                //for (int i = 0; i < uniGrid1.Rows.Count; i++)
                //{
                //    uniGrid1.SpreadLock("EMP_NO", i, i);
                //    uniGrid1.SpreadLock("NAME", i, i);
                //    uniGrid1.SpreadLock("WORK_DT", i, i);
                //   // uniGrid1.SpreadLock("DAY_WEEK", i, i);

                //}

                uniBase.UCommon.SetToolBarMultiAll(true);
                uniBase.UCommon.SetToolBarCommonAll(true);

               // DBQuery2();
            }



            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }
            return true;
        }

        //private bool DBQuery2()
        //{
            

        //    DataSet dsResult2 = null;

        //    //uniBase.UMessage.DisplayMessageBox("Test01", MessageBoxButtons.OK, "테스트 메세지");

        //    string dtPerFr = uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD, false);
        //    string dtPerTo = uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeT, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD, false);


        //    try
        //    {
        //        using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_H4007M2_Grid2_KO883"))
        //        {
        //            uniBase.UDatabase.AddInParameter(uniCommand, "@EMP_NO", SqlDbType.NVarChar, popEmpNo.CodeValue.Trim());
        //            uniBase.UDatabase.AddInParameter(uniCommand, "@DEPT_NO", SqlDbType.NVarChar, popDeptCd.CodeValue.Trim());
        //            uniBase.UDatabase.AddInParameter(uniCommand, "@Work_From", SqlDbType.NVarChar, dtPerFr);
        //            uniBase.UDatabase.AddInParameter(uniCommand, "@Work_To", SqlDbType.NVarChar, dtPerTo);


        //            dsResult2 = uniBase.UDatabase.ExecuteDataSet(uniCommand);

        //            //uniGrid1.ActiveRow.Cells["emp_name"].Value = dsResult.Tables[0].Rows[0]["name"].ToString().Trim();


        //        }

        //        if (dsResult2 == null || dsResult2.Tables.Count == 0 || dsResult2.Tables[0].Rows.Count == 0)
        //        {
        //            uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
        //            return false;
        //        }

        //        cstdsY8101M2_KO883.E_WT_MA_DETAIL.Merge(dsResult2.Tables[0], false, MissingSchemaAction.Ignore);
        //        uniGrid2.uniGridSetDataBinding(cstdsY8101M2_KO883.E_WT_MA_DETAIL);
        //    }



        //    catch (Exception ex)
        //    {
        //        bool reThrow = ExceptionControler.AutoProcessException(ex);
        //        if (reThrow)
        //            throw;
        //        return false;
        //    }
        //    finally
        //    {

        //    }
        //    return true;
        //}

        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            this.uniGrid1.UpdateData();
            cstdsY8101M2_KO883.E_WT_PROJECT.Clear();
            DataTable saveDt = new DataTable();

            try
            {


                cstdsY8101M2_KO883.E_WT_PROJECT.Merge(cstdsY8101M2_KO883.E_WT_MA.GetChanges(), false, MissingSchemaAction.Ignore);
                saveDt.Merge(cstdsY8101M2_KO883.E_WT_PROJECT, false, MissingSchemaAction.Add);
                saveDt.AcceptChanges();

                using (uniCommand _uniCmd = uniBase.UDatabase.GetStoredProcCommand("dbo.USP_H4007M9_KO883_S"))
                {
                    uniBase.UDatabase.AddInParameter(_uniCmd, "@TBL_DATA", SqlDbType.Structured, saveDt);
                    uniBase.UDatabase.AddInParameter(_uniCmd, "@USER_ID", SqlDbType.NVarChar, 15, CommonVariable.gUsrID);
                    uniBase.UDatabase.AddOutParameter(_uniCmd, "@MSG_CD", SqlDbType.NVarChar, 6);
                    uniBase.UDatabase.AddOutParameter(_uniCmd, "@MESSAGE", SqlDbType.NVarChar, 200);
                    uniBase.UDatabase.AddOutParameter(_uniCmd, "@ERR_POS", SqlDbType.Int, 6);

                    uniBase.UDatabase.AddReturnParameter(_uniCmd, "RETURN_VALUE", SqlDbType.Int, 1);

                    uniBase.UDatabase.ExecuteNonQuery(_uniCmd, false);

                    int iReturn = (int)uniBase.UDatabase.GetParameterValue(_uniCmd, "RETURN_VALUE");

                    if (iReturn < 0)
                    {
                        string sMsgCd = uniBase.UDatabase.GetParameterValue(_uniCmd, "@MSG_CD") as string;
                        string sMessage = uniBase.UDatabase.GetParameterValue(_uniCmd, "@MESSAGE") as string;

                        if (string.IsNullOrEmpty(sMsgCd)) sMsgCd = "DT9999";

                        uniBase.UMessage.DisplayMessageBox(sMsgCd, MessageBoxButtons.OK, sMessage);

                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }


            return true;

        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        #region ■■ 5.2.1 ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ButtonClicked >>> ClickCellButton

        #region ■■ 5.2.2 Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeExitEditMode(object sender, Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs e)
        {
            if (e.CancellingEditOperation)
                return;

            switch (uniGrid1.ActiveCell.Column.Key)
            {
                case "AAA":
                    break;
                case "BBB":
                    break;
                case "CCC":
                    break;
                default:
                    break;
            }
        }

        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {
            if (uniGrid1.ActiveRow == null || uniGrid1.ActiveCell == null) return;

            string sKey = uniGrid1.ActiveCell.Column.Key.ToUpper();
            DataSet pDataSet = null;


            switch (sKey)
            {
                case "EMP_NO":
                    DataSet dsChg = uniBase.UDataAccess.CommonQueryRs(" haa010t.EMP_NO, haa010t.NAME, haa010t.DEPT_NM, dbo.ufn_getcodename('h0002',haa010t.roll_pstn) as roll_pstn_nm  ",
                       " haa010t ", " (haa010t.emp_no like '%'+" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                       + " +'%' OR haa010t.NAME LIKE '%' +" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " +'%')"
                       );
                    if (uniGrid1.ActiveRow.Cells["emp_no"].Value.ToString().Trim() != "")
                    {
                        if (dsChg != null && dsChg.Tables.Count > 0 && dsChg.Tables[0].Rows.Count > 0)
                        {
                            if (dsChg.Tables[0].Rows.Count == 1)
                            {
                                uniGrid1.ActiveRow.Cells["emp_no"].Value = dsChg.Tables[0].Rows[0]["emp_no"].ToString().Trim();
                                uniGrid1.ActiveRow.Cells["name"].Value = dsChg.Tables[0].Rows[0]["name"].ToString().Trim();
                                //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = dsChg.Tables[0].Rows[0]["DEPT_NM"].ToString().Trim();
                                //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = dsChg.Tables[0].Rows[0]["roll_pstn_nm"].ToString().Trim();
                            }
                            else
                            {

                                uniGrid1.BeforePopupOpenEvent();

                            }
                        }
                        else
                        {
                            uniGrid1.ActiveRow.Cells["emp_no"].Value = string.Empty;
                            uniGrid1.ActiveRow.Cells["name"].Value = string.Empty;
                            //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = string.Empty;
                            //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = string.Empty;

                            return;
                        }
                    }
                    else
                    {
                        uniGrid1.ActiveRow.Cells["emp_no"].Value = string.Empty;
                        uniGrid1.ActiveRow.Cells["name"].Value = string.Empty;
                        //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = string.Empty;
                        //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = string.Empty;

                        return;
                    }
                    break;
                case "FLEX_SYS":
                    DataSet dsChg2 = uniBase.UDataAccess.CommonQueryRs("b_minor.MINOR_CD, b_minor.MINOR_NM",
                       "b_minor", " (b_minor.MINOR_CD like '%'+" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["FLEX_SYS"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                       + " +'%' OR b_minor.MINOR_NM LIKE '%' +" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["MINOR_NM"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " +'%')"
                       );
                    if (uniGrid1.ActiveRow.Cells["emp_no"].Value.ToString().Trim() != "")
                    {
                        if (dsChg2 != null && dsChg2.Tables.Count > 0 && dsChg2.Tables[0].Rows.Count > 0)
                        {
                            if (dsChg2.Tables[0].Rows.Count == 1)
                            {
                                uniGrid1.ActiveRow.Cells["FLEX_SYS"].Value = dsChg2.Tables[0].Rows[0]["MINOR_CD"].ToString().Trim();
                                uniGrid1.ActiveRow.Cells["MINOR_NM"].Value = dsChg2.Tables[0].Rows[0]["MINOR_NM"].ToString().Trim();
                                //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = dsChg.Tables[0].Rows[0]["DEPT_NM"].ToString().Trim();
                                //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = dsChg.Tables[0].Rows[0]["roll_pstn_nm"].ToString().Trim();
                            }
                            else
                            {

                                uniGrid1.BeforePopupOpenEvent();

                            }
                        }
                        else
                        {
                            uniGrid1.ActiveRow.Cells["FLEX_SYS"].Value = string.Empty;
                            uniGrid1.ActiveRow.Cells["MINOR_NM"].Value = string.Empty;
                            //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = string.Empty;
                            //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = string.Empty;

                            return;
                        }
                    }
                    else
                    {
                        uniGrid1.ActiveRow.Cells["FLEX_SYS"].Value = string.Empty;
                        uniGrid1.ActiveRow.Cells["MINOR_NM"].Value = string.Empty;
                        //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = string.Empty;
                        //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = string.Empty;

                        return;
                    }
                    break;
            }



        }
        #endregion ■■ Change >>> CellChange

        #region ■■ 5.2.3 Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
        }
        #endregion ■■ Click >>> AfterSelectChange

        #region ■■ 5.2.4 ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ComboSelChange >>> CellListSelect

        #region ■■ 5.2.5 DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
        }
        #endregion ■■ DblClick >>> DoubleClickCell

        #region ■■ 5.2.6 MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
        }
        #endregion ■■ MouseDown >>> MouseDown

        #region ■■ 5.2.7 ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
        }
        #endregion ■■ ScriptLeaveCell >>> BeforeCellDeactivate

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors


            #endregion

            #region ▶▶▶ 10.1.2.2 Setting Returned Data



            #endregion

        }

        #endregion

        private void popDeptCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "부서명";
            e.PopupPassData.ConditionCaption = "부서명 조회";

            e.PopupPassData.SQLFromStatements = "B_ACCT_DEPT(NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = this.popDeptCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "ORG_CHANGE_ID= " + uniBase.UCommon.FilterVariable(CommonVariable.gChangeOrgId, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "DEPT_CD";
            e.PopupPassData.GridCellCode[1] = "DEPT_NM";

            e.PopupPassData.GridCellCaption[0] = "부서 코드";
            e.PopupPassData.GridCellCaption[1] = "부서명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }


        #endregion

        private void popDeptCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popDeptCd.CodeValue = iDataSet.Tables[0].Rows[0]["dept_cd"].ToString().Trim();
            popDeptCd.CodeName = iDataSet.Tables[0].Rows[0]["dept_nm"].ToString().Trim();
            //txtInternalCd.Text = iDataSet.Tables[0].Rows[0]["internal_cd"].ToString();

            popEmpNo.CodeValue = string.Empty;
            popEmpNo.CodeName = string.Empty;
        }

        private void popEmpNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            string strDate = uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD);

            string[] param_array = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName, strDate };
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup_KO883";
            e.PopupPassData.PopupWinTitle = "Employee ID";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;
            e.PopupPassData.Data = param_array;
            
        }

        private void popEmpNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popEmpNo.CodeValue = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
            popEmpNo.CodeName = iDataSet.Tables[0].Rows[0]["name"].ToString();
            popDeptCd.CodeValue = "";
            popDeptCd.CodeName = "";

        }

        private void uniGrid1_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            switch (uniGrid1.ActiveCell.Column.ToString().ToUpper().Trim())
            {
                case "EMP_NO":

                    //if (dtYYYYMM.Value == null)
                    //{
                    //    e.Cancel = true;
                    //    break;
                    //}
                    
                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup_KO883";
                    e.PopupPassData.PopupWinTitle = "Employee PopUp";
                    e.PopupPassData.PopupWinWidth = 800;
                    e.PopupPassData.PopupWinHeight = 700;

                    //string strDate = dtYYYYMM.Value == null ? uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD) : uniBase.UDate.GetFirstDay(Convert.ToDateTime(dtYYYYMM.Value.ToString())).ToShortDateString();

                    //e.PopupPassData.Data = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName, strDate, "1", "" };
                    e.PopupPassData.Data = new string[] { "", "", uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD), "1", "" };

                    break;

                case "FLEX_SYS":

                   
                    e.PopupPassData.ConditionCaption = "근무구분";
                    
                    e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
                    e.PopupPassData.SQLWhereStatements = "  MAJOR_CD ='XH006' ";
                    e.PopupPassData.SQLWhereInputCodeValue = ""; // popPlantCd.CodeValue.Trim();
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.DistinctOrNot = false;
                    
                    e.PopupPassData.GridCellCode = new String[2];
                    e.PopupPassData.GridCellCaption = new String[2];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
                    
                    e.PopupPassData.GridCellCode[0] = "MINOR_CD";
                    e.PopupPassData.GridCellCode[1] = "MINOR_NM";
                    
                    e.PopupPassData.GridCellCaption[0] = "근무구분";
                    e.PopupPassData.GridCellCaption[1] = "근무구분명";
                    
                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

                    break;

                default:
                    break;
            }
        }

        private void uniGrid1_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null) return;

            iDataSet = (DataSet)e.ResultData.Data;

            switch (uniGrid1.ActiveCell.Column.Key.ToUpper().Trim())
            {
                case "EMP_NO":
                    uniBase.UGrid.SetGridValue(uniGrid1, "EMP_NO", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["EMP_NO"].ToString());
                    uniBase.UGrid.SetGridValue(uniGrid1, "NAME", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["NAME"].ToString());
                    //uniBase.UGrid.SetGridValue(uniGrid1, "dept_cd", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["dept_cd"].ToString());
                    uniBase.UGrid.SetGridValue(uniGrid1, "dept_nm", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["dept_nm"].ToString());
                    uniBase.UGrid.SetGridValue(uniGrid1, "ROLL_PSTN_NM", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["ROLL_PSTN_NM"].ToString());

                    

                    break;

                case "FLEX_SYS":
                    uniBase.UGrid.SetGridValue(uniGrid1, "FLEX_SYS", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString());
                    uniBase.UGrid.SetGridValue(uniGrid1, "MINOR_NM", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString());
                    break;

                default:
                    break;
            }
        }

        private void popProject_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.Y7001PA_KO883";
            e.PopupPassData.PopupWinTitle = "Projecct State Pop-up";
            e.PopupPassData.Data = null;
        }

        private void popProject_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
        }

        private void uniTabControl1_SelectedTabChanged(object sender, Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventArgs e)
        {
            if (e.Tab.Index == 0)
            {
                uniBase.UCommon.SetToolBarMultiAll(true);
            }
            else
            {
                uniBase.UCommon.SetToolBarMultiAll(false);
            }
        }

        private void popEmpNo_OnExitEditCode(object sender, EventArgs e)
        {
            if (popEmpNo.CodeValue == "")
            {
                popEmpNo.CodeName = "";
                return;
            }

            string[] UNISqlId = new string[] { "ZN_HR_EMP_NM5" };
            string[][] UNIValue = new string[1][];
            UNIValue[0] = new string[3];


            //string strDate = uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD);            

            //UNIValue[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            //UNIValue[0][1] = uniBase.UCommon.FilterVariable(strDate, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][0] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][1] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][2] = " ";

            DataSet pDataSet = null;

            try
            {
                pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("810010", MessageBoxButtons.OK);
                    popEmpNo.CodeName = "";
                    popEmpNo.Focus();
                    return;

                }
                popEmpNo.CodeValue = pDataSet.Tables[0].Rows[0]["emp_no"].ToString();
                popEmpNo.CodeName = pDataSet.Tables[0].Rows[0]["name"].ToString();
                popDeptCd.CodeValue = "";
                popDeptCd.CodeName = "";
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
        }

        //private void uniGrid1_OnExitEditCode(object sender, EventArgs e)
        //{
        //    if (uniGrid1.value == "")
        //    {
        //        popEmpNo.CodeName = "";
        //        return;
        //    }

        //    string[] UNISqlId = new string[] { "ZN_HR_EMP_NM2" };
        //    string[][] UNIValue = new string[1][];
        //    UNIValue[0] = new string[5];


        //    string strDate = dtYYYYMM.Value == null ? uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD) : uniBase.UDate.GetFirstDay(Convert.ToDateTime(dtYYYYMM.Value.ToString())).ToShortDateString();

        //    UNIValue[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
        //    UNIValue[0][1] = uniBase.UCommon.FilterVariable(strDate, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
        //    UNIValue[0][2] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
        //    UNIValue[0][3] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
        //    UNIValue[0][4] = " ";

        //    DataSet pDataSet = null;

        //    try
        //    {
        //        pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

        //        if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
        //        {
        //            uniBase.UMessage.DisplayMessageBox("810010", MessageBoxButtons.OK);
        //            popEmpNo.CodeName = "";
        //            popEmpNo.Focus();
        //            return;

        //        }
        //        popEmpNo.CodeValue = pDataSet.Tables[0].Rows[0]["emp_no"].ToString();
        //        popEmpNo.CodeName = pDataSet.Tables[0].Rows[0]["name"].ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
        //        if (reThrow)
        //            throw;
        //        return;
        //    }
        //}

        private void btnConfirm_Click(object sender, EventArgs e)
        {


            SubReleaseCheck();
        }


        private void SubReleaseCheck()
        {

            if (uniBase.UMessage.DisplayMessageBox("900018", MessageBoxButtons.YesNo) == DialogResult.No)
            { return; }
            else
            {
                cstdsY8101M2_KO883.Clear();


                string strQuery = string.Format(@"
                                    declare @From date;
                                    declare @TO date;
                                    declare @START_TIME nvarchar(8);
                                    declare @END_TIME nvarchar(8);
                                    declare @Row_NUM int;
                                    
                                    
                                    set @From = convert(date,SUBSTRING('{0}',1,10))
                                    set @TO = convert(date,SUBSTRING('{1}',1,10))
                                    set @START_TIME = 
									                 CASE SUBSTRING('{5}',12,2)
													 WHEN '오전'
													 THEN convert(char(8),SUBSTRING('{5}',15,8),108)
													 WHEN '오후'
													 THEN  convert(char(8),convert(datetime,SUBSTRING('{5}',15,8)) +'12:00:00' ,108)
													 END
                                    set @END_TIME = 
									                 CASE SUBSTRING('{6}',12,2)
													 WHEN '오전'
													 THEN convert(char(8),SUBSTRING('{6}',15,8),108)
													 WHEN '오후'
													 THEN  convert(char(8),convert(datetime,SUBSTRING('{6}',15,8)) +'12:00:00' ,108)
													 END
                                    While @From <= @TO

									begin

									   set @Row_NUM = 1

									   While @Row_NUM <=  CASE 
									                      WHEN (select count(emp_no) from HAA010T where dept_cd = '{3}' and RETIRE_DT is null)  = 0
														  THEN 1
														  WHEN (select count(emp_no) from HAA010T where dept_cd = '{3}' and RETIRE_DT is null)  <> 0
														  THEN (select count(emp_no) from HAA010T where dept_cd = '{3}' and RETIRE_DT is null)
														  END
									   
									   begin
                                    
                                       INSERT INTO WT_FLEX_KO883
                                       (
                                        WORK_DT,
                                        EMP_NO,
                                        DEPT_CD,
                                        FLEX_SYS,
                                        START_TIME,
                                        END_TIME,
                                        ISRT_EMP_NO,
                                        ISRT_DT,
                                        UPDT_EMP_NO,
                                        UPDT_DT
                                       
                                       )VALUES(
                                       @From,
                                       CASE ISNULL('{2}','')
									   WHEN ''
									   THEN (select B.EMP_NO FROM (select RANK() OVER(order by A.EMP_NO) as ROW_NUM, A.EMP_NO from HAA010T A where A.DEPT_CD ='{3}' and RETIRE_DT is null ) B WHERE B.ROW_NUM = @Row_NUM)
									   ELSE '{2}'
									   END,
                                       CASE ISNULL('{3}','')
									   WHEN ''
									   THEN (select A.DEPT_CD from HAA010T A where A.EMP_NO ='{2}')
									   ELSE '{3}'
									   END,
                                       '{4}',
                                       @START_TIME,
                                       @END_TIME,
                                       '{7}',
                                       GETDATE(),
                                       '{7}',
                                       GETDATE()
                                         
                                       
                                       )
                                       
                                       set @Row_NUM = @Row_NUM + 1
                                       END

                                    set @From = DATEADD(d,1,@From)

                                    END
                                     ",
                    dtPerFromTo.uniFromValue.Date.ToString().Trim(),
                    dtPerFromTo.uniToValue.Date.ToString().Trim(),
                    popEmpNo.CodeValue.ToString().Trim(),
                    popDeptCd.CodeValue.ToString().Trim(),
                    popFlexSys.CodeValue.ToString().Trim(),
                    uniDateTime1.Text.ToString().Trim(),
                    //uniDateTime1_bak.uniValue.ToString().Trim(),
                    uniDateTime2.Value.ToString().Trim(),
                    CommonVariable.gUsrID.ToString().Trim()

                    //this.uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["EMP_NO"].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true),
                    //this.uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["YYYY"].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true),
                    //this.uniBase.UCommon.FilterVariable(uniGrid1.)

                    //this.uniBase.UCommon.FilterVariable(uniCommand, "@EMP_NO", SqlDbType.NVarChar, popEmpNo.CodeValue.Trim());
                    //this.uniBase.UCommon.FilterVariable(uniCommand, "@DEPT_NO", SqlDbType.NVarChar, popDeptCd.CodeValue.Trim());
                    //this.uniBase.UCommon.FilterVariable(uniCommand, "@FLEX_SYS", SqlDbType.NVarChar, popFlexSys.CodeValue.Trim());
                    //this.uniBase.UCommon.FilterVariable(uniCommand, "@Work_From", SqlDbType.NVarChar, dtPerFr);
                    //this.uniBase.UCommon.FilterVariable(uniCommand, "@Work_To", SqlDbType.NVarChar, dtPerTo);
                    );

                DataSet dsSql = uniBase.UDataAccess.CommonQuerySQL(strQuery);

                //cqtdsEvalReg.E_PMS_PROJECT_RATE.Merge(dsSql.Tables[0], false, MissingSchemaAction.Ignore);
                //uniGrid1.uniGridSetDataBinding(cqtdsEvalReg.IS_EVAL_MAIN);


                DBQuery();
            }
        }

      

        private void uniGrid1_AfterCellUpdate(object sender, CellEventArgs e)
        {
           
         
        }

        private void popDeptCd_OnExitEditCode(object sender, EventArgs e)
        {
            if (popDeptCd.CodeValue == "")
            {
                popDeptCd.CodeName = "";
                return;
            }

            string[] UNISqlId = new string[] { "ZN_HR_EMP_NM4" };
            string[][] UNIValue = new string[1][];
            UNIValue[0] = new string[3];


            string strDate = uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD);

            //UNIValue[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            //UNIValue[0][1] = uniBase.UCommon.FilterVariable(strDate, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][0] = uniBase.UCommon.FilterVariable(popDeptCd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][1] = uniBase.UCommon.FilterVariable(popDeptCd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][2] = " ";

            DataSet pDataSet = null;


            try
            {
                pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                {
                    //uniBase.UMessage.DisplayMessageBox("810010", MessageBoxButtons.OK);
                    //popDeptCd.CodeName = "";
                    //popDeptCd.Focus();
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return;

                }
                popDeptCd.CodeValue = pDataSet.Tables[0].Rows[0]["DEPT_CD"].ToString();
                popDeptCd.CodeName = pDataSet.Tables[0].Rows[0]["DEPT_NM"].ToString();
                popEmpNo.CodeValue = "";
                popEmpNo.CodeName = "";
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
        }

        private void popFlexSys_BeforePopupOpen(object sender, AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "근무구분";
            e.PopupPassData.ConditionCaption = "근무구분";

            e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
            e.PopupPassData.SQLWhereStatements = "  MAJOR_CD ='XH006' ";
            e.PopupPassData.SQLWhereInputCodeValue = ""; // popPlantCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "근무구분";
            e.PopupPassData.GridCellCaption[1] = "근무구분명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popFlexSys_AfterPopupClosed(object sender, AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            uniOpenPopup popFlexSys = (uniOpenPopup)sender;
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popFlexSys.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popFlexSys.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }

        private void uniTBL_OuterMost_Paint(object sender, PaintEventArgs e)
        {

        }

        private void uniDateTime1_ValueChanged(object sender, EventArgs e)
        {

        }


        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        #endregion

        #endregion

    }
}