      
      
--���̺� ���� ����� ����      
      
/*              
--WT_FLEX_KO883             
DROP PROC usp_H4007M9_KO883_S               
DROP TYPE dbo.UTP_H4007M9_KO883              
CREATE TYPE dbo.UTP_H4007M9_KO883 AS TABLE              
(       
   
    WORK_DT  nvarchar(24) --5     
   ,EMP_NO  nvarchar(24)  -- 2  
   ,FLEX_SYS     nvarchar(12)  -- 4  
   ,START_TIME  nvarchar(24) --7      
   ,END_TIME  nvarchar(24) --8  
   ,CUD_CHAR   NVARCHAR(01) --15              
   ,ROW_NUM    INT    --16              
)              
*/              
/********************************************************************************************/              
/***** PROCEDURE NAME : usp_H4007M9_KO883_S          *****/              
/***** AUTHOR   : CHA            *****/              
/***** CREATE DATE  : 2021-02-18                *****/              
/***** DESCRIPTION  : �����ٹ������(S)              *****/               
/***** HISTORY   :                   *****/              
/********************************************************************************************/                        
CREATE PROCEDURE [dbo].[usp_H4007M9_KO883_S]                  
(                   
  @TBL_DATA   UTP_H4007M9_KO883 READONLY                  
, @USER_ID    NVARCHAR(13)                  
, @MSG_CD     NVARCHAR(06)  OUTPUT                  
, @MESSAGE    NVARCHAR(200)  OUTPUT                  
, @ERR_POS    INT     OUTPUT                  
)                  
AS                  
                  
BEGIN                  
 SET NOCOUNT ON                  
                  
 DECLARE                        
       
    @CUR_WORK_DT      nvarchar(24)  -- 1  
   ,@CUR_EMP_NO       nvarchar(24)  -- 2  
   ,@CUR_FLEX_SYS     nvarchar(12)  -- 4  
   ,@CUR_START_TIME   nvarchar(24)   -- 5  
   ,@CUR_END_TIME  nvarchar(24)   -- 6  
   ,@CUR_CUD_CHAR     NVARCHAR(01) --15              
   ,@CUR_ROW_NUM      INT    --16  
   ,@ERROR_NUMBER     INT     --17  
  
declare @START_TIME nvarchar(8);  
declare @END_TIME nvarchar(8);  
  
set @START_TIME =  CASE SUBSTRING(@CUR_START_TIME,12,2)  
       WHEN '����'  
       THEN convert(char(8),SUBSTRING(@CUR_START_TIME,15,8),108)  
       WHEN '����'  
       THEN  convert(char(8),convert(datetime,SUBSTRING(@CUR_START_TIME,15,8)) +'12:00:00' ,108)  
          END  
set @END_TIME =  CASE SUBSTRING(@CUR_END_TIME,12,2)  
     WHEN '����'  
     THEN convert(char(8),SUBSTRING(@CUR_END_TIME,15,8),108)  
     WHEN '����'  
     THEN  convert(char(8),convert(datetime,SUBSTRING(@CUR_END_TIME,15,8)) +'12:00:00' ,108)  
     END        
                  
  BEGIN TRY                  
  BEGIN TRANSACTION                  
                  
                   
  DECLARE Cur_WorkList CURSOR LOCAL FOR                  
                  
      
       
 SELECT  
                     
  
 A.WORK_DT        -- 1  
   ,A.EMP_NO         -- 2  
   ,A.FLEX_SYS       -- 4  
   ,A.START_TIME     -- 5  
   ,A.END_TIME      -- 6  
   ,A.CUD_CHAR       -- 15              
   ,A.ROW_NUM        -- 16   
                    
  FROM @TBL_DATA A                       
                  
  OPEN Cur_WorkList                   
  FETCH NEXT FROM Cur_WorkList                  
  INTO                   
    
   @CUR_WORK_DT       
  ,@CUR_EMP_NO         
  ,@CUR_FLEX_SYS      
  ,@CUR_START_TIME  
  ,@CUR_END_TIME           
  ,@CUR_CUD_CHAR      
  ,@CUR_ROW_NUM         
        
                        
  WHILE(@@FETCH_STATUS=0)                  
  BEGIN                  
   SET @ERR_POS = @CUR_ROW_NUM            
                  
  IF (@CUR_CUD_CHAR = 'C')                  
  BEGIN                  
           
    INSERT INTO WT_FLEX_KO883                  
    (                  
       WORK_DT       
   ,EMP_NO        
   ,DEPT_CD       
   ,FLEX_SYS      
   ,START_TIME    
   ,END_TIME   
   ,ISRT_EMP_NO   
   ,ISRT_DT       
   ,UPDT_EMP_NO   
   ,UPDT_DT         
      
    )                  
    VALUES                  
    (                  
          
      convert(char(10),Substring(@CUR_WORK_DT,1,10))       
  ,@CUR_EMP_NO        
  ,( SELECT DEPT_CD FROM haa010t WHERE EMP_NO = @CUR_EMP_NO)  
  ,@CUR_FLEX_SYS      
  ,convert(char(8),Substring(@CUR_START_TIME,12,8),108)  
     ,convert(char(8),Substring(@CUR_END_TIME,12,8),108)  
  ,@USER_ID   
  ,GETDATE()      
     ,@USER_ID  
  ,GETDATE()        
                      
    )                  
  END                  
  ELSE       
  IF (@CUR_CUD_CHAR = 'U')                      
  BEGIN                  
     UPDATE WT_FLEX_KO883      
    SET      
        
  
         WORK_DT   =  convert(char(10),Substring(@CUR_WORK_DT,1,10))     
     ,EMP_NO    = @CUR_EMP_NO     
     ,FLEX_SYS  = @CUR_FLEX_SYS    
     ,START_TIME = convert(char(8),Substring(@CUR_START_TIME,12,8),108)  
     ,END_TIME = convert(char(8),Substring(@CUR_END_TIME,12,8),108)  
     ,UPDT_EMP_NO  = @USER_ID  
     ,UPDT_DT      = GETDATE()  
  
       WHERE ISNULL(EMP_NO,'') = ISNULL(@CUR_EMP_NO,'') AND ISNULL(WORK_DT,'') = ISNULL(convert(char(10),Substring(@CUR_WORK_DT,1,10),23),'') AND ISNULL(FLEX_SYS,'') = ISNULL(@CUR_FLEX_SYS,'')  
      
        
                      
                  
  END                  
  ELSE IF (@CUR_CUD_CHAR = 'D')                  
  BEGIN                  
                      
    DELETE FROM WT_FLEX_KO883                   
    WHERE ISNULL(EMP_NO,'') = ISNULL(@CUR_EMP_NO,'') AND ISNULL(WORK_DT,'') = ISNULL(convert(char(10),Substring(@CUR_WORK_DT,1,10),23),'') AND ISNULL(FLEX_SYS,'') = ISNULL(@CUR_FLEX_SYS,'')   
                  
  END                  
              
           
                   
  FETCH NEXT FROM Cur_WorkList                  
  INTO                                
  
   @CUR_WORK_DT       
  ,@CUR_EMP_NO         
  ,@CUR_FLEX_SYS      
  ,@CUR_START_TIME    
  ,@CUR_END_TIME          
  ,@CUR_CUD_CHAR      
  ,@CUR_ROW_NUM  
                  
  END --WHILE END                  
                   
                  
 CLOSE Cur_WorkList                  
 DEALLOCATE Cur_WorkList                             
                  
 END TRY                  
 BEGIN CATCH                  
                   
 SET @ERROR_NUMBER = ERROR_NUMBER()                  
                    
  IF @ERROR_NUMBER = 2627  --%1! ���� ���� '%2!'��(��) �����߽��ϴ�. ��ü '%3!'�� �ߺ� Ű�� ������ �� �����ϴ�. �ߺ� Ű ���� %4!�Դϴ�.                  
   BEGIN                  
    SET @MSG_CD   = '970001' -- %1 ��(��) �̹� �����մϴ�.                     
   END                  
                  
  ELSE IF @ERROR_NUMBER = 547  -- %1! ���� %2! ���� ���� "%3!"��(��) �浹�߽��ϴ�. �����ͺ��̽� "%4!", ���̺� "%5!"%6!%7!%8!���� �浹�� �߻��߽��ϴ�.                  
   BEGIN                  
    SET @MSG_CD   = '971000' -- %1 ��(��) �����ϰ� �ִ� �����Ͱ� �ֽ��ϴ�. �۾��� ������ �� �����ϴ�.                       
   END                  
                  
  ELSE IF @ERROR_NUMBER = 1205  -- Ʈ�����(���μ��� ID %1!)�� %2! ���ҽ����� �ٸ� ���μ������� ���� ���°� �߻��Ͽ� ������ �����Ǿ����ϴ�. Ʈ������� �ٽ� �����Ͻʽÿ�.                  
   BEGIN                  
    SET @MSG_CD   = '122918' -- %1 ���忡 �����߽��ϴ�.                          
   END                  
                  
  ELSE                  
   SET @MESSAGE  = ERROR_MESSAGE()                  
                  
  GOTO __ERROR                  
 END CATCH                  
                  
 IF @@TRANCOUNT > 0 COMMIT TRANSACTION                  
 RETURN 1                  
                  
 __ERROR:                  
 IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION                  
 RETURN -1                  
END 