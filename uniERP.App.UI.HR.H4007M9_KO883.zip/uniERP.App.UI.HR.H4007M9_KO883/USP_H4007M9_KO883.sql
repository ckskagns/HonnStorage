--sp_helptext USP_H4007M2_KO883    
    
                      
                        
CREATE PROCEDURE [dbo].[USP_H4007M9_KO883]                        
 (              
 @EMP_NO nvarchar(26), -- ���            
 @DEPT_NO nvarchar(26), -- �μ���ȣ            
 @FLEX_SYS nvarchar(2), -- �ٹ�����            
 @Work_From nvarchar(26), -- �ٹ�����From               
 @Work_To  nvarchar(26)  -- �ٹ�����To            
 --@Start_Time nvarchar(8), -- ��ٽð�From               
 --@End_Time  nvarchar(8)  -- ��ٽð�To            
                         
 ) AS                                  
                            
 BEGIN                                                      
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                                
                                                   
SET NOCOUNT ON                                
            
  IF @Work_From IS NULL OR @Work_From = '' SET @Work_From ='1900-01-01'                 
  IF @Work_To IS NULL OR @Work_To = '' SET @Work_To ='2099-12-31'             
      
            
 --select * from WT_MA_KO883    
    
select a.EMP_NO, b.name, a.FLEX_SYS , c.minor_nm , a.WORK_DT , a.START_TIME , a.END_TIME  
 --, *    
from WT_FLEX_KO883 a(nolock)    
join haa010t b(nolock) on a.emp_no = b.emp_no    
join b_minor c(nolock) on c.major_cd = 'XH006' and  a.FLEX_SYS = c.minor_cd    
    
where             
( @EMP_NO ='' or A.EMP_NO = @EMP_NO )                  
and CONVERT (DATETIME, A.WORK_DT) BETWEEN  CONVERT (DATETIME, @Work_From) AND  CONVERT (DATETIME, @Work_To )     
and (@DEPT_NO = '' or B.DEPT_CD = @DEPT_NO)         
and (@FLEX_SYS = '' or C.MINOR_CD = @FLEX_SYS)         
    
            
 order by a.EMP_NO,a.WORK_DT     
    
 END         