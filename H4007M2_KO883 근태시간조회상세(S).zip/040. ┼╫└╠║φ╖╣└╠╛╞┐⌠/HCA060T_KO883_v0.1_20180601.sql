USE [PAM]
GO

/****** Object:  Table [dbo].[HCA060T_KO883]    Script Date: 2018-06-01 ���� 3:49:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[HCA060T_KO883](
	[EMP_NO] [nvarchar](13) NOT NULL,
	[DILIG_DT] [datetime] NOT NULL,
	[DILIG_CD] [nvarchar](2) NOT NULL,
	[DILIG_CNT] [numeric](3, 0) NOT NULL,
	[DILIG_HH] [numeric](3, 0) NOT NULL,
	[DILIG_MM] [numeric](2, 0) NOT NULL,
	[CONF_YN] [nchar](1) NOT NULL,
	[ISRT_DT] [datetime] NOT NULL,
	[ISRT_EMP_NO] [nvarchar](13) NOT NULL,
	[UPDT_DT] [datetime] NOT NULL,
	[UPDT_EMP_NO] [nvarchar](13) NOT NULL,
	[REMARK] [nvarchar](1000) NOT NULL,
	[EXT1_TXT] [nvarchar](100) NULL,
	[EXT2_TXT] [nvarchar](100) NULL,
	[EXT3_TXT] [nvarchar](100) NULL,
	[EXT4_TXT] [nvarchar](100) NULL,
	[EXT1_AMT] [numeric](18, 4) NULL,
	[EXT2_AMT] [numeric](18, 4) NULL,
	[EXT1_DT] [datetime] NULL,
	[EXT2_DT] [datetime] NULL,
 CONSTRAINT [PK_HCA060T_KO883] PRIMARY KEY CLUSTERED 
(
	[EMP_NO] ASC,
	[DILIG_DT] ASC,
	[DILIG_CD] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[HCA060T_KO883] ADD  DEFAULT ((1)) FOR [DILIG_CNT]
GO

ALTER TABLE [dbo].[HCA060T_KO883] ADD  DEFAULT ((0)) FOR [DILIG_HH]
GO

ALTER TABLE [dbo].[HCA060T_KO883] ADD  DEFAULT ((0)) FOR [DILIG_MM]
GO

ALTER TABLE [dbo].[HCA060T_KO883] ADD  DEFAULT (getdate()) FOR [ISRT_DT]
GO

ALTER TABLE [dbo].[HCA060T_KO883] ADD  DEFAULT (getdate()) FOR [UPDT_DT]
GO


