﻿
SET NOCOUNT ON;
---------------------------------------------------------------------------------------------------------------------------
--	FILE NAME	: HR_INS_DD_POPUP_20180605_HSY.sql
--	MODULE		: HR
--	DATE		: 2018-06-05
--	Modifier	: HSY
---------------------------------------------------------------------------------------------------------------------------
DELETE
FROM
	V27AdminDB..DD_POPUP_GRID_INFO
WHERE
	ParentPID IN (
'uniERP.App.UI.HR.H4006M1_KO883'
)

DELETE
FROM
	V27AdminDB..DD_POPUP_MASTER_INFO
WHERE
	ParentPID IN (
'uniERP.App.UI.HR.H4006M1_KO883'
)
---------------------------------------------------------------------------------------------------------------------------
-----Start  DD Popup DML   ParentPID = 'uniERP.App.UI.HR.H4006M1_KO883'-----------------------------------------------------------------------------

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'popCd'	,''	,1	,N'근태'
	,N'Attendance'	,N'出勤'	,N'Attendance'	,'2007-10-25'	,'2015-05-20'
	,NULL	,N'Chuyên cần'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'popCd'	,''	,2	,N'근태'
	,N'Attendance'	,N'出勤'	,N'Attendance'	,'2007-10-25'	,'2015-05-20'
	,NULL	,N'Chuyên cần'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'popEmpNo'	,''	,3	,N'사원'
	,N'Employee'	,N'员工'	,N'Employee PopUp'	,'2008-03-11'	,'2015-05-20'
	,NULL	,N'Nhân viên'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'popToDeptNm'	,''	,3	,N'부서'
	,N'Department Popup'	,N'Department Popup'	,N'Department Popup'	,'2010-05-19'	,'2015-05-20'
	,NULL	,N'Bộ phận'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'uniGrid1'	,'dilig_cd'	,1	,N'근태'
	,N'Attendance'	,N'出勤'	,N'Attendance'	,'2008-02-29'	,'2015-05-20'
	,NULL	,N'Chuyên cần'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'uniGrid1'	,'dilig_cd'	,2	,N'근태'
	,N'Attendance'	,N'出勤'	,N'Attendance'	,'2008-02-29'	,'2015-05-20'
	,NULL	,N'Chuyên cần'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'uniGrid1'	,'emp_no'	,3	,N'사원'
	,N'Employee'	,N'员工'	,N'Employee PopUp'	,'2008-03-11'	,'2015-05-20'
	,NULL	,N'Nhân viên'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'popCd'	,''	,0	,'dilig_cd'
	,'Edit'	,N'근태코드'	,N'Attendance Code'	,N'出勤代码'	,N'Attendance Code'
	,'2007-10-25'	,'2015-05-20'	,NULL	,N'Mã chuyên cần'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'popCd'	,''	,1	,'dilig_nm'
	,'Edit'	,N'근태명'	,N'Attendance Code Name'	,N'出勤名称'	,N'Attendance Code Name'
	,'2007-10-25'	,'2015-05-20'	,NULL	,N'Tên chuyên cần'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'popCd'	,''	,2	,'day_time'
	,'Edit'	,N'일수/시간'	,N'Day/hour/half-day Offe'	,N'日数/时间'	,N'Days/hour/half-day Offe'
	,'2007-10-25'	,'2015-05-20'	,NULL	,N'Số ngày/giờ'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'uniGrid1'	,'dilig_cd'	,0	,'dilig_cd'
	,'Edit'	,N'근태코드'	,N'Attendance Code'	,N'出勤代码'	,N'Attendance Code'
	,'2008-02-29'	,'2015-05-20'	,NULL	,N'Mã chuyên cần'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'uniGrid1'	,'dilig_cd'	,1	,'dilig_nm'
	,'Edit'	,N'근태명'	,N'Attendance Code Name'	,N'出勤名称'	,N'Attendance Code Name'
	,'2008-02-29'	,'2015-05-20'	,NULL	,N'Tên chuyên cần'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'uniGrid1'	,'dilig_cd'	,2	,'day_time'
	,'Edit'	,N'일수/시간'	,N'Day/hour/half-day Offe'	,N'日数/时间'	,N'Days/hour/half-day Offe'
	,'2008-02-29'	,'2015-05-20'	,NULL	,N'Số ngày/giờ'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.HR.H4006M1_KO883'	,'uniGrid1'	,'dilig_cd'	,2	,'day_time_type'
	,'Edit'	,N'일수/시간'	,N'Days/Hours_type'	,N'Days/Hours_type'	,N'Days/Hours_type'
	,'2008-04-03'	,'2015-05-20'	,NULL	,N'Loại ngày/giờ'
)
-----End    DD Popup DML   ParentPID = 'uniERP.App.UI.HR.H4006M1_KO883'-----------------------------------------------------------------------------