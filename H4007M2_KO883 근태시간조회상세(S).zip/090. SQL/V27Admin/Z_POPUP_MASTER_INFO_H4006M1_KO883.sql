
SET NOCOUNT ON;
---------------------------------------------------------------------------------------------------------------------------
--	FILE NAME	: HR_INS_Z_POPUP_MASTER_INFO_20180605_HSY.sql
--	MODULE		: HR
--	DATE		: 2018-06-05
--	Modifier	: HSY
---------------------------------------------------------------------------------------------------------------------------

DELETE
FROM
	Z_POPUP_MASTER_INFO
WHERE
	PARENTPID LIKE '%H4006M1_KO883'
---------------------------------------------------------------------------------------------------------------------------

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.HR.H4006M1_KO883'	,N'popCd'	,N''	,''	,''
	,'Y'	,'N'	,N'LK'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,NULL	,NULL	,NULL
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.HR.H4006M1_KO883'	,N'popEmpNo'	,N''	,''	,'ZN_HR_EMP_NM2'
	,'Y'	,'N'	,N'  '	,N'Y'	,''
	,''	,'N'	,100	,N'C'	,0
	,0	,NULL	,NULL	,NULL
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.HR.H4006M1_KO883'	,N'popFrDeptNm'	,N''	,''	,'ZN_HR_DEPT_NM'
	,'Y'	,'N'	,N'  '	,N'Y'	,''
	,''	,'N'	,100	,N'C'	,0
	,0	,NULL	,NULL	,NULL
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.HR.H4006M1_KO883'	,N'popToDeptNm'	,N''	,''	,'ZN_HR_DEPT_NM'
	,'Y'	,'N'	,N'  '	,N'Y'	,''
	,''	,'N'	,100	,N'C'	,0
	,0	,NULL	,NULL	,NULL
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.HR.H4006M1_KO883'	,N'uniGrid1'	,N'dilig_cd'	,'dilig_nm'	,NULL
	,'Y'	,'N'	,N'GE'	,N'Y'	,NULL
	,NULL	,NULL	,100	,N'C'	,NULL
	,NULL	,NULL	,NULL	,NULL
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.HR.H4006M1_KO883'	,N'uniGrid1'	,N'emp_no'	,'name'	,'ZN_HR_EMP_NM2'
	,'Y'	,'N'	,N'  '	,N'Y'	,''
	,''	,'N'	,100	,N'C'	,0
	,0	,NULL	,NULL	,NULL
)