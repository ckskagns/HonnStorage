              
                
ALTER PROCEDURE [dbo].[USP_H4007M2_KO883_Q]                
 (      
 @EMP_NO nvarchar(26), -- ���    
 @DEPT_NO nvarchar(26), -- �μ���ȣ    
 @Work_From nvarchar(26), -- �ٹ�����From       
    @Work_To  nvarchar(26)  -- �ٹ�����To    
                 
 ) AS                          
                    
 BEGIN                                              
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                        
                                           
SET NOCOUNT ON                        
    
  IF @Work_From IS NULL OR @Work_From = '' SET @Work_From ='1900-01-01'         
  IF @Work_To IS NULL OR @Work_To = '' SET @Work_To ='2099-12-31'     
    
select     
     A.EMP_NO		
    ,A.NAME		
    ,A.ROLL_PSTN_NM  
    ,A.DEPT_NM		
    ,A.WORK_DT		
    ,A.DAY_WEEK		
    ,A.START_TIME		
    ,A.END_TIME		
    , CASE ISNULL(A.TOT_TIME,'')
	      WHEN ''
		  THEN convert(char(8),'00:00:00',108)
		  ELSE CASE 
		       WHEN convert(char(8),A.TOT_TIME,108) like '%-%'  -- ���̳ʽ� �ٹ��ð����ǰ�� 00��00������ �ʱ�ȭ
			   THEN convert(char(8),'00:00:00',108)
			   ELSE A.TOT_TIME		
			   END
		  END as TOT_TIME
    ,A.OT		
    ,A.HT		
    ,A.TT		
    ,A.ETC1
	,A.ETC2	 
from WT_SG1_KO883 A
join HAA010T B on A.EMP_NO = B.EMP_NO    

    
where     
( @EMP_NO ='' or A.EMP_NO = @EMP_NO )    
and (@DEPT_NO = '' or B.DEPT_CD = @DEPT_NO)        
and CONVERT (DATETIME, A.WORK_DT) BETWEEN  CONVERT (DATETIME, @Work_From) AND  CONVERT (DATETIME, @Work_To )        

    
 order by WORK_DT ASC    
                
 END 

 --select * from WT_MA_KO883