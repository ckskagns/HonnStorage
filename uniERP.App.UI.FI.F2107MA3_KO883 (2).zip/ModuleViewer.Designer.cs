﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.FI.F2107MA3_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem2 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem3 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem4 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance37 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance38 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance39 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance40 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance41 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance42 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance43 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance44 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance45 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.Rdo_Type2 = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.popBdgcd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popDeptCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblbdgcd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblType2 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblType1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDeptCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblYear = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.DtYear = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.Rdo_Type1 = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid4 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniGrid3 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniGrid2 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Rdo_Type2)).BeginInit();
            this.popDeptCd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_a5d65465_24ca_4a0f_b577_82820a1da092)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DtYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rdo_Type1)).BeginInit();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.uniTBL_OuterMost.SuspendLayout();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.PathInfo;
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.DefaultRowSize = 23;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(957, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.Rdo_Type2, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.popBdgcd, 1, 3);
            this.uniTBL_MainCondition.Controls.Add(this.popDeptCd, 4, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblbdgcd, 0, 3);
            this.uniTBL_MainCondition.Controls.Add(this.lblType2, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblType1, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblDeptCd, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblYear, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.DtYear, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.Rdo_Type1, 1, 1);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 4;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(957, 109);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // Rdo_Type2
            // 
            this.Rdo_Type2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Rdo_Type2.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.Rdo_Type2.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            valueListItem1.DataValue = "";
            valueListItem1.DisplayText = "월별";
            valueListItem2.DataValue = "A";
            valueListItem2.DisplayText = "분기별";
            this.Rdo_Type2.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1,
            valueListItem2});
            this.Rdo_Type2.ItemSpacingHorizontal = 30;
            this.Rdo_Type2.ItemSpacingVertical = 10;
            this.Rdo_Type2.Location = new System.Drawing.Point(133, 59);
            this.Rdo_Type2.LockedField = false;
            this.Rdo_Type2.Margin = new System.Windows.Forms.Padding(0, 4, 1, 0);
            this.Rdo_Type2.Name = "Rdo_Type2";
            this.Rdo_Type2.RequiredField = false;
            this.Rdo_Type2.Size = new System.Drawing.Size(234, 21);
            this.Rdo_Type2.StyleSetName = "Default";
            this.Rdo_Type2.TabIndex = 26;
            this.Rdo_Type2.uniALT = null;
            // 
            // popBdgcd
            // 
            this.popBdgcd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popBdgcd.AutoPopupCodeParameter = null;
            this.popBdgcd.AutoPopupID = null;
            this.popBdgcd.AutoPopupNameParameter = null;
            this.popBdgcd.CodeMaxLength = 10;
            this.popBdgcd.CodeName = "";
            this.popBdgcd.CodeSize = 100;
            this.popBdgcd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBdgcd.CodeTextBoxName = null;
            this.popBdgcd.CodeValue = "";
            this.popBdgcd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popBdgcd.Location = new System.Drawing.Point(133, 84);
            this.popBdgcd.LockedField = false;
            this.popBdgcd.Margin = new System.Windows.Forms.Padding(0);
            this.popBdgcd.Name = "popBdgcd";
            this.popBdgcd.NameDisplay = true;
            this.popBdgcd.NameId = null;
            this.popBdgcd.NameMaxLength = 50;
            this.popBdgcd.NamePopup = false;
            this.popBdgcd.NameSize = 150;
            this.popBdgcd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBdgcd.Parameter = null;
            this.popBdgcd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popBdgcd.PopupId = null;
            this.popBdgcd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popBdgcd.QueryIfEnterKeyPressed = true;
            this.popBdgcd.RequiredField = false;
            this.popBdgcd.Size = new System.Drawing.Size(271, 21);
            this.popBdgcd.TabIndex = 24;
            this.popBdgcd.uniALT = "Dept";
            this.popBdgcd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popBdgcd.UseDynamicFormat = false;
            this.popBdgcd.ValueTextBoxName = null;
            this.popBdgcd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popBdgcd_BeforePopupOpen);
            this.popBdgcd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popBdgcd_AfterPopupClosed);
            this.popBdgcd.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popBdgcd_OnExitEditCode);
            // 
            // popDeptCd
            // 
            this.popDeptCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popDeptCd.AutoPopupCodeParameter = null;
            this.popDeptCd.AutoPopupID = null;
            this.popDeptCd.AutoPopupNameParameter = null;
            this.popDeptCd.CodeMaxLength = 10;
            this.popDeptCd.CodeName = "";
            this.popDeptCd.CodeSize = 100;
            this.popDeptCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDeptCd.CodeTextBoxName = null;
            this.popDeptCd.CodeValue = "";
            this.popDeptCd.Controls.Add(this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044);
            this.popDeptCd.Controls.Add(this.object_a5d65465_24ca_4a0f_b577_82820a1da092);
            this.popDeptCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popDeptCd.Location = new System.Drawing.Point(610, 34);
            this.popDeptCd.LockedField = false;
            this.popDeptCd.Margin = new System.Windows.Forms.Padding(0);
            this.popDeptCd.Name = "popDeptCd";
            this.popDeptCd.NameDisplay = true;
            this.popDeptCd.NameId = null;
            this.popDeptCd.NameMaxLength = 50;
            this.popDeptCd.NamePopup = false;
            this.popDeptCd.NameSize = 150;
            this.popDeptCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDeptCd.Parameter = null;
            this.popDeptCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popDeptCd.PopupId = null;
            this.popDeptCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popDeptCd.QueryIfEnterKeyPressed = true;
            this.popDeptCd.RequiredField = false;
            this.popDeptCd.Size = new System.Drawing.Size(271, 21);
            this.popDeptCd.TabIndex = 19;
            this.popDeptCd.uniALT = "Dept";
            this.popDeptCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popDeptCd.UseDynamicFormat = false;
            this.popDeptCd.ValueTextBoxName = null;
            this.popDeptCd.OnChange += new System.EventHandler(this.popDeptCd_OnChange);
            this.popDeptCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDeptCd_BeforePopupOpen);
            this.popDeptCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDeptCd_AfterPopupClosed);
            // 
            // object_d9fcbe89_f0d3_4187_9be7_328ecada0044
            // 
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Appearance = appearance1;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.AutoSize = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Location = new System.Drawing.Point(121, 0);
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.LockedField = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Margin = new System.Windows.Forms.Padding(0);
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.MaxLength = 50;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Name = "object_d9fcbe89_f0d3_4187_9be7_328ecada0044";
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.QueryIfEnterKeyPressed = true;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.ReadOnly = true;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.RequiredField = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Size = new System.Drawing.Size(150, 21);
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.StyleSetName = "Lock";
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.TabIndex = 0;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.TabStop = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.uniALT = null;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.UseDynamicFormat = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.WordWrap = false;
            // 
            // object_a5d65465_24ca_4a0f_b577_82820a1da092
            // 
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Appearance = appearance2;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.AutoSize = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Location = new System.Drawing.Point(0, 0);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.LockedField = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Margin = new System.Windows.Forms.Padding(0);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.MaxLength = 10;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Name = "object_a5d65465_24ca_4a0f_b577_82820a1da092";
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.QueryIfEnterKeyPressed = true;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.RequiredField = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Size = new System.Drawing.Size(100, 21);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.StyleSetName = "Default";
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.TabIndex = 0;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.uniALT = null;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.UseDynamicFormat = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.WordWrap = false;
            // 
            // lblbdgcd
            // 
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.lblbdgcd.Appearance = appearance3;
            this.lblbdgcd.AutoPopupID = null;
            this.lblbdgcd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblbdgcd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblbdgcd.Location = new System.Drawing.Point(15, 81);
            this.lblbdgcd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblbdgcd.Name = "lblbdgcd";
            this.lblbdgcd.Size = new System.Drawing.Size(118, 24);
            this.lblbdgcd.StyleSetName = "Default";
            this.lblbdgcd.TabIndex = 15;
            this.lblbdgcd.Text = "예산코드";
            this.lblbdgcd.UseMnemonic = false;
            // 
            // lblType2
            // 
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.lblType2.Appearance = appearance4;
            this.lblType2.AutoPopupID = null;
            this.lblType2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblType2.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblType2.Location = new System.Drawing.Point(15, 56);
            this.lblType2.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblType2.Name = "lblType2";
            this.lblType2.Size = new System.Drawing.Size(118, 24);
            this.lblType2.StyleSetName = "Default";
            this.lblType2.TabIndex = 14;
            this.lblType2.Text = "월구분";
            this.lblType2.UseMnemonic = false;
            // 
            // lblType1
            // 
            appearance5.TextHAlignAsString = "Left";
            appearance5.TextVAlignAsString = "Middle";
            this.lblType1.Appearance = appearance5;
            this.lblType1.AutoPopupID = null;
            this.lblType1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblType1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblType1.Location = new System.Drawing.Point(15, 31);
            this.lblType1.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblType1.Name = "lblType1";
            this.lblType1.Size = new System.Drawing.Size(118, 24);
            this.lblType1.StyleSetName = "Default";
            this.lblType1.TabIndex = 10;
            this.lblType1.Text = "부서구분";
            this.lblType1.UseMnemonic = false;
            // 
            // lblDeptCd
            // 
            appearance6.TextHAlignAsString = "Left";
            appearance6.TextVAlignAsString = "Middle";
            this.lblDeptCd.Appearance = appearance6;
            this.lblDeptCd.AutoPopupID = null;
            this.lblDeptCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDeptCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDeptCd.Location = new System.Drawing.Point(492, 31);
            this.lblDeptCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDeptCd.Name = "lblDeptCd";
            this.lblDeptCd.Size = new System.Drawing.Size(118, 24);
            this.lblDeptCd.StyleSetName = "Default";
            this.lblDeptCd.TabIndex = 4;
            this.lblDeptCd.Text = "부서";
            this.lblDeptCd.UseMnemonic = false;
            // 
            // lblYear
            // 
            appearance7.TextHAlignAsString = "Left";
            appearance7.TextVAlignAsString = "Middle";
            this.lblYear.Appearance = appearance7;
            this.lblYear.AutoPopupID = null;
            this.lblYear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblYear.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblYear.Location = new System.Drawing.Point(15, 6);
            this.lblYear.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(118, 24);
            this.lblYear.StyleSetName = "Default";
            this.lblYear.TabIndex = 13;
            this.lblYear.Text = "예산년도";
            this.lblYear.UseMnemonic = false;
            // 
            // DtYear
            // 
            this.DtYear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance8.TextHAlignAsString = "Center";
            this.DtYear.Appearance = appearance8;
            this.DtYear.DateTime = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            this.DtYear.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.DtYear.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.DtYear.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.DtYear.Location = new System.Drawing.Point(133, 6);
            this.DtYear.LockedField = false;
            this.DtYear.Margin = new System.Windows.Forms.Padding(0);
            this.DtYear.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.DtYear.Name = "DtYear";
            this.DtYear.QueryIfEnterKeyPressed = true;
            this.DtYear.RequiredField = false;
            this.DtYear.Size = new System.Drawing.Size(70, 24);
            this.DtYear.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.DtYear.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYY;
            this.DtYear.StyleSetName = "Default";
            this.DtYear.TabIndex = 23;
            this.DtYear.uniALT = null;
            this.DtYear.uniValue = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            this.DtYear.Value = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            // 
            // Rdo_Type1
            // 
            this.Rdo_Type1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Rdo_Type1.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.Rdo_Type1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            valueListItem3.DataValue = "";
            valueListItem3.DisplayText = "전체";
            valueListItem4.DataValue = "A";
            valueListItem4.DisplayText = "부서별";
            this.Rdo_Type1.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem3,
            valueListItem4});
            this.Rdo_Type1.ItemSpacingHorizontal = 30;
            this.Rdo_Type1.ItemSpacingVertical = 10;
            this.Rdo_Type1.Location = new System.Drawing.Point(133, 34);
            this.Rdo_Type1.LockedField = false;
            this.Rdo_Type1.Margin = new System.Windows.Forms.Padding(0, 4, 1, 0);
            this.Rdo_Type1.Name = "Rdo_Type1";
            this.Rdo_Type1.RequiredField = false;
            this.Rdo_Type1.Size = new System.Drawing.Size(234, 21);
            this.Rdo_Type1.StyleSetName = "Default";
            this.Rdo_Type1.TabIndex = 25;
            this.Rdo_Type1.uniALT = null;
            this.Rdo_Type1.ValueChanged += new System.EventHandler(this.Rdo_Type1_ValueChanged);
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid4, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.uniGrid3, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.uniGrid2, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 144);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(957, 465);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 0;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid4
            // 
            this.uniGrid4.AddEmptyRow = false;
            this.uniGrid4.DirectPaste = false;
            appearance9.BackColor = System.Drawing.SystemColors.Window;
            appearance9.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid4.DisplayLayout.Appearance = appearance9;
            this.uniGrid4.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid4.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance10.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance10.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid4.DisplayLayout.GroupByBox.Appearance = appearance10;
            appearance11.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid4.DisplayLayout.GroupByBox.BandLabelAppearance = appearance11;
            this.uniGrid4.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance12.BackColor2 = System.Drawing.SystemColors.Control;
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance12.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid4.DisplayLayout.GroupByBox.PromptAppearance = appearance12;
            this.uniGrid4.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid4.DisplayLayout.MaxRowScrollRegions = 1;
            appearance13.BackColor = System.Drawing.SystemColors.Window;
            appearance13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid4.DisplayLayout.Override.ActiveCellAppearance = appearance13;
            this.uniGrid4.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid4.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid4.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance14.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid4.DisplayLayout.Override.CardAreaAppearance = appearance14;
            appearance15.BorderColor = System.Drawing.Color.Silver;
            appearance15.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid4.DisplayLayout.Override.CellAppearance = appearance15;
            this.uniGrid4.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid4.DisplayLayout.Override.CellPadding = 0;
            appearance16.BackColor = System.Drawing.SystemColors.Control;
            appearance16.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance16.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance16.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid4.DisplayLayout.Override.GroupByRowAppearance = appearance16;
            appearance17.TextHAlignAsString = "Left";
            this.uniGrid4.DisplayLayout.Override.HeaderAppearance = appearance17;
            this.uniGrid4.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid4.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance18.BackColor = System.Drawing.SystemColors.Window;
            appearance18.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid4.DisplayLayout.Override.RowAppearance = appearance18;
            this.uniGrid4.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance19.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid4.DisplayLayout.Override.TemplateAddRowAppearance = appearance19;
            this.uniGrid4.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid4.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid4.EnableContextMenu = true;
            this.uniGrid4.EnableGridInfoContextMenu = true;
            this.uniGrid4.ExceptInExcel = false;
            this.uniGrid4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid4.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid4.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid4.Location = new System.Drawing.Point(0, 40);
            this.uniGrid4.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid4.Name = "uniGrid4";
            this.uniGrid4.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid4.PopupDeleteMenuVisible = true;
            this.uniGrid4.PopupInsertMenuVisible = true;
            this.uniGrid4.PopupUndoMenuVisible = true;
            this.uniGrid4.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid4.ShowHeaderCheck = true;
            this.uniGrid4.Size = new System.Drawing.Size(957, 20);
            this.uniGrid4.StyleSetName = "uniGrid_Query";
            this.uniGrid4.TabIndex = 3;
            this.uniGrid4.Text = "uniGrid4";
            this.uniGrid4.UseDynamicFormat = false;
            // 
            // uniGrid3
            // 
            this.uniGrid3.AddEmptyRow = false;
            this.uniGrid3.DirectPaste = false;
            appearance20.BackColor = System.Drawing.SystemColors.Window;
            appearance20.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid3.DisplayLayout.Appearance = appearance20;
            this.uniGrid3.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid3.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance21.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance21.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance21.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid3.DisplayLayout.GroupByBox.Appearance = appearance21;
            appearance22.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid3.DisplayLayout.GroupByBox.BandLabelAppearance = appearance22;
            this.uniGrid3.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance23.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance23.BackColor2 = System.Drawing.SystemColors.Control;
            appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance23.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid3.DisplayLayout.GroupByBox.PromptAppearance = appearance23;
            this.uniGrid3.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid3.DisplayLayout.MaxRowScrollRegions = 1;
            appearance24.BackColor = System.Drawing.SystemColors.Window;
            appearance24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid3.DisplayLayout.Override.ActiveCellAppearance = appearance24;
            this.uniGrid3.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid3.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid3.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance25.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid3.DisplayLayout.Override.CardAreaAppearance = appearance25;
            appearance26.BorderColor = System.Drawing.Color.Silver;
            appearance26.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid3.DisplayLayout.Override.CellAppearance = appearance26;
            this.uniGrid3.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid3.DisplayLayout.Override.CellPadding = 0;
            appearance27.BackColor = System.Drawing.SystemColors.Control;
            appearance27.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance27.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance27.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid3.DisplayLayout.Override.GroupByRowAppearance = appearance27;
            appearance28.TextHAlignAsString = "Left";
            this.uniGrid3.DisplayLayout.Override.HeaderAppearance = appearance28;
            this.uniGrid3.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid3.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance29.BackColor = System.Drawing.SystemColors.Window;
            appearance29.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid3.DisplayLayout.Override.RowAppearance = appearance29;
            this.uniGrid3.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance30.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid3.DisplayLayout.Override.TemplateAddRowAppearance = appearance30;
            this.uniGrid3.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid3.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid3.EnableContextMenu = true;
            this.uniGrid3.EnableGridInfoContextMenu = true;
            this.uniGrid3.ExceptInExcel = false;
            this.uniGrid3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid3.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid3.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid3.Location = new System.Drawing.Point(0, 60);
            this.uniGrid3.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid3.Name = "uniGrid3";
            this.uniGrid3.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid3.PopupDeleteMenuVisible = true;
            this.uniGrid3.PopupInsertMenuVisible = true;
            this.uniGrid3.PopupUndoMenuVisible = true;
            this.uniGrid3.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid3.ShowHeaderCheck = true;
            this.uniGrid3.Size = new System.Drawing.Size(957, 405);
            this.uniGrid3.StyleSetName = "uniGrid_Query";
            this.uniGrid3.TabIndex = 2;
            this.uniGrid3.Text = "uniGrid3";
            this.uniGrid3.UseDynamicFormat = false;
            // 
            // uniGrid2
            // 
            this.uniGrid2.AddEmptyRow = false;
            this.uniGrid2.DirectPaste = false;
            appearance31.BackColor = System.Drawing.SystemColors.Window;
            appearance31.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid2.DisplayLayout.Appearance = appearance31;
            this.uniGrid2.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid2.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance32.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance32.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance32.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.GroupByBox.Appearance = appearance32;
            appearance33.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.BandLabelAppearance = appearance33;
            this.uniGrid2.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance34.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance34.BackColor2 = System.Drawing.SystemColors.Control;
            appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance34.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.PromptAppearance = appearance34;
            this.uniGrid2.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid2.DisplayLayout.MaxRowScrollRegions = 1;
            appearance35.BackColor = System.Drawing.SystemColors.Window;
            appearance35.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid2.DisplayLayout.Override.ActiveCellAppearance = appearance35;
            this.uniGrid2.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid2.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid2.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance36.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.CardAreaAppearance = appearance36;
            appearance37.BorderColor = System.Drawing.Color.Silver;
            appearance37.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid2.DisplayLayout.Override.CellAppearance = appearance37;
            this.uniGrid2.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid2.DisplayLayout.Override.CellPadding = 0;
            appearance38.BackColor = System.Drawing.SystemColors.Control;
            appearance38.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance38.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance38.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.GroupByRowAppearance = appearance38;
            appearance39.TextHAlignAsString = "Left";
            this.uniGrid2.DisplayLayout.Override.HeaderAppearance = appearance39;
            this.uniGrid2.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid2.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance40.BackColor = System.Drawing.SystemColors.Window;
            appearance40.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid2.DisplayLayout.Override.RowAppearance = appearance40;
            this.uniGrid2.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance41.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid2.DisplayLayout.Override.TemplateAddRowAppearance = appearance41;
            this.uniGrid2.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid2.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid2.EnableContextMenu = true;
            this.uniGrid2.EnableGridInfoContextMenu = true;
            this.uniGrid2.ExceptInExcel = false;
            this.uniGrid2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid2.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid2.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid2.Location = new System.Drawing.Point(0, 0);
            this.uniGrid2.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid2.Name = "uniGrid2";
            this.uniGrid2.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid2.PopupDeleteMenuVisible = true;
            this.uniGrid2.PopupInsertMenuVisible = true;
            this.uniGrid2.PopupUndoMenuVisible = true;
            this.uniGrid2.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid2.ShowHeaderCheck = true;
            this.uniGrid2.Size = new System.Drawing.Size(957, 20);
            this.uniGrid2.StyleSetName = "uniGrid_Query";
            this.uniGrid2.TabIndex = 1;
            this.uniGrid2.Text = "uniGrid2";
            this.uniGrid2.UseDynamicFormat = false;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance42.BackColor = System.Drawing.SystemColors.Window;
            appearance42.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance42;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance43.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance43.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance43.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance43;
            appearance44.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance44;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance45.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance45.BackColor2 = System.Drawing.SystemColors.Control;
            appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance45.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance45;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance46.BackColor = System.Drawing.SystemColors.Window;
            appearance46.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance46;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance47.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance47;
            appearance48.BorderColor = System.Drawing.Color.Silver;
            appearance48.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance48;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance49.BackColor = System.Drawing.SystemColors.Control;
            appearance49.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance49.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance49.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance49;
            appearance50.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance50;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance51.BackColor = System.Drawing.SystemColors.Window;
            appearance51.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance51;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance52.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance52;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 20);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(957, 20);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.uniGrid1_BeforePopupOpen);
            this.uniGrid1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.uniGrid1_AfterPopupClosed);
            this.uniGrid1.AfterCellUpdate += new Infragistics.Win.UltraWinGrid.CellEventHandler(this.uniGrid1_AfterCellUpdate);
            this.uniGrid1.AfterExitEditMode += new System.EventHandler(this.uniGrid1_AfterExitEditMode);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 12);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 6;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 109F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 19F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(957, 628);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            this.uniTBL_OuterMost.Paint += new System.Windows.Forms.PaintEventHandler(this.uniTBL_OuterMost_Paint);
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(969, 652);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Rdo_Type2)).EndInit();
            this.popDeptCd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_a5d65465_24ca_4a0f_b577_82820a1da092)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DtYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rdo_Type1)).EndInit();
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private AppFramework.UI.Controls.uniRadioButton Rdo_Type2;
        private AppFramework.UI.Controls.uniOpenPopup popBdgcd;
        private AppFramework.UI.Controls.uniOpenPopup popDeptCd;
        private AppFramework.UI.Controls.uniTextBox object_d9fcbe89_f0d3_4187_9be7_328ecada0044;
        private AppFramework.UI.Controls.uniTextBox object_a5d65465_24ca_4a0f_b577_82820a1da092;
        private AppFramework.UI.Controls.uniLabel lblbdgcd;
        private AppFramework.UI.Controls.uniLabel lblType2;
        private AppFramework.UI.Controls.uniLabel lblType1;
        private AppFramework.UI.Controls.uniLabel lblDeptCd;
        private AppFramework.UI.Controls.uniLabel lblYear;
        private AppFramework.UI.Controls.uniDateTime DtYear;
        private AppFramework.UI.Controls.uniRadioButton Rdo_Type1;
        private AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private AppFramework.UI.Controls.uniGrid uniGrid4;
        private AppFramework.UI.Controls.uniGrid uniGrid3;
        private AppFramework.UI.Controls.uniGrid uniGrid2;
        private AppFramework.UI.Controls.uniGrid uniGrid1;



    }
}
