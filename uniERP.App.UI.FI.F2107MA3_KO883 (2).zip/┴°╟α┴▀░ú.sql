-- EXEC USP_F2107MA2_KO883 'A', '', '2021', '',''  
-- DROP PROCEDURE DBO.[USP_F2107MA2_KO883]                                    
-- GO                                    
/********************************************************************/                                    
/*****    PROC NAME   :  [USP_F2107MA2_KO883]        *****/                                    
/*****    ���α׷�    :  USP_F2107MA2_KO883          *****/                                    
/*****    DEVELOPER   :  SONS                        *****/                                    
/*****    ���߳�¥    :  2021-02-24                  *****/                                    
/*****    �ֽż�����¥:                              *****/                                    
/*****    ��    ��    :  ������� ��ȸ - �����ڵ庰, �μ���,     *****/  
/*****    Ư    ¡    :  @diff    ������, �μ��� => A, �ƴϸ� blank   */  
/*****                :  @quarter �б⺰         => A, �ƴϸ� blank   */  
/********************************************************************/               
  
CREATE  PROCEDURE [dbo].USP_F2107MA2_KO883 (            
  @diff nchar(1),  
  @quarter nchar(1),  
  @year nvarchar(10),    
  @bdg_cd nvarchar(12),  
  @dept_cd nchar(12)  
 ) AS  
  
BEGIN                                    
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED               
             
SET NOCOUNT ON         
  
--set @diff ='A'   --A ������, �μ���  
--set @quarter = 'A'  --A �б⺰  
--set @year ='2021'  
--set @bdg_cd = ''  
--set @dept_cd = ''  
  
declare @strym nvarchar(10),  
  @endym nvarchar(10)  
  
set @strym = @year + '01'  
set @endym = @year + '12'  
  
  
---����/�μ���, ����---------------------------------------------------  
if @diff = 'A' and @quarter <> 'A'  
begin  
select   
    D.GP_CD as gp_cd,    --�����׷�  
 E.GP_NM as gp_nm,    --�����׷��  
 A.BDG_CD as bdg_cd,    --�����ڵ�   
 B.GP_ACCT_NM as gp_acct_nm,  --�����ڵ��  
 B.ACCT_CD as acct_cd,   --�����ڵ�  
 D.ACCT_NM as acct_nm,   --�����ڵ��  
 A.DEPT_CD as dept_cd,   --���μ�  
 C.DEPT_NM dept_nm,    --�μ���  
 sum(A.BDG_PLAN_AMT) bdg_plan_amt,   
 sum(A.BDG_AMT) bdg_amt,   
 sum(A.BDG_GL_AMT + A.BDG_TMP_AMT) sum_amt,   
 sum(A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT)) sum_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_PLAN_AMT else 0 end) jan_plan_amt,
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_AMT else 0 end) jan_budget_amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jan_Sum,
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Jan_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_PLAN_AMT else 0 end) Feb_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_AMT else 0 end) Feb_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Feb_Sum,
 sum(case when substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Feb_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_PLAN_AMT else 0 end) Mar_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_AMT else 0 end) Mar_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Mar_Sum,
 sum(case when substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Mar_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_PLAN_AMT else 0 end) Apr_Plan_Amt,
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_AMT else 0 end) Apr_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Apr_Sum, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Apr_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_PLAN_AMT else 0 end) May_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_AMT else 0 end) May_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) May_Sum, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) May_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_PLAN_AMT else 0 end) Jun_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_AMT else 0 end) Jun_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jun_Sum, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Jun_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_PLAN_AMT else 0 end) Jul_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_AMT else 0 end) Jul_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jul_Sum, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Jul_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_PLAN_AMT else 0 end) Aug_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_AMT else 0 end) Aug_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Aug_Sum, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Aug_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_PLAN_AMT else 0 end) Sep_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_AMT else 0 end) Sep_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Sep_Sum, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Sep_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_PLAN_AMT else 0 end) Oct_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_AMT else 0 end) Oct_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Oct_Sum, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Oct_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_PLAN_AMT else 0 end) Nov_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_AMT else 0 end) Nov_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Nov_Sum, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Nov_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_PLAN_AMT else 0 end) Dec_Plan_Amt, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_AMT else 0 end) Dec_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Dec_Sum, 
 sum(case when substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Dec_bal  
 from f_bdg a  
 join f_bdg_acct b on b.BDG_CD = a.BDG_CD  
 join b_acct_dept c on A.dept_cd = C.dept_cd and A.org_change_id = C.org_change_id  
 join A_ACCT d on d.ACCT_CD = b.ACCT_CD  
 join A_ACCT_GP e on e.GP_CD = d.GP_CD  
 where A.bdg_yyyymm between  @strym and  @endym  
 and (@bdg_cd = '' or A.BDG_CD = @bdg_cd)  
 and (@dept_cd = '' or A.DEPT_CD = @dept_cd)  
  group by D.GP_CD, E.GP_NM, A.BDG_CD, B.GP_ACCT_NM, A.DEPT_CD, C.DEPT_NM, B.ACCT_CD, D.ACCT_NM  
 Order By A.BDG_CD ASC,B.GP_ACCT_NM , A.DEPT_CD ASC  
end  
  
------������, ����----------------------------------  
if @diff <> 'A' and @quarter <> 'A'  
begin   
select   
    D.GP_CD as gp_cd,    --�����׷�  
 E.GP_NM as gp_nm,    --�����׷��  
 A.BDG_CD as bdg_cd,    --�����ڵ�   
 B.GP_ACCT_NM as gp_acct_nm,  --�����ڵ��  
 B.ACCT_CD as acct_cd,   --�����ڵ�  
 D.ACCT_NM as acct_nm,   --�����ڵ��   
 sum(A.BDG_PLAN_AMT) bdg_plan_amt,   
 sum(A.BDG_AMT) bdg_amt,   
 sum(A.BDG_GL_AMT + A.BDG_TMP_AMT) sum_amt,   
 sum(A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT)) sum_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_PLAN_AMT else 0 end) jan_plan_amt, sum(case when substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_AMT else 0 end) jan_budget_amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jan_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Jan_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_PLAN_AMT else 0 end) Feb_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_AMT else 0 end) Feb_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Feb_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Feb_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_PLAN_AMT else 0 end) Mar_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_AMT else 0 end) Mar_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Mar_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Mar_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_PLAN_AMT else 0 end) Apr_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_AMT else 0 end) Apr_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Apr_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Apr_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_PLAN_AMT else 0 end) May_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_AMT else 0 end) May_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) May_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) May_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_PLAN_AMT else 0 end) Jun_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_AMT else 0 end) Jun_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jun_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Jun_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_PLAN_AMT else 0 end) Jul_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_AMT else 0 end) Jul_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jul_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Jul_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_PLAN_AMT else 0 end) Aug_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_AMT else 0 end) Aug_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Aug_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Aug_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_PLAN_AMT else 0 end) Sep_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_AMT else 0 end) Sep_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Sep_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Sep_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_PLAN_AMT else 0 end) Oct_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_AMT else 0 end) Oct_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Oct_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Oct_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_PLAN_AMT else 0 end) Nov_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_AMT else 0 end) Nov_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Nov_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Nov_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_PLAN_AMT else 0 end) Dec_Plan_Amt, sum(case when substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_AMT else 0 end) Dec_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Dec_Sum, sum(case when substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) Dec_bal  
 from f_bdg a  
 join f_bdg_acct b on b.BDG_CD = a.BDG_CD  
 join b_acct_dept c on A.dept_cd = C.dept_cd and A.org_change_id = C.org_change_id  
 join A_ACCT d on d.ACCT_CD = b.ACCT_CD  
 join A_ACCT_GP e on e.GP_CD = d.GP_CD  
 where A.bdg_yyyymm between  @strym and  @endym  
 and (@bdg_cd = '' or A.BDG_CD = @bdg_cd)  
  group by D.GP_CD, E.GP_NM, A.BDG_CD, B.GP_ACCT_NM, B.ACCT_CD, D.ACCT_NM  
 Order By A.BDG_CD ASC,B.GP_ACCT_NM   
end  
  
---3. ����/�μ���, �б⺰---------------------------------------------------  
if @diff = 'A' and @quarter = 'A'  
begin  
select   
    D.GP_CD as gp_cd,    --�����׷�  
 E.GP_NM as gp_nm,    --�����׷��  
 A.BDG_CD as bdg_cd,    --�����ڵ�   
 B.GP_ACCT_NM as gp_acct_nm,  --�����ڵ��  
 B.ACCT_CD as acct_cd,   --�����ڵ�  
 D.ACCT_NM as acct_nm,   --�����ڵ��  
 A.DEPT_CD as dept_cd,   --���μ�  
 C.DEPT_NM dept_nm,    --�μ���  
 sum(A.BDG_PLAN_AMT) bdg_plan_amt,   
 sum(A.BDG_AMT) bdg_amt,   
 sum(A.BDG_GL_AMT + A.BDG_TMP_AMT) sum_amt,   
 sum(A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT)) sum_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_PLAN_AMT else 0 end) oneQ_plan_amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_AMT else 0 end) oneQ_budget_amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) oneQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) oneQ_bal,   
   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_PLAN_AMT else 0 end) twoQ_Plan_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_AMT else 0 end) twoQ_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) twoQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) twoQ_bal,   
   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_PLAN_AMT else 0 end) thrQ_Plan_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_AMT else 0 end) thrQ_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) thrQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) thrQ_bal,   
   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_PLAN_AMT else 0 end) forQ_Plan_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_AMT else 0 end) forQ_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) for_Sum,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) for_bal    
 from f_bdg a  
 join f_bdg_acct b on b.BDG_CD = a.BDG_CD  
 join b_acct_dept c on A.dept_cd = C.dept_cd and A.org_change_id = C.org_change_id  
 join A_ACCT d on d.ACCT_CD = b.ACCT_CD  
 join A_ACCT_GP e on e.GP_CD = d.GP_CD  
 where A.bdg_yyyymm between  @strym and  @endym  
 and (@bdg_cd = '' or A.BDG_CD = @bdg_cd)  
 and (@dept_cd = '' or A.DEPT_CD = @dept_cd)  
  group by D.GP_CD, E.GP_NM, A.BDG_CD, B.GP_ACCT_NM, A.DEPT_CD, C.DEPT_NM, B.ACCT_CD, D.ACCT_NM  
 Order By A.BDG_CD ASC,B.GP_ACCT_NM , A.DEPT_CD ASC  
end  
  
---4. ������, �б⺰---------------------------------------------------  
if @diff <> 'A' and @quarter = 'A'  
begin  
select   
    D.GP_CD as gp_cd,    --�����׷�  
 E.GP_NM as gp_nm,    --�����׷��  
 A.BDG_CD as bdg_cd,    --�����ڵ�   
 B.GP_ACCT_NM as gp_acct_nm,  --�����ڵ��  
 B.ACCT_CD as acct_cd,   --�����ڵ�  
 D.ACCT_NM as acct_nm,   --�����ڵ��   
 sum(A.BDG_PLAN_AMT) bdg_plan_amt,   
 sum(A.BDG_AMT) bdg_amt,   
 sum(A.BDG_GL_AMT + A.BDG_TMP_AMT) sum_amt,   
 sum(A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT)) sum_bal,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_PLAN_AMT else 0 end) oneQ_plan_amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_AMT else 0 end) oneQ_budget_amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) oneQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) oneQ_bal,   
   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_PLAN_AMT else 0 end) twoQ_Plan_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_AMT else 0 end) twoQ_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) twoQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) twoQ_bal,   
   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_PLAN_AMT else 0 end) thrQ_Plan_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_AMT else 0 end) thrQ_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) thrQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) thrQ_bal,   
   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_PLAN_AMT else 0 end) forQ_Plan_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_AMT else 0 end) forQ_Budget_Amt,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) for_Sum,   
 sum(case when substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_AMT - (A.BDG_GL_AMT+A.BDG_TMP_AMT) else 0 end) for_bal    
 from f_bdg a  
 join f_bdg_acct b on b.BDG_CD = a.BDG_CD  
 join b_acct_dept c on A.dept_cd = C.dept_cd and A.org_change_id = C.org_change_id  
 join A_ACCT d on d.ACCT_CD = b.ACCT_CD  
 join A_ACCT_GP e on e.GP_CD = d.GP_CD  
 where A.bdg_yyyymm between  @strym and  @endym  
 and (@bdg_cd = '' or A.BDG_CD = @bdg_cd)  
 and (@dept_cd = '' or A.DEPT_CD = @dept_cd)  
  group by D.GP_CD, E.GP_NM, A.BDG_CD, B.GP_ACCT_NM, B.ACCT_CD, D.ACCT_NM  
 Order By A.BDG_CD ASC,B.GP_ACCT_NM ASC  
end  
  
END