﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.FI.F2107MA6_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.ValueListItem valueListItem5 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem6 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem7 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem8 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance83 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance84 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance85 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance86 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance87 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance88 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance89 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance90 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance91 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance92 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance93 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance72 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance73 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance74 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance75 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance76 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance77 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance78 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance79 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance80 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance81 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance82 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance62 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance63 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance64 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance65 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance66 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance68 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance69 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance70 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance71 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance94 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance95 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance96 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance97 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance98 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance99 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance100 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance101 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance102 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance103 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance104 = new Infragistics.Win.Appearance();
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.Rdo_Type2 = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.popBdgcd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popDeptCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblbdgcd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblType2 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblType1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDeptCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblYear = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.DtYear = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.Rdo_Type1 = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid2 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniGrid3 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniGrid4 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_MainCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Rdo_Type2)).BeginInit();
            this.popDeptCd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_a5d65465_24ca_4a0f_b577_82820a1da092)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DtYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rdo_Type1)).BeginInit();
            this.uniTBL_MainData.SuspendLayout();
            this.uniTBL_OuterMost.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.PathInfo;
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.DefaultRowSize = 23;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(957, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.Rdo_Type2, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.popBdgcd, 1, 3);
            this.uniTBL_MainCondition.Controls.Add(this.popDeptCd, 4, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblbdgcd, 0, 3);
            this.uniTBL_MainCondition.Controls.Add(this.lblType2, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblType1, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblDeptCd, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblYear, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.DtYear, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.Rdo_Type1, 1, 1);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 4;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(957, 109);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // Rdo_Type2
            // 
            this.Rdo_Type2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Rdo_Type2.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.Rdo_Type2.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            valueListItem5.DataValue = "";
            valueListItem5.DisplayText = "월별";
            valueListItem6.DataValue = "A";
            valueListItem6.DisplayText = "분기별";
            this.Rdo_Type2.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem5,
            valueListItem6});
            this.Rdo_Type2.ItemSpacingHorizontal = 30;
            this.Rdo_Type2.ItemSpacingVertical = 10;
            this.Rdo_Type2.Location = new System.Drawing.Point(133, 59);
            this.Rdo_Type2.LockedField = false;
            this.Rdo_Type2.Margin = new System.Windows.Forms.Padding(0, 4, 1, 0);
            this.Rdo_Type2.Name = "Rdo_Type2";
            this.Rdo_Type2.RequiredField = false;
            this.Rdo_Type2.Size = new System.Drawing.Size(234, 21);
            this.Rdo_Type2.StyleSetName = "Default";
            this.Rdo_Type2.TabIndex = 26;
            this.Rdo_Type2.uniALT = null;
            // 
            // popBdgcd
            // 
            this.popBdgcd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popBdgcd.AutoPopupCodeParameter = null;
            this.popBdgcd.AutoPopupID = null;
            this.popBdgcd.AutoPopupNameParameter = null;
            this.popBdgcd.CodeMaxLength = 10;
            this.popBdgcd.CodeName = "";
            this.popBdgcd.CodeSize = 100;
            this.popBdgcd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBdgcd.CodeTextBoxName = null;
            this.popBdgcd.CodeValue = "";
            this.popBdgcd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popBdgcd.Location = new System.Drawing.Point(133, 84);
            this.popBdgcd.LockedField = false;
            this.popBdgcd.Margin = new System.Windows.Forms.Padding(0);
            this.popBdgcd.Name = "popBdgcd";
            this.popBdgcd.NameDisplay = true;
            this.popBdgcd.NameId = null;
            this.popBdgcd.NameMaxLength = 50;
            this.popBdgcd.NamePopup = false;
            this.popBdgcd.NameSize = 150;
            this.popBdgcd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBdgcd.Parameter = null;
            this.popBdgcd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popBdgcd.PopupId = null;
            this.popBdgcd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popBdgcd.QueryIfEnterKeyPressed = true;
            this.popBdgcd.RequiredField = false;
            this.popBdgcd.Size = new System.Drawing.Size(271, 21);
            this.popBdgcd.TabIndex = 24;
            this.popBdgcd.uniALT = "Dept";
            this.popBdgcd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popBdgcd.UseDynamicFormat = false;
            this.popBdgcd.ValueTextBoxName = null;
            this.popBdgcd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popBdgcd_BeforePopupOpen);
            this.popBdgcd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popBdgcd_AfterPopupClosed);
            this.popBdgcd.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popBdgcd_OnExitEditCode);
            // 
            // popDeptCd
            // 
            this.popDeptCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popDeptCd.AutoPopupCodeParameter = null;
            this.popDeptCd.AutoPopupID = null;
            this.popDeptCd.AutoPopupNameParameter = null;
            this.popDeptCd.CodeMaxLength = 10;
            this.popDeptCd.CodeName = "";
            this.popDeptCd.CodeSize = 100;
            this.popDeptCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDeptCd.CodeTextBoxName = null;
            this.popDeptCd.CodeValue = "";
            this.popDeptCd.Controls.Add(this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044);
            this.popDeptCd.Controls.Add(this.object_a5d65465_24ca_4a0f_b577_82820a1da092);
            this.popDeptCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popDeptCd.Location = new System.Drawing.Point(610, 34);
            this.popDeptCd.LockedField = false;
            this.popDeptCd.Margin = new System.Windows.Forms.Padding(0);
            this.popDeptCd.Name = "popDeptCd";
            this.popDeptCd.NameDisplay = true;
            this.popDeptCd.NameId = null;
            this.popDeptCd.NameMaxLength = 50;
            this.popDeptCd.NamePopup = false;
            this.popDeptCd.NameSize = 150;
            this.popDeptCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDeptCd.Parameter = null;
            this.popDeptCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popDeptCd.PopupId = null;
            this.popDeptCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popDeptCd.QueryIfEnterKeyPressed = true;
            this.popDeptCd.RequiredField = false;
            this.popDeptCd.Size = new System.Drawing.Size(271, 21);
            this.popDeptCd.TabIndex = 19;
            this.popDeptCd.uniALT = "Dept";
            this.popDeptCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popDeptCd.UseDynamicFormat = false;
            this.popDeptCd.ValueTextBoxName = null;
            this.popDeptCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDeptCd_BeforePopupOpen);
            this.popDeptCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDeptCd_AfterPopupClosed);
            this.popDeptCd.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popDeptCd_OnExitEditCode);
            // 
            // object_d9fcbe89_f0d3_4187_9be7_328ecada0044
            // 
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Appearance = appearance53;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.AutoSize = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Location = new System.Drawing.Point(121, 0);
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.LockedField = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Margin = new System.Windows.Forms.Padding(0);
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.MaxLength = 50;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Name = "object_d9fcbe89_f0d3_4187_9be7_328ecada0044";
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.QueryIfEnterKeyPressed = true;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.ReadOnly = true;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.RequiredField = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Size = new System.Drawing.Size(150, 21);
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.StyleSetName = "Lock";
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.TabIndex = 0;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.TabStop = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.uniALT = null;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.UseDynamicFormat = false;
            this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044.WordWrap = false;
            // 
            // object_a5d65465_24ca_4a0f_b577_82820a1da092
            // 
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Appearance = appearance54;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.AutoSize = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Location = new System.Drawing.Point(0, 0);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.LockedField = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Margin = new System.Windows.Forms.Padding(0);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.MaxLength = 10;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Name = "object_a5d65465_24ca_4a0f_b577_82820a1da092";
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.QueryIfEnterKeyPressed = true;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.RequiredField = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Size = new System.Drawing.Size(100, 21);
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.StyleSetName = "Default";
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.TabIndex = 0;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.uniALT = null;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.UseDynamicFormat = false;
            this.object_a5d65465_24ca_4a0f_b577_82820a1da092.WordWrap = false;
            // 
            // lblbdgcd
            // 
            appearance55.TextHAlignAsString = "Left";
            appearance55.TextVAlignAsString = "Middle";
            this.lblbdgcd.Appearance = appearance55;
            this.lblbdgcd.AutoPopupID = null;
            this.lblbdgcd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblbdgcd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblbdgcd.Location = new System.Drawing.Point(15, 81);
            this.lblbdgcd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblbdgcd.Name = "lblbdgcd";
            this.lblbdgcd.Size = new System.Drawing.Size(118, 24);
            this.lblbdgcd.StyleSetName = "Default";
            this.lblbdgcd.TabIndex = 15;
            this.lblbdgcd.Text = "예산코드";
            this.lblbdgcd.UseMnemonic = false;
            // 
            // lblType2
            // 
            appearance56.TextHAlignAsString = "Left";
            appearance56.TextVAlignAsString = "Middle";
            this.lblType2.Appearance = appearance56;
            this.lblType2.AutoPopupID = null;
            this.lblType2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblType2.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblType2.Location = new System.Drawing.Point(15, 56);
            this.lblType2.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblType2.Name = "lblType2";
            this.lblType2.Size = new System.Drawing.Size(118, 24);
            this.lblType2.StyleSetName = "Default";
            this.lblType2.TabIndex = 14;
            this.lblType2.Text = "월구분";
            this.lblType2.UseMnemonic = false;
            // 
            // lblType1
            // 
            appearance57.TextHAlignAsString = "Left";
            appearance57.TextVAlignAsString = "Middle";
            this.lblType1.Appearance = appearance57;
            this.lblType1.AutoPopupID = null;
            this.lblType1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblType1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblType1.Location = new System.Drawing.Point(15, 31);
            this.lblType1.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblType1.Name = "lblType1";
            this.lblType1.Size = new System.Drawing.Size(118, 24);
            this.lblType1.StyleSetName = "Default";
            this.lblType1.TabIndex = 10;
            this.lblType1.Text = "부서구분";
            this.lblType1.UseMnemonic = false;
            // 
            // lblDeptCd
            // 
            appearance58.TextHAlignAsString = "Left";
            appearance58.TextVAlignAsString = "Middle";
            this.lblDeptCd.Appearance = appearance58;
            this.lblDeptCd.AutoPopupID = null;
            this.lblDeptCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDeptCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDeptCd.Location = new System.Drawing.Point(492, 31);
            this.lblDeptCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDeptCd.Name = "lblDeptCd";
            this.lblDeptCd.Size = new System.Drawing.Size(118, 24);
            this.lblDeptCd.StyleSetName = "Default";
            this.lblDeptCd.TabIndex = 4;
            this.lblDeptCd.Text = "부서";
            this.lblDeptCd.UseMnemonic = false;
            // 
            // lblYear
            // 
            appearance59.TextHAlignAsString = "Left";
            appearance59.TextVAlignAsString = "Middle";
            this.lblYear.Appearance = appearance59;
            this.lblYear.AutoPopupID = null;
            this.lblYear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblYear.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblYear.Location = new System.Drawing.Point(15, 6);
            this.lblYear.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(118, 24);
            this.lblYear.StyleSetName = "Default";
            this.lblYear.TabIndex = 13;
            this.lblYear.Text = "예산년도";
            this.lblYear.UseMnemonic = false;
            // 
            // DtYear
            // 
            this.DtYear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance60.TextHAlignAsString = "Center";
            this.DtYear.Appearance = appearance60;
            this.DtYear.DateTime = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            this.DtYear.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.DtYear.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.DtYear.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.DtYear.Location = new System.Drawing.Point(133, 6);
            this.DtYear.LockedField = false;
            this.DtYear.Margin = new System.Windows.Forms.Padding(0);
            this.DtYear.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.DtYear.Name = "DtYear";
            this.DtYear.QueryIfEnterKeyPressed = true;
            this.DtYear.RequiredField = false;
            this.DtYear.Size = new System.Drawing.Size(70, 24);
            this.DtYear.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.DtYear.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYY;
            this.DtYear.StyleSetName = "Default";
            this.DtYear.TabIndex = 23;
            this.DtYear.uniALT = null;
            this.DtYear.uniValue = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            this.DtYear.Value = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            // 
            // Rdo_Type1
            // 
            this.Rdo_Type1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Rdo_Type1.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.Rdo_Type1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            valueListItem7.DataValue = "";
            valueListItem7.DisplayText = "전체";
            valueListItem8.DataValue = "A";
            valueListItem8.DisplayText = "부서별";
            this.Rdo_Type1.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem7,
            valueListItem8});
            this.Rdo_Type1.ItemSpacingHorizontal = 30;
            this.Rdo_Type1.ItemSpacingVertical = 10;
            this.Rdo_Type1.Location = new System.Drawing.Point(133, 34);
            this.Rdo_Type1.LockedField = false;
            this.Rdo_Type1.Margin = new System.Windows.Forms.Padding(0, 4, 1, 0);
            this.Rdo_Type1.Name = "Rdo_Type1";
            this.Rdo_Type1.RequiredField = false;
            this.Rdo_Type1.Size = new System.Drawing.Size(234, 21);
            this.Rdo_Type1.StyleSetName = "Default";
            this.Rdo_Type1.TabIndex = 25;
            this.Rdo_Type1.uniALT = null;
            this.Rdo_Type1.ValueChanged += new System.EventHandler(this.Rdo_Type1_ValueChanged);
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid4, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.uniGrid3, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.uniGrid2, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 144);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(957, 465);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 0;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 12);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 6;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 109F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 19F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(957, 628);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            this.uniTBL_OuterMost.Paint += new System.Windows.Forms.PaintEventHandler(this.uniTBL_OuterMost_Paint);
            // 
            // uniGrid2
            // 
            this.uniGrid2.AddEmptyRow = false;
            this.uniGrid2.DirectPaste = false;
            appearance83.BackColor = System.Drawing.SystemColors.Window;
            appearance83.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid2.DisplayLayout.Appearance = appearance83;
            this.uniGrid2.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid2.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance84.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance84.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance84.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.GroupByBox.Appearance = appearance84;
            appearance85.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.BandLabelAppearance = appearance85;
            this.uniGrid2.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance86.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance86.BackColor2 = System.Drawing.SystemColors.Control;
            appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance86.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.PromptAppearance = appearance86;
            this.uniGrid2.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid2.DisplayLayout.MaxRowScrollRegions = 1;
            appearance87.BackColor = System.Drawing.SystemColors.Window;
            appearance87.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid2.DisplayLayout.Override.ActiveCellAppearance = appearance87;
            this.uniGrid2.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid2.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid2.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance88.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.CardAreaAppearance = appearance88;
            appearance89.BorderColor = System.Drawing.Color.Silver;
            appearance89.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid2.DisplayLayout.Override.CellAppearance = appearance89;
            this.uniGrid2.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid2.DisplayLayout.Override.CellPadding = 0;
            appearance90.BackColor = System.Drawing.SystemColors.Control;
            appearance90.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance90.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance90.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.GroupByRowAppearance = appearance90;
            appearance91.TextHAlignAsString = "Left";
            this.uniGrid2.DisplayLayout.Override.HeaderAppearance = appearance91;
            this.uniGrid2.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid2.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance92.BackColor = System.Drawing.SystemColors.Window;
            appearance92.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid2.DisplayLayout.Override.RowAppearance = appearance92;
            this.uniGrid2.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance93.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid2.DisplayLayout.Override.TemplateAddRowAppearance = appearance93;
            this.uniGrid2.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid2.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid2.EnableContextMenu = true;
            this.uniGrid2.EnableGridInfoContextMenu = true;
            this.uniGrid2.ExceptInExcel = false;
            this.uniGrid2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid2.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid2.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid2.Location = new System.Drawing.Point(0, 0);
            this.uniGrid2.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid2.Name = "uniGrid2";
            this.uniGrid2.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid2.PopupDeleteMenuVisible = true;
            this.uniGrid2.PopupInsertMenuVisible = true;
            this.uniGrid2.PopupUndoMenuVisible = true;
            this.uniGrid2.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid2.ShowHeaderCheck = true;
            this.uniGrid2.Size = new System.Drawing.Size(957, 405);
            this.uniGrid2.StyleSetName = "uniGrid_Query";
            this.uniGrid2.TabIndex = 1;
            this.uniGrid2.Text = "uniGrid2";
            this.uniGrid2.UseDynamicFormat = false;
            // 
            // uniGrid3
            // 
            this.uniGrid3.AddEmptyRow = false;
            this.uniGrid3.DirectPaste = false;
            appearance72.BackColor = System.Drawing.SystemColors.Window;
            appearance72.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid3.DisplayLayout.Appearance = appearance72;
            this.uniGrid3.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid3.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance73.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance73.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance73.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid3.DisplayLayout.GroupByBox.Appearance = appearance73;
            appearance74.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid3.DisplayLayout.GroupByBox.BandLabelAppearance = appearance74;
            this.uniGrid3.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance75.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance75.BackColor2 = System.Drawing.SystemColors.Control;
            appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance75.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid3.DisplayLayout.GroupByBox.PromptAppearance = appearance75;
            this.uniGrid3.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid3.DisplayLayout.MaxRowScrollRegions = 1;
            appearance76.BackColor = System.Drawing.SystemColors.Window;
            appearance76.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid3.DisplayLayout.Override.ActiveCellAppearance = appearance76;
            this.uniGrid3.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid3.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid3.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance77.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid3.DisplayLayout.Override.CardAreaAppearance = appearance77;
            appearance78.BorderColor = System.Drawing.Color.Silver;
            appearance78.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid3.DisplayLayout.Override.CellAppearance = appearance78;
            this.uniGrid3.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid3.DisplayLayout.Override.CellPadding = 0;
            appearance79.BackColor = System.Drawing.SystemColors.Control;
            appearance79.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance79.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance79.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid3.DisplayLayout.Override.GroupByRowAppearance = appearance79;
            appearance80.TextHAlignAsString = "Left";
            this.uniGrid3.DisplayLayout.Override.HeaderAppearance = appearance80;
            this.uniGrid3.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid3.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance81.BackColor = System.Drawing.SystemColors.Window;
            appearance81.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid3.DisplayLayout.Override.RowAppearance = appearance81;
            this.uniGrid3.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance82.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid3.DisplayLayout.Override.TemplateAddRowAppearance = appearance82;
            this.uniGrid3.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid3.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid3.EnableContextMenu = true;
            this.uniGrid3.EnableGridInfoContextMenu = true;
            this.uniGrid3.ExceptInExcel = false;
            this.uniGrid3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid3.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid3.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid3.Location = new System.Drawing.Point(0, 445);
            this.uniGrid3.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid3.Name = "uniGrid3";
            this.uniGrid3.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid3.PopupDeleteMenuVisible = true;
            this.uniGrid3.PopupInsertMenuVisible = true;
            this.uniGrid3.PopupUndoMenuVisible = true;
            this.uniGrid3.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid3.ShowHeaderCheck = true;
            this.uniGrid3.Size = new System.Drawing.Size(957, 20);
            this.uniGrid3.StyleSetName = "uniGrid_Query";
            this.uniGrid3.TabIndex = 2;
            this.uniGrid3.Text = "uniGrid3";
            this.uniGrid3.UseDynamicFormat = false;
            // 
            // uniGrid4
            // 
            this.uniGrid4.AddEmptyRow = false;
            this.uniGrid4.DirectPaste = false;
            appearance61.BackColor = System.Drawing.SystemColors.Window;
            appearance61.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid4.DisplayLayout.Appearance = appearance61;
            this.uniGrid4.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid4.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance62.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance62.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance62.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid4.DisplayLayout.GroupByBox.Appearance = appearance62;
            appearance63.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid4.DisplayLayout.GroupByBox.BandLabelAppearance = appearance63;
            this.uniGrid4.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance64.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance64.BackColor2 = System.Drawing.SystemColors.Control;
            appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance64.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid4.DisplayLayout.GroupByBox.PromptAppearance = appearance64;
            this.uniGrid4.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid4.DisplayLayout.MaxRowScrollRegions = 1;
            appearance65.BackColor = System.Drawing.SystemColors.Window;
            appearance65.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid4.DisplayLayout.Override.ActiveCellAppearance = appearance65;
            this.uniGrid4.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid4.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid4.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance66.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid4.DisplayLayout.Override.CardAreaAppearance = appearance66;
            appearance67.BorderColor = System.Drawing.Color.Silver;
            appearance67.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid4.DisplayLayout.Override.CellAppearance = appearance67;
            this.uniGrid4.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid4.DisplayLayout.Override.CellPadding = 0;
            appearance68.BackColor = System.Drawing.SystemColors.Control;
            appearance68.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance68.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance68.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid4.DisplayLayout.Override.GroupByRowAppearance = appearance68;
            appearance69.TextHAlignAsString = "Left";
            this.uniGrid4.DisplayLayout.Override.HeaderAppearance = appearance69;
            this.uniGrid4.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid4.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance70.BackColor = System.Drawing.SystemColors.Window;
            appearance70.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid4.DisplayLayout.Override.RowAppearance = appearance70;
            this.uniGrid4.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance71.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid4.DisplayLayout.Override.TemplateAddRowAppearance = appearance71;
            this.uniGrid4.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid4.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid4.EnableContextMenu = true;
            this.uniGrid4.EnableGridInfoContextMenu = true;
            this.uniGrid4.ExceptInExcel = false;
            this.uniGrid4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid4.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid4.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid4.Location = new System.Drawing.Point(0, 425);
            this.uniGrid4.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid4.Name = "uniGrid4";
            this.uniGrid4.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid4.PopupDeleteMenuVisible = true;
            this.uniGrid4.PopupInsertMenuVisible = true;
            this.uniGrid4.PopupUndoMenuVisible = true;
            this.uniGrid4.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid4.ShowHeaderCheck = true;
            this.uniGrid4.Size = new System.Drawing.Size(957, 20);
            this.uniGrid4.StyleSetName = "uniGrid_Query";
            this.uniGrid4.TabIndex = 3;
            this.uniGrid4.Text = "uniGrid4";
            this.uniGrid4.UseDynamicFormat = false;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance94.BackColor = System.Drawing.SystemColors.Window;
            appearance94.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance94;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance95.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance95.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance95.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance95;
            appearance96.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance96;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance97.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance97.BackColor2 = System.Drawing.SystemColors.Control;
            appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance97.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance97;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance98.BackColor = System.Drawing.SystemColors.Window;
            appearance98.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance98;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance99.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance99;
            appearance100.BorderColor = System.Drawing.Color.Silver;
            appearance100.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance100;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance101.BackColor = System.Drawing.SystemColors.Control;
            appearance101.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance101.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance101.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance101;
            appearance102.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance102;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance103.BackColor = System.Drawing.SystemColors.Window;
            appearance103.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance103;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance104.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance104;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 405);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(957, 20);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.uniGrid1_BeforePopupOpen);
            this.uniGrid1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.uniGrid1_AfterPopupClosed);
            this.uniGrid1.AfterCellUpdate += new Infragistics.Win.UltraWinGrid.CellEventHandler(this.uniGrid1_AfterCellUpdate);
            this.uniGrid1.AfterExitEditMode += new System.EventHandler(this.uniGrid1_AfterExitEditMode);
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(969, 652);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Rdo_Type2)).EndInit();
            this.popDeptCd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_d9fcbe89_f0d3_4187_9be7_328ecada0044)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_a5d65465_24ca_4a0f_b577_82820a1da092)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DtYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rdo_Type1)).EndInit();
            this.uniTBL_MainData.ResumeLayout(false);
            this.uniTBL_OuterMost.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private AppFramework.UI.Controls.uniRadioButton Rdo_Type2;
        private AppFramework.UI.Controls.uniOpenPopup popBdgcd;
        private AppFramework.UI.Controls.uniOpenPopup popDeptCd;
        private AppFramework.UI.Controls.uniTextBox object_d9fcbe89_f0d3_4187_9be7_328ecada0044;
        private AppFramework.UI.Controls.uniTextBox object_a5d65465_24ca_4a0f_b577_82820a1da092;
        private AppFramework.UI.Controls.uniLabel lblbdgcd;
        private AppFramework.UI.Controls.uniLabel lblType2;
        private AppFramework.UI.Controls.uniLabel lblType1;
        private AppFramework.UI.Controls.uniLabel lblDeptCd;
        private AppFramework.UI.Controls.uniLabel lblYear;
        private AppFramework.UI.Controls.uniDateTime DtYear;
        private AppFramework.UI.Controls.uniRadioButton Rdo_Type1;
        private AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private AppFramework.UI.Controls.uniGrid uniGrid4;
        private AppFramework.UI.Controls.uniGrid uniGrid3;
        private AppFramework.UI.Controls.uniGrid uniGrid2;
        private AppFramework.UI.Controls.uniGrid uniGrid1;



    }
}
