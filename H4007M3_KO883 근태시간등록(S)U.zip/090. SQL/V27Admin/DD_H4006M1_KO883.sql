﻿
SET NOCOUNT ON;
---------------------------------------------------------------------------------------------------------------------------
--	FILE NAME	: HR_INS_DD_20180605_HSY.sql
--	MODULE		: HR
--	DATE		: 2018-06-05
--	Modifier	: HSY
---------------------------------------------------------------------------------------------------------------------------
DELETE
FROM
	V27AdminDB..DD
WHERE
	ProgramID IN (
'uniERP.App.UI.HR.H4006M1_KO883'
)
---------------------------------------------------------------------------------------------------------------------------
-----Start  DD DML   ProgramID = 'uniERP.App.UI.HR.H4006M1_KO883'-----------------------------------------------------------------------------

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'사업장'	,N'사업장'	,N'Business Area Code'	,NULL
	,N'事业区域'	,N'事业区域'	,N''	,N'Business Area Code'
	,N'Địa điểm kinh doanh'	,N'Địa điểm kinh doanh'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'biz_area_cd'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-03-05'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'사업장'	,N'사업장'	,N'Business Area'	,N'Business Area'
	,N'事业区域'	,N'事业区域'	,N'Business Area'	,N'Business Area'
	,N'Địa điểm kinh doanh'	,N'Địa điểm kinh doanh'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'biz_area_nm'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2010-05-10'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'사업장'	,N'사업장'	,N'Business Area'	,N'Business Area'
	,N'事业场'	,N'事业场'	,N''	,N'Business Area'
	,N'Địa điểm kinh doanh'	,N'Địa điểm kinh doanh'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'cboBizAreaCd'	,'S'	,'Single'	,'uniCombo'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'승인여부'	,NULL	,N'승인여부'	,NULL
	,N'승인여부'	,NULL	,N'승인여부'	,N''
	,N'승인여부'	,N''
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'conf_yn'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2018-06-05'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'day_time'	,N'day_time'	,N'day_time'	,N'day_time'
	,N'day time'	,NULL	,N'day time'	,N'day time'
	,N'day time'	,N'day time'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'day_time'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2014-03-25'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'부서코드'	,N'부서코드'	,N'dept_cd'	,N'dept_cd'
	,N'部门'	,N'dept_cd'	,N''	,N'dept_cd'
	,N'Mã bộ phận'	,N'Mã bộ phận'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dept_cd'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'부서명'	,N'부서명'	,N'Department'	,N'Department'
	,N'部门'	,N'部门'	,N''	,N'Department'
	,N'Tên bộ phận'	,N'Tên bộ phận'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dept_nm'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'근태코드'	,N'근태코드'	,N'Attendance Code'	,N'Attendance Code'
	,N'出勤代码'	,N'出勤代码'	,N''	,N'Attendance Code'
	,N'Mã chấm công'	,N'Mã chấm công'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dilig_cd'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'근태횟수'	,N'근태횟수'	,N'dilig_cnt'	,N'dilig_cnt'
	,N'出勤次数'	,N'出勤次数'	,N''	,N'dilig_cnt'
	,N'Số lần chấm công'	,N'Số lần chấm công'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dilig_cnt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,0	,'2008-01-07'	,'2016-07-08'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'근태일'	,N'근태일'	,N'dilig_dt'	,N'dilig_dt'
	,N'attend_dt'	,N'dilig_dt'	,N''	,N'dilig_dt'
	,N'Ngày chấm công'	,N'Ngày chấm công'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dilig_dt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'시간'	,N'시간'	,N'Hour'	,N'Hour'
	,N'发生时间'	,N'发生时间'	,N''	,N'Hour'
	,N'Thời gian'	,N'Thời gian'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dilig_hh'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'분'	,N'분'	,N'Min'	,N'Min'
	,N'最小值'	,N'最小值'	,N''	,N'Min'
	,N'Phút'	,N'Phút'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dilig_mm'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'근태명'	,N'근태명'	,N'Attendance Name'	,N'Attendance Name'
	,N'出勤名称'	,N'出勤名称'	,N''	,N'Attendance Name'
	,N'Tên chấm công'	,N'Tên chấm công'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dilig_nm'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'기준일'	,NULL	,N'baseDt'	,NULL
	,N'baseDt'	,NULL	,N'baseDt'	,N''
	,N'baseDt'	,N''
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dtBase'	,'S'	,'Single'	,'uniDateTime'
	,NULL	,NULL	,'2018-06-05'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'근태일(시작)|근태일(종료)'	,N'근태일(시작)|근태일(종료)'	,N'Attendance one (start)|Attendance days (the end)'	,N'Attendance one (start)|Attendance days (the end)'
	,N'出席一（开始）|出勤天数（结束）'	,N'出席一（开始）|出勤天数（结束）'	,N'|'	,N''
	,N'|'	,N''
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dtDilgTerm'	,'S'	,'Single'	,'uniDateTerm'
	,NULL	,NULL	,'2016-07-08'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'근태일'	,N'근태일'	,N'Date'	,N'Date'
	,N'日期'	,N'日期'	,N''	,N'Date'
	,N'Ngày'	,N'Ngày'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'dtValidDt'	,'S'	,'Single'	,'uniDateTime'
	,NULL	,NULL	,'2008-01-07'	,'2015-05-20'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'사번'	,N'사번'	,N'Employee ID'	,N'Employee ID'
	,N'职员代码'	,N'职员代码'	,N''	,N'Employee ID'
	,N'Mã nhân viên (ID)'	,N'Mã nhân viên (ID)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'emp_no'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'추가필드1(amt)'	,N'추가필드1(amt)'	,N'ext1_amt'	,N'ext1_amt'
	,N'扩展字段1(amt)'	,N'扩展字段1(amt)'	,N''	,N'ext1_amt'
	,N'Lĩnh vực bổ sung 1 (amt)'	,N'Lĩnh vực bổ sung 1 (amt)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'ext1_amt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2016-07-08'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'추가필드1(dt)'	,N'추가필드1(dt)'	,N'ext1_dt'	,N'ext1_dt'
	,N'扩展字段1(dt)'	,N'扩展字段1(dt)'	,N''	,N'ext1_dt'
	,N'Lĩnh vực bổ sung 1 (dt)'	,N'Lĩnh vực bổ sung 1 (dt)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'ext1_dt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2016-07-08'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'추가필드1(txt)'	,N'추가필드1(txt)'	,N'ext1_txt'	,N'ext1_txt'
	,N'扩展字段1(txt)'	,N'扩展字段1(txt)'	,N''	,N'ext1_txt'
	,N'Lĩnh vực bổ sung 1 (txt)'	,N'Lĩnh vực bổ sung 1 (txt)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'ext1_txt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2016-07-08'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'추가필드2(amt)'	,N'추가필드2(amt)'	,N'ext2_amt'	,N'ext2_amt'
	,N'扩展字段2(amt)'	,N'扩展字段2(amt)'	,N''	,N'ext2_amt'
	,N'Lĩnh vực bổ sung 2 (amt)'	,N'Lĩnh vực bổ sung 2 (amt)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'ext2_amt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2016-07-08'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'추가필드2(dt)'	,N'추가필드2(dt)'	,N'ext2_dt'	,N'ext2_dt'
	,N'扩展字段2(dt)'	,N'扩展字段2(dt)'	,N''	,N'ext2_dt'
	,N'LĨnh vực bổ sung 2 (dt)'	,N'LĨnh vực bổ sung 2 (dt)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'ext2_dt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2016-07-08'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'추가필드2(txt)'	,N'추가필드2(txt)'	,N'ext2_txt'	,N'ext2_txt'
	,N'扩展字段2(txt)'	,N'扩展字段2(txt)'	,N''	,N'ext2_txt'
	,N'LĨnh vực bổ sung 2 (txt)'	,N'LĨnh vực bổ sung 2 (txt)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'ext2_txt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2016-07-08'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'추가필드3(txt)'	,N'추가필드3(txt)'	,N'ext3_txt'	,N'ext3_txt'
	,N'扩展字段3(txt)'	,N'扩展字段3(txt)'	,N''	,N'ext3_txt'
	,N'LĨnh vực bổ sung 3 (txt)'	,N'LĨnh vực bổ sung 3 (txt)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'ext3_txt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2016-07-08'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'추가필드4(txt)'	,N'추가필드4(txt)'	,N'ext4_txt'	,N'ext4_txt'
	,N'扩展字段4(txt)'	,N'扩展字段4(txt)'	,N''	,N'ext4_txt'
	,N'LĨnh vực bổ sung 4 (txt)'	,N'LĨnh vực bổ sung 4 (txt)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'ext4_txt'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2016-07-08'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'기준일'	,NULL	,N'BaseDt'	,NULL
	,N'BaseDt'	,NULL	,N'BaseDt'	,N''
	,N'BaseDt'	,N''
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'lblBaseDt'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-05'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'사업장'	,N'사업장'	,N'Business Area'	,N'Business Area'
	,N'事业场'	,N'事业场'	,N''	,N'Business Area'
	,N'Địa điểm kinh doanh'	,N'Địa điểm kinh doanh'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'lblBizArea'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'근태'	,N'근태'	,N'Attendance'	,N'Attendance'
	,N'出勤'	,N'出勤'	,N''	,N'Attendance'
	,N'Chấm công'	,N'Chấm công'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'lblCd'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'부서'	,N'부서'	,N'Department'	,N'Department'
	,N'部门'	,N'部门'	,N''	,N'Department'
	,N'Bộ phận '	,N'Bộ phận '
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'lblDept'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'사번'	,N'사번'	,N'Employee'	,N'Employee'
	,N'职员'	,N'职员'	,N''	,N'Employee'
	,N'Mã nhân viên (ID)'	,N'Mã nhân viên (ID)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'lblEmpNo'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'승인여부'	,NULL	,N'승인여부'	,NULL
	,N'승인여부'	,NULL	,N'승인여부'	,N''
	,N'승인여부'	,N''
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'lblFlag'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-05'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'~'	,N'~'	,N'~'	,N'~'
	,N'~'	,N'~'	,N''	,N'~'
	,N'~'	,N'~'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'lblFromTo1'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'근태일'	,N'근태일'	,N'Date'	,N'Date'
	,N'日期'	,N'日期'	,N''	,N'Date'
	,N'Ngày'	,N'Ngày'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'lblValidDt'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'이름'	,N'이름'	,N'Name'	,N'Name'
	,N'名称'	,N'名称'	,N''	,N'Name'
	,N'Họ tên'	,N'Họ tên'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'name'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'근태'	,N'근태'	,N'Attendance'	,N'Attendance'
	,N'出勤'	,N'出勤'	,N''	,N'Attendance'
	,N'Chấm công'	,N'Chấm công'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'popCd'	,'S'	,'Single'	,'uniOpenPopup'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'사번'	,N'사번'	,N'Employee'	,N'Employee'
	,N'职员'	,N'职员'	,N''	,N'Employee'
	,N'Mã nhân viên (ID)'	,N'Mã nhân viên (ID)'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'popEmpNo'	,'S'	,'Single'	,'uniOpenPopup'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'부서명'	,N'부서명'	,N'FromDepartment'	,N'FromDepartment'
	,N'起始部门'	,N'起始部门'	,N''	,N'FromDepartment'
	,N'Tên bộ phận'	,N'Tên bộ phận'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'popFrDeptNm'	,'S'	,'Single'	,'uniOpenPopup'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'부서명'	,N'부서명'	,N'To Department'	,N'To Department'
	,N'接收部门'	,N'接收部门'	,N''	,N'To Department'
	,N'Tên bộ phận'	,N'Tên bộ phận'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'popToDeptNm'	,'S'	,'Single'	,'uniOpenPopup'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'|전체|승인|미승인'	,NULL	,N'|전체|승인|미승인'	,NULL
	,N'|전체|승인|미승인'	,NULL	,N'|전체|승인|미승인'	,N''
	,N'|전체|승인|미승인'	,N''
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'rdoConfYn'	,'S'	,'Single'	,'uniRadioButton'
	,NULL	,NULL	,'2018-06-05'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'비고'	,NULL	,N'비고'	,NULL
	,N'비고'	,NULL	,N'비고'	,N''
	,N'비고'	,N''
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'remark'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2018-06-05'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'직위'	,N'직위'	,N'Position'	,N'Position'
	,N'职位'	,N'职位'	,N''	,N'Position'
	,N'Chức vị'	,N'Chức vị'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'roll_pstn_nm'	,'M'	,'uniGrid1'	,'uniGrid'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'시작내부부서코드'	,N'시작내부부서코드'	,N'From Intarnal Code'	,N'From Intarnal Cd.'
	,N'起始部门内码'	,N'起始部门内码'	,N''	,N'From Intarnal Cd.'
	,N'Mã bộ phận bắt đầu'	,N'Mã bộ phận bắt đầu'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'txtFrInternalCd'	,'S'	,'Single'	,'uniTextBox'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'종료내부부서코드'	,N'종료내부부서코드'	,N'To Internal Code'	,N'To Internal Code'
	,N'结束内部编码'	,N'结束内部编码'	,N''	,N'To Internal Code'
	,N'Mã bộ phận kết thúc'	,N'Mã bộ phận kết thúc'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'txtToInternalCd'	,'S'	,'Single'	,'uniTextBox'
	,NULL	,NULL	,'2008-01-07'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,NULL
	,NULL	,NULL
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'uniGrid1'	,'S'	,'Single'	,'uniGrid'
	,NULL	,NULL	,'2010-05-19'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'uniTBL_1'	,N'uniTBL_1'	,N'uniTBL_1'	,N'uniTBL_1'
	,NULL	,NULL	,NULL	,N'uniTBL_1'
	,N'uniTBL_1'	,N'uniTBL_1'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'uniTBL_1'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2014-03-25'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'uniTBL_2'	,N'uniTBL_2'	,N'uniTBL_2'	,N'uniTBL_2'
	,NULL	,NULL	,NULL	,N'uniTBL_2'
	,N'uniTBL_2'	,N'uniTBL_2'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'uniTBL_2'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2014-03-25'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'uniTBL_MainBatch'	,N'uniTBL_MainBatch'	,N'uniTBL_MainBatch'	,N'uniTBL_MainBatch'
	,NULL	,NULL	,NULL	,N'uniTBL_MainBatch'
	,N'uniTBL_MainBatch'	,N'uniTBL_MainBatch'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'uniTBL_MainBatch'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2014-03-25'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'uniTBL_MainCondition'	,N'uniTBL_MainCondition'	,N'uniTBL_MainCondition'	,N'uniTBL_MainCondition'
	,NULL	,NULL	,NULL	,N'uniTBL_MainCondition'
	,N'uniTBL_MainCondition'	,N'uniTBL_MainCondition'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'uniTBL_MainCondition'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2014-03-25'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'uniTBL_MainData'	,N'uniTBL_MainData'	,N'uniTBL_MainData'	,N'uniTBL_MainData'
	,NULL	,NULL	,NULL	,N'uniTBL_MainData'
	,N'uniTBL_MainData'	,N'uniTBL_MainData'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'uniTBL_MainData'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2014-03-25'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'uniTBL_MainReference'	,N'uniTBL_MainReference'	,N'uniTBL_MainReference'	,N'uniTBL_MainReference'
	,NULL	,NULL	,NULL	,N'uniTBL_MainReference'
	,N'uniTBL_MainReference'	,N'uniTBL_MainReference'
	,'uniERP.App.UI.HR.H4006M1_KO883'	,'uniTBL_MainReference'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2014-03-25'	,'2018-06-05'	,1
	,NULL	,NULL	,NULL
)
-----End    DD DML   ProgramID = 'uniERP.App.UI.HR.H4006M1_KO883'-----------------------------------------------------------------------------