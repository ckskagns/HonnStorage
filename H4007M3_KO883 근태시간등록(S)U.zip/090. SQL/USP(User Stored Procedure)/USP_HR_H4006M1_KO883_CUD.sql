
/*		
--�������ν����� ���̴� �ӽ� ���̺� , ó�� �� ���ν����� ������ ���̺��� ������ �켱 ���� �� �Ŀ� �����ؾ��մϴ�.

DROP PROCEDURE    dbo.USP_HR_H4006M1_KO883_CUD
Go
DROP TYPE dbo.HR_H4006M1_KO883
Go
--SELECT * FROM HCA060T_KO883
CREATE TYPE dbo.HR_H4006M1_KO883 AS TABLE
(
	  EMP_NO				nvarchar(13)
	, NAME					nvarchar(100)
	, DEPT_CD				nvarchar(10)
	, DEPT_NM				nvarchar(40)
	, BIZ_AREA_NM			nvarchar(50)
	, DILIG_DT				DATETIME
	, BIZ_AREA_CD			nvarchar(100)
	, ROLL_PSTN_NM			nvarchar(200)
	, DILIG_CD				nvarchar(02)
	, DILIG_NM				nvarchar(20)
	, DAY_TIME				nvarchar(01)
	, DILIG_HH				NUMERIC(3,0)
	, DILIG_MM				NUMERIC(3,0)
	, REMARK				nvarchar(500)
	, CONF_YN				nvarchar(01)
	, CUD_CHAR				nvarchar(01)
	, ROW_NUM				int	
)
GO
*/

/************************************************************************************/
/*****    PROC NAME   :  [USP_HR_H4006M1_KO883_CUD]								*****/
/*****    ���α׷�    :  H4006M1_KO883(���½�û���(S))										*****/
/*****	  Developer	  :  HSY												*****/
/*****    ���߳�¥    :  2018-06-04												*****/
/*****    �ֽż�����¥:  2018-06-04												*****/
/*****    ��    ��    :															*****/
/************************************************************************************/

CREATE PROCEDURE [dbo].[USP_HR_H4006M1_KO883_CUD]
(
		@TBL_GRID				HR_H4006M1_KO883				ReadOnly
	,   @PARAM_USER_ID											NVARCHAR(13)
	,	@MSG_CD													NVARCHAR(06)		OUTPUT
	,	@MESSAGE												NVARCHAR(200)		OUTPUT
)
AS

BEGIN 
	SET NOCOUNT ON 

	BEGIN TRY			
	BEGIN TRANSACTION
------------------------------------------------------------------------------------------
	DELETE A
	FROM HCA060T_KO883 A INNER JOIN @TBL_GRID B ON A.EMP_NO = B.EMP_NO AND A.DILIG_DT = CONVERT(NVARCHAR(10), B.DILIG_DT, 121) AND A.DILIG_CD = B.DILIG_CD
	WHERE B.CUD_CHAR = 'D'
------------------------------------------------------------------------------------------	
	INSERT INTO HCA060T_KO883
	(	EMP_NO, DILIG_DT, DILIG_CD, DILIG_CNT, DILIG_HH, DILIG_MM, CONF_YN, REMARK,
		ISRT_DT, ISRT_EMP_NO, UPDT_DT, UPDT_EMP_NO)
	SELECT
		EMP_NO, CONVERT(NVARCHAR(10), DILIG_DT, 121), DILIG_CD, 1, DILIG_HH, DILIG_MM, 'N', REMARK,
		GETDATE(), @PARAM_USER_ID,		GETDATE(),			@PARAM_USER_ID
	FROM @TBL_GRID
	WHERE CUD_CHAR = 'C'
------------------------------------------------------------------------------------------
	
	UPDATE	A
	SET		
			A.DILIG_HH			=	B.DILIG_HH
		,	A.DILIG_MM			=	B.DILIG_MM
		,	A.REMARK			=	B.REMARK
		,	A.UPDT_EMP_NO		=	@PARAM_USER_ID		
		,	A.UPDT_DT			=	GETDATE()
	FROM HCA060T_KO883 A INNER JOIN @TBL_GRID B ON A.EMP_NO = B.EMP_NO AND A.DILIG_DT = CONVERT(NVARCHAR(10), B.DILIG_DT, 121) AND A.DILIG_CD = B.DILIG_CD
	WHERE B.CUD_CHAR = 'U'

------------------------------------------------------------------------------------------		
	
	COMMIT TRANSACTION
	RETURN 1
	END TRY
	
	BEGIN CATCH
		SET @MSG_CD = 'DT9999'
		SET @MESSAGE = ERROR_MESSAGE()
		ROLLBACK TRANSACTION
		RETURN -1
	END CATCH
END

