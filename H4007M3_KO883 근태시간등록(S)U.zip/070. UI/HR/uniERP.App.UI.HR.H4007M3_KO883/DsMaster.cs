﻿namespace uniERP.App.UI.HR.H4007M3_KO883 {
    
    
    public partial class DsMaster {
    }
}
namespace uniERP.App.UI.HR.H4007M3_KO883 {
    
    
    public partial class DsMaster {
    }
}
