﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Common.Exceptions;

//using Excel;
using System.Data.OleDb;

#endregion

namespace uniERP.App.UI.HR.H4101M1_KO896
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①namespace</NameSpace>
        /// <Module>②module name</Module>
        /// <Class>③class name</Class>
        /// <Desc>④
        ///   This part describe the summary information about class 
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="creator" Date="created date">Make …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        #endregion

        #region ■ 1.4 Class global constants (grid)


        #endregion

        #region ■ 1.5 Class global variables (grid)

        // change your code
        private DsMaster cqtDs = new DsMaster();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(this.cqtDs);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.Common);  // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format
        }

        protected override void Form_Load_Completed()
        {
            DateTime getDt = uniBase.UDate.GetDBServerDateTime();
            dtDate.uniDateTimeF.Value = getDt.AddDays(-1);
            dtDate.uniDateTimeT.Value = getDt;
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            // init Dataset Row : change your code
            cqtDs.Clear();
        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            // Assign default value to controls
            return;
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            // Example: Set ComboBox List (Column Name, Select, From, Where)
            //uniBase.UData.ComboMajorAdd("TaxPolicy", "B0004");
            //uniBase.UData.ComboCustomAdd("MSG_TYPE", "MINOR_CD , MINOR_NM ", "B_MINOR", "MAJOR_CD='A1001'");
        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {
            #region User Define Numeric Format Data Setting  ☆
            //base.viewTB19029.ggUserDefined6.DecPoint = 0;
            //base.viewTB19029.ggUserDefined6.Integeral = 15;
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            /*
             * D00_TIME, -----정상 
             * D31_TIME, -----연장 
             * D35_TIME, -----특근 
             * D36_TIME, -----특잔 
             * D34_TIME, -----야간 
             * D21_TIME, -----지각 
             * D22_TIME, -----조퇴 
             * D23_TIME, -----외출 
             */
            this.uniGrid1.ShowHeaderCheck = false;
            DsMaster.E_TableDataTable uniGridTB1 = cqtDs.E_Table;

            CheckEditorDataFilter chkFilter = new CheckEditorDataFilter("Y", "");
            //CLOSE_FG
            this.uniGrid1.SSSetCheck(uniGridTB1.CLOSE_FGColumn.ColumnName, "확정", 80, enumDef.FieldType.ReadOnly, chkFilter, "", enumDef.HAlign.Center, enumDef.HAlign.Center);
            this.uniGrid1.SSSetDate(uniGridTB1.YYMMDDColumn.ColumnName, "신청일자", enumDef.FieldType.Primary, CommonVariable.gDateFormat, enumDef.HAlign.Center);            
            this.uniGrid1.SSSetEdit(uniGridTB1.EMP_NOColumn.ColumnName, "사원번호", 100, enumDef.FieldType.Primary, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.NAMEColumn.ColumnName, "성명", 130, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.DEPT_NMColumn.ColumnName, "부서", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.ROLE_NMColumn.ColumnName, "직책", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.FUNC_NMColumn.ColumnName, "직무", 115, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.WEEK_NMColumn.ColumnName, "요일", 60, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.S_HHMMColumn.ColumnName, "출근시간", enumDef.FieldType.Default, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.E_HHMMColumn.ColumnName, "퇴근시간", enumDef.FieldType.Default, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.DILIG_CDColumn.ColumnName, "근태코드", 90, enumDef.FieldType.Default, enumDef.CharCase.Upper, true, enumDef.HAlign.Left );
            this.uniGrid1.SSSetEdit(uniGridTB1.DILIG_NMColumn.ColumnName, "근태명칭", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetMask(uniGridTB1.D00_TIMEColumn.ColumnName, "정상", 70, enumDef.FieldType.ReadOnly, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.D31_TIMEColumn.ColumnName, "연장", 70, enumDef.FieldType.Default, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.D35_TIMEColumn.ColumnName, "특근", 70, enumDef.FieldType.Default, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.D36_TIMEColumn.ColumnName, "특잔", 70, enumDef.FieldType.Default, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.D34_TIMEColumn.ColumnName, "야간", 70, enumDef.FieldType.Default, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.D21_TIMEColumn.ColumnName, "지각", 70, enumDef.FieldType.Default, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.D22_TIMEColumn.ColumnName, "조퇴", 70, enumDef.FieldType.Default, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.D23_TIMEColumn.ColumnName, "외출", 70, enumDef.FieldType.Default, "{LOC}hh:mm", enumDef.HAlign.Center);

            //비고
            this.uniGrid1.SSSetEdit(uniGridTB1.REMColumn.ColumnName, "비고", 200, enumDef.FieldType.Default);

            this.uniGrid1.SSSetEdit(uniGridTB1.EMP_FGColumn.ColumnName, "", enumDef.FieldType.ReadOnly);//HH
            this.uniGrid1.SSSetEdit(uniGridTB1.DEPT_CDColumn.ColumnName, "부서", 100, enumDef.FieldType.ReadOnly);//HH
            this.uniGrid1.SSSetEdit(uniGridTB1.ROLE_CDColumn.ColumnName, "직책", 100, enumDef.FieldType.ReadOnly);//HH
            this.uniGrid1.SSSetEdit(uniGridTB1.FUNC_CDColumn.ColumnName, "직무", 100, enumDef.FieldType.ReadOnly);//HH
            
            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);

            #endregion

            #region ■■ 3.1.3 Setting etc grid
            this.uniGrid1.SSSetColHidden(uniGridTB1.EMP_FGColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.DEPT_CDColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.ROLE_CDColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.FUNC_CDColumn.ColumnName);
            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
            // TO-DO: 컨트롤을 초기화(또는 초기값)할때 할일 
            // SetDefaultVal과의 차이점은 전자는 Form_Load 시점에 콘트롤에 초기값을 세팅하는것이고
            // 후자는 특정 시점(조회후 또는 행추가후 등 특정이벤트)에서 초기값을 셋팅한다.
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            // Grid binding with global dataset variable.
            this.InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(this.cqtDs.E_Table);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //TO-DO : code business oriented logic
            if (!uniBase.UDate.CompareDateBetween(dtDate.uniDateTimeF, dtDate.uniDateTimeT))
            {
                return false;
            }

            return DBQuery();
        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)

        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic

            return DBSave();
        }

        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic
            if (this.uniGrid1.ActiveRow != null)
            {
                this.uniGrid1.ActiveRow.Cells["EMP_FG"].Value = "1";
                this.uniGrid1.ActiveRow.Cells["S_HHMM"].Value = "";
                this.uniGrid1.ActiveRow.Cells["E_HHMM"].Value = "";
                this.uniGrid1.ActiveRow.Cells["D00_TIME"].Value = "";
                this.uniGrid1.ActiveRow.Cells["D31_TIME"].Value = "";
                this.uniGrid1.ActiveRow.Cells["D35_TIME"].Value = "";
                this.uniGrid1.ActiveRow.Cells["D36_TIME"].Value = "";
                this.uniGrid1.ActiveRow.Cells["D34_TIME"].Value = "";
                this.uniGrid1.ActiveRow.Cells["D21_TIME"].Value = "";
                this.uniGrid1.ActiveRow.Cells["D22_TIME"].Value = "";
                this.uniGrid1.ActiveRow.Cells["D23_TIME"].Value = "";
            }
            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            DataSet iqtDs = new DataSet();

            try
            {
                /*
                    @S_YYMMDD [NVARCHAR](10), -- 일자FROM  
                    @E_YYMMDD [NVARCHAR](10), -- 일자TO  
                    @DEPT_CD [NVARCHAR](15), -- 부서코드  
                    @EMP_NO  [NVARCHAR](13), -- 사원번호  
                    @USR_ID  [NVARCHAR](15), -- USER_ID  
		            @MSG_CD  [NVARCHAR](6)  OUTPUT   -- ERROR MESSAGE CODE
                 */

                string pS_YYMMDD = dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? "1900-01-01" : dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd");
                string pE_YYMMDD = dtDate.uniDateTimeT.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? "2999-12-31" : dtDate.uniDateTimeT.uniValue.ToString("yyyy-MM-dd");                
                string pDEPT_CD = popDeptCd.CodeValue.Trim();
                string pEMP_NO = popEmpNo.CodeValue.Trim();
                string pUSR_ID = CommonVariable.gUsrID;


                using (uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetStoredProcCommand("[DBO].[USP_DWN_H4101M1_1_KO896]"))
                {
                    uniBase.UDatabase.AddInParameter(uniCmd, "@S_YYMMDD", SqlDbType.NVarChar, 10, pS_YYMMDD);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@E_YYMMDD", SqlDbType.NVarChar, 10, pE_YYMMDD);                    
                    uniBase.UDatabase.AddInParameter(uniCmd, "@DEPT_CD", SqlDbType.NVarChar, 15, pDEPT_CD);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@EMP_NO", SqlDbType.NVarChar, 13, pEMP_NO);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@USR_ID", SqlDbType.NVarChar, 15, pUSR_ID);                    
                    uniBase.UDatabase.AddOutParameter(uniCmd, "@MSG_CD", SqlDbType.NVarChar, 06);

                    uniBase.UDatabase.AddReturnParameter(uniCmd, "RETURN_VALUE", SqlDbType.Int, 1);

                    iqtDs = uniBase.UDatabase.ExecuteDataSet(uniCmd);

                    int iReturn = (int)uniBase.UDatabase.GetParameterValue(uniCmd, "RETURN_VALUE");

                    if (iReturn < 0)
                    {
                        string sMsgCd = uniBase.UDatabase.GetParameterValue(uniCmd, "@MSG_CD") as string;
                        string sMessage = ""; // uniBase.UDatabase.GetParameterValue(_command, "@MESSAGE") as string;

                        if (string.IsNullOrEmpty(sMsgCd)) sMsgCd = "DT9999";

                        uniBase.UMessage.DisplayMessageBox(sMsgCd, MessageBoxButtons.OK, sMessage);

                        return false;
                    }
                    else
                    {
                        if (iqtDs == null || iqtDs.Tables[0].Rows.Count < 1)
                        {
                            uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                            return false;
                        }

                        cqtDs.E_Table.Merge(iqtDs.Tables[0], false, MissingSchemaAction.Ignore);

                        if (uniGrid1.Rows.Count > 0)
                        {
                            for (int iRow = 0; iRow < uniGrid1.Rows.Count; iRow++)
                            {
                                if (uniGrid1.Rows[iRow].Cells["CLOSE_FG"].Value.ToString().ToUpper().Trim() == "Y")
                                {
                                    this.uniGrid1.SpreadLock("YYMMDD", iRow, iRow);
                                    this.uniGrid1.SpreadLock("EMP_NO", iRow, iRow);
                                    this.uniGrid1.SpreadLock("S_HHMM", iRow, iRow);
                                    this.uniGrid1.SpreadLock("E_HHMM", iRow, iRow);
                                    this.uniGrid1.SpreadLock("DILIG_CD", iRow, iRow);
                                    //this.uniGrid1.SpreadLock("D00_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadLock("D31_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadLock("D35_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadLock("D36_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadLock("D34_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadLock("D21_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadLock("D22_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadLock("D23_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadLock("REM", iRow, iRow);
                                }
                                else
                                {
                                    this.uniGrid1.SpreadUnLock("YYMMDD", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("EMP_NO", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("S_HHMM", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("E_HHMM", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("DILIG_CD", iRow, iRow);
                                    //this.uniGrid1.SpreadUnLock("D00_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("D31_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("D35_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("D36_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("D34_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("D21_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("D22_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("D23_TIME", iRow, iRow);
                                    this.uniGrid1.SpreadUnLock("REM", iRow, iRow);

                                    this.uniGrid1.SSSetRequired("YYMMDD", iRow, iRow);
                                    this.uniGrid1.SSSetRequired("EMP_NO", iRow, iRow);
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                if (iqtDs != null) iqtDs.Dispose();
            }

            return true;
        }

        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            //TO-DO : code business oriented logic
            this.uniGrid1.UpdateData();

            try
            {
                DataTable iqtDt = new DataTable();
                iqtDt.Merge(new DsMaster.I_TableDataTable(), false, MissingSchemaAction.Add);
                iqtDt.Merge(cqtDs.E_Table.GetChanges(), false, MissingSchemaAction.Ignore);
                iqtDt.AcceptChanges();

                using (uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetStoredProcCommand("dbo.USP_DWN_H4101M1_KO896_S"))
                {
                    uniBase.UDatabase.AddInParameter(uniCmd, "@TBL_DATA", SqlDbType.Structured, iqtDt);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@USER_ID", SqlDbType.NVarChar, 13, CommonVariable.gUsrID);
                    uniBase.UDatabase.AddOutParameter(uniCmd, "@MSG_CD", SqlDbType.NVarChar, 6);
                    uniBase.UDatabase.AddOutParameter(uniCmd, "@MESSAGE", SqlDbType.NVarChar, 200);
                    uniBase.UDatabase.AddOutParameter(uniCmd, "@ERR_POS", SqlDbType.Int, 3);

                    uniBase.UDatabase.AddReturnParameter(uniCmd, "RETURN_VALUE", SqlDbType.Int, 1);

                    uniBase.UDatabase.ExecuteNonQuery(uniCmd, false);

                    int iReturn = (int)uniBase.UDatabase.GetParameterValue(uniCmd, "RETURN_VALUE");

                    if (iReturn < 0)
                    {
                        string sMsgCd = uniBase.UDatabase.GetParameterValue(uniCmd, "@MSG_CD") as string;
                        string sMessage = uniBase.UDatabase.GetParameterValue(uniCmd, "@MESSAGE") as string;

                        if (string.IsNullOrEmpty(sMsgCd)) sMsgCd = "DT9999";

                        uniBase.UMessage.DisplayMessageBox(sMsgCd, MessageBoxButtons.OK, sMessage);

                        return false;
                    }
                    else if (iReturn == 1)
                    {
                        uniBase.UMessage.DisplayMessageBox("990000", MessageBoxButtons.OK);
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                //if (isettdsTypedDataSet != null) isettdsTypedDataSet.Dispose();
            }


            return true;
        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        #region ■■ 5.2.1 ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ButtonClicked >>> ClickCellButton

        #region ■■ 5.2.2 Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeExitEditMode(object sender, Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs e)
        {
        }
        #endregion ■■ Change >>> CellChange

        #region ■■ 5.2.3 Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
        }
        #endregion ■■ Click >>> AfterSelectChange

        #region ■■ 5.2.4 ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ComboSelChange >>> CellListSelect

        #region ■■ 5.2.5 DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
        }
        #endregion ■■ DblClick >>> DoubleClickCell

        #region ■■ 5.2.6 MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
        }
        #endregion ■■ MouseDown >>> MouseDown

        #region ■■ 5.2.7 ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
        }
        #endregion ■■ ScriptLeaveCell >>> BeforeCellDeactivate

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors
            //CommonPopup cp = new CommonUtil.CommonPopup(PopupType.AutoNumbering);

            //string[] arrRet = cp.showModalDialog(InputParam1);

            #endregion

            #region ▶▶▶ 10.1.2.2 Setting Returned Data

            //if (iWhere) 
            //{
            //    txtMinor.value = arrRet[0];
            //    txtMinorNm.value = arrRet[1];
            //}
            //else
            //{
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingCd].value = arrRet[0];
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingNm].value = arrRet[1];

            //    if (arrRet[2].Length > 0) 
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = arrRet[2];
            //    else
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = "18";

            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.PrefixCd].value = arrRet[0];

            //}

            #endregion

            //CommonVariable.lgBlnFlgChgValue = true;  // 사용자 액션 발생 알림
        }

        #endregion

        #endregion

        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        #region popDeptCd
        private void popDeptCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            //2018-07-30 김지후 사업장없이 진행
            //if (!uniBase.UCommon.CheckRequiredField(cboBizAreaCd, enumDef.PanelType.Condition))
            //{
            //    e.Cancel = true;
            //    return;
            //}

            string pCode = (sender as uniOpenPopup).CodeValue.Trim();
            string pDateYYMM = dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM") == "0001-01" ? "" : dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM");//dtYearMonth.uniValue.ToString("yyyy-MM");
            string pBizAreaCd = CommonVariable.gBizArea;//cboBizAreaCd.SelectedItem.DataValue.ToString();

            string[] param_array = new string[] { pCode, "", pDateYYMM, pBizAreaCd };

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.HDeptPopup";
            e.PopupPassData.PopupWinTitle = "Department Popup";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;
            e.PopupPassData.Data = param_array;
        }

        private void popDeptCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            (sender as uniOpenPopup).CodeValue = iDataSet.Tables[0].Rows[0]["dept_cd"].ToString();
            (sender as uniOpenPopup).CodeName = iDataSet.Tables[0].Rows[0]["dept_nm"].ToString();
        }

        private void popDeptCd_OnChange(object sender, EventArgs e)
        {
            if (popDeptCd.CodeValue.Trim() == "")
            {
                popDeptCd.CodeName = "";
                return;
            }

            //2018-07-30 김지후 사업장없이 진행
            //if (!uniBase.UCommon.CheckRequiredField(cboBizAreaCd, enumDef.PanelType.Condition))
            //{
            //    return;
            //}

            string[] UNISqlId = new string[] { "ZN_HR_DEPT_NM_KO891" };
            string[][] UNIValue = new string[1][];

            UNIValue[0] = new string[6];

            // 0: DATE(IF '' DEFAULT GETDATE)
            // 1: USER ID 
            // 2: DEPT CODE
            // 3: DEPT CODE
            // 4: BIZ AREA CODE
            // 5: ADDITIONAL CONDITION

            string strBizAreaCdSelect = CommonVariable.gBizArea;//cboBizAreaCd.SelectedItem.DataValue.ToString();
            string pCode = popDeptCd.CodeValue.Trim();


            UNIValue[0][0] = "''";
            UNIValue[0][1] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][2] = uniBase.UCommon.FilterVariable(pCode, "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][3] = uniBase.UCommon.FilterVariable(pCode, "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][4] = "'%'";// uniBase.UCommon.FilterVariable(strBizAreaCdSelect, "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][5] = "";// string.Format("AND (DEPT.dept_cd like '{0}'+'%' OR DEPT.dept_nm like '{0}'+'%') ", pCode);

            DataSet pDataSet = null;

            try
            {
                pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                {
                    popDeptCd.CodeValue = "";
                    popDeptCd.CodeName = "";
                    popDeptCd.uniButton_Click(null, null);
                    popDeptCd.Focus();
                    return;
                }

                popDeptCd.CodeValue = pDataSet.Tables[0].Rows[0]["dept_cd"].ToString();
                popDeptCd.CodeName = pDataSet.Tables[0].Rows[0]["dept_nm"].ToString();
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
        }
        #endregion

        #region popEmpNo
        private void popEmpNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            //2018-07-30 김지후 사업장없이 진행
            //if (!uniBase.UCommon.CheckRequiredField(cboBizAreaCd, enumDef.PanelType.Condition))
            //{
            //    e.Cancel = true;
            //    return;
            //}

            string pDate = dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? "1900-01-01" : dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd"); //dtYearMonth.uniValue.ToString("yyyy-MM-dd");
            string pBizAreaCd = CommonVariable.gBizArea;//cboBizAreaCd.SelectedItem.DataValue.ToString();            

            string[] param_array = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName, string.Empty, "", string.Empty };
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup";
            e.PopupPassData.PopupWinTitle = "사원팝업(EmpPopup)";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;
            e.PopupPassData.Data = param_array;

            //Statement ID = 'ZN_HR_EMP_NM2'에 들어갈 파라메터
            e.PopupPassData.UserParameters = new string[] { uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "NULL", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                                                          , string.Concat("'", pDate, "'")
                                                          , uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "NULL", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                                                          , uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "NULL", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                                                          , "''" };
            //, "AND HAA010T.BIZ_AREA_CD LIKE "+uniBase.UCommon.FilterVariable( pBizAreaCd, "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true) };

        }

        private void popEmpNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popEmpNo.CodeValue = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
            popEmpNo.CodeName = iDataSet.Tables[0].Rows[0]["name"].ToString();
        }

        private void popEmpNo_OnChange(object sender, EventArgs e)
        {
            string pCode = popEmpNo.CodeValue.Trim();
            string pDate = dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? CommonVariable.gMinimumDate : dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd"); //dtYearMonth.uniValue.ToString("yyyy-MM-dd");


            if (pCode == "")
            {
                popEmpNo.CodeName = "";
                return;
            }

            string[] UNISqlId = new string[] { "ZN_HR_EMP_NM2_KO891" };
            string[][] UNIValue = new string[1][];

            UNIValue[0] = new string[5];
            //UNIValue[0][0] = "''";
            UNIValue[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][1] = string.Concat("'", pDate, "'");
            UNIValue[0][2] = uniBase.UCommon.FilterVariable(pCode, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][3] = uniBase.UCommon.FilterVariable(pCode, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][4] = "";// string.Format("AND (DEPT.dept_cd like '{0}'+'%' OR DEPT.dept_nm like '{0}'+'%') ", pCode);

            DataSet pDataSet = null;

            try
            {
                pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                {
                    popEmpNo.uniButton_Click(null, null);
                    popEmpNo.Focus();
                    return;
                }
                else
                {
                    popEmpNo.CodeValue = pDataSet.Tables[0].Rows[0]["emp_no"].ToString();
                    popEmpNo.CodeName = pDataSet.Tables[0].Rows[0]["name"].ToString();
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
        }
        #endregion

        #region uniGrid
        private void uniGrid1_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            switch (uniGrid1.ActiveCell.Column.Key.ToUpper())
            {
                case "EMP_NO":
                    string pCode = uniGrid1.ActiveRow.Cells["EMP_NO"].Value.ToString().Trim();
                    string pDate = dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? CommonVariable.gMinimumDate : dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd"); //dtYearMonth.uniValue.ToString("yyyy-MM-dd");
                    //string pBizAreaCd = CommonVariable.gBizArea;//cboBizAreaCd.SelectedItem.DataValue.ToString();

                    string[] param_array = new string[] { pCode, "", string.Empty, "", string.Empty };
                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup";
                    e.PopupPassData.PopupWinTitle = "사원팝업(EmpPopup)";
                    e.PopupPassData.PopupWinWidth = 800;
                    e.PopupPassData.PopupWinHeight = 700;
                    e.PopupPassData.Data = param_array;

                    //Statement ID = 'ZN_HR_EMP_NM2'에 들어갈 파라메터
                    //e.PopupPassData.UserParameters = new string[] { uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "NULL", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                    //                                      , string.Concat("'", pDate, "'")
                    //                                      , uniBase.UCommon.FilterVariable(pCode, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                    //                                      , uniBase.UCommon.FilterVariable(pCode, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                    //                                      , ""};
                    //, "AND HAA010T.BIZ_AREA_CD LIKE "+uniBase.UCommon.FilterVariable( pBizAreaCd, "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true) };
                    break;

                case "DILIG_CD":
                    #region DILIG_CD
                    e.PopupPassData.PopupWinTitle = "근태";
                    e.PopupPassData.ConditionCaption = "근태";
                    e.PopupPassData.PopupWinWidth = 450;
                    e.PopupPassData.PopupWinHeight = 420;

                    e.PopupPassData.SQLFromStatements = "HCA010T(nolock)";
                    e.PopupPassData.SQLWhereStatements = "(DILIG_TYPE = '1' AND DAY_TIME = '1')";
                    e.PopupPassData.SQLWhereInputCodeValue = uniGrid1.ActiveRow.Cells["DILIG_CD"].Value.ToString().Trim();
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.DistinctOrNot = false;

                    e.PopupPassData.GridCellCode = new String[2];
                    e.PopupPassData.GridCellCaption = new String[2];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
                    e.PopupPassData.GridCellLength = new int[2];

                    e.PopupPassData.GridCellCode[0] = "DILIG_CD";
                    e.PopupPassData.GridCellCode[1] = "DILIG_NM";

                    e.PopupPassData.GridCellCaption[0] = "근태";
                    e.PopupPassData.GridCellCaption[1] = "근태명";

                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

                    e.PopupPassData.GridCellLength[0] = 100;
                    e.PopupPassData.GridCellLength[1] = 130;
                    #endregion                   
                    break;
            }
        }

        private void uniGrid1_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            switch (uniGrid1.ActiveCell.Column.Key.ToUpper())
            {
                case "EMP_NO":

                    uniGrid1.ActiveRow.Cells["EMP_NO"].Value = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
                    uniGrid1.ActiveRow.Cells["NAME"].Value = iDataSet.Tables[0].Rows[0]["name"].ToString();
                    uniGrid1.ActiveRow.Cells["DEPT_CD"].Value = iDataSet.Tables[0].Rows[0]["DEPT_CD"].ToString();
                    uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = iDataSet.Tables[0].Rows[0]["DEPT_NM"].ToString();

                    //이 이하는 이벤트처리 : uniGrid1_AfterExitEditMode 참고
                    //uniGrid1.ActiveRow.Cells["ROLE_CD"].Value = iDataSet.Tables[0].Rows[0]["ROLE_CD"].ToString();
                    //uniGrid1.ActiveRow.Cells["ROLE_NM"].Value = iDataSet.Tables[0].Rows[0]["ROLE_NM"].ToString();
                    //uniGrid1.ActiveRow.Cells["FUNC_CD"].Value = iDataSet.Tables[0].Rows[0]["FUNC_CD"].ToString();
                    //uniGrid1.ActiveRow.Cells["FUNC_NM"].Value = iDataSet.Tables[0].Rows[0]["FUNC_NM"].ToString();                 

                    break;

                case "DILIG_CD":
                    uniGrid1.ActiveRow.Cells["DILIG_CD"].Value = iDataSet.Tables[0].Rows[0]["DILIG_CD"].ToString();
                    uniGrid1.ActiveRow.Cells["DILIG_NM"].Value = iDataSet.Tables[0].Rows[0]["DILIG_NM"].ToString();
                    break;
            }
        }

        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {
            switch (uniGrid1.ActiveCell.Column.Key.ToUpper())
            {
                case "EMP_NO":

                    string pCode = uniGrid1.ActiveRow.Cells["EMP_NO"].Value.ToString().Trim();
                    string pDate = dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? CommonVariable.gMinimumDate : dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd"); //dtYearMonth.uniValue.ToString("yyyy-MM-dd");


                    if (pCode == "")
                    {
                        uniGrid1.ActiveRow.Cells["EMP_NO"].Value = "";
                        uniGrid1.ActiveRow.Cells["NAME"].Value = "";
                        uniGrid1.ActiveRow.Cells["DEPT_CD"].Value = "";
                        uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = "";
                        uniGrid1.ActiveRow.Cells["ROLE_CD"].Value = "";
                        uniGrid1.ActiveRow.Cells["ROLE_NM"].Value = "";
                        uniGrid1.ActiveRow.Cells["FUNC_CD"].Value = "";
                        uniGrid1.ActiveRow.Cells["FUNC_NM"].Value = "";
                        uniGrid1.ActiveRow.Cells["WEEK_NM"].Value = "";
                        return;
                    }

                    string[] UNISqlId = new string[] { "ZN_HR_EMP_NM2_KO891" };
                    string[][] UNIValue = new string[1][];

                    UNIValue[0] = new string[5];
                    //UNIValue[0][0] = "''";
                    UNIValue[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    UNIValue[0][1] = string.Concat("'", pDate, "'");
                    UNIValue[0][2] = uniBase.UCommon.FilterVariable(pCode, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    UNIValue[0][3] = uniBase.UCommon.FilterVariable(pCode, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    UNIValue[0][4] = "";// string.Format("AND (DEPT.dept_cd like '{0}'+'%' OR DEPT.dept_nm like '{0}'+'%') ", pCode);

                    DataSet pDataSet = null;

                    try
                    {
                        pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                        if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                        {
                            //popDeptCd.uniButton_Click(null, null);
                            //popDeptCd.Focus();
                            return;
                        }
                        else
                        {
                            uniGrid1.ActiveRow.Cells["EMP_NO"].Value = pDataSet.Tables[0].Rows[0]["emp_no"].ToString();
                            uniGrid1.ActiveRow.Cells["NAME"].Value = pDataSet.Tables[0].Rows[0]["name"].ToString();

                            uniGrid1.ActiveRow.Cells["DEPT_CD"].Value = pDataSet.Tables[0].Rows[0]["DEPT_CD"].ToString();
                            uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = pDataSet.Tables[0].Rows[0]["DEPT_NM"].ToString();
                            uniGrid1.ActiveRow.Cells["ROLE_CD"].Value = pDataSet.Tables[0].Rows[0]["ROLE_CD"].ToString();
                            uniGrid1.ActiveRow.Cells["ROLE_NM"].Value = pDataSet.Tables[0].Rows[0]["ROLE_NM"].ToString();
                            uniGrid1.ActiveRow.Cells["FUNC_CD"].Value = pDataSet.Tables[0].Rows[0]["FUNC_CD"].ToString();
                            uniGrid1.ActiveRow.Cells["FUNC_NM"].Value = pDataSet.Tables[0].Rows[0]["FUNC_NM"].ToString();
                        }
                    }
                    catch (Exception ex)
                    {
                        bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                        if (reThrow)
                            throw;
                        return;
                    }
                    break;

                case "YYMMDD":
                    /*
                        SELECT	DATENAME(DW,{0})					AS	WEEK_NM,--요일구분
                     */

                    if (uniGrid1.ActiveRow.Cells["YYMMDD"].Value.ToString() == "")
                    {
                        return;
                    }

                    string pYYMMDD = Convert.ToDateTime(uniGrid1.ActiveRow.Cells["YYMMDD"].Value).ToString("yyyy-MM-dd");

                    string sGetValue = string.Format(@"SELECT	DATENAME(DW,'{0}')					 AS	WEEK_NM--요일구분", pYYMMDD);

                    DataSet Ds = uniBase.UDataAccess.CommonQuerySQL(sGetValue);

                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        uniGrid1.ActiveRow.Cells["WEEK_NM"].Value = Ds.Tables[0].Rows[0]["WEEK_NM"].ToString();
                    }


                    break;
            }
        }
        #endregion

        #region Excel Control
        private string ExcelConnection(string filename)
        {
            string strConn = "";
            string[] extension = filename.Split('.');


            OleDbEnumerator enumerator = new OleDbEnumerator();
            DataTable table = enumerator.GetElements(); //사용할 수 있는 전체 OLEDB 객체를 가져옴.
            List<string> aryProviders = new List<string>();

            foreach (DataRow row in table.Rows)
                aryProviders.Add(row[0].ToString());

            table.Dispose();
            aryProviders.Sort((p, n) => n.CompareTo(p));//최신 버전이 위로 올라가게 Sort

            //엑셀에서 사용할 OLEDB 객체를 찾음.
            string providerName = aryProviders.Find(m => m.ToUpper().StartsWith("MICROSOFT.ACE.OLEDB"));

            if (string.IsNullOrEmpty(providerName))
                providerName = aryProviders.Find(m => m.ToUpper().StartsWith("MICROSOFT.JET.OLEDB"));

            if (string.IsNullOrEmpty(providerName))
                return "";

            if (Debugger.IsAttached)
                strConn = "Provider=" + providerName + ";Data Source=" + filename + ";Mode=ReadWrite|Share Deny None;Extended Properties='";
            else
                strConn = "Provider=" + providerName + ";Data Source=" + filename + ";Mode=ReadWrite|Share Deny None;Extended Properties='";

            if (extension[extension.Length - 1].ToLower().Equals("xls"))
                strConn += "Excel 8.0;";
            else
                strConn += "Excel 12.0;";

            strConn += " HDR=NO;IMEX=1';Persist Security Info=False";

            return strConn;
        }

        private string GetX86ExcelConnectionString(string extensions)
        {
            string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Mode=ReadWrite|Share Deny None;Extended Properties='";

            if (extensions.ToLower().Equals("xls"))
                strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Mode=ReadWrite|Share Deny None;Extended Properties='Excel 8.0;";
            else
                strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Mode=ReadWrite|Share Deny None;Extended Properties='Excel 12.0;";

            strConn += " HDR=NO; IMEX=1';Persist Security Info=False";

            return strConn;
        }

        private string GetX64ExcelConnectionString(string extensions)
        {
            string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Mode=ReadWrite|Share Deny None;Extended Properties='";

            if (extensions.ToLower().Equals("xls"))
                strConn += "Excel 8.0;";
            else
                strConn += "Excel 12.0;";

            //HDR:엑셀의 첫번째 줄의 데이터를 field명으로 인식할것인지 여부(YES,NO)
            //IMX: 데이타 형식을 어떻게 적용할 것인지에 대한 옵션. 만약 그 줄의 데이터의 표본이 정수라면 필드가 생성될때 정수형으로 생성됨.
            //IMX=1로 해서 정수형 생성 무시하고 무조건 string으로 생성.
            strConn += " HDR=NO; IMEX=1';Persist Security Info=False";

            return strConn;
        }

        private void lblRefData_Click(object sender, EventArgs e)
        {
            OleDbConnection ExcelConn = null;
            string xlsfilename;
            string[] sheetNames = null;

            StringBuilder sbSQL = new StringBuilder();

            try
            {
                this.Presenter.ProgressBarController.DisplayProgressBar();

                FileDialog fileDlg = new OpenFileDialog();
                //fileDlg.InitialDirectory = "C:\\";
                //fileDlg.InitialDirectory = "D:\\이노비즈\\04.프로젝트\\18.나인테크";
                fileDlg.Filter = "모든파일(*.*)|*.*";
                fileDlg.Filter = "Excel files97|*.xls|Excel files(*.xlsx)|*.xlsx;";
                fileDlg.Title = "엑셀파일을 선택하세요.";
                fileDlg.RestoreDirectory = true;

                if (fileDlg.ShowDialog() == DialogResult.OK)
                {
                    DialogResult IntRetCDmsg = uniBase.UMessage.DisplayMessageBox("900018", MessageBoxButtons.YesNo);
                    if (IntRetCDmsg == DialogResult.No)
                        return;

                    xlsfilename = fileDlg.FileName;

                    string strCon = ExcelConnection(xlsfilename);

                    if (string.IsNullOrEmpty(strCon))
                    {
                        MessageBox.Show("사용 가능한 OLEDB가 없습니다. OFFICE의 Platform(Bit 수)를 확인하세요. (사용자 PC 32 Bit ->  MicroSoft OFFICE 32 Bit or 사용자 PC 64 Bit -> MicroSoft OFFICE 64 Bit)");
                        return;
                    }

                    ExcelConn = new OleDbConnection(strCon);
                    ExcelConn.Open();

                    //
                    DataTable dtsheets = new DataTable();
                    dtsheets = ExcelConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                    sheetNames = new string[dtsheets.Rows.Count];

                    for (int i = 0; i < dtsheets.Rows.Count; i++)
                    {
                        sheetNames[i] = dtsheets.Rows[i]["TABLE_NAME"].ToString().Trim('\'').Replace("$", "");
                    }

                    //string SQL = @"SELECT * FROM[Sheet1$]";
                    // 첫번째 Sheet만 Select
                    string SQL = @"SELECT * FROM[" + sheetNames[0] + "$]";


                    OleDbCommand cmd = new OleDbCommand(SQL, ExcelConn);

                    OleDbDataReader reader = cmd.ExecuteReader();

                    decimal rowCnt = 0;
                    string strSelect = string.Empty;
                    string strItemCd = string.Empty;

                    DsMaster.I_EXCEL_UPDataTable idtSave = new DsMaster.I_EXCEL_UPDataTable();

                    while (reader.Read())
                    {
                        try
                        {
                            if (rowCnt == 0)
                            {
                                rowCnt++;
                                continue;
                            }

                            DsMaster.I_EXCEL_UPRow iRow = idtSave.NewI_EXCEL_UPRow();

                            //iRow["cud_char"] = "C";
                            /*
                             * S_DATE
                                EMP_NO
                                USER_NM
                                DEPT_NM
                                SHIFT
                                SCHEDULE
                             * 
                                S_TIME
                                E_TIME
                                RESULT
                                FIRST_IN
                             * 
                                LAST_OUT
                                BREAKTIME
                                WORKTIME
                                PRO_FG
                                INSRT_USER_ID
                                INSRT_DT
                                UPDT_USER_ID
                                UPDT_DT
                             */

                            // 날짜값
                            //iRow.S_DATE = Convert.ToDateTime(reader[0]).ToString("yyyy-MM-dd");

                            //DateTime Dt = Convert.ToDateTime(reader[0]);
                            string sDate = reader[0].ToString();

                            try
                            {
                                DateTime Dt2 = DateTime.ParseExact(sDate, "yyyy/MM/dd", System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch
                            {
                                if (CommonVariable.gLang == "KO")
                                    uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"Date Format을 확인하십시오. : {0} line", rowCnt.ToString()));
                                else
                                    uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"Date Format Check! : {0} line", rowCnt.ToString()));

                                break;
                            }

                            //근무일자
                            iRow.YYMMDD = sDate;
                            //조직1
                            iRow.DEPT1 = reader[1].ToString().Trim();
                            //조직2
                            iRow.DEPT2 = reader[2].ToString().Trim();
                            //조직3
                            iRow.DEPT3 = reader[3].ToString().Trim();
                            //조직4
                            iRow.DEPT4 = reader[4].ToString().Trim();
                            //NAME
                            iRow.NAME = reader[5].ToString().Trim();
                            //EMP_NO
                            iRow.EMP_NO = reader[6].ToString().Trim();
                            //PAY_GRD1	직급
                            iRow.PAY_GRD1 = reader[7].ToString().Trim();
                            //SECOM_NO	카드번호
                            iRow.SECOM_NO = reader[8].ToString().Trim();
                            //WK_TYPE	근무조
                            iRow.WK_TYPE = reader[9].ToString().Trim();
                            //WK_SCHEDUL	근무스케줄
                            iRow.WK_SCHEDUL = reader[10].ToString().Trim();
                            //START_DT	출근일자/시간
                            if (sChangeYYYYMMDDHHSS(reader[11].ToString()).Length > 16)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"출근일자을 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.START_DT = sChangeYYYYMMDDHHSS(reader[11].ToString());
                            }
                            //END_DT	퇴근시간
                            if (sChangeYYYYMMDDHHSS(reader[12].ToString()).Length > 16)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"퇴근일자 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.END_DT = sChangeYYYYMMDDHHSS(reader[12].ToString());
                            }
                            //START_FG	출근판정
                            iRow.START_FG = reader[13].ToString();
                            //END_FG	퇴근판정
                            iRow.END_FG = reader[14].ToString();
                            //LATENESS	지각시간
                            if (sChangeHHMM(reader[15].ToString()).Length > 5)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"조기출근시간을 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.LATENESS = sChangeHHMM(reader[15].ToString());
                            }
                            //FS_TIME	조기출근시간                        
                            if (sChangeHHMM(reader[16].ToString()).Length > 5)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"조기출근시간을 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.FS_TIME = sChangeHHMM(reader[16].ToString());
                            }
                            //EXT_TIME	연장근무시간
                            if (sChangeHHMM(reader[17].ToString()).Length > 5)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"연장근무시간을 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.EXT_TIME = sChangeHHMM(reader[17].ToString());
                            }
                            //LIGHT_TIME	야간근무시간
                            if (sChangeHHMM(reader[18].ToString()).Length > 5)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"야간근무시간을 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.LIGHT_TIME = sChangeHHMM(reader[18].ToString());
                            }
                            //HOLI_TIME	휴일근무시간
                            if (sChangeHHMM(reader[19].ToString()).Length > 5)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"휴일근무시간을 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.HOLI_TIME = sChangeHHMM(reader[19].ToString());
                            }
                            //WK_TIME	실제근무시간                            
                            if (sChangeHHMM(reader[20].ToString()).Length > 5)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"실제근무시간을 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.WK_TIME = sChangeHHMM(reader[20].ToString());
                            }
                            //TOTAL_TIME	총근무시간
                            if (sChangeHHMM(reader[21].ToString()).Length > 5)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"총근무시간을 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.TOTAL_TIME = sChangeHHMM(reader[21].ToString());
                            }
                            //STD_TIME	정상근무시간
                            if (sChangeHHMM(reader[22].ToString()).Length > 5)
                            {
                                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, string.Format(@"정상근무시간을 확인하십시오. : {0} line", rowCnt.ToString()));
                                break;
                            }
                            else
                            {
                                iRow.STD_TIME = sChangeHHMM(reader[22].ToString());
                            }
                            //SLOW_FG	외출여부
                            iRow.STD_TIME = reader[23].ToString();

                            idtSave.AddI_EXCEL_UPRow(iRow);

                            rowCnt++;

                        }
                        catch (Exception ex)
                        {
                            this.Presenter.ProgressBarController.HideProgressBar();
                            bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                            if (reThrow)
                                throw;

                            reader.Close();
                            ExcelConn.Close();
                            return;
                        }
                    } // Excel File DataTable에 넣기.

                    reader.Close();
                    ExcelConn.Close();

                    if (idtSave.Rows.Count > 0)
                    {
                        string pDateFr = dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? CommonVariable.gMinimumDate : dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd");
                        string pDateTo = dtDate.uniDateTimeT.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? CommonVariable.gMaximumDate : dtDate.uniDateTimeT.uniValue.ToString("yyyy-MM-dd");

                        DataTable iqtExcelDt = new DataTable();
                        iqtExcelDt.Merge(new DsMaster.I_EXCEL_UPDataTable(), false, MissingSchemaAction.Add);
                        iqtExcelDt.Merge(idtSave, false, MissingSchemaAction.Ignore);
                        iqtExcelDt.AcceptChanges();

                        using (uniERP.AppFramework.DataBridge.uniCommand _uniCmd = uniBase.UDatabase.GetStoredProcCommand("dbo.USP_DWN_H4101M1_KO896_EXCEL_UPLOAD"))
                        {
                            uniBase.UDatabase.AddInParameter(_uniCmd, "@TBL_DATA", SqlDbType.Structured, iqtExcelDt);
                            uniBase.UDatabase.AddInParameter(_uniCmd, "@DATE_FR", SqlDbType.NVarChar, 10, pDateFr);
                            uniBase.UDatabase.AddInParameter(_uniCmd, "@DATE_TO", SqlDbType.NVarChar, 10, pDateTo);
                            uniBase.UDatabase.AddInParameter(_uniCmd, "@USER_ID", SqlDbType.NVarChar, 15, CommonVariable.gUsrID);
                            uniBase.UDatabase.AddOutParameter(_uniCmd, "@MSG_CD", SqlDbType.NVarChar, 6);
                            uniBase.UDatabase.AddOutParameter(_uniCmd, "@MESSAGE", SqlDbType.NVarChar, 200);
                            uniBase.UDatabase.AddOutParameter(_uniCmd, "@ERR_POS", SqlDbType.Int, 3);

                            uniBase.UDatabase.AddReturnParameter(_uniCmd, "RETURN_VALUE", SqlDbType.Int, 1);

                            uniBase.UDatabase.ExecuteNonQuery(_uniCmd, false);

                            int iReturn = (int)uniBase.UDatabase.GetParameterValue(_uniCmd, "RETURN_VALUE");

                            if (iReturn < 0)
                            {
                                string sMsgCd = uniBase.UDatabase.GetParameterValue(_uniCmd, "@MSG_CD") as string;
                                string sMessage = uniBase.UDatabase.GetParameterValue(_uniCmd, "@MESSAGE") as string;

                                if (string.IsNullOrEmpty(sMsgCd)) sMsgCd = "DT9999";

                                uniBase.UMessage.DisplayMessageBox(sMsgCd, MessageBoxButtons.OK, sMessage);

                                return;
                            }
                            else
                            {
                                uniBase.UMessage.DisplayMessageBox("990000", MessageBoxButtons.OK);
                            }
                        } // Using END
                    }
                }

                uniGrid1.redrawAllRowImage();
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
            }
            finally
            {
                this.Presenter.ProgressBarController.HideProgressBar();
            }

            uniGrid1.clearSpreadData();
            DBQuery();
        }

        //연/월/일 시:분
        private string sChangeYYYYMMDDHHSS(string pReader)
        {
            string sRetVal = string.Empty;

            try
            {
                sRetVal = DateTime.FromOADate(double.Parse(pReader.ToString())).ToString("{yyyy/MM/dd HH:mm}");

            }
            catch
            {
                sRetVal = pReader.ToString().Trim();
            }

            return sRetVal;
        }

        private string sChangeHHMM(string pReader)
        {
            string sRetVal = string.Empty;

            try
            {
                sRetVal = DateTime.FromOADate(double.Parse(pReader.ToString())).ToString("{HH:mm}");
            }
            catch
            {
                sRetVal = pReader.ToString().Trim();
            }

            return sRetVal;
        }

        #endregion

       


        #endregion

        #endregion

    }
}