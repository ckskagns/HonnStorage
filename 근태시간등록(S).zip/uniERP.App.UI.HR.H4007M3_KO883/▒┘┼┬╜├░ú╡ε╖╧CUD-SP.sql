

--CREATE TYPE [dbo].[UTP_H4007M3_KO883] AS TABLE(
--	   EMP_NO      nvarchar(26),
--	   EMP_NM      nvarchar(26),
--	   DEPT_NM     nvarchar(26), 
--	   ROLL_PSTN_NM nvarchar(26),
--	   Work_Day     nvarchar(40),
--	   Work_Week   nvarchar(40), 
--	   Attendance  nvarchar(40), 
--	   Leave       nvarchar(40), 
--	   OT          nvarchar(26), 
--	   HT          nvarchar(26), 
--	   TT          nvarchar(26),
--	   EXT_QTY1    nvarchar(40),	    
--	   CUD_CHAR    nvarchar(2),
--	   ROW_NUM int

--)

       
CREATE PROCEDURE [dbo].[USP_H4007M3_KO883_CUD]          
(           
  @TBL_DATA    UTP_H4007M3_KO883 READONLY          
, @USER_ID    NVARCHAR(13)          
, @MSG_CD     NVARCHAR(06)  OUTPUT          
, @MESSAGE    NVARCHAR(200)  OUTPUT          
, @ERR_POS    INT     OUTPUT          
)          
AS          
          
BEGIN          
 SET NOCOUNT ON          
          
 DECLARE                
	
	@EMP_NO	     nvarchar(26),
	@EMP_NM      nvarchar(26),
	@DEPT_NM     nvarchar(26), 
	@ROLL_PSTN_NM nvarchar(26),
	@Work_Day     nvarchar(40),
	@Work_Week   nvarchar(40), 
	@Attendance  nvarchar(40), 
	@Leave       nvarchar(40), 
	@OT          nvarchar(26), 
	@HT          nvarchar(26), 
	@TT          nvarchar(26), 	
	@EXT_QTY1    nvarchar(40),					
	@CUD_CHAR    nvarchar(2),
	@ROW_NUM int,             
    @ERROR_NUMBER INT          

          
  BEGIN TRY          
  BEGIN TRANSACTION          
          
           
  DECLARE CUR_H4007M3_KO883 CURSOR LOCAL FOR          
          
  SELECT          	 
        EMP_NO       ,  
	    EMP_NM     	 ,
	    DEPT_NM    	 ,
	    ROLL_PSTN_NM ,
	    Work_Day   	 ,
	    Work_Week  	 ,
	    Attendance 	 ,
	    Leave      	 ,
	    OT         	 ,
	    HT         	 ,
	    TT         	 ,
		EXT_QTY1     ,	
	    CUD_CHAR   	 ,
	    ROW_NUM              
		   
   FROM @TBL_DATA          
          
  OPEN CUR_H4007M3_KO883           
  FETCH NEXT FROM CUR_H4007M3_KO883          
  INTO   
       @EMP_NO       ,
	   @EMP_NM     	 ,
	   @DEPT_NM    	 ,
	   @ROLL_PSTN_NM ,
	   @Work_Day   	 ,
	   @Work_Week  	 ,
	   @Attendance 	 ,
	   @Leave      	 ,
	   @OT         	 ,
	   @HT         	 ,
	   @TT         	 ,	
	   @EXT_QTY1     ,
	   @CUD_CHAR   	 ,
	   @ROW_NUM            

                
  WHILE(@@FETCH_STATUS=0)          
  BEGIN          
   SET @ERR_POS = @ROW_NUM          
          
  IF (@CUD_CHAR = 'C')          
  BEGIN          
   
    INSERT INTO WT_MA          
    (
	  EMP_NO        
    , EMP_NM   
	, DEPT_NM    
	, ROLL_PSTN_NM
	, Work_Day   
	, Work_Week  
	, Attendance 
	, Leave      
	, OT         
	, HT         
	, TT
	, EXT_QTY1
	, ISRT_DT    
	, UPDT_EMP_NO
	, UPDT_DT       
    )          
    VALUES          
    (
	  @EMP_NO          
    , @EMP_NM   
	, @DEPT_NM    
	, @ROLL_PSTN_NM
	, @Work_Day   
	, @Work_Week  
	, @Attendance 
	, @Leave      
	, @OT         
	, @HT         
	, @TT  
	, @EXT_QTY1
	, GETDATE()
	, @USER_ID
	, GETDATE()                  
    )          
  END          
  ELSE IF (@CUD_CHAR = 'U') 
           
  BEGIN          
    UPDATE WT_MA          
    SET               
	  EMP_NO          =     @EMP_NO
    , EMP_NM          =     @EMP_NM   
	, DEPT_NM    	  =	    @DEPT_NM    
	, ROLL_PSTN_NM	  =	    @ROLL_PSTN_NM
	, Work_Day   	  =	    @Work_Day   
	, Work_Week  	  =	    @Work_Week  
	, Attendance 	  =	    @Attendance 
	, Leave      	  =	    @Leave      
	, OT         	  =	    @OT         
	, HT         	  =	    @HT         
	, TT         	  =	    @TT         
	, EXT_QTY1        =     @EXT_QTY1 
	, ISRT_DT    	  =	    GETDATE()
	, UPDT_EMP_NO	  =	    @USER_ID
	, UPDT_DT         =     GETDATE()     
         
    WHERE          
       EMP_NM = @EMP_NM
	AND Work_Day = @Work_Day         
              
          
  END          
  ELSE IF (@CUD_CHAR = 'D')          
  BEGIN          
              
    DELETE FROM WT_MA           
    WHERE          
       EMP_NM = @EMP_NM
	AND Work_Day = @Work_Day         
  
          
  END          
    --     IF (@CUD_CHAR <> 'D')   
    --      BEGIN  
    --IF (@BASIC_QTY + @USER_QTY)    <=0  
    --BEGIN  
    --     SET @MSG_CD   = '122918' -- %1 ���忡 �����߽��ϴ�.          
    --SET @MESSAGE  = '������Ʈ/���(' + @DILIG_EMP_NO + '/' + @YYYY  + ')'    
    -- RAISERROR(@MSG_CD, 16, 1)  
    --END  
    --END  
    
           
  FETCH NEXT FROM CUR_H4007M3_KO883          
  INTO           
       @EMP_NO       ,
	   @EMP_NM     	 ,
	   @DEPT_NM    	 ,
	   @ROLL_PSTN_NM ,
	   @Work_Day   	 ,
	   @Work_Week  	 ,
	   @Attendance 	 ,
	   @Leave      	 ,
	   @OT         	 ,
	   @HT         	 ,
	   @TT         	 ,
	   @EXT_QTY1     ,
	   @CUD_CHAR   	 ,
	   @ROW_NUM        

  END --WHILE END          
           
          
 CLOSE CUR_H4007M3_KO883          
 DEALLOCATE CUR_H4007M3_KO883                    
          
 END TRY          
 BEGIN CATCH          
           
 SET @ERROR_NUMBER = ERROR_NUMBER()          
            
  --IF @ERROR_NUMBER = 2627  --%1! ���� ���� '%2!'��(��) �����߽��ϴ�. ��ü '%3!'�� �ߺ� Ű�� ������ �� �����ϴ�. �ߺ� Ű ���� %4!�Դϴ�.          
  -- BEGIN          
  --  SET @MSG_CD   = '970001' -- %1 ��(��) �̹� �����մϴ�.          
  --  SET @MESSAGE  = '������Ʈ/���(' + @DILIG_EMP_NO + '/' + @YYYY  + ')'        
  -- END          
          
  --ELSE IF @ERROR_NUMBER = 547  -- %1! ���� %2! ���� ���� "%3!"��(��) �浹�߽��ϴ�. �����ͺ��̽� "%4!", ���̺� "%5!"%6!%7!%8!���� �浹�� �߻��߽��ϴ�.          
  -- BEGIN          
  --  SET @MSG_CD   = '971000' -- %1 ��(��) �����ϰ� �ִ� �����Ͱ� �ֽ��ϴ�. �۾��� ������ �� �����ϴ�.          
  --  SET @MESSAGE  = '������Ʈ/���(' + @DILIG_EMP_NO + '/' + @YYYY  + ')'        
  -- END          
          
  --ELSE IF @ERROR_NUMBER = 1205  -- Ʈ�����(���μ��� ID %1!)�� %2! ���ҽ����� �ٸ� ���μ������� ���� ���°� �߻��Ͽ� ������ �����Ǿ����ϴ�. Ʈ������� �ٽ� �����Ͻʽÿ�.          
  -- BEGIN          
  --  SET @MSG_CD   = '122918' -- %1 ���忡 �����߽��ϴ�.          
  --  SET @MESSAGE  = '������Ʈ/���(' + @DILIG_EMP_NO + '/' + @YYYY  + ')'        
  -- END          
          
  --ELSE          
  -- SET @MESSAGE  = ERROR_MESSAGE()          
          
  --GOTO __ERROR          
 END CATCH          
          
 IF @@TRANCOUNT > 0 COMMIT TRANSACTION          
 RETURN 1          
          
 __ERROR:          
 IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION          
 RETURN -1          
END          

