          
            
CREATE PROCEDURE [dbo].[USP_H4007M2_KO883]            
 (  
	@EMP_NO nvarchar(26), -- ���
	@DEPT_NM nvarchar(26), -- �μ�
	@Work_From nvarchar(26), -- �ٹ�����From   
    @Work_To  nvarchar(26)  -- �ٹ�����To
             
 ) AS                      
                
 BEGIN                                          
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                    
                                       
SET NOCOUNT ON                    

  IF @Work_From IS NULL OR @Work_From = '' SET @Work_From ='1900-01-01'     
  IF @Work_To IS NULL OR @Work_To = '' SET @Work_To ='2099-12-31' 
             
--declare @str datetime,                
--  @end datetime                  
                
--select @str = convert(datetime,@yyyy + '-' + '01' + '-' + '01')                
--select @end = convert(datetime,@yyyy + '-' + '12' + '-' + '31')           
    
    
select     

	 EMP_NO      , 
	 EMP_NM      ,
	 DEPT_NM     ,
	 ROLL_PSTN_NM,
	 Work_Day    ,
	 Work_Week   ,
	 Attendance  ,
	 Leave       ,
	 OT          ,
	 HT          ,
	 TT          ,
	 EXT_QTY1    ,
	 EXT_QTY2    ,
	 EXT_QTY3    ,
	 ISRT_DT     ,	
	 UPDT_EMP_NO ,
	 UPDT_DT     	
  
 from WT_MA

  where a.YYYY = @YYYY and ( @DILIG_EMP_NO ='' or A.DILIG_EMP_NO = @DILIG_EMP_NO ) and (@DEPT_CD = '' or dept.dept_cd = @DEPT_CD)      
  order by Work_Day desc   
            
 END 