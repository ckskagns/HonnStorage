﻿namespace uniERP.App.UI.HR.H4007M7_KO883.tdsY8101M2_KO883TableAdapters
{
}
namespace uniERP.App.UI.HR.H4007M7_KO883 {
    
    
    public partial class tdsY8101M2_KO883 {
        partial class E_WT_MA_DETAILDataTable
        {
        }   
        partial class I_PMS_PROJECT_RATEDataTable
        {
        }
    }
}
