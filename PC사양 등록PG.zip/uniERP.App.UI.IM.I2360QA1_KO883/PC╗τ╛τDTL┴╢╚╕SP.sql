--exec USP_I2359QA1_KO883 @EMP_NO=N'',@Pur_FROM=N'1900-01-01',@Pur_TO=N'2999-12-31',@PC_NAME=N'',@TV_NAME=N''

CREATE PROCEDURE [dbo].[USP_I2360QA1_KO883]            
 (                        
	  @EMP_NO    NVARCHAR(26) --���                
    , @PC_TYPE   NVARCHAR(26) --PC����                  
	, @PC_NAME   NVARCHAR(40) --PC��
	, @TV_NAME   NVARCHAR(40) --����� ��
 ) AS                      
                
 BEGIN                                          
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                    
                                       
SET NOCOUNT ON                    
             
    
select 
    A.EMP_NO,
	B.EMP_NM,
	B.DEPT_NM,
	B.PC_NAME,
	B.CPU,
	B.RAM,
	B.GRAPHIC,
	B.SSD,
	B.HDD,
	B.TV_1,
	B.TV_2

 from HAA010T A(NOLOCK)
 join PC_DTL B(NOLOCK) on A.EMP_NO = B.EMP_NO  
 where 
 (@EMP_NO ='' or A.EMP_NO = @EMP_NO ) 
 and (@PC_NAME='' or (B.PC_NAME like '%'+ISNULL(@PC_NAME,'')+'%') )
 and (@TV_NAME='' or (B.TV_1 like '%'+@TV_NAME+'%') or (B.TV_2 like '%'+@TV_NAME+'%') )
 and (@PC_TYPE='' or (B.PC_TYPE like '%'+@PC_TYPE+'%')  )
  order by   A.EMP_NO    
            
 END 
