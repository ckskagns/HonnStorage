﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.IM.I2360QA1_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniLabel3 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.PC_TXT = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniLabel2 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.TV_TXT = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblEmpNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popEmpNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblProPer = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnConfirm = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.PC_TYPE_TXT = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.uniTBL_MainCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PC_TXT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TV_TXT)).BeginInit();
            this.uniTBL_MainBatch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PC_TYPE_TXT)).BeginInit();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.PathInfo;
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(937, 597);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 97);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(937, 468);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 0;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance1.BackColor = System.Drawing.SystemColors.Window;
            appearance1.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance1;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance2.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance2.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance2;
            appearance3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance3;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance4.BackColor2 = System.Drawing.SystemColors.Control;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance4;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance5;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance6.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance6;
            appearance7.BorderColor = System.Drawing.Color.Silver;
            appearance7.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance7;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance8.BackColor = System.Drawing.SystemColors.Control;
            appearance8.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance8.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance8.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance8;
            appearance9.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance9;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance10.BackColor = System.Drawing.SystemColors.Window;
            appearance10.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance10;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance11.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance11;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(937, 468);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.uniGrid1_BeforePopupOpen);
            this.uniGrid1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.uniGrid1_AfterPopupClosed);
            this.uniGrid1.AfterCellUpdate += new Infragistics.Win.UltraWinGrid.CellEventHandler(this.uniGrid1_AfterCellUpdate);
            this.uniGrid1.AfterExitEditMode += new System.EventHandler(this.uniGrid1_AfterExitEditMode);
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.uniLabel3, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.PC_TXT, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.uniLabel2, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.TV_TXT, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblEmpNo, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popEmpNo, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblProPer, 2, 0);
            this.uniTBL_MainCondition.Controls.Add(this.PC_TYPE_TXT, 3, 0);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 2;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(937, 61);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniLabel3
            // 
            appearance12.TextHAlignAsString = "Left";
            appearance12.TextVAlignAsString = "Middle";
            this.uniLabel3.Appearance = appearance12;
            this.uniLabel3.AutoPopupID = null;
            this.uniLabel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniLabel3.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.uniLabel3.Location = new System.Drawing.Point(15, 29);
            this.uniLabel3.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.uniLabel3.Name = "uniLabel3";
            this.uniLabel3.Size = new System.Drawing.Size(116, 22);
            this.uniLabel3.StyleSetName = "Default";
            this.uniLabel3.TabIndex = 16;
            this.uniLabel3.Text = "PC브랜드";
            this.uniLabel3.UseMnemonic = false;
            // 
            // PC_TXT
            // 
            this.PC_TXT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance13.TextVAlignAsString = "Bottom";
            this.PC_TXT.Appearance = appearance13;
            this.PC_TXT.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.PC_TXT.Location = new System.Drawing.Point(131, 30);
            this.PC_TXT.LockedField = false;
            this.PC_TXT.Margin = new System.Windows.Forms.Padding(0);
            this.PC_TXT.Name = "PC_TXT";
            this.PC_TXT.QueryIfEnterKeyPressed = true;
            this.PC_TXT.RequiredField = false;
            this.PC_TXT.Size = new System.Drawing.Size(192, 21);
            this.PC_TXT.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.PC_TXT.StyleSetName = "Default";
            this.PC_TXT.TabIndex = 17;
            this.PC_TXT.uniALT = null;
            this.PC_TXT.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.PC_TXT.UseDynamicFormat = false;
            // 
            // uniLabel2
            // 
            appearance14.TextHAlignAsString = "Left";
            appearance14.TextVAlignAsString = "Middle";
            this.uniLabel2.Appearance = appearance14;
            this.uniLabel2.AutoPopupID = null;
            this.uniLabel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniLabel2.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.uniLabel2.Location = new System.Drawing.Point(483, 29);
            this.uniLabel2.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.uniLabel2.Name = "uniLabel2";
            this.uniLabel2.Size = new System.Drawing.Size(116, 22);
            this.uniLabel2.StyleSetName = "Default";
            this.uniLabel2.TabIndex = 14;
            this.uniLabel2.Text = "모니터브랜드";
            this.uniLabel2.UseMnemonic = false;
            // 
            // TV_TXT
            // 
            this.TV_TXT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance15.TextVAlignAsString = "Bottom";
            this.TV_TXT.Appearance = appearance15;
            this.TV_TXT.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.TV_TXT.Location = new System.Drawing.Point(599, 30);
            this.TV_TXT.LockedField = false;
            this.TV_TXT.Margin = new System.Windows.Forms.Padding(0);
            this.TV_TXT.Name = "TV_TXT";
            this.TV_TXT.QueryIfEnterKeyPressed = true;
            this.TV_TXT.RequiredField = false;
            this.TV_TXT.Size = new System.Drawing.Size(192, 21);
            this.TV_TXT.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.TV_TXT.StyleSetName = "Default";
            this.TV_TXT.TabIndex = 15;
            this.TV_TXT.uniALT = null;
            this.TV_TXT.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TV_TXT.UseDynamicFormat = false;
            // 
            // lblEmpNo
            // 
            appearance16.TextHAlignAsString = "Left";
            appearance16.TextVAlignAsString = "Middle";
            this.lblEmpNo.Appearance = appearance16;
            this.lblEmpNo.AutoPopupID = null;
            this.lblEmpNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmpNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblEmpNo.Location = new System.Drawing.Point(15, 6);
            this.lblEmpNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblEmpNo.Name = "lblEmpNo";
            this.lblEmpNo.Size = new System.Drawing.Size(116, 22);
            this.lblEmpNo.StyleSetName = "Default";
            this.lblEmpNo.TabIndex = 6;
            this.lblEmpNo.Text = "사번";
            this.lblEmpNo.UseMnemonic = false;
            // 
            // popEmpNo
            // 
            this.popEmpNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popEmpNo.AutoPopupCodeParameter = null;
            this.popEmpNo.AutoPopupID = null;
            this.popEmpNo.AutoPopupNameParameter = null;
            this.popEmpNo.CodeMaxLength = 13;
            this.popEmpNo.CodeName = "";
            this.popEmpNo.CodeSize = 100;
            this.popEmpNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popEmpNo.CodeTextBoxName = null;
            this.popEmpNo.CodeValue = "";
            this.popEmpNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popEmpNo.Location = new System.Drawing.Point(131, 7);
            this.popEmpNo.LockedField = false;
            this.popEmpNo.Margin = new System.Windows.Forms.Padding(0);
            this.popEmpNo.Name = "popEmpNo";
            this.popEmpNo.NameDisplay = true;
            this.popEmpNo.NameId = null;
            this.popEmpNo.NameMaxLength = 50;
            this.popEmpNo.NamePopup = false;
            this.popEmpNo.NameSize = 150;
            this.popEmpNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popEmpNo.Parameter = null;
            this.popEmpNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popEmpNo.PopupId = null;
            this.popEmpNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popEmpNo.QueryIfEnterKeyPressed = true;
            this.popEmpNo.RequiredField = false;
            this.popEmpNo.Size = new System.Drawing.Size(271, 21);
            this.popEmpNo.TabIndex = 7;
            this.popEmpNo.uniALT = "Emp No";
            this.popEmpNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popEmpNo.UseDynamicFormat = false;
            this.popEmpNo.ValueTextBoxName = null;
            this.popEmpNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popEmpNo_BeforePopupOpen);
            this.popEmpNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popEmpNo_AfterPopupClosed);
            this.popEmpNo.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popEmpNo_OnExitEditCode);
            // 
            // lblProPer
            // 
            appearance17.TextHAlignAsString = "Left";
            appearance17.TextVAlignAsString = "Middle";
            this.lblProPer.Appearance = appearance17;
            this.lblProPer.AutoPopupID = null;
            this.lblProPer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProPer.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProPer.Location = new System.Drawing.Point(483, 6);
            this.lblProPer.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProPer.Name = "lblProPer";
            this.lblProPer.Size = new System.Drawing.Size(116, 22);
            this.lblProPer.StyleSetName = "Default";
            this.lblProPer.TabIndex = 13;
            this.lblProPer.Text = "PC 종류";
            this.lblProPer.UseMnemonic = false;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.DefaultRowSize = 23;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(937, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 5;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.Controls.Add(this.btnConfirm, 0, 0);
            this.uniTBL_MainBatch.DefaultRowSize = 23;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 568);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(937, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnConfirm
            // 
            this.btnConfirm.AutoPopupID = null;
            this.btnConfirm.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnConfirm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnConfirm.Enabled = false;
            this.btnConfirm.Location = new System.Drawing.Point(0, 1);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.PopupID = null;
            this.btnConfirm.Size = new System.Drawing.Size(97, 24);
            this.btnConfirm.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnConfirm.TabIndex = 1;
            this.btnConfirm.Text = "반영";
            this.btnConfirm.UserDefinedText = null;
            this.btnConfirm.Visible = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // PC_TYPE_TXT
            // 
            this.PC_TYPE_TXT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance18.TextVAlignAsString = "Bottom";
            this.PC_TYPE_TXT.Appearance = appearance18;
            this.PC_TYPE_TXT.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.PC_TYPE_TXT.Location = new System.Drawing.Point(599, 7);
            this.PC_TYPE_TXT.LockedField = false;
            this.PC_TYPE_TXT.Margin = new System.Windows.Forms.Padding(0);
            this.PC_TYPE_TXT.Name = "PC_TYPE_TXT";
            this.PC_TYPE_TXT.QueryIfEnterKeyPressed = true;
            this.PC_TYPE_TXT.RequiredField = false;
            this.PC_TYPE_TXT.Size = new System.Drawing.Size(192, 21);
            this.PC_TYPE_TXT.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.PC_TYPE_TXT.StyleSetName = "Default";
            this.PC_TYPE_TXT.TabIndex = 15;
            this.PC_TYPE_TXT.uniALT = null;
            this.PC_TYPE_TXT.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.PC_TYPE_TXT.UseDynamicFormat = false;
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(948, 617);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PC_TXT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TV_TXT)).EndInit();
            this.uniTBL_MainBatch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PC_TYPE_TXT)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniLabel lblEmpNo;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popEmpNo;
        private uniERP.AppFramework.UI.Controls.uniButton btnConfirm;
        private AppFramework.UI.Controls.uniGrid uniGrid1;
        private AppFramework.UI.Controls.uniLabel uniLabel3;
        private AppFramework.UI.Controls.uniTextBox PC_TXT;
        private AppFramework.UI.Controls.uniLabel uniLabel2;
        private AppFramework.UI.Controls.uniTextBox TV_TXT;
        private AppFramework.UI.Controls.uniLabel lblProPer;
        private AppFramework.UI.Controls.uniTextBox PC_TYPE_TXT;

    }
}
