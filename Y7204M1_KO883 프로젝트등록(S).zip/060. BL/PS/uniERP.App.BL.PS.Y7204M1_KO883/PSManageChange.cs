﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.EnterpriseServices;

using uniERP.AppFramework.Service;
using uniERP.App.BL.PS.PY7G204;

namespace uniERP.App.BL.PS.Y7204M1_KO883
{
    /// <NameSpace>uniERP.App.BL.PS.Y7204M1_KO883</NameSpace>
    /// <Module>module name</Module>
    /// <Class>cManageBusinessLogicName</Class>
    /// <Desc>
    ///   This part describe the summary information about class 
    /// </Desc>
    /// <Parent>
    ///   <NameSpace>Parnet namespace</NameSpace>
    ///   <Class>Parent Child</Class>
    /// </Parent>
    /// <History>
    ///   <FirstCreated>
    ///     <history name="creator" Date="created date">Make …</history>
    ///   </FirstCreated>
    ///   <Lastmodified>
    ///     <history name="modifier"  Date="modified date"> contents </history>
    ///     <history name="modifier"  Date="modified date"> contents </history>
    ///     <history name="modifier"  Date="modified date"> contents </history>
    ///   </Lastmodified>
    /// </History>
    /// <Remarks>
    ///   <remark name="modifier"  Date="modified date">… </remark>
    ///   <remark name="modifier"  Date="modified date">… </remark>
    /// </Remarks>
    public class PSManageChange : BizTxBase
    {
        /// <summary>
        /// Write this Service Description
        /// </summary>
        /// <param name="pvStrGlobalCollection"> Mandatory : uniERP Global Infomation </param>
        [AutoComplete(true)]
        public string PSSaveChange(string[] pvStrGlobalCollection, DataSet pDateSet, string strCommandSend)
        {
            string strReturn = string.Empty;

            if (pDateSet == null)
                return strReturn;

            try
            {
                this.LoadCommonGINF(pvStrGlobalCollection);
                this.TimeLogPrepare();

                using (PY7G204.cPMngProject iPY7G204 = new PY7G204.cPMngProject())   // BL의 CS(저장)
                {
                    PY7G204.DsPManageProject saveDs = new PY7G204.DsPManageProject();
                    saveDs.Merge(pDateSet, false, MissingSchemaAction.Ignore);
                    strReturn = iPY7G204.P_MANAGE_PROJECT(pvStrGlobalCollection, saveDs, strCommandSend);
                }

                if (strCommandSend == "CREATE" || strCommandSend == "UPDATE")
                {
                    this.ManageUpdateServiceName(pDateSet.Tables["I1_PMS_PROJECT"].Rows[0], strReturn);
                    
                }
                
                return strReturn;
            }
            finally
            {
                this.TimeLogMeasureAndWriteLog();
            }
        }



        private void ManageUpdateServiceName(DataRow row, string strReturn)
        {
            if (strReturn =="" )
            {
                strReturn =row["project_code"].ToString();
            }

            try
            {
                
                string strSQL = string.Format(@"
UPDATE
    PMS_PROJECT
SET
	 EXT1_CD_KO883	= {1}
	,EXT2_CD_KO883	= {2}
	,EXT3_CD_KO883	= {3}
	,EXT4_CD_KO883	= {4}
	,EXT5_CD_KO883	= {5}
    ,EXT6_CD_KO883   = {6}
    ,EXT7_CD_KO883   = {7}
    ,EXT1_DT_KO883   = {8}
WHERE
	project_code	= {0}"
                    //, this.FilterVar(row.KeyColumnName, "''", "S", true)
                    //, this.FilterVar(row.VarcharColumnName, "''", "S", true)
                    //, this.DateTimeToString(row.DateTimeColumnName, true)
                    //, this.FilterVar(row.NumericColumnName, "''", "", true)
                    , this.FilterVar(strReturn, "NULL", "S", true)
                    , this.FilterVar(row["ext1_cd_ko883"].ToString(), "NULL", "S", true)
                    , this.FilterVar(row["ext2_cd_ko883"].ToString(), "NULL", "S", true)
                    , this.FilterVar(row["ext3_cd_ko883"].ToString(), "NULL", "S", true)
                    , this.FilterVar(row["ext4_cd_ko883"].ToString(), "NULL", "S", true)
                    , this.FilterVar(row["ext5_cd_ko883"].ToString(), "NULL", "S", true)
                    , this.FilterVar(row["ext6_cd_ko883"].ToString(), "NULL", "S", true)
                    , this.FilterVar(row["ext7_cd_ko883"].ToString(), "NULL", "S", true)
                    , this.FilterVar(Convert.ToDateTime(row["ext1_dt_ko883"].ToString()).ToShortDateString(), "NULL", "S", true)
                    );

                if (!this.CommonTxRs(strSQL, false))
                {
                    this._bCase.ZU00.MsgCode = "15242";
                    this._bCase.ZU01.MsgCode = "547";
                    this._bCase.ZU02.MsgCode = "1205";
                    this._bCase.ZU03.MsgCode = "7905";
                    this.ProcessBCase("U");
                }
            }
            finally
            {
                this.TimeLogMeasureAndWriteLog();
            }
        }


    }
}