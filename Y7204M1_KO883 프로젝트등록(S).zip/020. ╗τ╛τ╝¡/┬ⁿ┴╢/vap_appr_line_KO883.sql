
/*******************************************************************************************/
/*****   TABLE NAME   : vap_appr_line_KO883                                            *****/
/*****   OWNER        : ����	                                                       *****/
/*****   CREATE DATE  : 2018-06-01                                                     *****/
/*****   DESCRIPTION  : 1. ERP(UNIERP) VS GW(UNIPORTAL) IF                             *****/
/*****                  2. ���� :                                                      *****/
/*****                  3. ����ȭ�� : ������Ʈ���							           *****/
/*****   MODIFIED BY   : ������                                                        *****/
/*****   MODIFIED DATE : 2018-06-01                                                    *****/
/*****   VERSION       : 20180601JYR: ���ʹݿ�                                         *****/
/*****                 :									                           *****/
/*******************************************************************************************/
IF EXISTS (SELECT *
             FROM dbo.sysobjects
            WHERE id = object_id(N'[dbo].[vap_appr_line_KO883]')
              --AND OBJECTPROPERTY(id, N'IsUserView') = 1
			  )
DROP view [dbo].[vap_appr_line_KO883]
GO

CREATE view [dbo].[vap_appr_line_KO883]
AS 

select
	   doc.DOC_ID 
	 , doc.CREATE_DATE
	 , appr_role_seq =
	   ( CASE WHEN line.appr_role =  'DRFT' /**P*/ THEN 1
              WHEN line.appr_role =  'APPR' /**P*/
               or line.appr_role =  'ARBI' /**P*/
               or line.appr_role =  'AGRE' /**P*/
               or line.appr_role =  'RECV' /**P*/ THEN 2
              ELSE 3 
		 END )
     , doc.TITLE
     , doc.IF_FORM_NO
     , line.APPROVER_DEPT_NAME
     , line.APPROVER_DEPT_ID
     , line.LINE_ORDER
     , line.APPROVER_NAME
     , line.APPROVER_POS_NAME
     , user1.USER_ID
     , user1.EMPLOYEE_ID
     , r_name.appr_role_name
     , opinion.PROC_OPINION
     , d_name.doc_state_name
	  , p_name.proc_state_name
	  , proc1.PROCESS_DATE
	  , line.LINE_APP_SEQ
from (select * from PAM_UNIPORTAL...tap_appr_doc where if_form_no is not null) doc
left outer join (select l.* from PAM_UNIPORTAL...tap_appr_doc_line l
							inner join (select * from PAM_UNIPORTAL...tap_appr_doc where if_form_no is not null) a
							on l.TENANT_ID = a.TENANT_ID
							and l.COMP_ID = a.COMP_ID
							and l.DOC_ID = a.DOC_ID) line
	on doc.TENANT_ID = line.TENANT_ID
	and doc.COMP_ID = line.COMP_ID
	and doc.DOC_ID = line.DOC_ID
left outer join (select p.TENANT_ID, p.COMP_ID, p.doc_id, p.APPR_ROLE, MAX(p.line_his_id) as line_his_id, p.LINE_ORDER, p.PROCESS_DATE, p.PROC_STATE
						from PAM_UNIPORTAL...tap_appr_doc_line_proc p
						inner join (select * from PAM_UNIPORTAL...tap_appr_doc where if_form_no is not null) a
						on p.TENANT_ID = a.TENANT_ID
						and p.COMP_ID = a.COMP_ID
						and p.DOC_ID = a.DOC_ID
						group by p.TENANT_ID, p.COMP_ID, p.doc_id, p.APPR_ROLE, p.LINE_ORDER, p.PROCESS_DATE, p.PROC_STATE) proc1
	on line.TENANT_ID = proc1.TENANT_ID
	and line.COMP_ID = proc1.COMP_ID
	and line.DOC_ID = proc1.DOC_ID
	and line.APPR_ROLE = proc1.APPR_ROLE
	and line.LINE_ORDER = proc1.LINE_ORDER
left outer join PAM_UNIPORTAL...tim_user_basic user1
	on line.TENANT_ID = user1.TENANT_ID
	and line.COMP_ID = user1.COMP_ID
	and line.APPROVER_ID = user1.USER_UID
left outer join (select o.* from PAM_UNIPORTAL...tap_appr_doc_opinion o
					  inner join (select * from PAM_UNIPORTAL...tap_appr_doc where if_form_no is not null) a
						on o.TENANT_ID = a.TENANT_ID
						and o.COMP_ID = a.COMP_ID
						and o.DOC_ID = a.DOC_ID) opinion
	on line.TENANT_ID = opinion.TENANT_ID
	and line.COMP_ID = opinion.COMP_ID
	and line.DOC_ID = opinion.DOC_ID
	and line.APPROVER_ID = opinion.CREATOR_UID
left join (select code.TENANT_ID, code.code, r.RESOURCE_NAME as appr_role_name from PAM_UNIPORTAL...tco_code code
						inner join PAM_UNIPORTAL...tco_resource r
						on code.TENANT_ID = r.TENANT_ID
						and code.CODE_VALUE = r.RESOURCE_ID
						and r.LANG_TYPE = 'ko'
						where category_gubun = 'APPR'
						  and code_group = 'APPR_ROLE') r_name
	on line.APPR_ROLE = r_name.code
left join (select code.TENANT_ID, code.code, r.RESOURCE_NAME as doc_state_name from PAM_UNIPORTAL...tco_code code
						inner join PAM_UNIPORTAL...tco_resource r
						on code.TENANT_ID = r.TENANT_ID
						and code.CODE_VALUE = r.RESOURCE_ID
						and r.LANG_TYPE = 'ko'
						where category_gubun = 'APPR'
						  and code_group = 'APPR_DOC_STATE') d_name
	on doc.DOC_STATE = d_name.code
left outer join (select code.TENANT_ID, code.code, r.RESOURCE_NAME as proc_state_name from PAM_UNIPORTAL...tco_code code
						inner join PAM_UNIPORTAL...tco_resource r
						on code.TENANT_ID = r.TENANT_ID
						and code.CODE_VALUE = r.RESOURCE_ID
						and r.LANG_TYPE = 'ko'
						where category_gubun = 'APPR'
						  and code_group = 'APPR_PROC_STATE') p_name
	on proc1.PROC_STATE = p_name.code

--order by doc.DOC_ID, doc.CREATE_DATE
--		 , CASE WHEN line.appr_role =  'DRFT' /**P*/ THEN 1
--                     WHEN line.appr_role =  'APPR' /**P*/
--                        or line.appr_role =  'ARBI' /**P*/
--                        or line.appr_role =  'AGRE' /**P*/
--                        or line.appr_role =  'RECV' /**P*/ THEN 2
--                      ELSE 3 END
--       , line.line_order
