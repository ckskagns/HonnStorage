﻿using System;
using System.Data;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;
using uniERP.App.BL.PS.Y7204M1_KO883;
using uniERP.AppFramework.Facade;
using uniERP.AppFramework.Service;



//using uniERP.App.BL.Template.Sample;

namespace uniERP.App.FL.PS.Y7204M1_KO883
{
    /// <summary>
    /// Summary description for WebService
    /// </summary>
    [WebService(Namespace = "http://www.unierp.com/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    public class Y7204M1_KO883FL : WebServiceBase
    {
        [WebMethod]
        public string PSManageChange_Updatechange(string[] pvStrGlobalCollection, DataSet pDataSet, string strCommandSend)
        {
            string strReturn = string.Empty;

            this.ValidateSession(pvStrGlobalCollection);

            try
            {
                uniERP.App.BL.PS.Y7204M1_KO883.PSManageChange oBiz = null;
                using (oBiz = new uniERP.App.BL.PS.Y7204M1_KO883.PSManageChange())
                {
                    strReturn = oBiz.PSSaveChange(pvStrGlobalCollection, pDataSet, strCommandSend);
                }
            }
            catch (Exception ex)
            {
                this.ProcessError(ex, pvStrGlobalCollection);
            }

            return strReturn;

            }
      }
      
    }

