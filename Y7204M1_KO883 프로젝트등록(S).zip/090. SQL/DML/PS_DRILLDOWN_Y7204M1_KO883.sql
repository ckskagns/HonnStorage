
SET NOCOUNT ON;
---------------------------------------------------------------------------------------------------------------------------
--	FILE NAME	: PS_INS_DrillDown_20180709_user.sql
--	MODULE		: PS
--	DATE		: 2018-07-09
--	Modifier	: user
---------------------------------------------------------------------------------------------------------------------------

DELETE
FROM
	zd_navi_branch
WHERE
	base_page_id IN (
'Y7204M1_KO883'
)

DELETE
FROM
	zd_navi_dtl
WHERE
	base_page_id IN (
'Y7204M1_KO883'
)

DELETE
FROM
	zd_navi
WHERE
	base_page_id IN (
'Y7204M1_KO883'
)
---------------------------------------------------------------------------------------------------------------------------
-----Start  Drill Down DML   base_page_id = 'Y7204M1_KO883'-----------------------------------------------------------------------------

INSERT INTO zd_navi
(
	base_page_id	,base_ctrl_id	,dest_page_id	,navi_desc	,auto_query_flag
	,insrt_dt	,insrt_user_id	,updt_dt	,updt_user_id
)
VALUES
(
	N'Y7204M1_KO883'	,N'lblCompose'	,N'Y7207MA1'	,N''	,N'Y'
	,GETDATE()	,N'UNIERP'	,GETDATE()	,N'UNIERP'
)

INSERT INTO zd_navi
(
	base_page_id	,base_ctrl_id	,dest_page_id	,navi_desc	,auto_query_flag
	,insrt_dt	,insrt_user_id	,updt_dt	,updt_user_id
)
VALUES
(
	N'Y7204M1_KO883'	,N'lblRegstration'	,N'Y7205MA1'	,N''	,N'Y'
	,GETDATE()	,N'UNIERP'	,GETDATE()	,N'UNIERP'
)

INSERT INTO zd_navi_dtl
(
	base_page_id	,base_ctrl_id	,dest_page_id	,param_seq	,base_param_type
	,base_param_value	,stat_output	,dest_ctrl_id	,param_desc	,insrt_dt
	,insrt_user_id	,updt_dt	,updt_user_id
)
VALUES
(
	N'Y7204M1_KO883'	,N'lblCompose'	,N'Y7207MA1'	,1	,N'CT'
	,N'popProjectCode1'	,N''	,N'popPrjCd'	,N''	,GETDATE()
	,N'UNIERP'	,GETDATE()	,N'UNIERP'
)

INSERT INTO zd_navi_dtl
(
	base_page_id	,base_ctrl_id	,dest_page_id	,param_seq	,base_param_type
	,base_param_value	,stat_output	,dest_ctrl_id	,param_desc	,insrt_dt
	,insrt_user_id	,updt_dt	,updt_user_id
)
VALUES
(
	N'Y7204M1_KO883'	,N'lblRegstration'	,N'Y7205MA1'	,1	,N'CT'
	,N'popProjectCode1'	,N''	,N'popProject'	,N''	,GETDATE()
	,N'UNIERP'	,GETDATE()	,N'UNIERP'
)
-----End    Drill Down DML   base_page_id = 'Y7204M1_KO883'-----------------------------------------------------------------------------