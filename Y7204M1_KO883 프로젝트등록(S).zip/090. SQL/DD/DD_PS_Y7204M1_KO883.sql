﻿
SET NOCOUNT ON;
---------------------------------------------------------------------------------------------------------------------------
--	FILE NAME	: 모듈_INS_DD_20180709_user.sql
--	MODULE		: 모듈
--	DATE		: 2018-07-09
--	Modifier	: user
---------------------------------------------------------------------------------------------------------------------------
DELETE
FROM
	V27AdminDB..DD
WHERE
	ProgramID IN (
'uniERP.App.UI.PS.Y7204M1_KO883'
)
---------------------------------------------------------------------------------------------------------------------------
-----Start  DD DML   ProgramID = 'uniERP.App.UI.PS.Y7204M1_KO883'-----------------------------------------------------------------------------

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'결재상신'	,NULL	,N'결재상신'	,NULL
	,N'결재상신'	,NULL	,N'결재상신'	,N''
	,N'결재상신'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'btnApproval'	,'S'	,'Single'	,'uniButton'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'결재(진행사항)'	,NULL	,N'결재(진행사항)'	,NULL
	,N'결재(진행사항)'	,NULL	,N'결재(진행사항)'	,N''
	,N'결재(진행사항)'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'btnApprovalpro'	,'S'	,'Single'	,'uniButton'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'출력'	,NULL	,N'출력'	,NULL
	,N'출력'	,NULL	,N'출력'	,N''
	,N'출력'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'btnPrint'	,'S'	,'Single'	,'uniButton'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'미리보기'	,NULL	,N'미리보기'	,NULL
	,N'미리보기'	,NULL	,N'미리보기'	,N''
	,N'미리보기'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'btnPriview'	,'S'	,'Single'	,'uniButton'
	,NULL	,NULL	,'2018-07-04'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'발주구분'	,NULL	,N'발주구분'	,NULL
	,N'발주구분'	,NULL	,N'발주구분'	,N''
	,N'발주구분'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'cboBaljugb'	,'S'	,'Single'	,'uniCombo'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트형태'	,N'프로젝트형태'	,N'Project Type'	,N'Project Type'
	,N'项目类型'	,N'项目类型'	,N'Project Type'	,N'Project Type'
	,N'Hình thức dự án'	,N'Hình thức dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'cboPrjType'	,'S'	,'Single'	,'uniCombo'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트형태'	,N'프로젝트형태'	,N'Project Type'	,N'Project Type'
	,N'项目类型'	,N'项目类型'	,N'Project Type'	,N'Project Type'
	,N'Hình thức dự án'	,N'Hình thức dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'cboProjectType'	,'S'	,'Single'	,'uniCombo'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트유형1'	,N'프로젝트유형1'	,N'Project Type1'	,N'Project Type1'
	,N'项目类型1'	,N'项目类型1'	,N'Project Type1'	,N'Project Type1'
	,N'Loại hình dự án1'	,N'Loại hình dự án1'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'cboProjectType1'	,'S'	,'Single'	,'uniCombo'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'매출인식기준'	,N'매출인식기준'	,N'Sale recognition compasrison'	,N'Sale recognition compasrison'
	,N'销售识别基准'	,N'销售识别基准'	,N'Sale recognition compasrison'	,N'Sale recognition compasrison'
	,N'Tiêu chuẩn ghi nhận doanh thu'	,N'Tiêu chuẩn ghi nhận doanh thu'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'cboRevenue'	,'S'	,'Single'	,'uniCombo'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'VAT포함여부'	,N'VAT포함여부'	,N'VAT inclusion ID'	,N'VAT inclusion ID'
	,N'增值税包含标志'	,N'增值税包含标志'	,N'VAT inclusion ID'	,N'VAT inclusion ID'
	,N'Có bao gồm VAT hay không'	,N'Có bao gồm VAT hay không'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'cboVatIncFlag'	,'S'	,'Single'	,'uniCombo'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'dtBaljudt'	,'S'	,'Single'	,'uniDateTime'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'납기일'	,N'납기일'	,N'Delivery Date'	,N'Delivery Date'
	,N'交货日期'	,N'交货日期'	,N'Delivery Date'	,N'Delivery Date'
	,N'Ngày giao hàng'	,N'Ngày giao hàng'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'dtDlvyDt'	,'S'	,'Single'	,'uniDateTime'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'시작일|종료일'	,N'시작일|종료일'	,N'Project PeriodFrom|Project PeriodTo'	,N'Project PeriodFrom|Project PeriodTo'
	,N'起始日期|结束日期'	,N'起始日期|结束日期'	,N'Project PeriodFrom|Project PeriodTo'	,N'Project PeriodFrom|Project PeriodTo'
	,N'Ngày bắt đầu|Ngày kết thúc'	,N'Ngày bắt đầu|Ngày kết thúc'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'dtPlanStartDt'	,'S'	,'Single'	,'uniDateTerm'
	,NULL	,NULL	,'2008-06-24'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'발주일'	,NULL	,N'발주일'	,NULL
	,N'발주일'	,NULL	,N'발주일'	,N''
	,N'발주일'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblBaljudt'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'발주구분'	,NULL	,N'발주구분'	,NULL
	,N'발주구분'	,NULL	,N'발주구분'	,N''
	,N'발주구분'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblBaljugb'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'변경이력'	,N'변경이력'	,N'Change History'	,N'Change History'
	,N'变更履历'	,N'变更履历'	,N'Change History'	,N'Change History'
	,N'Lý lịch thay đổi'	,N'Lý lịch thay đổi'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblChange'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트코드/Ver.'	,N'프로젝트코드/Ver.'	,N'Project Code/Ver'	,N'Project Code/Ver'
	,N'项目编号/版本'	,N'项目编号/版本'	,N'Project Code/Ver'	,N'Project Code/Ver'
	,N'Mã dự án/Ver'	,N'Mã dự án/Ver'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblCode'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'매출인식기준'	,N'매출인식기준'	,N'Sale recognition compasrison'	,N'Sale recognition compasrison'
	,N'销售识别基准'	,N'销售识别基准'	,N'Sale recognition compasrison'	,N'Sale recognition compasrison'
	,N'Tiêu chuẩn ghi nhận doanh thu'	,N'Tiêu chuẩn ghi nhận doanh thu'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblComparison'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트구성'	,N'프로젝트구성'	,N'Project Compose'	,N'Project Compose'
	,N'项目组成'	,N'项目组成'	,N'Project Compose'	,N'Project Compose'
	,N'Cấu thành dự án'	,N'Cấu thành dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblCompose'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'CS담당'	,NULL	,N'CS담당'	,NULL
	,N'CS담당'	,NULL	,N'CS담당'	,N''
	,N'CS담당'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblCsmng'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'통화/수주금액'	,N'통화/수주금액'	,N'Currency Unit/Order Amount'	,N'Currency Unit/Order Amount'
	,N'货币单位/订单金额'	,N'货币单位/订单金额'	,N'Currency Unit/Order Amount'	,N'Currency Unit/Order Amount'
	,N'Giá trị đơn hàng/tiền tệ'	,N'Giá trị đơn hàng/tiền tệ'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblCurrency'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'고객담당자'	,NULL	,N'고객담당자'	,NULL
	,N'고객담당자'	,NULL	,N'고객담당자'	,N''
	,N'고객담당자'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblCusmng'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'고객담당자(부서)'	,NULL	,N'고객담당자(부서)'	,NULL
	,N'고객담당자(부서)'	,NULL	,N'고객담당자(부서)'	,N''
	,N'고객담당자(부서)'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblCusmngdept'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'고객담당자(연락처)'	,NULL	,N'고객담당자(연락처)'	,NULL
	,N'고객담당자(연락처)'	,NULL	,N'고객담당자(연락처)'	,N''
	,N'고객담당자(연락처)'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblCusmngnum'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'적용된견적차수'	,N'적용된견적차수'	,N'Applied Estimate Degree'	,N'Applied Estimate Degree'
	,N'适用报价程度'	,N'适用报价程度'	,N'Applied Estimate Degree'	,N'Applied Estimate Degree'
	,N'Số lần báo giá được áp dụng'	,N'Số lần báo giá được áp dụng'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblDegree'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'납기일'	,N'납기일'	,N'Delivery Date'	,N'Delivery Date'
	,N'交货日期'	,N'交货日期'	,N'Delivery Date'	,N'Delivery Date'
	,N'Ngày giao hàng'	,N'Ngày giao hàng'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblDeliveryDate'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'적용된견적번호'	,N'적용된견적번호'	,N'Applied Estimate No'	,N'Applied Estimate No'
	,N'适用报价编号'	,N'适用报价编号'	,N'Applied Estimate No'	,N'Applied Estimate No'
	,N'Mã số báo giá được áp dụng'	,N'Mã số báo giá được áp dụng'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblEstimateNo'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'견적참조'	,N'견적참조'	,N'Estimate Ref.'	,N'Estimate Ref.'
	,N'报价参考'	,N'报价参考'	,N'Estimate Ref.'	,N'Estimate Ref.'
	,N'Tham chiếu báo giá'	,N'Tham chiếu báo giá'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblEstimateRef'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'그룹프로젝트여부'	,N'그룹프로젝트여부'	,N'Group Project Flag'	,N'Group Project Flag'
	,N'项目组标志'	,N'项目组标志'	,N'Group Project Flag'	,N'Group Project Flag'
	,N'Có (không) dự án nhóm'	,N'Có (không) dự án nhóm'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblFlag'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'영업그룹'	,N'영업그룹'	,N'Sales Group'	,N'Sales Group'
	,N'销售组'	,N'销售组'	,N'Sales Group'	,N'Sales Group'
	,N'Nhóm kinh doanh'	,N'Nhóm kinh doanh'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblGroup'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2008-06-24'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'VAT포함여부'	,N'VAT포함여부'	,N'VAT inclusion ID'	,N'VAT inclusion ID'
	,N'增值税包含标志'	,N'增值税包含标志'	,N'VAT inclusion ID'	,N'VAT inclusion ID'
	,N'Có bao gồm VAT hay không'	,N'Có bao gồm VAT hay không'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblInclusion'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'수주금액(자국)'	,N'수주금액(자국)'	,N'S/O Amt(Local)'	,N'S/O Amt(Local)'
	,N'订单金额(本位币)'	,N'订单金额(本位币)'	,N'S/O Amt(Local)'	,N'S/O Amt(Local)'
	,N'Số tiền đặt hàng (trong nước)'	,N'Số tiền đặt hàng (trong nước)'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblLocal'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'관리자'	,N'관리자'	,N'Manager'	,N'Manager'
	,N'管理员'	,N'管理员'	,N'Manager'	,N'Manager'
	,N'Người quản lý'	,N'Người quản lý'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblManager'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'고객명'	,N'고객명'	,N'Customer Name'	,N'Customer Name'
	,N'客户名称'	,N'客户名称'	,N'Customer Name'	,N'Customer Name'
	,N'Tên khách hàng'	,N'Tên khách hàng'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblName'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'개요'	,N'개요'	,N'Outline'	,N'Outline'
	,N'概要'	,N'概要'	,N'Outline'	,N'Outline'
	,N'Khái quát'	,N'Khái quát'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblOutline'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'결제방법'	,N'결제방법'	,N'Pay Method'	,N'Pay Method'
	,N'支付方法'	,N'支付方法'	,N'Pay Method'	,N'Pay Method'
	,N'Phương pháp thanh toán'	,N'Phương pháp thanh toán'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblPayMethod'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'결재상태'	,NULL	,N'결재상태'	,NULL
	,N'결재상태'	,NULL	,N'결재상태'	,N''
	,N'결재상태'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblPaystat'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트'	,N'프로젝트'	,N'Project'	,N'Project'
	,N'项目'	,N'项目'	,N'Project'	,N'Project'
	,N'Dự án'	,N'Dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblProject'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2008-06-24'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'그룹프로젝코드'	,N'그룹프로젝코드 '	,N'Group Project Code'	,N'Group Project Code'
	,N'项目组'	,N'项目组'	,N'Group Project Code'	,N'Group Project Code'
	,N'Mã dự án nhóm'	,N'Mã dự án nhóm'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblProjectCode'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트명'	,N'프로젝트명'	,N'Project Name'	,N'Project Name'
	,N'项目名称'	,N'项目名称'	,N'Project Name'	,N'Project Name'
	,N'Tên dự án'	,N'Tên dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblProjectName'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트기간'	,N'프로젝트기간'	,N'Project Period'	,N'Project Period'
	,N'项目期间'	,N'项目期间'	,N'Project Period'	,N'Project Period'
	,N'Thời gian dự án'	,N'Thời gian dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblProjectPeriod'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트종류'	,N'프로젝트종류'	,N'ProjectType'	,N'ProjectType'
	,N'项目类型'	,N'项目类型'	,N'ProjectType'	,N'ProjectType'
	,N'Loại dự án'	,N'Loại dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblProjectType'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트종류1'	,N'프로젝트종류1'	,N'Project Type1'	,N'Project Type1'
	,N'项目类型1'	,N'项目类型1'	,N'Project Type1'	,N'Project Type1'
	,N'Loại dự án1'	,N'Loại dự án1'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblProjectType1'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'환율'	,N'환율'	,N'Exchange Rate'	,N'Exchange Rate'
	,N'汇率'	,N'汇率'	,N'Exchange Rate'	,N'Exchange Rate'
	,N'Tỷ giá'	,N'Tỷ giá'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblRate'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'입금유형'	,N'입금유형'	,N'Receipt Type'	,N'Receipt Type'
	,N'支付类型'	,N'支付类型'	,N'Receipt Type'	,N'Receipt Type'
	,N'Loại hình tiền gửi'	,N'Loại hình tiền gửi'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblReceipt'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트자원등록'	,N'프로젝트자원등록'	,N'Project resource regstration'	,N'Project resource regstration'
	,N'项目资源注册'	,N'项目资源注册'	,N'Project resource regstration'	,N'Project resource regstration'
	,N'Đăng ký nguồn dự án'	,N'Đăng ký nguồn dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblRegstration'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'특기사항'	,N'특기사항'	,N'Remark'	,N'Remark'
	,N'备注'	,N'备注'	,N'Remark'	,N'Remark'
	,N'Khoản mục đặc biệt'	,N'Khoản mục đặc biệt'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblRemark'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2008-06-24'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'전자결재 요청자'	,NULL	,N'전자결재 요청자'	,NULL
	,N'전자결재 요청자'	,NULL	,N'전자결재 요청자'	,N''
	,N'전자결재 요청자'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblReqman'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트상태'	,N'프로젝트상태'	,N'Project State'	,N'Project State'
	,N'项目状态'	,N'项目状态'	,N'Project State'	,N'Project State'
	,N'Tình trạng dự án'	,N'Tình trạng dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblState'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'설계담당'	,NULL	,N'설계담당'	,NULL
	,N'설계담당'	,NULL	,N'설계담당'	,N''
	,N'설계담당'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblSulgye'	,'S'	,'Single'	,'uniLabel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트형태'	,N'프로젝트형태'	,N'Project Type'	,N'Project Type'
	,N'项目类型'	,N'项目类型'	,N'Project Type'	,N'Project Type'
	,N'Hình thức dự án'	,N'Hình thức dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblType'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'VAT유형'	,N'VAT유형'	,N'VAT Type'	,N'VAT Type'
	,N'增值税类型'	,N'增值税类型'	,N'VAT Type'	,N'VAT Type'
	,N'Hình thức thuế VAT'	,N'Hình thức thuế VAT'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblVat'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'VAT금액'	,N'VAT금액'	,N'VAT Amt.'	,N'VAT Amt.'
	,N'增值税额'	,N'增值税额'	,N'VAT Amt.'	,N'VAT Amt.'
	,N'Tiền thuế VAT'	,N'Tiền thuế VAT'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblVatAmt'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'VAT율'	,N'VAT율'	,N'VAT Rate'	,N'VAT Rate'
	,N'附加税率'	,N'附加税率'	,N'VAT Rate'	,N'VAT Rate'
	,N'Tỷ lệ thuế VAT'	,N'Tỷ lệ thuế VAT'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'lblVatRate'	,'S'	,'Single'	,'uniLabel'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'수주금액'	,N'수주금액'	,N'Order Amount'	,N'Order Amount'
	,N'金额'	,N'金额'	,N'Order Amount'	,N'Order Amount'
	,N'Số tiền đặt hàng'	,N'Số tiền đặt hàng'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'numNetAmt'	,'S'	,'Single'	,'uniNumeric'
	,NULL	,NULL	,'2008-06-24'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'VAT금액'	,N'VAT금액'	,N'VAT Amt'	,N'VAT Amt'
	,N'增值税额'	,N'增值税额'	,N'VAT Amt'	,N'VAT Amt'
	,N'Tiền thuế VAT'	,N'Tiền thuế VAT'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'numVatAmt'	,'S'	,'Single'	,'uniNumeric'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'VAT율'	,N'VAT율'	,N'VAT Rate'	,N'VAT Rate'
	,N'附加税率'	,N'附加税率'	,N'VAT Rate'	,N'VAT Rate'
	,N'Tỷ lệ thuế VAT'	,N'Tỷ lệ thuế VAT'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'numVatRate'	,'S'	,'Single'	,'uniNumeric'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'환율'	,N'환율'	,N'Exchange Rate'	,N'Exchange Rate'
	,N'汇率'	,N'汇率'	,N'Exchange Rate'	,N'Exchange Rate'
	,N'Tỷ giá'	,N'Tỷ giá'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'numXchRate'	,'S'	,'Single'	,'uniNumeric'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'고객명'	,N'고객명'	,N'Customer Name'	,N'Customer Name'
	,N'客户名称'	,N'客户名称'	,N'Customer Name'	,N'Customer Name'
	,N'Tên khách hàng'	,N'Tên khách hàng'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popBpCd'	,'S'	,'Single'	,'uniOpenPopup'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popCsmng'	,'S'	,'Single'	,'uniOpenPopup'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'화폐단위'	,N'화폐단위'	,N'Currency Unit'	,N'Currency Unit'
	,N'货币'	,N'货币'	,N'Currency Unit'	,N'Currency Unit'
	,N'Đơn vị tiền tệ'	,N'Đơn vị tiền tệ'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popCurrency'	,'S'	,'Single'	,'uniOpenPopup'
	,'CUR'	,NULL	,'2008-06-24'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'Group Project코드'	,N'Group Project코드'	,N'Group Project Code'	,N'Group Project Code'
	,N'项目组'	,N'项目组'	,N'Group Project Code'	,N'Group Project Code'
	,N'Mã dự án nhóm'	,N'Mã dự án nhóm'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popGroupPrjCd'	,'S'	,'Single'	,'uniOpenPopup'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'결제방법'	,N'결제방법'	,N'Pay Method'	,N'Pay Method'
	,N'支付方法'	,N'支付方法'	,N'Pay Method'	,N'Pay Method'
	,N'Phương pháp thanh toán'	,N'Phương pháp thanh toán'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayMeth'	,'S'	,'Single'	,'uniOpenPopup'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'입금유형'	,N'입금유형'	,N'Receipt Type'	,N'Receipt Type'
	,N'支付类型'	,N'支付类型'	,N'Receipt Type'	,N'Receipt Type'
	,N'Loại hình tiền gửi'	,N'Loại hình tiền gửi'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayType'	,'S'	,'Single'	,'uniOpenPopup'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'관리자'	,N'관리자'	,N'Manager'	,N'Manager'
	,N'管理员'	,N'管理员'	,N'Manager'	,N'Manager'
	,N'Người quản lý'	,N'Người quản lý'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPmResourceCd'	,'S'	,'Single'	,'uniOpenPopup'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트'	,N'프로젝트'	,N'Project'	,N'Project'
	,N'项目'	,N'项目'	,N'Project'	,N'Project'
	,N'Dự án'	,N'Dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popProjectCode1'	,'S'	,'Single'	,'uniOpenPopup'
	,NULL	,NULL	,'2008-06-24'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popReqman'	,'S'	,'Single'	,'uniOpenPopup'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'영업그룹'	,N'영업그룹'	,N'Sales Group'	,N'Sales Group'
	,N'销售组'	,N'销售组'	,N'Sales Group'	,N'Sales Group'
	,N'Nhóm kinh doanh'	,N'Nhóm kinh doanh'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popSalesGrp'	,'S'	,'Single'	,'uniOpenPopup'
	,'SG'	,NULL	,'2008-06-24'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popSulgye'	,'S'	,'Single'	,'uniOpenPopup'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'VAT유형'	,N'VAT유형'	,N'VAT Type'	,N'VAT Type'
	,N'增值税类型'	,N'增值税类型'	,N'VAT Type'	,N'VAT Type'
	,N'Hình thức thuế VAT'	,N'Hình thức thuế VAT'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'popVatType'	,'S'	,'Single'	,'uniOpenPopup'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'Group Project 여부|아니오|예|'	,N'Group Project 여부|아니오|예|'	,N'Group Project Flag|N|Y'	,N'Group Project Flag|N|Y'
	,N'项目组标志|否|是'	,N'项目组标志|否|是'	,N'Group Project Flag|N|Y'	,N'Group Project Flag|N|Y'
	,N'Có nhóm dự án không|Không|Có|'	,N'Có nhóm dự án không|Không|Có|'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'rdoGroupPrjFlg'	,'S'	,'Single'	,'uniRadioButton'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'tbl1'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2018-06-20'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'tbl2'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2018-06-20'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtCusmng'	,'S'	,'Single'	,'uniTextBox'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtCusmngdept'	,'S'	,'Single'	,'uniTextBox'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtCusmngnum'	,'S'	,'Single'	,'uniTextBox'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'개 요'	,N'개 요'	,N'Outline'	,N'Outline'
	,N'概要'	,N'概要'	,N'Outline'	,N'Outline'
	,N'Khái quát'	,N'Khái quát'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtDescription'	,'S'	,'Single'	,'uniTextBox'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'적용된견적번호'	,N'적용된견적번호'	,N'Applied Estimate No.'	,N'Applied Estimate No.'
	,N'适用报价编号'	,N'适用报价编号'	,N'Applied Estimate No.'	,N'Applied Estimate No.'
	,N'Mã số báo giá được áp dụng'	,N'Mã số báo giá được áp dụng'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtEstimate'	,'S'	,'Single'	,'uniTextBox'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'적용된견적차수'	,N'적용된견적차수'	,N'Applied Estimate Degree'	,N'Applied Estimate Degree'
	,N'适用报价程度'	,N'适用报价程度'	,N'Applied Estimate Degree'	,N'Applied Estimate Degree'
	,N'Số lần báo giá được áp dụng'	,N'Số lần báo giá được áp dụng'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtEstimateDegreeForm'	,'S'	,'Single'	,'uniTextBox'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'수주금액(자국)'	,N'수주금액(자국)'	,N'S/O Amt(Local)'	,N'S/O Amt(Local)'
	,N'订单金额(本位币)'	,N'订单金额(本位币)'	,N'S/O Amt(Local)'	,N'S/O Amt(Local)'
	,N'Số tiền đặt hàng (trong nước)'	,N'Số tiền đặt hàng (trong nước)'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtNetAmtLoc'	,'S'	,'Single'	,'uniNumeric'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtPaystat'	,'S'	,'Single'	,'uniTextBox'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtPaystatcd'	,'S'	,'Single'	,'uniTextBox'
	,NULL	,NULL	,'2018-07-04'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트코드/Ver'	,N'프로젝트코드/Ver'	,N'Project Code/Ver'	,N'Project Code/Ver'
	,N'项目编号'	,N'项目编号'	,N'Project Code/Ver'	,N'Project Code/Ver'
	,N'Mã dự án/Ver'	,N'Mã dự án/Ver'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtProjectCode'	,'S'	,'Single'	,'uniTextBox'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트명'	,N'프로젝트명'	,N'Project Name'	,N'Project Name'
	,N'项目名称'	,N'项目名称'	,N'Project Name'	,N'Project Name'
	,N'Tên dự án'	,N'Tên dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtProjectNm'	,'S'	,'Single'	,'uniTextBox'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'특기사항'	,N'특기사항'	,N'Remark'	,N'Remark'
	,N'备注'	,N'备注'	,N'Remark'	,N'Remark'
	,N'Khoản mục đặc biệt'	,N'Khoản mục đặc biệt'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtRemark'	,'S'	,'Single'	,'uniTextBox'
	,NULL	,NULL	,'2008-06-24'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트 상태'	,N'프로젝트 상태'	,N'Project State'	,N'Project State'
	,N'项目状态'	,N'项目状态'	,N'Project State'	,N'Project State'
	,N'Tình trạng dự án'	,N'Tình trạng dự án'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtState'	,'S'	,'Single'	,'uniTextBox'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'프로젝트코드/Ver'	,N'프로젝트코드/Ver'	,N'Project Code/Ver'	,N'Project Code/Ver'
	,N'项目版本'	,N'项目版本'	,N'Project Code/Ver'	,N'Project Code/Ver'
	,N'Mã dự án/Ver'	,N'Mã dự án/Ver'
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'txtVer'	,'S'	,'Single'	,'uniTextBox'
	,''	,NULL	,'2008-10-10'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	N'미리보기'	,NULL	,N'미리보기'	,NULL
	,N'미리보기'	,NULL	,N'미리보기'	,N''
	,N'미리보기'	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'uniButton1'	,'S'	,'Single'	,'uniButton'
	,NULL	,NULL	,'2018-06-27'	,'2018-06-27'	,0
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'uniTableLayoutPanel1'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2018-06-27'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'uniTableLayoutPanel3'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2018-07-04'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'uniTBL_MainBatch'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2018-06-20'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'uniTBL_MainCondition'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2018-06-20'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'uniTBL_MainData'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2018-06-20'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)

INSERT INTO V27AdminDB..DD
(
	DD_KO	,DD_KO_FULL_NM	,DD_EN	,DD_EN_FULL_NM
	,DD_CN	,DD_CN_FULL_NM	,DD_JP	,DD_JP_FULL_NM
	,DD_VN	,DD_VN_FULL_NM
	,ProgramID	,ObjectID	,Type	,GridID	,ControlType
	,DefaultValueName	,AutoFocus	,INSERT_DT	,UPDATE_DT	,imiv
	,DA_DataAuthType_Major	,DA_DataAuthType_Minor	,Pairs_ObjectID
)
VALUES
(
	NULL	,NULL	,NULL	,NULL
	,NULL	,NULL	,NULL	,N''
	,NULL	,N''
	,'uniERP.App.UI.PS.Y7204M1_KO883'	,'uniTBL_MainReference'	,'S'	,'Single'	,'uniTableLayoutPanel'
	,NULL	,NULL	,'2018-06-20'	,'2018-07-06'	,1
	,NULL	,NULL	,NULL
)
-----End    DD DML   ProgramID = 'uniERP.App.UI.PS.Y7204M1_KO883'-----------------------------------------------------------------------------