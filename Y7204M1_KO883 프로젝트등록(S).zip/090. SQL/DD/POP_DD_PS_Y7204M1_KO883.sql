﻿
SET NOCOUNT ON;
---------------------------------------------------------------------------------------------------------------------------
--	FILE NAME	: 모듈_INS_DD_POPUP_20180709_user.sql
--	MODULE		: 모듈
--	DATE		: 2018-07-09
--	Modifier	: user
---------------------------------------------------------------------------------------------------------------------------
DELETE
FROM
	V27AdminDB..DD_POPUP_GRID_INFO
WHERE
	ParentPID IN (
'uniERP.App.UI.PS.Y7204M1_KO883'
)

DELETE
FROM
	V27AdminDB..DD_POPUP_MASTER_INFO
WHERE
	ParentPID IN (
'uniERP.App.UI.PS.Y7204M1_KO883'
)
---------------------------------------------------------------------------------------------------------------------------
-----Start  DD Popup DML   ParentPID = 'uniERP.App.UI.PS.Y7204M1_KO883'-----------------------------------------------------------------------------

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popBpCd'	,''	,1	,N'고객'
	,N'Customer'	,N'客户'	,N'Customer'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Khách hàng'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popBpCd'	,''	,2	,N'고객'
	,N'Customer'	,N'客户'	,N'Customer'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Khách hàng'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popCurrency'	,''	,1	,N'통화'
	,N'Currency'	,N'货币'	,N'Currency'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Tiền tệ'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popCurrency'	,''	,2	,N'통화'
	,N'Currency'	,N'货币'	,N'Currency'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Tiền tệ'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popGroupPrjCd'	,''	,1	,N'그룹프로젝트'
	,N'Group Project'	,N'Group Project'	,N'Group Project'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Dự án nhóm'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popGroupPrjCd'	,''	,2	,N'그룹프로젝트그룹'
	,N'Group Project'	,N'Group Project'	,N'Group Project'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Nhóm dự án nhóm'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayMeth'	,''	,1	,N'결제방법'
	,N'Pay Method'	,N'结算方法'	,N'Pay Method'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Phương pháp thanh toán'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayMeth'	,''	,2	,N'결제방법'
	,N'Pay Method'	,N'结算方法'	,N'Pay Method'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Phương pháp thanh toán'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayType'	,''	,1	,N'입금유형'
	,N'Receipt Type'	,N'收款类型'	,N'Receipt Type'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Loại hình tiền thu '
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayType'	,''	,2	,N'입금유형'
	,N'Receipt Type'	,N'收款类型'	,N'Receipt Type'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Loại hình tiền thu '
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPmResourceCd'	,''	,1	,N'관리자'
	,N'Employee'	,N'员工'	,N'Employee'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Người quản lý'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPmResourceCd'	,''	,2	,N'관리자'
	,N'Employee'	,N'员工'	,N'Employee'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Người quản lý'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popProjectCode1'	,''	,1	,N'프로젝트'
	,N'Project'	,N'项目'	,N'Project'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Dự án'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popProjectCode1'	,''	,2	,N'프로젝트'
	,N'Project'	,N'项目'	,N'Project'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Dự án'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popSalesGrp'	,''	,1	,N'영업그룹'
	,N'Sales Group'	,N'销售组'	,N'Sales Group'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Nhóm kinh doanh'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popSalesGrp'	,''	,2	,N'영업그룹'
	,N'Sales Group'	,N'销售组'	,N'Sales Group'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Nhóm kinh doanh'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popVatType'	,''	,1	,N'VAT유형'
	,N'VAT Type'	,N'附加税类型'	,N'VAT Type'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Loại VAT'
)

INSERT INTO V27AdminDB..DD_POPUP_MASTER_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,Kind	,DD_KO
	,DD_EN	,DD_CN	,DD_JP	,INSERT_DT	,UPDATE_DT
	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popVatType'	,''	,2	,N'VAT유형'
	,N'VAT Type'	,N'附加税类型'	,N'VAT Type'	,'2008-02-22'	,'2015-05-20'
	,NULL	,N'Loại VAT'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popBpCd'	,''	,0	,'bp_cd'
	,'Edit'	,N'고객'	,N'Customer'	,N'客户'	,N'Customer'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Khách hàng'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popBpCd'	,''	,1	,'bp_nm'
	,'Edit'	,N'고객명'	,N'Customer Description'	,N'客户名称'	,N'Customer Description'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Tên khách hàng'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popBpCd'	,''	,2	,'bp_rgst_no'
	,'Edit'	,N'법인등록번호'	,N'Company Registration No'	,N'法人注册编号'	,N'Company Registration No'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Mã số đăng ký công ty'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popCurrency'	,''	,0	,'currency'
	,'Edit'	,N'통화'	,N'Currency'	,N'货币'	,N'Currency'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Tiền tệ'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popCurrency'	,''	,1	,'currency_desc'
	,'Edit'	,N'통화명'	,N'Currency Description'	,N'货币名称'	,N'Currency Description'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Tên tiền tệ'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popGroupPrjCd'	,''	,0	,'project_code'
	,'Edit'	,N'그룹프로젝트코드'	,N'GROUP Project Code'	,N'组织项目编号'	,N'GROUP Project Code'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Mã dự án nhóm'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popGroupPrjCd'	,''	,1	,'project_nm'
	,'Edit'	,N'그룹프로젝트명'	,N'GROUP Project Description'	,N'组织项目名称'	,N'GROUP Project Description'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Tên dự án nhóm'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayMeth'	,''	,0	,'minor_cd'
	,'Edit'	,N'결제방법'	,N'Payment Code'	,N'结算编号'	,N'Payment Code'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Phương thức thanh toán'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayMeth'	,''	,1	,'minor_nm'
	,'Edit'	,N'결제방법명'	,N'Payment Description'	,N'结算名称'	,N'Payment Description'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Tên phương thức thanh toán'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayType'	,''	,0	,'b_minor.minor_cd'
	,'Edit'	,N'입금유형'	,N'Receipt Type'	,N'入库类型'	,N'Receipt Type'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Loại hình tiền gửi'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayType'	,''	,0	,'minor_cd'
	,'Edit'	,N'입금유형'	,N'Receipt Type'	,N'入库类型'	,N'Receipt Type'
	,'2008-03-12'	,'2015-05-20'	,NULL	,N'Loại hình tiền gửi'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayType'	,''	,1	,'b_minor.minor_nm'
	,'Edit'	,N'입금유형명'	,N'Receipt Type Description'	,N'入库类型名称'	,N'Receipt Type Description'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Tên loại hình tiền gửi'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPayType'	,''	,1	,'minor_nm'
	,'Edit'	,N'입금유형명'	,N'Receipt Type Description'	,N'入库类型名称'	,N'Receipt Type Description'
	,'2008-03-12'	,'2015-05-20'	,NULL	,N'Tên loại hình tiền gửi'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPmResourceCd'	,''	,0	,'emp_no'
	,'Edit'	,N'사번'	,N'Employee ID'	,N'员工编号'	,N'Employee ID'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Mã nhân viên'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPmResourceCd'	,''	,1	,'name'
	,'Edit'	,N'이름'	,N'Name'	,N'姓名'	,N'Name'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Tên'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popPmResourceCd'	,''	,2	,'dept_nm'
	,'Edit'	,N'부서'	,N'Department'	,N'部门'	,N'Department'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Bộ phận'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popProjectCode1'	,''	,0	,'project_code'
	,'Edit'	,N'프로젝트코드'	,N'Project Code'	,N'项目代码'	,N'Project Code'
	,'2007-10-27'	,'2015-05-20'	,NULL	,N'Mã dự án'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popProjectCode1'	,''	,1	,'project_nm'
	,'Edit'	,N'프로젝트명'	,N'Project Description'	,N'项目名称'	,N'Project Description'
	,'2007-10-27'	,'2015-05-20'	,NULL	,N'Tên dự án'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popSalesGrp'	,''	,0	,'sales_grp'
	,'Edit'	,N'영업그룹'	,N'Sales Group'	,N'销售组'	,N'Sales Group'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Nhóm kinh doanh'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popSalesGrp'	,''	,1	,'sales_grp_nm'
	,'Edit'	,N'영업그룹명'	,N'Sales Group Description'	,N'销售组名称'	,N'Sales Group Description'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Tên nhóm kinh doanh'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popVatType'	,''	,0	,'minor.minor_cd'
	,'Edit'	,N'VAT 유형'	,N'VAT Type'	,N'附加税类型'	,N'VAT Type'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Loại thuế giá trị gia tăng'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popVatType'	,''	,0	,'minor_cd'
	,'Edit'	,N'VAT 유형'	,N'VAT Type'	,N'附加税类型'	,N'VAT Type'
	,'2008-03-12'	,'2015-05-20'	,NULL	,N'Loại thuế giá trị gia tăng'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popVatType'	,''	,1	,'minor.minor_nm'
	,'Edit'	,N'VAT 유형명'	,N'VAT Type Description'	,N'附加税类型名称'	,N'VAT Type Description'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Tên loại thuế giá trị gia tăng'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popVatType'	,''	,1	,'minor_nm'
	,'Edit'	,N'VAT 유형명'	,N'VAT Type Description'	,N'附加税类型名称'	,N'VAT Type Description'
	,'2008-03-12'	,'2015-05-20'	,NULL	,N'Tên loại thuế giá trị gia tăng'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popVatType'	,''	,2	,'config.reference'
	,'ExchangeRate'	,N'VAT율'	,N'VAT Rate'	,N'附加税率'	,N'VAT Rate'
	,'2007-10-29'	,'2015-05-20'	,NULL	,N'Thuế suất thuế giá trị gia tăng'
)

INSERT INTO V27AdminDB..DD_POPUP_GRID_INFO
(
	ParentPID	,ParentCID	,ParentColumnID	,FieldNo	,FieldCD
	,FieldType	,DD_KO	,DD_EN	,DD_CN	,DD_JP
	,INSERT_DT	,UPDATE_DT	,objectid	,DD_VN
)
VALUES
(
	'uniERP.App.UI.PS.Y7204M1_KO883'	,'popVatType'	,''	,2	,'reference'
	,'ExchangeRate'	,N'VAT율'	,N'VAT Rate'	,N'附加税率'	,N'VAT Rate'
	,'2008-03-12'	,'2015-05-20'	,NULL	,N'Thuế suất thuế giá trị gia tăng'
)
-----End    DD Popup DML   ParentPID = 'uniERP.App.UI.PS.Y7204M1_KO883'-----------------------------------------------------------------------------