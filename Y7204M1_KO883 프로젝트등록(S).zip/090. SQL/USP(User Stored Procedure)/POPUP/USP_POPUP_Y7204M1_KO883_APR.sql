    
--DROP PROCEDURE    dbo.[USP_POPUP_Y7204M1_KO883_APR]    
--Go    
/************************************************************************************/    
/*****    PROC NAME   :  [USP_POPUP_Y7204M1_KO883_APR]         *****/    
/*****    ���α׷�    :  Y7204M1_KO883(������Ʈ���)          *****/    
/*****   Developer   :  ������            *****/    
/*****    ���߳�¥    :  2018-07-06            *****/    
/*****    �ֽż�����¥:  2018-07-06            *****/    
/*****    ��    ��    :   ���� ���� ��ȸ����            *****/    
/************************************************************************************/    
alter PROC [dbo].[USP_POPUP_Y7204M1_KO883_APR](    
    
   @PROJECT_CODE    NVARCHAR(50)  -- ������Ʈ �ڵ�    
      
       
)        
AS    
    
    Set Nocount On    
     
SELECT    B.APPROVER_POS_NAME + '/' + B.APPROVER_NAME AS APPROVER_POS_NAME    
    ,B.PROCESS_DATE as PROCESS_DATE    
    ,B.PROC_STATE_NAME    
    
FROM   PMS_PROJECT A (NOLOCK)    
LEFT JOIN   VAP_APPR_LINE_KO883 B (NOLOCK) ON A.PROJECT_CODE = B.IF_FORM_NO    
    
WHERE B.APPR_ROLE_NAME = '����'    
AND     b.IF_FORM_NO = @PROJECT_CODE 
    
    
    