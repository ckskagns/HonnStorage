                  
--DROP PROCEDURE    DBO.[USP_���_���α׷�ID]                  
--GO                  
/************************************************************************************/                  
/*****    PROC NAME   :  [USP_���_���α׷�ID]         *****/                  
/*****    ���α׷�    :  ���α׷�ID(���α׷���)          *****/                  
/*****   DEVELOPER   :  �������̸�            *****/                  
/*****    ���߳�¥    :  2016-04-01            *****/                  
/*****    �ֽż�����¥:  2016-04-01            *****/                  
/*****    ��    ��    :  �̱� ��ȸ����            *****/                  
/************************************************************************************/                  
                  
CREATE PROC [DBO].[USP_PS_Y7204M1_KO883](                  
                  
   @PROJECT_CODE   NVARCHAR(50)  -- ������Ʈ �ڵ�                  
                    
                     
)                      
AS                  
                  
                  
                  
                  
                  
    SET NOCOUNT ON                  
SELECT A.PROJECT_CODE, A.VER, A.PROJECT_NM,                   
          A.DLVY_DT, A.PLAN_START_DT, A.PLAN_END_DT,                   
   A.PM_RESOURCE_CD, (SELECT NAME FROM HAA010T WHERE EMP_NO = A.PM_RESOURCE_CD) AS PM_RESOURCE_NM,                   
   A.PROJECT_TYPE,                   
   A.PROJECT_TYPE1,                   
   A.BP_CD, (SELECT BP_NM FROM B_BIZ_PARTNER WHERE BP_TYPE IN ('C', 'CS') AND USAGE_FLAG = 'Y' AND BP_CD = A.BP_CD) AS BP_NM,                   
   A.CURRENCY,                   
   A.NET_AMT,                   
   A.SALES_GRP,                   
   (SELECT SALES_GRP_NM FROM B_SALES_GRP WHERE USAGE_FLAG= 'Y' AND SALES_GRP = A.SALES_GRP) AS SALES_GRP_NM,                   
   A.NET_AMT_LOC,                   
   A.PAY_METH,                   
   (SELECT MINOR_NM FROM B_MINOR WHERE MAJOR_CD = 'B9004' AND MINOR_CD = A.PAY_METH) AS PAY_METH_NM,                   
   A.PAY_TYPE,                   
   (SELECT MINOR_NM FROM B_MINOR WHERE MAJOR_CD = 'A1006' AND MINOR_CD = A.PAY_TYPE) AS PAY_TYPE_NM,                   
   A.XCH_RATE,                   
   A.VAT_TYPE,                   
   (SELECT X.MINOR_NM FROM B_MINOR X, B_CONFIGURATION Y WHERE X.MAJOR_CD = 'B9001' AND Y.MAJOR_CD = X.MAJOR_CD AND Y.MINOR_CD = X.MINOR_CD AND Y.SEQ_NO = 1 AND X.MINOR_CD = A.VAT_TYPE) AS VAT_TYPE_NM,                   
   A.VAT_RATE, A.VAT_INC_FLAG,                      
   CAST(A.GROUP_PRJ_FLG AS CHAR(1)) AS GROUP_PRJ_FLG, A.VAT_AMT,                   
   A.GROUP_PRJ_CD,                   
   (SELECT PROJECT_NM FROM PMS_PROJECT WHERE GROUP_PRJ_FLG = '1' AND PROJECT_CODE = A.GROUP_PRJ_CD) AS GROUP_PRJ_NM,                   
   A.STATE,                   
   (SELECT MINOR_NM FROM B_MINOR WHERE MAJOR_CD = 'Y0004' AND MINOR_CD = A.STATE) AS STATE_NM,                   
   A.DESCRIPTION,                   
   REPLACE(A.REMARK, CHAR(13) + CHAR(10), CHAR(11)) AS REMARK,                   
   A.REAL_START_DT, A.REAL_END_DT, A.PLAN_COST_RATE, A.COST_PLAN_CFM,                   
   A.VAT_AMT_LOC, A.MONTHLY_CLOSE_DT, A.COMP_RATE_DT, A.COMP_RATE,                   
   A.SO_DT, A.SO_NO, A.ESTIMATE_NO ,A.ESTIMATE_DEGREE,                   
   A.ALLOC_BASIS_OF_EXPENSE_BY_TASK, A.ALLOC_BASIS_OF_LABOR_BY_ITEM,                   
   A.CHANGED_FLAG , A.REVENUE_FLAG AS REVENUE_FLG, A.PRJ_TYPE AS PRJTYPE ,                  
  ISNULL(A.EXT1_CD_KO883,'') as EXT1_CD_KO883,    
  ISNULL(A.EXT2_CD_KO883,'') as EXT2_CD_KO883,    
   A.EXT3_CD_KO883,    
   A.EXT4_CD_KO883,                  
  ISNULL(A.EXT5_CD_KO883,'') as EXT5_CD_KO883,    
  ISNULL(A.EXT6_CD_KO883,'') as EXT6_CD_KO883,    
  ISNULL(A.EXT7_CD_KO883,'') as EXT7_CD_KO883,    
   A.EXT1_DT_KO883,                
  ISNULL((SELECT APPROVAL_RTN FROM ERP_IF_APPROVAL WHERE A.PROJECT_CODE = DOC_NO),'F') as APPROVAL_RTNCD ,            
   dbo.ufn_GetCodeName('SM003', (SELECT APPROVAL_RTN FROM ERP_IF_APPROVAL WHERE A.PROJECT_CODE = DOC_NO))     as APPROVAL_RTN              
    ,(SELECT NAME FROM HAA010T WHERE EMP_NO = A.EXT1_CD_KO883  )as ext1_nm_ko883      
 ,(SELECT NAME FROM HAA010T WHERE EMP_NO = A.EXT2_CD_KO883)as ext2_nm_ko883      
 ,(SELECT NAME FROM HAA010T WHERE EMP_NO = A.EXT4_CD_KO883)as ext4_nm_ko883      
            
    FROM PMS_PROJECT A                   
                  
    WHERE A.PROJECT_CODE =  @PROJECT_CODE 