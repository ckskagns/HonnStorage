INSERT INTO ERP_IF_APPROVAL_DOCUMENT VALUES
('Y7204M1_KO883','Project ���� ��û��','P1',
'
<html>
<head>
    <title>Project ���� ��û��</title>
    <style type=''text/css''>
        td, th
        {
            font-size: 8pt;
            font-family: Arial Unicode MS;
            padding: 0;
        }
        table
        {
            padding: 0;
            border-spacing: 0;
            border: 1px;
            border-collapse: collapse;
        }
        .td_2201
        {
            border-style: solid;
            border-width: 1px;
            border-color: black;
            border-left-width: 1px;
            border-top-width: 1px;
            border-right-width: 0;
            border-bottom-width: 1px;
            vertical-align: middle;
        }
        .td_1221
        {
            border-style: solid;
            border-width: 1px;
            border-color: black;
            border-left-width: 1px;
            border-top-width: 1px;
            border-right-width: 1px;
            border-bottom-width: 1px;
            vertical-align: middle;
        }
        .td_1224
        {
            border-style: solid;
            border-width: 1px;
            border-color: black;
            border-left-width: 1px;
            border-top-width: 1px;
            border-right-width: 0px;
            border-bottom-width: 1px;
            vertical-align: middle;
        }
        .td_1225
        {
            border-style: solid;
            border-width: 1px;
            border-color: black;
            border-left-width: 0px;
            border-top-width: 1px;
            border-right-width: 1px;
            border-bottom-width: 1px;
            vertical-align: middle;
        }
        .td_1222
        {
            border-style: solid;
            border-width: 1px;
            border-color: black;
            border-left-width: 1px;
            border-top-width: 1px;
            border-right-width: 1px;
            border-bottom-width: 1px;
            vertical-align: middle;
            font-weight: bold;
        }
        .td_2001
        {
            border-style: solid;
            border-width: 1px;
            border-color: black;
            border-left-width: 1px;
            border-top-width: 0;
            border-right-width: 1px;
            border-bottom-width: 1px;
            vertical-align: middle;
            font-weight: bold;
        }
    </style>
</head>
<meta http-equiv="CONTENT-TYPE" content="TEXT/HTML; CHARSET=UTF-8">
<body>
    <br />
    <br />
    <br />
    <table width=''950''>
        <tr>
            <td>
                <tr height=''28''>
                    <td>
                        <table width=''100%'' height=''100%''>
                            <tr height=''80''>
                                <td class=''td_1225'' colspan="6" align="center">
                                    <h1>
                                        <strong>Project ���� ��û��</strong></h1>
                                </td>
                            </tr>
                            <tr height=''40''>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;����
                                </td>
                                <td class=''td_1221'' colspan="5" align=''center''>
                                    &nbsp;&nbsp;##PMS_PROJECT.PROJECT_TYPE1##
                                </td>
                            </tr>
                            <tr height=''40''>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;PROJECT NO.
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.PROJECT_CODE##
                                </td>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;PROJECT ��
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.PROJECT_NM##
                                </td>
                            </tr>
                            <tr height=''40''>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;������Ʈ ����
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.PROJECT_TYPE##
                                </td>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;������
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.BP_CD##
                                </td>
                            </tr>
                            <tr height=''40''>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;���� �����
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.EXT5_CD_KO883##
                                </td>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;���� ���(�μ�)
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.EXT6_CD_KO883##
                                </td>
                            </tr>
                            <tr height=''40''>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;���ֱ���
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.EXT3_CD_KO883##
                                </td>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;������
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.EXT1_DT_KO883##
                                </td>
                            </tr>
                            <tr height=''40''>
                                <td class=''td_2201'' width=''15%'' align=''center''>
                                    &nbsp;
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;
                                </td>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;������
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.DLVY_DT##
                                </td>
                            </tr>
                            <tr height=''40''>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;���� ���
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.EXT1_CD_KO883##
                                </td>
                                <td class=''td_1222'' width=''15%'' align=''center''>
                                    &nbsp;CS ���
                                </td>
                                <td class=''td_1221'' colspan="2" width=''35%''>
                                    &nbsp;&nbsp;##PMS_PROJECT.EXT2_CD_KO883##
                                </td>
                            </tr>
                            <tr height=''28''>
                                <td class=''td_1221'' colspan=''6''>
                                </td>
                            </tr>
                            <tr height=''18''>
                                <td class=''td_1221'' colspan="6">
                                </td>
                            </tr>
                        </table>
                        <table width=''100%'' height=''100%''>
                            <tr height=''28''>
                                <td class="td_2001" align="center" width=''5%''>
                                    ����
                                </td>
                                <td class="td_2001" align="center" width=''23%''>
                                    ǰ��
                                </td>
                                <td class="td_2001" align="center" width=''17%''>
                                    ǰ���
                                </td>
                                <td class="td_2001" align="center" width=''5%''>
                                    �԰�
                                </td>
                                <td class="td_2001" align="center" width=''15%''>
                                    ����
                                </td>
                                <td class="td_2001" align="center" width=''35%''>
                                    [ Ư�̻��� ]
                                </td>
                            </tr>
                            ##CONTENT_DTL##
                            <tr height=''18''>
                                <td class="td_2001" align="center" colspan=''6''>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </td>
        </tr>
        <tr height=''2'' />
    </table>
    <br />
</body>
</html>


',


'','','unierp',GETDATE(), 'unierp',GETDATE())
