﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Library.UI;
using uniERP.AppFramework.DataBridge;
using Infragistics.Win.UltraWinGrid;

using Microsoft.Practices.CompositeUI.SmartParts;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.Commands;


using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Controls.Popup;
using uniERP.AppFramework.UI.Providers;
using uniERP.AppFramework.UI.Common.Exceptions;


#endregion


namespace uniERP.App.UI.POPUP.Y7204P1_KO883
{

    [Microsoft.Practices.CompositeUI.SmartParts.SmartPart]
    public partial class PopupViewer : PopupViewBase
    {
        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①namespace</NameSpace>
        /// <Module>②module name</Module>
        /// <Class>③class name</Class>
        /// <Desc>④
        ///   This part describe the summary information about class 
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="creator" Date="created date">Make …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        #endregion

        #region ■ 1.4 Class global constants (grid)

        #endregion

        #region ■ 1.5 Class global variables (grid)
        tdspop cqtdsData = new tdspop();
        // change your code
        //private wsMyBizFL.TypedDataSet cstdsTypedDataSet = new wsMyBizFL.TypedDataSet();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public PopupViewer()
        {
            InitializeComponent();

            SetLayoutBasePanel(uniTBL_OuterMost);  // Outer most TableLayout Panel Name

        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(this.cqtdsData);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T04_MultiMulti | enumDef.ViewType.TA1_UserPopup);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Query, enumDef.ModuleInformation.Common);      // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                                   // Load custom numeric format

        }

        protected override void Form_Load_Completed()
        {
            string[] appParam = (string[])base.ParentData.Data;
            txtProjectType.Value = appParam[0];
            txtProjectNo.Value = appParam[1];
            txtProjectNm.Value = appParam[2];
            txtProjectType1.Value = appParam[3];
            txtDocId.Value = appParam[4];

            DBQuery();
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            cqtdsData.Clear();
        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            //txtValidDT.Value = uniBase.UDate.GetDBServerDateTime();          // get DB Server DateTime 
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringCode)

        protected override void GatheringComboData()
        {

        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆

            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            tdspop.E_PMS_PROJECT_HAPDataTable uniGridTB1 = cqtdsData.E_PMS_PROJECT_HAP ; 

            this.uniGrid1.SSSetEdit(uniGridTB1.approver_dept_nameColumn.ColumnName, "부서", 70, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.approver_pos_nameColumn.ColumnName, "결재자", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetDate(uniGridTB1.process_dateColumn.ColumnName, "결재일", 120, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.proc_opinionColumn.ColumnName, "의견", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.proc_state_nameColumn.ColumnName, "결재상태", 80, enumDef.FieldType.ReadOnly);

            tdspop.E_PMS_PROJECT_APRDataTable uniGridTB2 = cqtdsData.E_PMS_PROJECT_APR;
            this.uniGrid2.SSSetEdit(uniGridTB1.approver_dept_nameColumn.ColumnName, "부서", 70, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.approver_pos_nameColumn.ColumnName, "결재자", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetDate(uniGridTB2.process_dateColumn.ColumnName, "결재일", 120, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB1.proc_opinionColumn.ColumnName, "의견", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.proc_state_nameColumn.ColumnName, "결재상태", 80, enumDef.FieldType.ReadOnly);
           

            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.Yes);
            this.uniGrid2.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.Yes);

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            UltraGridGroup group0 = this.uniGrid1.DisplayLayout.Bands[0].Groups.Add("전자결재(합의)");
            UltraGridGroup group1 = this.uniGrid2.DisplayLayout.Bands[0].Groups.Add("전자결재(결재)");

            this.uniGrid1.DisplayLayout.Bands[0].Columns["approver_dept_name"].Group = group0;
            this.uniGrid1.DisplayLayout.Bands[0].Columns["approver_pos_name"].Group = group0;
            this.uniGrid1.DisplayLayout.Bands[0].Columns["process_date"].Group = group0;
            this.uniGrid1.DisplayLayout.Bands[0].Columns["proc_opinion"].Group = group0;
            this.uniGrid1.DisplayLayout.Bands[0].Columns["proc_state_name"].Group = group0;

            this.uniGrid2.DisplayLayout.Bands[0].Columns["approver_dept_name"].Group = group1;
            this.uniGrid2.DisplayLayout.Bands[0].Columns["approver_pos_name"].Group = group1;
            this.uniGrid2.DisplayLayout.Bands[0].Columns["process_date"].Group = group1;
            this.uniGrid2.DisplayLayout.Bands[0].Columns["proc_opinion"].Group = group1;
            this.uniGrid2.DisplayLayout.Bands[0].Columns["proc_state_name"].Group = group1;

            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {

        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
        }
        #endregion

        #region ■ 3.4 initControlBinding
        protected override void InitControlBinding()
        {
            // Grid binding with global dataset variable.
            this.InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(this.cqtdsData.E_PMS_PROJECT_HAP);
            this.uniGrid2.uniGridSetDataBinding(this.cqtdsData.E_PMS_PROJECT_APR);

        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 FncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //TO-DO : code business oriented logic

            return DBQuery();

        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)
        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic
            return DBSave();
        }
        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)
        protected override bool OnFncCopy()
        {
            return true;
        }
        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)
        protected override bool OnFncPrev()
        {
            return true;
        }
        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)
        protected override bool OnFncNext()
        {
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 FncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic

            return true;
        }
        #endregion

        #region ■■ 4.3.2 FncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 FncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopyRow)
        protected override bool OnFncCopyRow()
        {
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.3 Db function group

        #region ■■ 4.3.1 DBQuery(Common)

        private bool DBQuery()
        {
            try
            {

                DataSet iqtds = new DataSet();
                using (uniCommand unicmd1 = uniBase.UDatabase.GetStoredProcCommand("USP_POPUP_Y7204M1_KO883_HAP"))
                {
                    uniBase.UDatabase.AddInParameter(unicmd1, "@PROJECT_CODE", SqlDbType.NVarChar, txtProjectNo.Value.ToString());


                    DataSet dsData = uniBase.UDatabase.ExecuteDataSet(unicmd1);

                    if (dsData == null || dsData.Tables.Count == 0 || dsData.Tables[0].Rows.Count == 0)
                    {
                       // uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                       // return true;
                    }
                    //20171101 hsy 컬럼 max length 변경으로 인한 추가

                    cqtdsData.E_PMS_PROJECT_HAP.Merge(dsData.Tables[0], false, MissingSchemaAction.Ignore);
                }
                using (uniCommand unicmd2 = uniBase.UDatabase.GetStoredProcCommand("USP_POPUP_Y7204M1_KO883_APR"))
                {
                    uniBase.UDatabase.AddInParameter(unicmd2, "@PROJECT_CODE", SqlDbType.NVarChar, txtProjectNo.Value.ToString());


                    DataSet dsData = uniBase.UDatabase.ExecuteDataSet(unicmd2);

                    if (dsData == null || dsData.Tables.Count == 0 || dsData.Tables[0].Rows.Count == 0)
                    {
                        //uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                       // return true;
                    }
                    //20171101 hsy 컬럼 max length 변경으로 인한 추가
                    cqtdsData.E_PMS_PROJECT_APR.Clear();
                    cqtdsData.E_PMS_PROJECT_APR.Merge(dsData.Tables[0], false, MissingSchemaAction.Ignore);
                }

            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                //if (iqtdsTypedDataSet != null) iqtdsTypedDataSet.Dispose();
                //if (iqtdsICondition != null) iqtdsICondition.Dispose();
            }

            return true;
        }

     

        #region ■■ 4.3.2 DBDelete(Single)

        #endregion

        #region ■■ 4.3.3 DBSave(Common)

        private bool DBSave()
        {

            return true;

        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        private void btnQuery_Click(object sender, EventArgs e)
        {
            this.uniGrid1.clearSpreadData();                                // clear grid data
            this.DBQuery();                                                 // Query
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.OKProcess();                                               // get selected row and retrun to caller
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.ParentForm.Close();                                  // close current popup
        }

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        private void uniGrid1_DoubleClickRow(object sender, DoubleClickRowEventArgs e)
        {
            if (uniGrid1.Rows.Count < 1)
                return;

            this.OKProcess();
        }

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        #endregion

        #endregion

        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        private void OKProcess()
        {
            base.SetPopupOK();  // enable raise after_popup event;

            //base.ResultData.Data = GetSelectedRow();

            this.ParentForm.Close();
        }

        private DataSet GetSelectedRow()
        {
            //wsPB1G041FL.DsBListAutoNumbering.E1_B_AUTO_NUMBERINGDataTable iE1_B_AUTO_NUMBERINGDataTable = cqtdsBListAutoNumbering.E1_B_AUTO_NUMBERING;

            DataSet tempDataSet = new DataSet();

            DataSet iDataSet = null;

            //iDataSet = GetGridSelectedRow(uniGrid1, iE1_B_AUTO_NUMBERINGDataTable);
            iDataSet = GetGridSelectedRow(uniGrid1, tempDataSet.Tables[0]);

            if (iDataSet == null)
            {
                return (GetActiveRow());
            }

            return iDataSet;

        }

        private DataSet GetActiveRow()
        {

            //wsPB1G041FL.DsBListAutoNumbering.E1_B_AUTO_NUMBERINGDataTable iE1_B_AUTO_NUMBERINGDataTable = cqtdsBListAutoNumbering.E1_B_AUTO_NUMBERING;

            DataSet tempDataSet = new DataSet();

            DataSet iDataSet = null;

            //iDataSet = GetGridActiveRow(uniGrid1, iE1_B_AUTO_NUMBERINGDataTable);
            iDataSet = GetGridActiveRow(uniGrid1, tempDataSet.Tables[0]);

            return iDataSet;

        }

        // get selected row data in uniGrid

        private DataSet GetGridSelectedRow(uniGrid puniGrid, DataTable pDataTable)
        {

            DataSet iDataSet = new DataSet();

            Infragistics.Win.UltraWinGrid.SelectedRowsCollection selectedRows;

            selectedRows = puniGrid.Selected.Rows;  // Get the selected rows.

            if (selectedRows.Count < 1)                  // If there are no selected rows, return
            {
                return null;
            }

            DataTable iDataTable = pDataTable.Clone();

            for (int i = 0; i < selectedRows.Count; i++)           // Loop through all the selected rows
            {
                Infragistics.Win.UltraWinGrid.UltraGridRow row;

                row = selectedRows[i];

                DataRow iDataRow = iDataTable.NewRow();

                foreach (DataColumn col in pDataTable.Columns)
                {

                    iDataRow[col.ColumnName] = row.Cells[col.ColumnName].Value;

                }

                iDataTable.Rows.Add(iDataRow);

            }

            iDataSet.Tables.Add(iDataTable);

            return iDataSet;

        }

        // get active row data in uniGrid

        private DataSet GetGridActiveRow(uniGrid puniGrid, DataTable pDataTable)
        {

            DataSet iDataSet = new DataSet();

            if (uniGrid1.Rows.Count < 1)
            {
                return null;
            }

            DataTable iDataTable = pDataTable.Clone();

            DataRow iDataRow = iDataTable.NewRow();

            iDataTable.Rows.Add(iDataRow);

            if (puniGrid.ActiveRow != null)
            {

                foreach (DataColumn col in pDataTable.Columns)
                {
                    iDataRow[col.ColumnName] = puniGrid.ActiveRow.Cells[col.ColumnName].Value;

                }
                iDataSet.Tables.Add(iDataTable);
            }
            else
            {
                return null;
            }
            return iDataSet;
        }

        #endregion

        private void uniGrid1_InitializeLayout(object sender, InitializeLayoutEventArgs e)
        {

        }


        #endregion


        #endregion



    }
}
