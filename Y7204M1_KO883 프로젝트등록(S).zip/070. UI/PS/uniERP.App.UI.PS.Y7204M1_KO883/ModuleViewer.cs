﻿#region �� Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;


using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.DataBridge;
#endregion
namespace uniERP.App.UI.PS.Y7204M1_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region �� 1. Declaration part

        #region �� 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>��Y7204M1_KO883</NameSpace>
        /// <Module>��PS</Module>
        /// <Class>��class name</Class>
        /// <Desc>��
        ///   This part describe the summary information about class 
        /// </Desc>
        /// <History>��
        ///   <FirstCreated>
        ///     <history name="최재학" Date="2018-07-09">프로젝트 등록(S) ��</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>��
        ///   <remark name="modifier"  Date="modified date">�� </remark>
        ///   <remark name="modifier"  Date="modified date">�� </remark>
        /// </Remarks>

        #endregion

        #region �� 1.2. Class global constants (common)

        #endregion

        #region �� 1.3. Class global variables (common)

        // change your code

        wsPY7G204FL.DsPManageProject cqtdsPManageProject = new uniERP.App.UI.PS.Y7204M1_KO883.wsPY7G204FL.DsPManageProject();

        wsPB5GS45FL.DsBListDefaultBpFtnSvr cqtdsBListDefaultBpFtnSvr = new uniERP.App.UI.PS.Y7204M1_KO883.wsPB5GS45FL.DsBListDefaultBpFtnSvr(); //쓰이는곳이 없음

 
        string strCommandSend = string.Empty;

        #endregion

        #region �� 1.4 Class global constants (grid)

        #endregion

        #region �� 1.5 Class global variables (grid)

        #endregion

        #endregion

        #region �� 2. Initialization part

        #region �� 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region �� 2.2 Form_Load(common)

        protected override void Form_Load()
        {

            uniBase.UData.SetWorkingDataSet(cqtdsPManageProject);
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("ext1_cd_ko883", typeof(string));
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("ext2_cd_ko883", typeof(string));
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("ext3_cd_ko883", typeof(string));
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("ext4_cd_ko883", typeof(string));
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("ext1_dt_ko883", typeof(DateTime));
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("approval_rtn", typeof(string));
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("approval_rtncd", typeof(string));
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("ext5_cd_ko883", typeof(string));
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("ext6_cd_ko883", typeof(string));
            cqtdsPManageProject.I1_PMS_PROJECT.Columns.Add("ext7_cd_ko883", typeof(string));
            uniBase.UCommon.SetViewType(enumDef.ViewType.T01_Single);



            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.ProjectManagement);  // Load company numeric format. I: Input Program, *: All Module

            this.LoadCustomInfTB19029();
        }

        protected override void Form_Load_Completed()
        {
            uniBase.UCommon.SetToolBarAll(false);
            uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Query | enumDef.ToolBitCommon.Save, true);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New, true);
        }

        #endregion

        #region �� 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        
        
        {

        }

        #endregion

        #region �� 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            cboPrjType.Value = "I";
            cboRevenue.Value = "C";
            cboVatIncFlag.Value = "1";
            cboProjectType.Value = "100";
            cboBaljugb.Value = "PO";
            cboProjectType1.Value = "100";
//#if DEBUG
//            popPmResourceCd.CodeValue = "20110301";
//            popBpCd.CodeValue = "10301";
//            popSalesGrp.CodeValue = "S10";
//            popPayMeth.CodeValue = "CH";
//            popReqman.CodeValue = "test";
//            popVatType.CodeValue = "A";


//#endif
            DateTime Today = uniBase.UDate.GetDBServerDateTime();
            dtPlanStartDt.uniDateTimeF.uniValue = Today;
            dtPlanStartDt.uniDateTimeT.uniValue = Today.AddMonths(1);
            dtBaljudt.Value = Today;
            dtDlvyDt.uniValue = Today.AddMonths(1);
            txtVer.Text = "0.0";

            numVatRate.Value = 0.00000;
            numNetAmt.Value = 0;
            numVatAmt.Value = 0;
            txtNetAmtLoc.Text = "0";
            popCurrency.CodeValue = CommonVariable.gCurrency;

            uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Normal);

            if (CommonVariable.gCurrency == "KRW")
            {
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
                numXchRate.Value = 1;
            }
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Normal);
            }

            DataSet itds = new DataSet();

            try
            {
                itds = uniBase.UDataAccess.CommonQueryRs(" MINOR_CD,MINOR_NM ", " B_MINOR ", "MAJOR_CD ='Y0004' AND MINOR_CD = '0'");
                txtState.Text = itds.Tables[0].Rows[0][1].ToString().Trim();
                txtEstimateDegreeForm.Text = "0";
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }

            rdoGroupPrjFlg.CheckedIndex = 0;
        }

        #endregion

        #region �� 2.5 Gathering combo data(old:InitComboBox/InitSpreadComboBox)

        protected override void GatheringComboData()
        {
            uniBase.UData.ComboMajorAdd("Project", "Y8312");
            uniBase.UData.ComboMajorAdd("Vat", "S4035");
            uniBase.UData.ComboMajorAdd("Type", "Y0003");
            uniBase.UData.ComboMajorAdd("Type1", "Y0011");
            uniBase.UData.ComboMajorAdd("Revenue", "Y8311");
        }
        #endregion

        #region �� 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ��
            // Example :
            base.viewTB19029.ggUserDefined6.DecPoint = 2;
            base.viewTB19029.ggUserDefined6.Integeral = 6;

            base.viewTB19029.ggUserDefined7.DecPoint = 2;
            base.viewTB19029.ggUserDefined7.Integeral = 3;

            base.viewTB19029.ggUserDefined8.DecPoint = 1;
            base.viewTB19029.ggUserDefined8.Integeral = 2;


            #endregion
        }

        #endregion

        #endregion

        #region �� 3. Grid method part

        #region �� 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {

        }
        #endregion

        #region �� 3.2 InitData

        private void InitData()
        {

        }

        #endregion

        #region �� 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {

        }
        #endregion

        #region �� 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            // General Control : (example)

            wsPY7G204FL.DsPManageProject.I1_PMS_PROJECTDataTable uniTB = cqtdsPManageProject.I1_PMS_PROJECT;

            uniTB.Columns.Add("PM_RESOURCE_NM");
            uniTB.Columns.Add("SALES_GRP_NM");
            uniTB.Columns.Add("BP_NM");
            uniTB.Columns.Add("PAY_METH_NM");
            uniTB.Columns.Add("PAY_TYPE_NM");
            uniTB.Columns.Add("VAT_TYPE_NM");
            uniTB.Columns.Add("GROUP_PRJ_NM");
            uniTB.Columns.Add("STATE_NM");
            uniTB.Columns.Add("ESTIMATE_NO");
            uniTB.Columns.Add("EXT1_NM_KO883");
            uniTB.Columns.Add("EXT2_NM_KO883");
            uniTB.Columns.Add("EXT4_NM_KO883");


            uniBase.UData.addDataBinding(popSulgye, "CodeValue", uniTB.Columns["ext1_cd_ko883"]);
            uniBase.UData.addDataBinding(popSulgye, "CodeName", uniTB.Columns["EXT1_NM_KO883"]);
            uniBase.UData.addDataBinding(this.cboBaljugb, uniTB.Columns["ext3_cd_ko883"]);
            uniBase.UData.addDataBinding(this.popReqman, "CodeValue", uniTB.Columns["ext4_cd_ko883"]);
            uniBase.UData.addDataBinding(popReqman, "CodeName", uniTB.Columns["EXT4_NM_KO883"]);
            uniBase.UData.addDataBinding(this.txtCusmng, uniTB.Columns["ext5_cd_ko883"]);
            uniBase.UData.addDataBinding(this.txtCusmngnum, uniTB.Columns["ext7_cd_ko883"]);
            uniBase.UData.addDataBinding(this.popCsmng, "CodeValue", uniTB.Columns["ext2_cd_ko883"]);
            uniBase.UData.addDataBinding(popCsmng, "CodeName", uniTB.Columns["EXT2_NM_KO883"]);
            uniBase.UData.addDataBinding(this.dtBaljudt, uniTB.Columns["ext1_dt_ko883"]);
            uniBase.UData.addDataBinding(this.txtPaystat, uniTB.Columns["approval_rtn"]);
            uniBase.UData.addDataBinding(this.txtPaystatcd, uniTB.Columns["approval_rtncd"]);
            uniBase.UData.addDataBinding(this.txtCusmngdept, uniTB.Columns["ext6_cd_ko883"]);

            uniBase.UData.addDataBinding(txtProjectCode, uniTB, uniTB.project_codeColumn.ColumnName);
            uniBase.UData.addDataBinding(txtVer, uniTB, uniTB.verColumn.ColumnName);
            uniBase.UData.addDataBinding(txtEstimateDegreeForm, uniTB, uniTB.estimate_degreeColumn.ColumnName);
            uniBase.UData.addDataBinding(txtEstimate, uniTB, uniTB.Columns["ESTIMATE_NO"].ColumnName);
            uniBase.UData.addDataBinding(txtProjectNm, uniTB, uniTB.project_nmColumn.ColumnName);
            uniBase.UData.addDataBinding(dtDlvyDt, uniTB, uniTB.dlvy_dtColumn.ColumnName);
            uniBase.UData.addDataBinding(dtPlanStartDt.uniDateTimeF, uniTB, uniTB.plan_start_dtColumn.ColumnName);
            uniBase.UData.addDataBinding(dtPlanStartDt.uniDateTimeT, uniTB, uniTB.plan_end_dtColumn.ColumnName);
            uniBase.UData.addDataBinding(popPmResourceCd, "CodeValue", uniTB, uniTB.pm_resource_cdColumn.ColumnName);
            uniBase.UData.addDataBinding(popPmResourceCd, "CodeName", uniTB.Columns["PM_RESOURCE_NM"]);
            uniBase.UData.addDataBinding(cboProjectType, uniTB, uniTB.project_typeColumn.ColumnName);
            uniBase.UData.addDataBinding(cboProjectType1, uniTB, uniTB.project_type1Column.ColumnName);
            uniBase.UData.addDataBinding(popBpCd, "CodeValue", uniTB, uniTB.bp_cdColumn.ColumnName);
            uniBase.UData.addDataBinding(popBpCd, "CodeName", uniTB.Columns["BP_NM"]);
            uniBase.UData.addDataBinding(popCurrency, "CodeValue", uniTB, uniTB.currencyColumn.ColumnName);
            uniBase.UData.addDataBinding(numNetAmt, uniTB, uniTB.net_amtColumn.ColumnName);
            uniBase.UData.addDataBinding(popSalesGrp, "CodeValue", uniTB, uniTB.sales_grpColumn.ColumnName);
            uniBase.UData.addDataBinding(popSalesGrp, "CodeName", uniTB.Columns["SALES_GRP_NM"]);
            uniBase.UData.addDataBinding(txtNetAmtLoc, uniTB, uniTB.net_amt_locColumn.ColumnName);
            uniBase.UData.addDataBinding(popPayMeth, "CodeValue", uniTB, uniTB.pay_methColumn.ColumnName);
            uniBase.UData.addDataBinding(popPayMeth, "CodeName", uniTB.Columns["PAY_METH_NM"]);
            uniBase.UData.addDataBinding(popPayType, "CodeValue", uniTB, uniTB.pay_typeColumn.ColumnName);
            uniBase.UData.addDataBinding(popPayType, "CodeName", uniTB.Columns["PAY_TYPE_NM"]);
            uniBase.UData.addDataBinding(numXchRate, uniTB, uniTB.xch_rateColumn.ColumnName);
            uniBase.UData.addDataBinding(popVatType, "CodeValue", uniTB, uniTB.vat_typeColumn.ColumnName);
            uniBase.UData.addDataBinding(popVatType, "CodeName", uniTB.Columns["VAT_TYPE_NM"]);
            uniBase.UData.addDataBinding(numVatRate, uniTB, uniTB.vat_rateColumn.ColumnName);
            uniBase.UData.addDataBinding(cboVatIncFlag, uniTB, uniTB.vat_inc_flagColumn.ColumnName);
            uniBase.UData.addDataBinding(cboRevenue, uniTB, uniTB.revenue_flgColumn.ColumnName);
            uniBase.UData.addDataBinding(cboPrjType, uniTB, uniTB.prjtypeColumn.ColumnName);
            uniBase.UData.addDataBinding(numVatAmt, uniTB, uniTB.vat_amtColumn.ColumnName);
            uniBase.UData.addDataBinding(rdoGroupPrjFlg, uniTB, uniTB.group_prj_flgColumn.ColumnName);
            uniBase.UData.addDataBinding(popGroupPrjCd, "CodeValue", uniTB, uniTB.group_prj_cdColumn.ColumnName);
            uniBase.UData.addDataBinding(popGroupPrjCd, "CodeName", uniTB.Columns["GROUP_PRJ_NM"]);
            uniBase.UData.addDataBinding(txtState, uniTB, uniTB.Columns["STATE_NM"].ColumnName);
            uniBase.UData.addDataBinding(txtDescription, uniTB, uniTB.descriptionColumn.ColumnName);
            uniBase.UData.addDataBinding(txtRemark, uniTB, uniTB.remarkColumn.ColumnName);


        }
        #endregion

        #endregion

        #region �� 4. Toolbar method part

        #region �� 4.1 Common Fnction group

        #region ��� 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            return DBQuery();
        }

        #endregion

        #region ��� 4.1.2 OnFncSave(old:FncSave)
        protected override bool OnFncSave()
        {
            if (dtPlanStartDt.uniDateTimeF.Value != null && dtPlanStartDt.uniDateTimeT.Value != null)
            {
                if (Convert.ToDateTime(dtPlanStartDt.uniDateTimeF.Value) > Convert.ToDateTime(dtPlanStartDt.uniDateTimeT.Value))
                {
                    uniBase.UMessage.DisplayMessageBox("YM0018", MessageBoxButtons.OK, popProjectCode1.uniALT);
                    dtPlanStartDt.Focus();
                    return false;
                }

                if (Convert.ToDateTime(dtPlanStartDt.uniDateTimeF.Value) > Convert.ToDateTime(dtDlvyDt.Value))
                {
                    uniBase.UMessage.DisplayMessageBox("YM0022", MessageBoxButtons.OK, dtPlanStartDt.uniDateTimeF.uniALT);
                    dtDlvyDt.Focus();
                    return false;
                }

                if (Convert.ToDateTime(dtPlanStartDt.uniDateTimeT.Value) < Convert.ToDateTime(dtDlvyDt.Value))
                {
                    uniBase.UMessage.DisplayMessageBox("YM0023", MessageBoxButtons.OK, dtDlvyDt.uniALT);
                    dtDlvyDt.Focus();
                    return false;
                }

                if (txtProjectNm.Text.ToString().Trim().Length > 120)
                {
                    uniBase.UMessage.DisplayMessageBox("Y71031", MessageBoxButtons.OK, lblProjectName.Text, "120");
                    txtProjectNm.Focus();
                    return false;
                }

                if (txtDescription.Text.ToString().Trim().Length > 120)
                {
                    uniBase.UMessage.DisplayMessageBox("Y71031", MessageBoxButtons.OK, lblOutline.Text, "120");
                    txtDescription.Focus();
                    return false;
                }

                if (txtRemark.Text.ToString().Trim().Length > 1000)
                {
                    uniBase.UMessage.DisplayMessageBox("Y71031", MessageBoxButtons.OK, lblRemark.Text, "1000");
                    txtRemark.Focus();
                    return false;
                }

            }
            return DBSave();
        }
        #endregion

        #endregion

        #region �� 4.2 Single Fnction group

        #region ��� 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {
            //cqtdsPManageProject.Clear();
            this.viewDBSaveMode = enumDef.DBSaveMode.CreateMode;
            uniBase.UCommon.ChangeFieldLockAttribute(txtProjectCode, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeF, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeT, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
            txtEstimateDegreeForm.Value = "0";
            txtVer.Value = "1.0";
            cboProjectType.Value = "100";
            DateTime Today;
            Today = uniBase.UDate.GetDBServerDateTime();
            dtPlanStartDt.uniDateTimeF.uniValue = Today;
            dtPlanStartDt.uniDateTimeT.Value = Today.AddMonths(1);
            popCurrency.CodeValue = "KRW";
            txtNetAmtLoc.Value = "0";
            numXchRate.Value = "1";
            cboRevenue.Value = "C";
            cboVatIncFlag.Value = "1";
            cboPrjType.Value = "I";
            DataSet itds = null;

            itds = uniBase.UDataAccess.CommonQueryRs(" MINOR_CD,MINOR_NM ", " B_MINOR ", "MAJOR_CD ='Y0004' AND MINOR_CD = '0'");
            txtState.Text = itds.Tables[0].Rows[0][1].ToString().Trim();

            txtProjectCode.Focus();
            return true;
        }

        #endregion

        #region ��� 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {



            return DBDelete();
        }
        #endregion

        #region ��� 4.2.3 OnFncCopy(old:FncCopy)
        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic  
            txtProjectCode.Text = "";
            txtProjectNm.Text = "";
            popProjectCode1.CodeValue = "";
            txtVer.Text = "0";
            txtState.Text = "";
            uniBase.UCommon.ChangeFieldLockAttribute(txtProjectCode, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(txtProjectNm, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(cboPrjType, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeF, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeT, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(dtDlvyDt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType1, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popPmResourceCd, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(popBpCd, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(popCurrency, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(popSalesGrp, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(popPayMeth, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(popPayType, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popVatType, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(cboVatIncFlag, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(cboRevenue, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(rdoGroupPrjFlg, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(txtDescription, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Normal);
            return true;
        }
        #endregion

        #region ��� 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ��� 4.2.5 OnFncPrev(old:FncPrev)
        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ��� 4.2.6 OnFncNext(old:FncNext)
        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ��� 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region �� 4.3 Grid Fnction group

        #region ��� 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            return true;
        }
        #endregion

        #region ��� 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            return true;
        }
        #endregion

        #region ��� 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            return true;
        }
        #endregion

        #region ��� 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            return true;
        }
        #endregion


        #endregion

        #region �� 4.4 Db function group

        #region ��� 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            try
            {

                DataSet iqtds = new DataSet();
                using (uniCommand unicmd1 = uniBase.UDatabase.GetStoredProcCommand("USP_PS_Y7204M1_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(unicmd1, "@PROJECT_CODE", SqlDbType.NVarChar, popProjectCode1.CodeValue.ToString());


                    DataSet dsData = uniBase.UDatabase.ExecuteDataSet(unicmd1);

                    if (dsData == null || dsData.Tables.Count == 0 || dsData.Tables[0].Rows.Count == 0)
                    {
                        uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                        return true;
                    }
                    //20171101 hsy 컬럼 max length 변경으로 인한 추가

                    cqtdsPManageProject.I1_PMS_PROJECT.Merge(dsData.Tables[0], false, MissingSchemaAction.Ignore);
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            if (txtPaystatcd.Text == "T" | txtPaystatcd.Text == "F")
            {
                uniBase.UCommon.DisableButton(btnApprovalpro, false);
                uniBase.UCommon.DisableButton(btnPrint, false);
                uniBase.UCommon.DisableButton(btnPriview, false);
            }
            else
            {
                uniBase.UCommon.DisableButton(btnApprovalpro, true);
                uniBase.UCommon.DisableButton(btnPrint, true);
                uniBase.UCommon.DisableButton(btnPriview, true);
            }
            


            OnPostFncQuery();

            popProjectCode1.CodeName = txtProjectNm.Text;

            return true;
        }

        protected override bool OnPostFncQuery()
        {
            base.OnPostFncQuery();

            uniBase.UCommon.ChangeFieldLockAttribute(txtProjectCode, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.SetToolBarAll(false);
            uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Query | enumDef.ToolBitCommon.Save, true);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Delete | enumDef.ToolBitSingle.New, true);

            if (cqtdsPManageProject.I1_PMS_PROJECT == null || cqtdsPManageProject.I1_PMS_PROJECT.Count == 0)
            {
                uniBase.UCommon.ChangeFieldLockAttribute(txtProjectCode, enumDef.FieldLockAttribute.Required);
                txtVer.Text = "0.0";

                return true;
            }

            if ((Convert.ToInt32(cqtdsPManageProject.I1_PMS_PROJECT.Rows[0]["state"].ToString()) == 0) || (Convert.ToInt32(cqtdsPManageProject.I1_PMS_PROJECT.Rows[0]["state"].ToString()) == 2))
            {
                if (txtVer.Text == "1.00")
                {
                    uniBase.UCommon.ChangeFieldLockAttribute(txtProjectNm, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(rdoGroupPrjFlg, enumDef.FieldLockAttribute.Normal);

                    if (rdoGroupPrjFlg.CheckedIndex != 1)
                    {
                        uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Normal);
                    }
                    else
                    {
                        uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Protected);
                    }

                    if (CommonVariable.gCurrency == popCurrency.CodeValue)
                    {
                        uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
                    }
                    else
                    {
                        uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Normal);
                    }
                }
                else
                {
                    uniBase.UCommon.SetToolBarAll(false);
                uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Query | enumDef.ToolBitCommon.Save, true);
                uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New, true);
                uniBase.UCommon.ChangeFieldLockAttribute(txtProjectCode, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtProjectNm, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtDlvyDt, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeF, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeT, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popPmResourceCd, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType1, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popBpCd, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popCurrency, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(numNetAmt, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popSalesGrp, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popPayMeth, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popPayType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popVatType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(numVatRate, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboVatIncFlag, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(rdoGroupPrjFlg, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtDescription, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboRevenue, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboPrjType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popSulgye, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popCsmng, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboBaljugb, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtBaljudt, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popReqman, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtCusmng, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtCusmngdept, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtCusmngnum, enumDef.FieldLockAttribute.Protected);
         
                }
            }
            else
            {
                uniBase.UCommon.SetToolBarAll(false);
                uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Query | enumDef.ToolBitCommon.Save, true);
                uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New, true);
                uniBase.UCommon.ChangeFieldLockAttribute(txtProjectCode, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtProjectNm, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtDlvyDt, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeF, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeT, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popPmResourceCd, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType1, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popBpCd, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popCurrency, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(numNetAmt, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popSalesGrp, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popPayMeth, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popPayType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popVatType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(numVatRate, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboVatIncFlag, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(rdoGroupPrjFlg, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtDescription, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboRevenue, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboPrjType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popSulgye, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popCsmng, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboBaljugb, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtBaljudt, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popReqman, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtCusmng, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtCusmngdept, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtCusmngnum, enumDef.FieldLockAttribute.Protected);
            }

            uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeF, enumDef.FieldLockAttribute.Protected);


            /* 이부분에서 결재상태의 따라 체크해야겠군 - 보류 왜냐하면 진행중이면 누르면 return 메시지로 막아주기때문에 굳이..
            if (txtPaystat.Value.ToString() == "승인")
            {
                btnApproval.Enabled = false;
             이게 맞음 uniBase.UCommon.DisableButton(btnApproval, true);
            }
            else
            {
                btnApproval.Enabled = true;
            }
             */
            if (txtPaystat.Value == null)
            {
                txtPaystat.Value = "미진행";
            }

            if (txtPaystatcd.Value.ToString() != "8" && txtPaystatcd.Value.ToString() != "F" && txtPaystatcd.Value.ToString() != "0" && txtPaystatcd.Value.ToString().Trim() != "")
            {
                uniBase.UCommon.SetToolBarAll(false);
                uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Query | enumDef.ToolBitCommon.Save, true);
                uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New, true);
                uniBase.UCommon.ChangeFieldLockAttribute(txtProjectCode, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtProjectNm, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtDlvyDt, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeF, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeT, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popPmResourceCd, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType1, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popBpCd, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popCurrency, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(numNetAmt, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popSalesGrp, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popPayMeth, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popPayType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popVatType, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(numVatRate, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboVatIncFlag, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(rdoGroupPrjFlg, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtDescription, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboRevenue, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.ChangeFieldLockAttribute(cboPrjType, enumDef.FieldLockAttribute.Protected);
                 uniBase.UCommon.ChangeFieldLockAttribute(popSulgye,enumDef.FieldLockAttribute.Protected);
                 uniBase.UCommon.ChangeFieldLockAttribute(popCsmng,enumDef.FieldLockAttribute.Protected);
                 uniBase.UCommon.ChangeFieldLockAttribute(cboBaljugb, enumDef.FieldLockAttribute.Protected);
                 uniBase.UCommon.ChangeFieldLockAttribute(dtBaljudt,enumDef.FieldLockAttribute.Protected);
                 uniBase.UCommon.ChangeFieldLockAttribute(popReqman,enumDef.FieldLockAttribute.Protected);
                 uniBase.UCommon.ChangeFieldLockAttribute(txtCusmng,enumDef.FieldLockAttribute.Protected);
                 uniBase.UCommon.ChangeFieldLockAttribute(txtCusmngdept,enumDef.FieldLockAttribute.Protected);
                 uniBase.UCommon.ChangeFieldLockAttribute(txtCusmngnum, enumDef.FieldLockAttribute.Protected);
                 uniBase.UCommon.DisableButton(btnApproval, false);
            }
          
            else
            {
              //  uniBase.UCommon.ChangeFieldLockAttribute(txtProjectCode, enumDef.FieldLockAttribute.Normal);
                //uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeF, enumDef.FieldLockAttribute.Required);
                //uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeT, enumDef.FieldLockAttribute.Required);
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
                uniBase.UCommon.DisableButton(btnApproval, true);
                //uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Delete, true);
                //uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, true);
            }

            return true;
        }
        #endregion

        #region ��� 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            strCommandSend = "DELETE";
            return DBSave1();

        }

        #endregion

        #region ��� 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            switch (this.viewDBSaveMode)
            {
                case enumDef.DBSaveMode.CreateMode:
                    strCommandSend = "CREATE";
                    break;
                case enumDef.DBSaveMode.UpdateMode:
                    strCommandSend = "UPDATE";
                    break;
            }
            return DBSave1();
        }

        private bool DBSave1()
        {
            string istrprojcode = String.Empty;

            wsPY7G204FL.DsPManageProject istdsPManageProject = new uniERP.App.UI.PS.Y7204M1_KO883.wsPY7G204FL.DsPManageProject();

            cqtdsPManageProject.AcceptChanges();
            istdsPManageProject.I1_PMS_PROJECT.Merge(cqtdsPManageProject.I1_PMS_PROJECT, false, MissingSchemaAction.Add);

            //wsPY7G204FL.PY7G204FL iwsPY7G204FL = (wsPY7G204FL.PY7G204FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPY7G204FL.PY7G204FL());


            wsY7204M1_KO883FL.Y7204M1_KO883FL wsSave = (wsY7204M1_KO883FL.Y7204M1_KO883FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsY7204M1_KO883FL.Y7204M1_KO883FL());


            try
            {

                DataSet pDataSet = new DataSet();
                pDataSet.Merge(istdsPManageProject);
                //istrprojcode = iwsPY7G204FL.cPMngProject_P_MANAGE_PROJECT(CommonVariable.gStrGlobalCollection, istdsPManageProject, strCommandSend);
//#if DEBUG
//                wsSave.Url = "http://localhost:3710/VD/Services/PS/Y7204M1_KO883FL.asmx";
//#endif
                istrprojcode = wsSave.PSManageChange_Updatechange(CommonVariable.gStrGlobalCollection, pDataSet, strCommandSend);
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;

                return false;
            }
            if (strCommandSend == "CREATE")
            {
                popProjectCode1.CodeValue = istrprojcode;
            }

            return true;
        }


        #endregion

        #endregion

        #endregion

        #region �� 5. Event method part

        #region �� 5.1 Single control event implementation group



        #endregion

        #region �� 5.2 Grid   control event implementation group


        #endregion

        #region �� 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region �� 6. Popup method part

        #region �� 6.1 Common popup implementation group

        #endregion

        #region �� 6.2 User-defined popup implementation group

        private void OpenNumberingType(string iWhere)
        {
            #region ������ 10.1.2.1 Popup Constructors

            #endregion

            #region ������ 10.1.2.2 Setting Returned Data



            #endregion


        }

        #endregion


        #endregion

        private void popProjectCode1_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popProjectCode1.CodeValue = iDataSet.Tables[0].Rows[0]["PROJECT_CODE"].ToString();
            popProjectCode1.CodeName = iDataSet.Tables[0].Rows[0]["PROJECT_NM"].ToString();
        }

        private void popProjectCode1_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Project PopUp";
            e.PopupPassData.ConditionCaption = "Project";

            e.PopupPassData.SQLFromStatements = "PMS_PROJECT(nolock)";
            e.PopupPassData.SQLWhereStatements = " ";
            e.PopupPassData.SQLWhereInputCodeValue = popProjectCode1.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;


            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "PROJECT_CODE";
            e.PopupPassData.GridCellCode[1] = "PROJECT_NM";

            e.PopupPassData.GridCellCaption[0] = "Project Code";
            e.PopupPassData.GridCellCaption[1] = "Project name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

        }

        private void popPmResourceCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPmResourceCd.CodeValue = iDataSet.Tables[0].Rows[0]["Emp_no"].ToString();
            popPmResourceCd.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();

        }

        private void popPmResourceCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popPmResourceCd.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }
            e.PopupPassData.PopupWinTitle = "Employee ID";
            e.PopupPassData.ConditionCaption = "Employee ID";

            e.PopupPassData.SQLFromStatements = "HAA010T(nolock)";
            e.PopupPassData.SQLWhereStatements = "  (RETIRE_DT IS NULL OR RETIRE_DT > '" + Convert.ToDateTime(dtDlvyDt.Value).ToShortDateString() + "')";
            e.PopupPassData.SQLWhereInputCodeValue = popPmResourceCd.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "Emp_no";
            e.PopupPassData.GridCellCode[1] = "NAME";
            e.PopupPassData.GridCellCode[2] = "dept_nm";

            e.PopupPassData.GridCellCaption[0] = "Employee ID.";
            e.PopupPassData.GridCellCaption[1] = "Name";
            e.PopupPassData.GridCellCaption[2] = "Department";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;

        }

        private void popBpCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popBpCd.CodeValue = iDataSet.Tables[0].Rows[0]["BP_CD"].ToString();
            popBpCd.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
            DBquery1();
        }

        private bool DBquery1()
        {
            strCommandSend = "Query";

            wsPB5CS41FL.DsBLookupBizPartner iqtdsBLookupBizPartner = null;
            string strBpCd = popBpCd.CodeValue;
            wsPB5CS41FL.PB5CS41FL iwsPB5CS41FL = (wsPB5CS41FL.PB5CS41FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPB5CS41FL.PB5CS41FL());

            try
            {
                iqtdsBLookupBizPartner = iwsPB5CS41FL.cLookupBizPartnerSvr_B_LOOKUP_BIZ_PARTNER(CommonVariable.gStrGlobalCollection, strBpCd, "Y");
                if (iqtdsBLookupBizPartner == null || iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows.Count == 0)
                {
                    return false; ;
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }

            popPayMeth.CodeValue = iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows[0]["pay_meth"].ToString();
            popPayMeth.CodeName = iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows[0]["pay_meth_nm"].ToString();
            popVatType.CodeValue = iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows[0]["vat_type"].ToString();
            popVatType.CodeName = iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows[0]["vat_type_nm"].ToString();
            numVatRate.Value = iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows[0]["vat_rate"].ToString();
            popCurrency.CodeValue = iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows[0]["currency"].ToString();
            popSalesGrp.CodeValue = iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows[0]["b_sales_grp_cd"].ToString();
            popSalesGrp.CodeName = iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows[0]["b_sales_grp_nm"].ToString();
            cboVatIncFlag.Value = iqtdsBLookupBizPartner.E1_B_BIZ_PARTNER.Rows[0]["vat_inc_flag"].ToString();

            if (CommonVariable.gCurrency == popCurrency.CodeValue)
            {
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
                numXchRate.Value = 1;
            }
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Required);
                numXchRate.Value = 0;
            }

            return true;
        }


        private void popBpCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popBpCd.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }

            e.PopupPassData.PopupWinTitle = "Customer";
            e.PopupPassData.ConditionCaption = "Customer";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER(nolock)";
            e.PopupPassData.SQLWhereStatements = "  BP_TYPE in ('C','CS') AND usage_flag = 'Y' ";
            e.PopupPassData.SQLWhereInputCodeValue = popBpCd.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "BP_CD";
            e.PopupPassData.GridCellCode[1] = "BP_NM";
            e.PopupPassData.GridCellCode[2] = "BP_RGST_NO";

            e.PopupPassData.GridCellCaption[0] = "Customer";
            e.PopupPassData.GridCellCaption[1] = "Customer Name";
            e.PopupPassData.GridCellCaption[2] = "Corp. Registration No.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }

        private void popSalesGrp_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popSalesGrp.CodeValue = iDataSet.Tables[0].Rows[0]["SALES_GRP"].ToString();
            popSalesGrp.CodeName = iDataSet.Tables[0].Rows[0]["SALES_GRP_NM"].ToString();
        }

        private void popSalesGrp_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popSalesGrp.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }

            e.PopupPassData.PopupWinTitle = "Sales Group";
            e.PopupPassData.ConditionCaption = "Sales Group";

            e.PopupPassData.SQLFromStatements = "B_SALES_GRP(nolock)";
            e.PopupPassData.SQLWhereStatements = " USAGE_FLAG = 'Y'";
            e.PopupPassData.SQLWhereInputCodeValue = popSalesGrp.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "SALES_GRP";
            e.PopupPassData.GridCellCode[1] = "SALES_GRP_NM";

            e.PopupPassData.GridCellCaption[0] = "Sales Group";
            e.PopupPassData.GridCellCaption[1] = "Sales Group Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popPayMeth_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPayMeth.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popPayMeth.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }

        private void popPayMeth_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popPayMeth.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }

            e.PopupPassData.PopupWinTitle = "Payment Code";
            e.PopupPassData.ConditionCaption = "Payment Code";

            e.PopupPassData.SQLFromStatements = "B_MINOR(nolock)";
            e.PopupPassData.SQLWhereStatements = " MAJOR_CD = 'B9004' ";
            e.PopupPassData.SQLWhereInputCodeValue = popPayMeth.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Payment Code";
            e.PopupPassData.GridCellCaption[1] = "Payment Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popGroupPrjCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popGroupPrjCd.CodeValue = iDataSet.Tables[0].Rows[0]["PROJECT_CODE"].ToString();
            popGroupPrjCd.CodeName = iDataSet.Tables[0].Rows[0]["PROJECT_NM"].ToString();
        }

        private void popGroupPrjCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popGroupPrjCd.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }

            e.PopupPassData.PopupWinTitle = "GROUP Project PopUp";
            e.PopupPassData.ConditionCaption = "GROUP Project";

            e.PopupPassData.SQLFromStatements = "PMS_PROJECT(nolock)";
            e.PopupPassData.SQLWhereStatements = " GROUP_PRJ_FLG = '1' ";
            e.PopupPassData.SQLWhereInputCodeValue = popGroupPrjCd.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "PROJECT_CODE";
            e.PopupPassData.GridCellCode[1] = "PROJECT_NM";

            e.PopupPassData.GridCellCaption[0] = "GROUP Project Code";
            e.PopupPassData.GridCellCaption[1] = "GROUP Project Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popCurrency_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popCurrency.CodeValue = iDataSet.Tables[0].Rows[0]["CURRENCY"].ToString();
        }

        private void popCurrency_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popCurrency.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }

            e.PopupPassData.PopupWinTitle = "Currency";
            e.PopupPassData.ConditionCaption = "Currency";

            e.PopupPassData.SQLFromStatements = "B_CURRENCY(nolock)";
            e.PopupPassData.SQLWhereStatements = "  ";
            e.PopupPassData.SQLWhereInputCodeValue = popCurrency.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "CURRENCY";
            e.PopupPassData.GridCellCode[1] = "CURRENCY_DESC";

            e.PopupPassData.GridCellCaption[0] = "Currency";
            e.PopupPassData.GridCellCaption[1] = "Cur. Desc.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popPayType_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPayType.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popPayType.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }

        private void popPayType_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popPayType.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }

            if (popPayMeth.CodeValue.Trim().ToString().Equals(""))
            {
                uniBase.UMessage.DisplayMessageBox("205152", MessageBoxButtons.OK, popPayMeth.uniALT);
                popPayMeth.Focus();
                e.Cancel = true;
                return;
            }

            e.PopupPassData.PopupWinTitle = "Receipt Type";
            e.PopupPassData.ConditionCaption = "Receipt Type";

            e.PopupPassData.SQLFromStatements = "B_MINOR(nolock),B_CONFIGURATION(nolock),(Select REFERENCE From B_CONFIGURATION(nolock) Where MAJOR_CD ='B9004'"
                + " And MINOR_CD = " + uniBase.UCommon.FilterVariable(popPayMeth.CodeValue.Trim().ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                + " And SEQ_NO >= 2) C";
            e.PopupPassData.SQLWhereStatements = " B_MINOR.MINOR_CD = C.REFERENCE And B_CONFIGURATION.MINOR_CD = B_MINOR.MINOR_CD And B_MINOR.MAJOR_CD = 'A1006' "
                + " AND B_CONFIGURATION.REFERENCE IN('RP','R')";
            e.PopupPassData.SQLWhereInputCodeValue = popPayType.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];
            e.PopupPassData.GridCellCodeAlias = new string[2];

            e.PopupPassData.GridCellCode[0] = "B_MINOR.MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "B_MINOR.MINOR_NM";

            e.PopupPassData.GridCellCodeAlias[0] = "MINOR_CD";
            e.PopupPassData.GridCellCodeAlias[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Receipt Type";
            e.PopupPassData.GridCellCaption[1] = "Receipt Type Description";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popVatType_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popVatType.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popVatType.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            numVatRate.Value = iDataSet.Tables[0].Rows[0]["REFERENCE"].ToString();

            if (Convert.ToDecimal(numVatRate.Value) != 0 && Convert.ToDecimal(numNetAmt.Value) != 0)
            {
                numVatAmt.Value = Convert.ToDecimal(numNetAmt.Value) * (Convert.ToDecimal(numVatRate.Value) / 100);
            }
            else
            {
                numVatAmt.Value = 0;
            }
        }

        private void popVatType_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popVatType.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }

            e.PopupPassData.PopupWinTitle = "VAT Type";
            e.PopupPassData.ConditionCaption = "VAT Type";

            e.PopupPassData.SQLFromStatements = " B_MINOR Minor(nolock),B_CONFIGURATION Config(nolock)";
            e.PopupPassData.SQLWhereStatements = " Minor.MAJOR_CD='B9001'  And Config.MAJOR_CD = Minor.MAJOR_CD "
            + "  And Config.MAJOR_CD = Minor.MAJOR_CD  And Config.MINOR_CD = Minor.MINOR_CD  And Config.SEQ_NO = 1";

            e.PopupPassData.SQLWhereInputCodeValue = popVatType.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];
            e.PopupPassData.GridCellCodeAlias = new string[3];

            e.PopupPassData.GridCellCode[0] = "Minor.MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "Minor.MINOR_NM";
            e.PopupPassData.GridCellCode[2] = "Config.REFERENCE";

            e.PopupPassData.GridCellCodeAlias[0] = "MINOR_CD";
            e.PopupPassData.GridCellCodeAlias[1] = "MINOR_NM";
            e.PopupPassData.GridCellCodeAlias[2] = "REFERENCE";

            e.PopupPassData.GridCellCaption[0] = "VAT Type";
            e.PopupPassData.GridCellCaption[1] = "VAT Type Description";
            e.PopupPassData.GridCellCaption[2] = "VAT Rate";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.ExchangeRate;
        }

        private void lblChange_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {

        }

        private void lblChange_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (txtProjectCode.Value == null)
            {
                uniBase.UMessage.DisplayMessageBox("900002", MessageBoxButtons.OK, "");
                e.Cancel = true;
                return;
            }
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.Y7204RA1";
            e.PopupPassData.PopupWinTitle = "HISTORY";

            DataSet iDataSet = new DataSet();
            DataTable iDataTable = new DataTable();
            iDataSet.Tables.Add(iDataTable);
            iDataTable.Rows.Add();
            iDataTable.Columns.Add("ProjectCode");
            iDataTable.Columns.Add("ProjectNm");
            iDataSet.Tables[0].Rows[0]["ProjectCode"] = txtProjectCode.Text.ToString();
            iDataSet.Tables[0].Rows[0]["ProjectNm"] = popProjectCode1.CodeName.Trim().ToString();
            e.PopupPassData.Data = iDataSet;
        }

        private void lblEstimateRef_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            string strSelect;
            string strFrom;
            string strWhere;
            string projectcd;
            string estimate;
            DataSet ds = new DataSet();
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            if (iDataSet.Tables[0].Rows[0][0].ToString() == string.Empty)
                return;

            projectcd = iDataSet.Tables[0].Rows[0]["project_code"].ToString();
            estimate = iDataSet.Tables[0].Rows[0]["estimate_degree"].ToString();
            strSelect = " PAY_METH , B.MINOR_NM , PAY_TYPE , C.MINOR_NM , a.vat_type , D.MINOR_NM , VAT_RATE ";
            strFrom = @"  PMS_ESTIMATE  A  inner join  B_MINOR B  on A.PAY_METH = B.MINOR_CD AND B.MAJOR_CD = 'B9004' 
                                           left join B_MINOR C on  A.PAY_TYPE = C.MINOR_CD and C.MAJOR_CD = 'A1006'
                                           inner join  B_MINOR D  on A.VAT_TYPE = D.MINOR_CD and D.MAJOR_CD = 'B9001' ";



            strWhere = "  PROJECT_CODE = '" + projectcd + "'" + " and estimate_degree = '" + estimate + "'";

            ds = uniBase.UDataAccess.CommonQueryRs(strSelect, strFrom, strWhere);

            popPayMeth.CodeValue = ds.Tables[0].Rows[0]["pay_meth"].ToString();
            popPayMeth.CodeName = ds.Tables[0].Rows[0]["minor_nm"].ToString();
            numVatRate.Value = ds.Tables[0].Rows[0]["vat_rate"].ToString();
            popVatType.CodeValue = ds.Tables[0].Rows[0]["vat_type"].ToString();
            popVatType.CodeName = ds.Tables[0].Rows[0]["minor_nm2"].ToString();
            popPayType.CodeValue = ds.Tables[0].Rows[0]["pay_type"].ToString();
            popPayType.CodeName = ds.Tables[0].Rows[0]["minor_nm1"].ToString();
            txtEstimateDegreeForm.Text = iDataSet.Tables[0].Rows[0]["estimate_degree"].ToString();
            txtEstimate.Text = iDataSet.Tables[0].Rows[0]["project_code"].ToString();
            popPmResourceCd.CodeValue = iDataSet.Tables[0].Rows[0]["pm_resource_cd"].ToString();
            popPmResourceCd.CodeName = iDataSet.Tables[0].Rows[0]["description"].ToString();
            dtDlvyDt.uniValue = Convert.ToDateTime(iDataSet.Tables[0].Rows[0]["dlvy_dt"]);
            dtPlanStartDt.uniFromValue = Convert.ToDateTime(iDataSet.Tables[0].Rows[0]["plan_start_dt"]);
            dtPlanStartDt.uniToValue = Convert.ToDateTime(iDataSet.Tables[0].Rows[0]["plan_end_dt"]);
            cboProjectType.Value = iDataSet.Tables[0].Rows[0]["project_type"];
            popBpCd.CodeValue = iDataSet.Tables[0].Rows[0]["bp_cd"].ToString();
            popBpCd.CodeName = iDataSet.Tables[0].Rows[0]["bp_nm"].ToString();
            popSalesGrp.CodeValue = iDataSet.Tables[0].Rows[0]["sales_grp"].ToString();
            popSalesGrp.CodeName = iDataSet.Tables[0].Rows[0]["sales_grp_nm"].ToString();
            popCurrency.CodeValue = iDataSet.Tables[0].Rows[0]["currency"].ToString();

            CurrencyOnChange();


        }

        private void lblEstimateRef_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (base.viewDBSaveMode == enumDef.DBSaveMode.UpdateMode)
            {
                uniBase.UMessage.DisplayMessageBox("YM0200", MessageBoxButtons.OK);
                e.Cancel = true;
                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.Y7204RA2";
            e.PopupPassData.PopupWinTitle = "Estimate Reference";
            e.PopupPassData.Data = null;
        }

        private void popCurrency_BeforePopupOpen_1(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Currency";
            e.PopupPassData.ConditionCaption = "Currency";

            e.PopupPassData.SQLFromStatements = "B_CURRENCY(nolock)";
            e.PopupPassData.SQLWhereStatements = " ";
            e.PopupPassData.SQLWhereInputCodeValue = popCurrency.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "CURRENCY";
            e.PopupPassData.GridCellCode[1] = "CURRENCY_DESC";

            e.PopupPassData.GridCellCaption[0] = "Currency";
            e.PopupPassData.GridCellCaption[1] = "Cur. Desc.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popCurrency_AfterPopupClosed_1(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popCurrency.CodeValue = iDataSet.Tables[0].Rows[0]["CURRENCY"].ToString();

            CurrencyOnChange();
        }

        private void popBpCd_OnExitEditCode(object sender, EventArgs e)
        {
            if (popBpCd.CodeValue.Trim() != "")
            {
                DBquery1();
            }
            else
            {
                return;
            }
        }

        private void StateCheck()
        {
            uniBase.UCommon.ChangeFieldLockAttribute(txtProjectCode, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(txtProjectNm, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(dtDlvyDt, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeF, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(dtPlanStartDt.uniDateTimeT, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popPmResourceCd, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(cboProjectType1, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popBpCd, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popCurrency, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(numNetAmt, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popSalesGrp, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popPayMeth, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popPayType, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popVatType, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(numVatRate, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(cboVatIncFlag, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(rdoGroupPrjFlg, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(txtDescription, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(cboRevenue, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(cboPrjType, enumDef.FieldLockAttribute.Protected);
        }

        private void numNetAmt_AfterExitEditMode(object sender, EventArgs e)
        {
            if (numNetAmt.Value == System.DBNull.Value)
            {
                numNetAmt.Value = uniBase.UNumber.FormatNumber(Convert.ToDecimal(0), this.viewTB19029.ggQty, 0);
            }

            if (numXchRate.Value == System.DBNull.Value)
            {
                numXchRate.Value = uniBase.UNumber.FormatNumber(Convert.ToDecimal(0), this.viewTB19029.ggQty, 0);
            }

            if (Convert.ToDecimal(numNetAmt.Value) != 0 && Convert.ToDecimal(numXchRate.Value) != 0)
            {
                txtNetAmtLoc.Value = Convert.ToDecimal(numNetAmt.Value) * Convert.ToDecimal(numXchRate.Value);
            }
            else
            {
                txtNetAmtLoc.Value = 0;
            }

            if (Convert.ToDecimal(numNetAmt.Value) != 0 && Convert.ToDecimal(numVatRate.Value) != 0)
            {
                numVatAmt.Value = Convert.ToDecimal(numNetAmt.Value) * (Convert.ToDecimal(numVatRate.Value) / 100); ;
            }
            else
            {
                numVatAmt.Value = 0;
            }
        }

        private void numXchRate_AfterExitEditMode(object sender, EventArgs e)
        {
            if (numXchRate.Value == System.DBNull.Value)
            {
                numXchRate.Value = uniBase.UNumber.FormatNumber(Convert.ToDecimal(0), this.viewTB19029.ggQty, 0);
            }

            if (numNetAmt.Value == System.DBNull.Value)
            {
                numNetAmt.Value = uniBase.UNumber.FormatNumber(Convert.ToDecimal(0), this.viewTB19029.ggQty, 0);
            }

            if (Convert.ToDecimal(numXchRate.Value) != 0 && Convert.ToDecimal(numNetAmt.Value) != 0)
            {
                txtNetAmtLoc.Value = Convert.ToDecimal(numNetAmt.Value) * (Convert.ToDecimal(numXchRate.Value));
                numVatAmt.Value = Convert.ToDecimal(numNetAmt.Value) * (Convert.ToDecimal(numVatRate.Value) / 100);
            }
            else
            {
                numVatAmt.Value = 0;
            }
        }

        private void popVatType_OnChange(object sender, EventArgs e)
        {
            if (numVatRate.Value == System.DBNull.Value)
            {
                numVatRate.Value = uniBase.UNumber.FormatNumber(Convert.ToDecimal(0), this.viewTB19029.ggQty, 0);
            }

            if (numNetAmt.Value == System.DBNull.Value)
            {
                numNetAmt.Value = uniBase.UNumber.FormatNumber(Convert.ToDecimal(0), this.viewTB19029.ggQty, 0);
            }

            if (Convert.ToDecimal(numVatRate.Value) != 0 && Convert.ToDecimal(numNetAmt.Value) != 0)
            {
                numVatAmt.Value = Convert.ToDecimal(numNetAmt.Value) * (Convert.ToDecimal(numVatRate.Value) / 100);
            }
            else
            {
                numVatAmt.Value = 0;
            }
        }

        private void CurrencyOnChange()
        {
            string[] strValue = new string[4];

            strValue[0] = popCurrency.CodeValue.ToUpper();
            strValue[1] = CommonVariable.gCurrency;
            strValue[2] = uniBase.UDate.DateTimeToString(dtPlanStartDt.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD);
            strValue[3] = uniBase.UDate.DateTimeToString(dtPlanStartDt.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYYMM);

            FormLookUpData(strValue);

            if (popCurrency.CodeValue.Trim().ToUpper() == CommonVariable.gCurrency.Trim().ToUpper())
            {
                numXchRate.Value = 1;
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Protected);
                numXchRate.FieldType = enumDef.FieldType.ReadOnly;
            }
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(numXchRate, enumDef.FieldLockAttribute.Required);
                numXchRate.FieldType = enumDef.FieldType.NotNull;
            }
        }

        private void FormLookUpData(string[] pvstrValue)
        {
            string istrSelect = string.Empty;
            string istrFrom = string.Empty;
            string istrWhere = string.Empty;


            DataSet idsFormLookUp = null;

            istrSelect = "Select dbo.ufn_GetXchgRateForProject(" + uniBase.UCommon.FilterVariable(pvstrValue[0], "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                "," + uniBase.UCommon.FilterVariable(pvstrValue[1], "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                "," + uniBase.UCommon.FilterVariable(pvstrValue[2], "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                "," + uniBase.UCommon.FilterVariable(pvstrValue[3], "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + ") as cur";

            idsFormLookUp = uniBase.UDataAccess.CommonQuerySQL(istrSelect);
            
            if (idsFormLookUp.Tables[0].Rows.Count == 0)
            {
                uniBase.UMessage.DisplayMessageBox("971012", MessageBoxButtons.OK, numXchRate.uniALT);

                numXchRate.uniValue = 0;

                return;
            }

                    numXchRate.Value = Convert.ToDecimal(idsFormLookUp.Tables[0].Rows[0][0].ToString());
                    txtNetAmtLoc.Value = Convert.ToDecimal(numXchRate.Value) * Convert.ToDecimal(numNetAmt.Value);
        }

        private void popCurrency_OnChange(object sender, EventArgs e)
        {
            CurrencyOnChange();
        }

        private void rdoGroupPrjFlg_ValueChanged(object sender, EventArgs e)
        {
            if (rdoGroupPrjFlg.CheckedIndex.ToString() == "0")
            {
                uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Normal);
            }
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(popGroupPrjCd, enumDef.FieldLockAttribute.Protected);
                popGroupPrjCd.CodeValue = "";
                popGroupPrjCd.CodeName = "";
            }

        }



 


        private void popSulgye_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popPmResourceCd.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }
            e.PopupPassData.PopupWinTitle = "설계담당";
            e.PopupPassData.ConditionCaption = "설계담당";

            e.PopupPassData.SQLFromStatements = "HAA010T(nolock)";
            e.PopupPassData.SQLWhereStatements = "  (RETIRE_DT IS NULL OR RETIRE_DT > '" + Convert.ToDateTime(dtDlvyDt.Value).ToShortDateString() + "')";
            e.PopupPassData.SQLWhereInputCodeValue = popSulgye.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "Emp_no";
            e.PopupPassData.GridCellCode[1] = "NAME";
            e.PopupPassData.GridCellCode[2] = "dept_nm";

            e.PopupPassData.GridCellCaption[0] = "사번";
            e.PopupPassData.GridCellCaption[1] = "이름";
            e.PopupPassData.GridCellCaption[2] = "부서";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }

        private void popSulgye_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popSulgye.CodeValue = iDataSet.Tables[0].Rows[0]["Emp_no"].ToString();
            popSulgye.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();
        }

        private void popReqman_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popReqman.CodeValue = iDataSet.Tables[0].Rows[0]["Emp_no"].ToString();
            popReqman.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();
        }

        private void popReqman_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popPmResourceCd.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }
            e.PopupPassData.PopupWinTitle = "전자결재 요청자";
            e.PopupPassData.ConditionCaption = "전자결재 요청자";

            e.PopupPassData.SQLFromStatements = "HAA010T(nolock)";
            e.PopupPassData.SQLWhereStatements = "  (RETIRE_DT IS NULL OR RETIRE_DT > '" + Convert.ToDateTime(dtDlvyDt.Value).ToShortDateString() + "')";
            e.PopupPassData.SQLWhereInputCodeValue = popReqman.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "Emp_no";
            e.PopupPassData.GridCellCode[1] = "NAME";
            e.PopupPassData.GridCellCode[2] = "dept_nm";

            e.PopupPassData.GridCellCaption[0] = "사번";
            e.PopupPassData.GridCellCaption[1] = "이름";
            e.PopupPassData.GridCellCaption[2] = "부서";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }

        private void popCsmng_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popCsmng.CodeValue = iDataSet.Tables[0].Rows[0]["Emp_no"].ToString();
            popCsmng.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();
        }

        private void popCsmng_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popPmResourceCd.FieldType.Equals(ReadOnlyAttribute.Yes))
            {
                e.Cancel = true;
                return;
            }
            e.PopupPassData.PopupWinTitle = "CS담당";
            e.PopupPassData.ConditionCaption = "CS담당";

            e.PopupPassData.SQLFromStatements = "HAA010T(nolock)";
            e.PopupPassData.SQLWhereStatements = "  (RETIRE_DT IS NULL OR RETIRE_DT > '" + Convert.ToDateTime(dtDlvyDt.Value).ToShortDateString() + "')";
            e.PopupPassData.SQLWhereInputCodeValue = popCsmng.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "Emp_no";
            e.PopupPassData.GridCellCode[1] = "NAME";
            e.PopupPassData.GridCellCode[2] = "dept_nm";

            e.PopupPassData.GridCellCaption[0] = "사번";
            e.PopupPassData.GridCellCaption[1] = "이름";
            e.PopupPassData.GridCellCaption[2] = "부서";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }

        private void btnPriview_Click(object sender, EventArgs e)
        {
            PrintEasyBaseDocument(enumDef.EasyBaseActionType.View);   //TO-DO : code business oriented logic
        }


        #region �� 7. User-defined method part

        #region �� 7.1 User-defined function group
        private void btnApprovalpro_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (this.viewDBSaveMode == enumDef.DBSaveMode.CreateMode)
            {
                // 조회를 먼저 하십시오.
                uniBase.UMessage.DisplayMessageBox("900002", MessageBoxButtons.OK);
                e.Cancel = true;

                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.Y7204P1_KO883";
            e.PopupPassData.PopupWinTitle = "Project 진행 요청서";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 600;


            string[] appParam = new String[5];
            appParam[0] = cboProjectType1.Text.ToString().Trim();
            appParam[1] = popProjectCode1.CodeValue.ToString().Trim();
            appParam[2] = txtProjectNm.Text.ToString().Trim();
            appParam[3] = cboProjectType.Text.ToString().Trim();
            appParam[4] = popProjectCode1.CodeValue.ToString().Trim();
            e.PopupPassData.Data = appParam;
        }



        #region ■ 8.1 common function group
        private void PrintEasyBaseDocument(enumDef.EasyBaseActionType pEasyBaseActionType)
        {
            StringBuilder isbURL = new StringBuilder();
            string istrEasyBaseID;


            if (!uniBase.UCommon.CheckRequiredFields(enumDef.PanelType.Condition))                      //TO-DO : check fields
                return;

            //TO-DO : Batch , SP or DLL Call
            this.Presenter.ProgressBarController.DisplayProgressBar();
            try
            {
                if (!SetPrintConditionValue(isbURL, out istrEasyBaseID))                                    //TO-DO : set EasyBase file name and parameters
                    return;

                switch (pEasyBaseActionType)                                                                  //TO-DO : EasyBase Start
                {
                    case enumDef.EasyBaseActionType.View:
                        uniBase.UEasyBase.PreviewEBRDocument(istrEasyBaseID, isbURL.ToString());
                        break;
                    case enumDef.EasyBaseActionType.Print:
                        uniBase.UEasyBase.PrintEBRDocument(istrEasyBaseID, isbURL.ToString());
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                this.Presenter.ProgressBarController.HideProgressBar();
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
            this.Presenter.ProgressBarController.HideProgressBar();
        }
        #endregion

        #region SetPrintConditionValue
        private bool SetPrintConditionValue(StringBuilder psbURL, out string pstrEasyBaseID)
        {
            string cstrEasyBaseID = "";
            string state=""; 
            cstrEasyBaseID = "y7201q1_ko883";
            pstrEasyBaseID = uniBase.UEasyBase.AskEBDocumentName(cstrEasyBaseID, enumDef.EasyBaseDocType.EBR.ToString());

            if (dtPlanStartDt.uniDateTimeF.Value == null)      //dt값이 null일경우 전체검색 되도록
            {
                dtPlanStartDt.uniDateTimeF.Value = CommonVariable.gMinimumDate;
            }
            if (dtPlanStartDt.uniDateTimeT.Value == null)
            {
                dtPlanStartDt.uniDateTimeT.Value = CommonVariable.gMaximumDate;
            }
            if (txtState.Value.ToString()== "미확정")
            {
                state = "0";
            }
            else if (txtState.Value.ToString() == "진행중")
            {
                state = "1";
            }
            else if (txtState.Value.ToString() == "일시중지")
            {
                state = "2";
            }
            else if (txtState.Value.ToString() == "취소")
            {
                state = "3";
            }

            else 
            {
                state = "4";
            }

            psbURL.Append("BP_CD|").Append(popBpCd.CodeValue.Trim());
            psbURL.Append("|SALES_GRP|").Append(popSalesGrp.CodeValue.Trim());
            psbURL.Append("|PROJECT_CD|").Append(popProjectCode1.CodeValue.Trim());
            psbURL.Append("|STATE|").Append(state.ToString());
            psbURL.Append("|PLAN_START_DT|").Append(dtPlanStartDt.uniDateTimeF.uniValue.ToString(CommonVariable.CDT_YYYY_MM_DD));
            psbURL.Append("|EXT2_CD|").Append(popCsmng.CodeValue.Trim());
            psbURL.Append("|EXT1_CD|").Append(popSulgye.CodeValue.Trim());
            psbURL.Append("|EXT3_CD|").Append(cboBaljugb.Value.ToString());
            psbURL.Append("|EXT5_CD|").Append(txtCusmng.Text.ToString());
            psbURL.Append("|APPRV_STATE|").Append(txtPaystatcd.Value.ToString());
      
            return true;
        }

        #endregion

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintEasyBaseDocument(enumDef.EasyBaseActionType.Print);   //TO-DO : code business oriented logic
        }
        
        #endregion

        private void btnApproval_Click(object sender, EventArgs e)
        {
            if (this.viewDBSaveMode == enumDef.DBSaveMode.CreateMode)
            {
                // 조회를 먼저 하십시오.
                
                return;
            }
            if (txtPaystatcd.Text == "0")
            {

                StringBuilder strSQL2 = new StringBuilder();

                strSQL2.AppendFormat(@"
DELETE ERP_IF_APPROVAL
WHERE
DOC_NO={0} 
"
                       , uniBase.UCommon.FilterVariable(popProjectCode1.CodeValue.ToString(), "''''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                       );
                uniCommand uniCmd2 = uniBase.UDatabase.GetSqlStringCommand(strSQL2.ToString());
                uniBase.UDatabase.ExecuteNonQuery(uniCmd2, false);
                
            }


            if (uniBase.UMessage.DisplayMessageBox("900018", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                return;
            }
            uniBase.UProcess.DisplayProgressBar();
     
            try
            {
                DataTable isdt1 = new DataTable();
                isdt1.Merge(cqtdsPManageProject.I1_PMS_PROJECT, false, MissingSchemaAction.Add);
                uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_IF_APPROVAL_KO883");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@doc_no", SqlDbType.NVarChar, popProjectCode1.CodeValue.ToString().Trim());
                uniBase.UDatabase.AddInParameter(iuniCommand, "@system_code", SqlDbType.NVarChar, "PS");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@ap_form", SqlDbType.NVarChar, "Y7204M1_KO883");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@ref_no", SqlDbType.NVarChar, popProjectCode1.CodeValue.ToString().Trim()); 
                uniBase.UDatabase.AddInParameter(iuniCommand, "@doc_user_id", SqlDbType.NVarChar, popReqman.CodeValue.ToString().Trim());    
                uniBase.UDatabase.AddInParameter(iuniCommand, "@user_id", SqlDbType.NVarChar, popReqman.CodeValue.ToString().Trim());         
                uniBase.UDatabase.AddInParameter(iuniCommand, "@key_val1", SqlDbType.NVarChar, "");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@key_val2", SqlDbType.NVarChar, "");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@key_val3", SqlDbType.NVarChar, "");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@key_val4", SqlDbType.NVarChar, "");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@key_val5", SqlDbType.NVarChar, "");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@key_val6", SqlDbType.NVarChar, "");
                uniBase.UDatabase.AddOutParameter(iuniCommand, "@msg_cd", SqlDbType.NVarChar, 8);
                uniBase.UDatabase.AddOutParameter(iuniCommand, "@msg_text", SqlDbType.NVarChar, 200);
                uniBase.UDatabase.AddReturnParameter(iuniCommand, "RETURN_VALUE", SqlDbType.Int, 4);
                uniBase.UDatabase.ExecuteNonQuery(iuniCommand);
                int iretVal = (int)uniBase.UDatabase.GetParameterValue(iuniCommand, "RETURN_VALUE");
                if (iretVal != 1)
                {
                    string istrMsgCd = uniBase.UDatabase.GetParameterValue(iuniCommand, "@msg_cd").ToString();
                    string istrMsgText = uniBase.UDatabase.GetParameterValue(iuniCommand, "@msg_text").ToString();
                    uniBase.UMessage.DisplayMessageBox(istrMsgCd, MessageBoxButtons.OK, istrMsgText);
                    this.Presenter.ProgressBarController.HideProgressBar();
                    return;
                }

                // --결재창 OPEN
                uniERP.AppFramework.UI.Controls.Popup.PopupRunningInfo popupRunninginfo = new uniERP.AppFramework.UI.Controls.Popup.PopupRunningInfo();
                string callPopupID = "uniERP.App.UI.Popup.SMES";
                popupRunninginfo.ParentData.CalledPopupID = callPopupID;
                popupRunninginfo.ParentData.PopupWinTitle = "전자결재";
                popupRunninginfo.ParentData.Data = popProjectCode1.CodeValue.ToString().Trim();  
                popupRunninginfo.ParentView = this;
                popupRunninginfo.ReturnPopup = (uniERP.AppFramework.UI.Controls.uniControls.IOpenPopup)this.btnApproval;
                popupRunninginfo.ParentColumnID = "";
                popupRunninginfo.ParentData.PopupWinWidth = 1500;
                popupRunninginfo.ParentData.PopupWinHeight = 1500;
                ControlManager.PopupLoad(callPopupID, popupRunninginfo, this.Presenter.WorkItem);
                //
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                this.Presenter.ProgressBarController.HideProgressBar();
                return;
            }
            this.Presenter.ProgressBarController.HideProgressBar();

            StringBuilder strSQL = new StringBuilder();

            strSQL.AppendFormat(@"
UPDATE ERP_IF_APPROVAL
   SET APPROVAL_RTN = 'T'

WHERE
DOC_NO={0} AND 
AP_ITEM='P1' AND 
MNU_ID='Y7204M1_KO883'"
                   , uniBase.UCommon.FilterVariable(popProjectCode1.CodeValue.ToString(), "''''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                   );
            uniCommand uniCmd = uniBase.UDatabase.GetSqlStringCommand(strSQL.ToString());
            uniBase.UDatabase.ExecuteNonQuery(uniCmd, false);

            cqtdsPManageProject.Clear();

            DBQuery();
        }







    }
}
        #endregion