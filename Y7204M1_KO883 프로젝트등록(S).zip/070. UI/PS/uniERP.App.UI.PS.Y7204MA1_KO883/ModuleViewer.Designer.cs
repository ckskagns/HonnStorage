﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.PS.Y7204MA1_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem2 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance37 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance38 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance39 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance40 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance41 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance42 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance43 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance44 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance45 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance62 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance63 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance64 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblCode = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDegree = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDeliveryDate = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblManager = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblName = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblGroup = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPayMethod = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblRate = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblVatRate = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblComparison = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblFlag = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProjectCode = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.tbl1 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.txtProjectCode = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.txtVer = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.cboPrjType = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.dtDlvyDt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.popPmResourceCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popBpCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popSalesGrp = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popPayMeth = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.txtEstimateDegreeForm = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.cboRevenue = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.rdoGroupPrjFlg = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.popGroupPrjCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblProjectName = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblEstimateNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProjectPeriod = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProjectType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProjectType1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCurrency = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtProjectNm = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.txtEstimate = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.dtPlanStartDt = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.cboProjectType = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.cboProjectType1 = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.numXchRate = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.numVatRate = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.tbl2 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.popCurrency = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.numNetAmt = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.txtRemark = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblRemark = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblSulgye = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblBaljugb = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblReqman = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCusmng = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCusmngnum = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCsmng = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblBaljudt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPaystat = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCusmngdept = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtCusmng = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.txtCusmngnum = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.txtCusmngdept = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.cboBaljugb = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.dtBaljudt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.popSulgye = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popReqman = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTextBox_Name = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTextBox_Code = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.popCsmng = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTableLayoutPanel1 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.txtPaystat = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.txtPaystatcd = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblLocal = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblReceipt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblVat = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtNetAmtLoc = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.popPayType = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popVatType = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblInclusion = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblVatAmt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblState = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblOutline = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.cboVatIncFlag = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.numVatAmt = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.txtState = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.txtDescription = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblSubGoods = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCostCom = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCostToT = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtCostCom = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.txtCostToT = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.txtSubGoods = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.uniCheckBox1 = new uniERP.AppFramework.UI.Controls.uniCheckBox(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblProject = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popProjectCode1 = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblEstimateRef = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblChange = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnApprovalpro = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.lblRegstration = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.btnApproval = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnPrint = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.lblCompose = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.btnPriview = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnCancel = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.uniTableLayoutPanel2 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniButton2 = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.uniButton3 = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            this.tbl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPrjType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDlvyDt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimateDegreeForm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRevenue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoGroupPrjFlg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboProjectType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboProjectType1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXchRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVatRate)).BeginInit();
            this.tbl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNetAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCusmng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCusmngnum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCusmngdept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboBaljugb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtBaljudt)).BeginInit();
            this.popReqman.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).BeginInit();
            this.popCsmng.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_c2f684bf_1215_43eb_bceb_14274d5879ed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68)).BeginInit();
            this.uniTableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaystat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaystatcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNetAmtLoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboVatIncFlag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVatAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDescription)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCostCom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCostToT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubGoods)).BeginInit();
            this.uniTBL_MainCondition.SuspendLayout();
            this.uniTBL_MainReference.SuspendLayout();
            this.uniTBL_MainBatch.SuspendLayout();
            this.uniTableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.AutoScroll = true;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.DataRowCount = 19;
            this.uniTBL_OuterMost.DefaultRowSize = 25;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 12);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(978, 736);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.AutoScroll = true;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 4;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainData.Controls.Add(this.lblCode, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.lblDegree, 0, 1);
            this.uniTBL_MainData.Controls.Add(this.lblType, 0, 2);
            this.uniTBL_MainData.Controls.Add(this.lblDeliveryDate, 0, 3);
            this.uniTBL_MainData.Controls.Add(this.lblManager, 0, 4);
            this.uniTBL_MainData.Controls.Add(this.lblName, 0, 5);
            this.uniTBL_MainData.Controls.Add(this.lblGroup, 0, 6);
            this.uniTBL_MainData.Controls.Add(this.lblPayMethod, 0, 7);
            this.uniTBL_MainData.Controls.Add(this.lblRate, 0, 8);
            this.uniTBL_MainData.Controls.Add(this.lblVatRate, 0, 9);
            this.uniTBL_MainData.Controls.Add(this.lblComparison, 0, 10);
            this.uniTBL_MainData.Controls.Add(this.lblFlag, 0, 11);
            this.uniTBL_MainData.Controls.Add(this.lblProjectCode, 0, 12);
            this.uniTBL_MainData.Controls.Add(this.tbl1, 1, 0);
            this.uniTBL_MainData.Controls.Add(this.cboPrjType, 1, 2);
            this.uniTBL_MainData.Controls.Add(this.dtDlvyDt, 1, 3);
            this.uniTBL_MainData.Controls.Add(this.popPmResourceCd, 1, 4);
            this.uniTBL_MainData.Controls.Add(this.popBpCd, 1, 5);
            this.uniTBL_MainData.Controls.Add(this.popSalesGrp, 1, 6);
            this.uniTBL_MainData.Controls.Add(this.popPayMeth, 1, 7);
            this.uniTBL_MainData.Controls.Add(this.txtEstimateDegreeForm, 1, 1);
            this.uniTBL_MainData.Controls.Add(this.cboRevenue, 1, 10);
            this.uniTBL_MainData.Controls.Add(this.rdoGroupPrjFlg, 1, 11);
            this.uniTBL_MainData.Controls.Add(this.popGroupPrjCd, 1, 12);
            this.uniTBL_MainData.Controls.Add(this.lblProjectName, 2, 0);
            this.uniTBL_MainData.Controls.Add(this.lblEstimateNo, 2, 1);
            this.uniTBL_MainData.Controls.Add(this.lblProjectPeriod, 2, 2);
            this.uniTBL_MainData.Controls.Add(this.lblProjectType, 2, 3);
            this.uniTBL_MainData.Controls.Add(this.lblProjectType1, 2, 4);
            this.uniTBL_MainData.Controls.Add(this.lblCurrency, 2, 5);
            this.uniTBL_MainData.Controls.Add(this.txtProjectNm, 3, 0);
            this.uniTBL_MainData.Controls.Add(this.txtEstimate, 3, 1);
            this.uniTBL_MainData.Controls.Add(this.dtPlanStartDt, 3, 2);
            this.uniTBL_MainData.Controls.Add(this.cboProjectType, 3, 3);
            this.uniTBL_MainData.Controls.Add(this.cboProjectType1, 3, 4);
            this.uniTBL_MainData.Controls.Add(this.numXchRate, 1, 8);
            this.uniTBL_MainData.Controls.Add(this.numVatRate, 1, 9);
            this.uniTBL_MainData.Controls.Add(this.tbl2, 3, 5);
            this.uniTBL_MainData.Controls.Add(this.txtRemark, 1, 13);
            this.uniTBL_MainData.Controls.Add(this.lblRemark, 0, 15);
            this.uniTBL_MainData.Controls.Add(this.lblSulgye, 0, 16);
            this.uniTBL_MainData.Controls.Add(this.lblBaljugb, 0, 17);
            this.uniTBL_MainData.Controls.Add(this.lblReqman, 0, 18);
            this.uniTBL_MainData.Controls.Add(this.lblCusmng, 0, 19);
            this.uniTBL_MainData.Controls.Add(this.lblCusmngnum, 0, 20);
            this.uniTBL_MainData.Controls.Add(this.lblCsmng, 2, 16);
            this.uniTBL_MainData.Controls.Add(this.lblBaljudt, 2, 17);
            this.uniTBL_MainData.Controls.Add(this.lblPaystat, 2, 18);
            this.uniTBL_MainData.Controls.Add(this.lblCusmngdept, 2, 19);
            this.uniTBL_MainData.Controls.Add(this.txtCusmng, 1, 19);
            this.uniTBL_MainData.Controls.Add(this.txtCusmngnum, 1, 20);
            this.uniTBL_MainData.Controls.Add(this.txtCusmngdept, 3, 19);
            this.uniTBL_MainData.Controls.Add(this.cboBaljugb, 1, 17);
            this.uniTBL_MainData.Controls.Add(this.dtBaljudt, 3, 17);
            this.uniTBL_MainData.Controls.Add(this.popSulgye, 1, 16);
            this.uniTBL_MainData.Controls.Add(this.popReqman, 1, 18);
            this.uniTBL_MainData.Controls.Add(this.popCsmng, 3, 16);
            this.uniTBL_MainData.Controls.Add(this.uniTableLayoutPanel1, 3, 18);
            this.uniTBL_MainData.Controls.Add(this.lblLocal, 2, 6);
            this.uniTBL_MainData.Controls.Add(this.lblReceipt, 2, 7);
            this.uniTBL_MainData.Controls.Add(this.lblVat, 2, 8);
            this.uniTBL_MainData.Controls.Add(this.txtNetAmtLoc, 3, 6);
            this.uniTBL_MainData.Controls.Add(this.popPayType, 3, 7);
            this.uniTBL_MainData.Controls.Add(this.popVatType, 3, 8);
            this.uniTBL_MainData.Controls.Add(this.lblInclusion, 2, 9);
            this.uniTBL_MainData.Controls.Add(this.lblVatAmt, 2, 10);
            this.uniTBL_MainData.Controls.Add(this.lblState, 2, 11);
            this.uniTBL_MainData.Controls.Add(this.lblOutline, 2, 12);
            this.uniTBL_MainData.Controls.Add(this.cboVatIncFlag, 3, 9);
            this.uniTBL_MainData.Controls.Add(this.numVatAmt, 3, 10);
            this.uniTBL_MainData.Controls.Add(this.txtState, 3, 11);
            this.uniTBL_MainData.Controls.Add(this.txtDescription, 3, 12);
            this.uniTBL_MainData.Controls.Add(this.lblSubGoods, 2, 20);
            this.uniTBL_MainData.Controls.Add(this.lblCostCom, 2, 21);
            this.uniTBL_MainData.Controls.Add(this.lblCostToT, 2, 22);
            this.uniTBL_MainData.Controls.Add(this.txtCostCom, 3, 21);
            this.uniTBL_MainData.Controls.Add(this.txtCostToT, 3, 22);
            this.uniTBL_MainData.Controls.Add(this.txtSubGoods, 3, 20);
            this.uniTBL_MainData.Controls.Add(this.uniCheckBox1, 3, 23);
            this.uniTBL_MainData.DataRowCount = 18;
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 28F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 74);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 25;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(978, 630);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 1;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblCode
            // 
            appearance1.TextHAlignAsString = "Left";
            appearance1.TextVAlignAsString = "Middle";
            this.lblCode.Appearance = appearance1;
            this.lblCode.AutoPopupID = null;
            this.lblCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCode.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCode.Location = new System.Drawing.Point(15, 6);
            this.lblCode.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(121, 22);
            this.lblCode.StyleSetName = "Default";
            this.lblCode.TabIndex = 0;
            this.lblCode.Text = "Project Code/Ver";
            this.lblCode.UseMnemonic = false;
            // 
            // lblDegree
            // 
            appearance2.TextHAlignAsString = "Left";
            appearance2.TextVAlignAsString = "Middle";
            this.lblDegree.Appearance = appearance2;
            this.lblDegree.AutoPopupID = null;
            this.lblDegree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDegree.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDegree.Location = new System.Drawing.Point(15, 29);
            this.lblDegree.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDegree.Name = "lblDegree";
            this.lblDegree.Size = new System.Drawing.Size(121, 22);
            this.lblDegree.StyleSetName = "Default";
            this.lblDegree.TabIndex = 1;
            this.lblDegree.Text = "Applied Estimate Degree";
            this.lblDegree.UseMnemonic = false;
            // 
            // lblType
            // 
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.lblType.Appearance = appearance3;
            this.lblType.AutoPopupID = null;
            this.lblType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblType.Location = new System.Drawing.Point(15, 52);
            this.lblType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(121, 22);
            this.lblType.StyleSetName = "Default";
            this.lblType.TabIndex = 2;
            this.lblType.Text = "Project Type";
            this.lblType.UseMnemonic = false;
            // 
            // lblDeliveryDate
            // 
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.lblDeliveryDate.Appearance = appearance4;
            this.lblDeliveryDate.AutoPopupID = null;
            this.lblDeliveryDate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDeliveryDate.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDeliveryDate.Location = new System.Drawing.Point(15, 75);
            this.lblDeliveryDate.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDeliveryDate.Name = "lblDeliveryDate";
            this.lblDeliveryDate.Size = new System.Drawing.Size(121, 22);
            this.lblDeliveryDate.StyleSetName = "Default";
            this.lblDeliveryDate.TabIndex = 3;
            this.lblDeliveryDate.Text = "Delivery Date";
            this.lblDeliveryDate.UseMnemonic = false;
            // 
            // lblManager
            // 
            appearance5.TextHAlignAsString = "Left";
            appearance5.TextVAlignAsString = "Middle";
            this.lblManager.Appearance = appearance5;
            this.lblManager.AutoPopupID = null;
            this.lblManager.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblManager.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblManager.Location = new System.Drawing.Point(15, 98);
            this.lblManager.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblManager.Name = "lblManager";
            this.lblManager.Size = new System.Drawing.Size(121, 22);
            this.lblManager.StyleSetName = "Default";
            this.lblManager.TabIndex = 4;
            this.lblManager.Text = "Manager";
            this.lblManager.UseMnemonic = false;
            // 
            // lblName
            // 
            appearance6.TextHAlignAsString = "Left";
            appearance6.TextVAlignAsString = "Middle";
            this.lblName.Appearance = appearance6;
            this.lblName.AutoPopupID = null;
            this.lblName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblName.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblName.Location = new System.Drawing.Point(15, 121);
            this.lblName.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(121, 22);
            this.lblName.StyleSetName = "Default";
            this.lblName.TabIndex = 5;
            this.lblName.Text = "Customer Name";
            this.lblName.UseMnemonic = false;
            // 
            // lblGroup
            // 
            appearance7.TextHAlignAsString = "Left";
            appearance7.TextVAlignAsString = "Middle";
            this.lblGroup.Appearance = appearance7;
            this.lblGroup.AutoPopupID = null;
            this.lblGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGroup.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblGroup.Location = new System.Drawing.Point(15, 144);
            this.lblGroup.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblGroup.Name = "lblGroup";
            this.lblGroup.Size = new System.Drawing.Size(121, 22);
            this.lblGroup.StyleSetName = "Default";
            this.lblGroup.TabIndex = 6;
            this.lblGroup.Text = "Sales Group";
            this.lblGroup.UseMnemonic = false;
            // 
            // lblPayMethod
            // 
            appearance8.TextHAlignAsString = "Left";
            appearance8.TextVAlignAsString = "Middle";
            this.lblPayMethod.Appearance = appearance8;
            this.lblPayMethod.AutoPopupID = null;
            this.lblPayMethod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPayMethod.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPayMethod.Location = new System.Drawing.Point(15, 167);
            this.lblPayMethod.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPayMethod.Name = "lblPayMethod";
            this.lblPayMethod.Size = new System.Drawing.Size(121, 22);
            this.lblPayMethod.StyleSetName = "Default";
            this.lblPayMethod.TabIndex = 7;
            this.lblPayMethod.Text = "Pay Method";
            this.lblPayMethod.UseMnemonic = false;
            // 
            // lblRate
            // 
            appearance9.TextHAlignAsString = "Left";
            appearance9.TextVAlignAsString = "Middle";
            this.lblRate.Appearance = appearance9;
            this.lblRate.AutoPopupID = null;
            this.lblRate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRate.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRate.Location = new System.Drawing.Point(15, 190);
            this.lblRate.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRate.Name = "lblRate";
            this.lblRate.Size = new System.Drawing.Size(121, 22);
            this.lblRate.StyleSetName = "Default";
            this.lblRate.TabIndex = 8;
            this.lblRate.Text = "Exchange Rate";
            this.lblRate.UseMnemonic = false;
            // 
            // lblVatRate
            // 
            appearance10.TextHAlignAsString = "Left";
            appearance10.TextVAlignAsString = "Middle";
            this.lblVatRate.Appearance = appearance10;
            this.lblVatRate.AutoPopupID = null;
            this.lblVatRate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVatRate.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblVatRate.Location = new System.Drawing.Point(15, 213);
            this.lblVatRate.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblVatRate.Name = "lblVatRate";
            this.lblVatRate.Size = new System.Drawing.Size(121, 22);
            this.lblVatRate.StyleSetName = "Default";
            this.lblVatRate.TabIndex = 9;
            this.lblVatRate.Text = "VAT Rate";
            this.lblVatRate.UseMnemonic = false;
            // 
            // lblComparison
            // 
            appearance11.TextHAlignAsString = "Left";
            appearance11.TextVAlignAsString = "Middle";
            this.lblComparison.Appearance = appearance11;
            this.lblComparison.AutoPopupID = null;
            this.lblComparison.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblComparison.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblComparison.Location = new System.Drawing.Point(15, 236);
            this.lblComparison.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblComparison.Name = "lblComparison";
            this.lblComparison.Size = new System.Drawing.Size(121, 22);
            this.lblComparison.StyleSetName = "Default";
            this.lblComparison.TabIndex = 10;
            this.lblComparison.Text = "Sale recognition compasrison";
            this.lblComparison.UseMnemonic = false;
            // 
            // lblFlag
            // 
            appearance12.TextHAlignAsString = "Left";
            appearance12.TextVAlignAsString = "Middle";
            this.lblFlag.Appearance = appearance12;
            this.lblFlag.AutoPopupID = null;
            this.lblFlag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFlag.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblFlag.Location = new System.Drawing.Point(15, 259);
            this.lblFlag.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblFlag.Name = "lblFlag";
            this.lblFlag.Size = new System.Drawing.Size(121, 22);
            this.lblFlag.StyleSetName = "Default";
            this.lblFlag.TabIndex = 11;
            this.lblFlag.Text = "Group Project Flag";
            this.lblFlag.UseMnemonic = false;
            // 
            // lblProjectCode
            // 
            appearance13.TextHAlignAsString = "Left";
            appearance13.TextVAlignAsString = "Middle";
            this.lblProjectCode.Appearance = appearance13;
            this.lblProjectCode.AutoPopupID = null;
            this.lblProjectCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectCode.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectCode.Location = new System.Drawing.Point(15, 282);
            this.lblProjectCode.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(121, 22);
            this.lblProjectCode.StyleSetName = "Default";
            this.lblProjectCode.TabIndex = 12;
            this.lblProjectCode.Text = "Group Project Code";
            this.lblProjectCode.UseMnemonic = false;
            // 
            // tbl1
            // 
            this.tbl1.AutoFit = false;
            this.tbl1.AutoFitColumnCount = 4;
            this.tbl1.AutoFitRowCount = 4;
            this.tbl1.BackColor = System.Drawing.Color.Transparent;
            this.tbl1.ColumnCount = 2;
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl1.Controls.Add(this.txtProjectCode, 0, 0);
            this.tbl1.Controls.Add(this.txtVer, 1, 0);
            this.tbl1.DefaultRowSize = 23;
            this.tbl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl1.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.tbl1.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.tbl1.HEIGHT_TYPE_01 = 6F;
            this.tbl1.HEIGHT_TYPE_01_CONDITION = 38F;
            this.tbl1.HEIGHT_TYPE_02 = 9F;
            this.tbl1.HEIGHT_TYPE_02_DATA = 0F;
            this.tbl1.HEIGHT_TYPE_03 = 3F;
            this.tbl1.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.tbl1.HEIGHT_TYPE_04 = 1F;
            this.tbl1.Location = new System.Drawing.Point(136, 5);
            this.tbl1.Margin = new System.Windows.Forms.Padding(0);
            this.tbl1.Name = "tbl1";
            this.tbl1.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.tbl1.RowCount = 1;
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl1.Size = new System.Drawing.Size(352, 23);
            this.tbl1.SizeTD5 = 14F;
            this.tbl1.SizeTD6 = 36F;
            this.tbl1.TabIndex = 0;
            this.tbl1.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.tbl1.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // txtProjectCode
            // 
            this.txtProjectCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance14.TextVAlignAsString = "Bottom";
            this.txtProjectCode.Appearance = appearance14;
            this.txtProjectCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtProjectCode.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtProjectCode.Location = new System.Drawing.Point(0, 0);
            this.txtProjectCode.LockedField = false;
            this.txtProjectCode.Margin = new System.Windows.Forms.Padding(0);
            this.txtProjectCode.MaxLength = 25;
            this.txtProjectCode.Name = "txtProjectCode";
            this.txtProjectCode.QueryIfEnterKeyPressed = true;
            this.txtProjectCode.RequiredField = false;
            this.txtProjectCode.Size = new System.Drawing.Size(150, 26);
            this.txtProjectCode.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtProjectCode.StyleSetName = "Default";
            this.txtProjectCode.TabIndex = 0;
            this.txtProjectCode.uniALT = "Project Code/Ver";
            this.txtProjectCode.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtProjectCode.UseDynamicFormat = false;
            // 
            // txtVer
            // 
            this.txtVer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance15.TextHAlignAsString = "Right";
            appearance15.TextVAlignAsString = "Bottom";
            this.txtVer.Appearance = appearance15;
            this.txtVer.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtVer.Location = new System.Drawing.Point(160, 0);
            this.txtVer.LockedField = false;
            this.txtVer.Margin = new System.Windows.Forms.Padding(0);
            this.txtVer.MaxLength = 8;
            this.txtVer.Name = "txtVer";
            this.txtVer.QueryIfEnterKeyPressed = true;
            this.txtVer.RequiredField = false;
            this.txtVer.Size = new System.Drawing.Size(50, 26);
            this.txtVer.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.HalfCode;
            this.txtVer.StyleSetName = "Default";
            this.txtVer.TabIndex = 1;
            this.txtVer.uniALT = "Project Code/Ver";
            this.txtVer.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtVer.UseDynamicFormat = false;
            // 
            // cboPrjType
            // 
            this.cboPrjType.AddEmptyRow = false;
            this.cboPrjType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboPrjType.ComboFrom = "";
            this.cboPrjType.ComboMajorCd = "Y8312";
            this.cboPrjType.ComboSelect = "";
            this.cboPrjType.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboPrjType.ComboWhere = "";
            this.cboPrjType.DropDownListWidth = -1;
            this.cboPrjType.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboPrjType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.cboPrjType.Location = new System.Drawing.Point(136, 51);
            this.cboPrjType.LockedField = false;
            this.cboPrjType.Margin = new System.Windows.Forms.Padding(0);
            this.cboPrjType.Name = "cboPrjType";
            this.cboPrjType.RequiredField = false;
            this.cboPrjType.Size = new System.Drawing.Size(144, 26);
            this.cboPrjType.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboPrjType.StyleSetName = "Default";
            this.cboPrjType.TabIndex = 4;
            this.cboPrjType.uniALT = "Project Type";
            // 
            // dtDlvyDt
            // 
            this.dtDlvyDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance16.TextHAlignAsString = "Center";
            this.dtDlvyDt.Appearance = appearance16;
            this.dtDlvyDt.DateTime = new System.DateTime(2007, 9, 12, 0, 0, 0, 0);
            this.dtDlvyDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtDlvyDt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtDlvyDt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtDlvyDt.Location = new System.Drawing.Point(136, 74);
            this.dtDlvyDt.LockedField = false;
            this.dtDlvyDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtDlvyDt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtDlvyDt.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtDlvyDt.Name = "dtDlvyDt";
            this.dtDlvyDt.QueryIfEnterKeyPressed = true;
            this.dtDlvyDt.RequiredField = false;
            this.dtDlvyDt.Size = new System.Drawing.Size(100, 26);
            this.dtDlvyDt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtDlvyDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.dtDlvyDt.StyleSetName = "Default";
            this.dtDlvyDt.TabIndex = 6;
            this.dtDlvyDt.uniALT = "Delivery Date";
            this.dtDlvyDt.uniValue = new System.DateTime(2007, 9, 12, 0, 0, 0, 0);
            this.dtDlvyDt.Value = new System.DateTime(2007, 9, 12, 0, 0, 0, 0);
            // 
            // popPmResourceCd
            // 
            this.popPmResourceCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPmResourceCd.AutoPopupCodeParameter = null;
            this.popPmResourceCd.AutoPopupID = null;
            this.popPmResourceCd.AutoPopupNameParameter = null;
            this.popPmResourceCd.CodeMaxLength = 13;
            this.popPmResourceCd.CodeName = "";
            this.popPmResourceCd.CodeSize = 100;
            this.popPmResourceCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPmResourceCd.CodeTextBoxName = null;
            this.popPmResourceCd.CodeValue = "";
            this.popPmResourceCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popPmResourceCd.Location = new System.Drawing.Point(136, 99);
            this.popPmResourceCd.LockedField = false;
            this.popPmResourceCd.Margin = new System.Windows.Forms.Padding(0);
            this.popPmResourceCd.Name = "popPmResourceCd";
            this.popPmResourceCd.NameDisplay = true;
            this.popPmResourceCd.NameId = null;
            this.popPmResourceCd.NameMaxLength = 40;
            this.popPmResourceCd.NamePopup = false;
            this.popPmResourceCd.NameSize = 150;
            this.popPmResourceCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPmResourceCd.Parameter = null;
            this.popPmResourceCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPmResourceCd.PopupId = null;
            this.popPmResourceCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPmResourceCd.QueryIfEnterKeyPressed = true;
            this.popPmResourceCd.RequiredField = false;
            this.popPmResourceCd.Size = new System.Drawing.Size(271, 21);
            this.popPmResourceCd.TabIndex = 8;
            this.popPmResourceCd.uniALT = "Manager";
            this.popPmResourceCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPmResourceCd.UseDynamicFormat = false;
            this.popPmResourceCd.ValueTextBoxName = null;
            this.popPmResourceCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPmResourceCd_BeforePopupOpen);
            this.popPmResourceCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPmResourceCd_AfterPopupClosed);
            // 
            // popBpCd
            // 
            this.popBpCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popBpCd.AutoPopupCodeParameter = null;
            this.popBpCd.AutoPopupID = null;
            this.popBpCd.AutoPopupNameParameter = null;
            this.popBpCd.CodeMaxLength = 10;
            this.popBpCd.CodeName = "";
            this.popBpCd.CodeSize = 100;
            this.popBpCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBpCd.CodeTextBoxName = null;
            this.popBpCd.CodeValue = "";
            this.popBpCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popBpCd.Location = new System.Drawing.Point(136, 122);
            this.popBpCd.LockedField = false;
            this.popBpCd.Margin = new System.Windows.Forms.Padding(0);
            this.popBpCd.Name = "popBpCd";
            this.popBpCd.NameDisplay = true;
            this.popBpCd.NameId = null;
            this.popBpCd.NameMaxLength = 40;
            this.popBpCd.NamePopup = false;
            this.popBpCd.NameSize = 150;
            this.popBpCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBpCd.Parameter = null;
            this.popBpCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popBpCd.PopupId = null;
            this.popBpCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popBpCd.QueryIfEnterKeyPressed = true;
            this.popBpCd.RequiredField = false;
            this.popBpCd.Size = new System.Drawing.Size(271, 21);
            this.popBpCd.TabIndex = 10;
            this.popBpCd.uniALT = "Customer Name";
            this.popBpCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popBpCd.UseDynamicFormat = false;
            this.popBpCd.ValueTextBoxName = null;
            this.popBpCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popBpCd_BeforePopupOpen);
            this.popBpCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popBpCd_AfterPopupClosed);
            // 
            // popSalesGrp
            // 
            this.popSalesGrp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSalesGrp.AutoPopupCodeParameter = null;
            this.popSalesGrp.AutoPopupID = null;
            this.popSalesGrp.AutoPopupNameParameter = null;
            this.popSalesGrp.CodeMaxLength = 20;
            this.popSalesGrp.CodeName = "";
            this.popSalesGrp.CodeSize = 100;
            this.popSalesGrp.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSalesGrp.CodeTextBoxName = null;
            this.popSalesGrp.CodeValue = "";
            this.popSalesGrp.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popSalesGrp.Location = new System.Drawing.Point(136, 145);
            this.popSalesGrp.LockedField = false;
            this.popSalesGrp.Margin = new System.Windows.Forms.Padding(0);
            this.popSalesGrp.Name = "popSalesGrp";
            this.popSalesGrp.NameDisplay = true;
            this.popSalesGrp.NameId = null;
            this.popSalesGrp.NameMaxLength = 40;
            this.popSalesGrp.NamePopup = false;
            this.popSalesGrp.NameSize = 150;
            this.popSalesGrp.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSalesGrp.Parameter = null;
            this.popSalesGrp.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSalesGrp.PopupId = null;
            this.popSalesGrp.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSalesGrp.QueryIfEnterKeyPressed = true;
            this.popSalesGrp.RequiredField = false;
            this.popSalesGrp.Size = new System.Drawing.Size(271, 21);
            this.popSalesGrp.TabIndex = 12;
            this.popSalesGrp.uniALT = "Sales Group";
            this.popSalesGrp.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popSalesGrp.UseDynamicFormat = false;
            this.popSalesGrp.ValueTextBoxName = null;
            this.popSalesGrp.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSalesGrp_BeforePopupOpen);
            this.popSalesGrp.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSalesGrp_AfterPopupClosed);
            // 
            // popPayMeth
            // 
            this.popPayMeth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPayMeth.AutoPopupCodeParameter = null;
            this.popPayMeth.AutoPopupID = null;
            this.popPayMeth.AutoPopupNameParameter = null;
            this.popPayMeth.CodeMaxLength = 5;
            this.popPayMeth.CodeName = "";
            this.popPayMeth.CodeSize = 100;
            this.popPayMeth.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPayMeth.CodeTextBoxName = null;
            this.popPayMeth.CodeValue = "";
            this.popPayMeth.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popPayMeth.Location = new System.Drawing.Point(136, 168);
            this.popPayMeth.LockedField = false;
            this.popPayMeth.Margin = new System.Windows.Forms.Padding(0);
            this.popPayMeth.Name = "popPayMeth";
            this.popPayMeth.NameDisplay = true;
            this.popPayMeth.NameId = null;
            this.popPayMeth.NameMaxLength = 40;
            this.popPayMeth.NamePopup = false;
            this.popPayMeth.NameSize = 150;
            this.popPayMeth.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPayMeth.Parameter = null;
            this.popPayMeth.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPayMeth.PopupId = null;
            this.popPayMeth.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPayMeth.QueryIfEnterKeyPressed = true;
            this.popPayMeth.RequiredField = false;
            this.popPayMeth.Size = new System.Drawing.Size(271, 21);
            this.popPayMeth.TabIndex = 14;
            this.popPayMeth.uniALT = "Pay Method";
            this.popPayMeth.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPayMeth.UseDynamicFormat = false;
            this.popPayMeth.ValueTextBoxName = null;
            this.popPayMeth.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPayMeth_BeforePopupOpen);
            this.popPayMeth.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPayMeth_AfterPopupClosed);
            // 
            // txtEstimateDegreeForm
            // 
            this.txtEstimateDegreeForm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance17.TextHAlignAsString = "Right";
            appearance17.TextVAlignAsString = "Bottom";
            this.txtEstimateDegreeForm.Appearance = appearance17;
            this.txtEstimateDegreeForm.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEstimateDegreeForm.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtEstimateDegreeForm.Location = new System.Drawing.Point(136, 28);
            this.txtEstimateDegreeForm.LockedField = false;
            this.txtEstimateDegreeForm.Margin = new System.Windows.Forms.Padding(0);
            this.txtEstimateDegreeForm.MaxLength = 15;
            this.txtEstimateDegreeForm.Name = "txtEstimateDegreeForm";
            this.txtEstimateDegreeForm.QueryIfEnterKeyPressed = true;
            this.txtEstimateDegreeForm.RequiredField = false;
            this.txtEstimateDegreeForm.Size = new System.Drawing.Size(50, 26);
            this.txtEstimateDegreeForm.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.HalfCode;
            this.txtEstimateDegreeForm.StyleSetName = "Default";
            this.txtEstimateDegreeForm.TabIndex = 2;
            this.txtEstimateDegreeForm.uniALT = "Applied Estimate Degree";
            this.txtEstimateDegreeForm.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEstimateDegreeForm.UseDynamicFormat = false;
            // 
            // cboRevenue
            // 
            this.cboRevenue.AddEmptyRow = false;
            this.cboRevenue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboRevenue.ComboFrom = "";
            this.cboRevenue.ComboMajorCd = "Y8311";
            this.cboRevenue.ComboSelect = "";
            this.cboRevenue.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboRevenue.ComboWhere = "";
            this.cboRevenue.DropDownListWidth = -1;
            this.cboRevenue.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboRevenue.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.cboRevenue.Location = new System.Drawing.Point(136, 235);
            this.cboRevenue.LockedField = false;
            this.cboRevenue.Margin = new System.Windows.Forms.Padding(0);
            this.cboRevenue.Name = "cboRevenue";
            this.cboRevenue.RequiredField = false;
            this.cboRevenue.Size = new System.Drawing.Size(144, 26);
            this.cboRevenue.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboRevenue.StyleSetName = "Default";
            this.cboRevenue.TabIndex = 20;
            this.cboRevenue.uniALT = "Sale recognition compasrison";
            // 
            // rdoGroupPrjFlg
            // 
            this.rdoGroupPrjFlg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.rdoGroupPrjFlg.Appearance = appearance18;
            this.rdoGroupPrjFlg.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.rdoGroupPrjFlg.CheckedIndex = 0;
            this.rdoGroupPrjFlg.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            valueListItem1.DataValue = "0";
            valueListItem1.DisplayText = "N";
            valueListItem2.DataValue = "1";
            valueListItem2.DisplayText = "Y";
            this.rdoGroupPrjFlg.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1,
            valueListItem2});
            this.rdoGroupPrjFlg.ItemSpacingHorizontal = 10;
            this.rdoGroupPrjFlg.ItemSpacingVertical = 10;
            this.rdoGroupPrjFlg.Location = new System.Drawing.Point(136, 258);
            this.rdoGroupPrjFlg.LockedField = false;
            this.rdoGroupPrjFlg.Margin = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.rdoGroupPrjFlg.Name = "rdoGroupPrjFlg";
            this.rdoGroupPrjFlg.RequiredField = false;
            this.rdoGroupPrjFlg.Size = new System.Drawing.Size(259, 23);
            this.rdoGroupPrjFlg.StyleSetName = "Default";
            this.rdoGroupPrjFlg.TabIndex = 22;
            this.rdoGroupPrjFlg.Text = "N";
            this.rdoGroupPrjFlg.uniALT = "Group Project Flag";
            this.rdoGroupPrjFlg.ValueChanged += new System.EventHandler(this.rdoGroupPrjFlg_ValueChanged);
            // 
            // popGroupPrjCd
            // 
            this.popGroupPrjCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popGroupPrjCd.AutoPopupCodeParameter = null;
            this.popGroupPrjCd.AutoPopupID = null;
            this.popGroupPrjCd.AutoPopupNameParameter = null;
            this.popGroupPrjCd.CodeMaxLength = 25;
            this.popGroupPrjCd.CodeName = "";
            this.popGroupPrjCd.CodeSize = 150;
            this.popGroupPrjCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popGroupPrjCd.CodeTextBoxName = null;
            this.popGroupPrjCd.CodeValue = "";
            this.popGroupPrjCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popGroupPrjCd.Location = new System.Drawing.Point(136, 283);
            this.popGroupPrjCd.LockedField = false;
            this.popGroupPrjCd.Margin = new System.Windows.Forms.Padding(0);
            this.popGroupPrjCd.Name = "popGroupPrjCd";
            this.popGroupPrjCd.NameDisplay = true;
            this.popGroupPrjCd.NameId = null;
            this.popGroupPrjCd.NameMaxLength = 100;
            this.popGroupPrjCd.NamePopup = false;
            this.popGroupPrjCd.NameSize = 150;
            this.popGroupPrjCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popGroupPrjCd.Parameter = null;
            this.popGroupPrjCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popGroupPrjCd.PopupId = null;
            this.popGroupPrjCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popGroupPrjCd.QueryIfEnterKeyPressed = true;
            this.popGroupPrjCd.RequiredField = false;
            this.popGroupPrjCd.Size = new System.Drawing.Size(321, 21);
            this.popGroupPrjCd.TabIndex = 24;
            this.popGroupPrjCd.uniALT = "Group Project Code";
            this.popGroupPrjCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popGroupPrjCd.UseDynamicFormat = false;
            this.popGroupPrjCd.ValueTextBoxName = null;
            this.popGroupPrjCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popGroupPrjCd_BeforePopupOpen);
            this.popGroupPrjCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popGroupPrjCd_AfterPopupClosed);
            // 
            // lblProjectName
            // 
            appearance19.TextHAlignAsString = "Left";
            appearance19.TextVAlignAsString = "Middle";
            this.lblProjectName.Appearance = appearance19;
            this.lblProjectName.AutoPopupID = null;
            this.lblProjectName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectName.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectName.Location = new System.Drawing.Point(503, 6);
            this.lblProjectName.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(121, 22);
            this.lblProjectName.StyleSetName = "Default";
            this.lblProjectName.TabIndex = 27;
            this.lblProjectName.Text = "Project Name";
            this.lblProjectName.UseMnemonic = false;
            // 
            // lblEstimateNo
            // 
            appearance20.TextHAlignAsString = "Left";
            appearance20.TextVAlignAsString = "Middle";
            this.lblEstimateNo.Appearance = appearance20;
            this.lblEstimateNo.AutoPopupID = null;
            this.lblEstimateNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEstimateNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblEstimateNo.Location = new System.Drawing.Point(503, 29);
            this.lblEstimateNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblEstimateNo.Name = "lblEstimateNo";
            this.lblEstimateNo.Size = new System.Drawing.Size(121, 22);
            this.lblEstimateNo.StyleSetName = "Default";
            this.lblEstimateNo.TabIndex = 28;
            this.lblEstimateNo.Text = "Applied Estimate No";
            this.lblEstimateNo.UseMnemonic = false;
            // 
            // lblProjectPeriod
            // 
            appearance21.TextHAlignAsString = "Left";
            appearance21.TextVAlignAsString = "Middle";
            this.lblProjectPeriod.Appearance = appearance21;
            this.lblProjectPeriod.AutoPopupID = null;
            this.lblProjectPeriod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectPeriod.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectPeriod.Location = new System.Drawing.Point(503, 52);
            this.lblProjectPeriod.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectPeriod.Name = "lblProjectPeriod";
            this.lblProjectPeriod.Size = new System.Drawing.Size(121, 22);
            this.lblProjectPeriod.StyleSetName = "Default";
            this.lblProjectPeriod.TabIndex = 29;
            this.lblProjectPeriod.Text = "Project Period";
            this.lblProjectPeriod.UseMnemonic = false;
            // 
            // lblProjectType
            // 
            appearance22.TextHAlignAsString = "Left";
            appearance22.TextVAlignAsString = "Middle";
            this.lblProjectType.Appearance = appearance22;
            this.lblProjectType.AutoPopupID = null;
            this.lblProjectType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectType.Location = new System.Drawing.Point(503, 75);
            this.lblProjectType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectType.Name = "lblProjectType";
            this.lblProjectType.Size = new System.Drawing.Size(121, 22);
            this.lblProjectType.StyleSetName = "Default";
            this.lblProjectType.TabIndex = 30;
            this.lblProjectType.Text = "ProjectType";
            this.lblProjectType.UseMnemonic = false;
            // 
            // lblProjectType1
            // 
            appearance23.TextHAlignAsString = "Left";
            appearance23.TextVAlignAsString = "Middle";
            this.lblProjectType1.Appearance = appearance23;
            this.lblProjectType1.AutoPopupID = null;
            this.lblProjectType1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectType1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectType1.Location = new System.Drawing.Point(503, 98);
            this.lblProjectType1.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectType1.Name = "lblProjectType1";
            this.lblProjectType1.Size = new System.Drawing.Size(121, 22);
            this.lblProjectType1.StyleSetName = "Default";
            this.lblProjectType1.TabIndex = 31;
            this.lblProjectType1.Text = "Project Type1";
            this.lblProjectType1.UseMnemonic = false;
            // 
            // lblCurrency
            // 
            appearance24.TextHAlignAsString = "Left";
            appearance24.TextVAlignAsString = "Middle";
            this.lblCurrency.Appearance = appearance24;
            this.lblCurrency.AutoPopupID = null;
            this.lblCurrency.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCurrency.Font = new System.Drawing.Font("SimSun", 9F);
            this.lblCurrency.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCurrency.Location = new System.Drawing.Point(503, 121);
            this.lblCurrency.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(121, 22);
            this.lblCurrency.StyleSetName = "Default";
            this.lblCurrency.TabIndex = 32;
            this.lblCurrency.Text = "Currency Unit/Order Amount";
            this.lblCurrency.UseMnemonic = false;
            // 
            // txtProjectNm
            // 
            this.txtProjectNm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance25.TextVAlignAsString = "Bottom";
            this.txtProjectNm.Appearance = appearance25;
            this.txtProjectNm.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.txtProjectNm.Location = new System.Drawing.Point(624, 5);
            this.txtProjectNm.LockedField = false;
            this.txtProjectNm.Margin = new System.Windows.Forms.Padding(0);
            this.txtProjectNm.MaxLength = 120;
            this.txtProjectNm.Name = "txtProjectNm";
            this.txtProjectNm.QueryIfEnterKeyPressed = true;
            this.txtProjectNm.RequiredField = false;
            this.txtProjectNm.Size = new System.Drawing.Size(150, 26);
            this.txtProjectNm.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtProjectNm.StyleSetName = "Default";
            this.txtProjectNm.TabIndex = 1;
            this.txtProjectNm.uniALT = "Project Name";
            this.txtProjectNm.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProjectNm.UseDynamicFormat = false;
            // 
            // txtEstimate
            // 
            this.txtEstimate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance26.TextVAlignAsString = "Bottom";
            this.txtEstimate.Appearance = appearance26;
            this.txtEstimate.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEstimate.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtEstimate.Location = new System.Drawing.Point(624, 28);
            this.txtEstimate.LockedField = false;
            this.txtEstimate.Margin = new System.Windows.Forms.Padding(0);
            this.txtEstimate.MaxLength = 25;
            this.txtEstimate.Name = "txtEstimate";
            this.txtEstimate.QueryIfEnterKeyPressed = true;
            this.txtEstimate.RequiredField = false;
            this.txtEstimate.Size = new System.Drawing.Size(150, 26);
            this.txtEstimate.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtEstimate.StyleSetName = "Default";
            this.txtEstimate.TabIndex = 3;
            this.txtEstimate.uniALT = "Applied Estimate No.";
            this.txtEstimate.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEstimate.UseDynamicFormat = false;
            // 
            // dtPlanStartDt
            // 
            this.dtPlanStartDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtPlanStartDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtPlanStartDt.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtPlanStartDt.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtPlanStartDt.Location = new System.Drawing.Point(624, 53);
            this.dtPlanStartDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtPlanStartDt.Name = "dtPlanStartDt";
            this.dtPlanStartDt.Size = new System.Drawing.Size(225, 21);
            this.dtPlanStartDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.dtPlanStartDt.TabIndex = 36;
            this.dtPlanStartDt.uniFromALT = "Project PeriodFrom";
            this.dtPlanStartDt.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtPlanStartDt.uniTabSameValue = false;
            this.dtPlanStartDt.uniToALT = "Project PeriodTo";
            this.dtPlanStartDt.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // cboProjectType
            // 
            this.cboProjectType.AddEmptyRow = false;
            this.cboProjectType.AllowDrop = true;
            this.cboProjectType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboProjectType.ComboFrom = "";
            this.cboProjectType.ComboMajorCd = "Y0003";
            this.cboProjectType.ComboSelect = "";
            this.cboProjectType.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboProjectType.ComboWhere = "";
            this.cboProjectType.DropDownListWidth = -1;
            this.cboProjectType.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboProjectType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.cboProjectType.Location = new System.Drawing.Point(624, 74);
            this.cboProjectType.LockedField = false;
            this.cboProjectType.Margin = new System.Windows.Forms.Padding(0);
            this.cboProjectType.Name = "cboProjectType";
            this.cboProjectType.RequiredField = false;
            this.cboProjectType.Size = new System.Drawing.Size(144, 26);
            this.cboProjectType.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboProjectType.StyleSetName = "Default";
            this.cboProjectType.TabIndex = 7;
            this.cboProjectType.uniALT = "Project Type";
            // 
            // cboProjectType1
            // 
            this.cboProjectType1.AddEmptyRow = true;
            this.cboProjectType1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboProjectType1.ComboFrom = "";
            this.cboProjectType1.ComboMajorCd = "Y0011";
            this.cboProjectType1.ComboSelect = "";
            this.cboProjectType1.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboProjectType1.ComboWhere = "";
            this.cboProjectType1.DropDownListWidth = -1;
            this.cboProjectType1.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboProjectType1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.cboProjectType1.Location = new System.Drawing.Point(624, 97);
            this.cboProjectType1.LockedField = false;
            this.cboProjectType1.Margin = new System.Windows.Forms.Padding(0);
            this.cboProjectType1.Name = "cboProjectType1";
            this.cboProjectType1.RequiredField = false;
            this.cboProjectType1.Size = new System.Drawing.Size(144, 26);
            this.cboProjectType1.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboProjectType1.StyleSetName = "Default";
            this.cboProjectType1.TabIndex = 9;
            this.cboProjectType1.uniALT = "Project Type1";
            // 
            // numXchRate
            // 
            this.numXchRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numXchRate.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.numXchRate.Location = new System.Drawing.Point(136, 189);
            this.numXchRate.LockedField = false;
            this.numXchRate.Margin = new System.Windows.Forms.Padding(0);
            this.numXchRate.Name = "numXchRate";
            this.numXchRate.Nullable = true;
            this.numXchRate.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numXchRate.QueryIfEnterKeyPressed = true;
            this.numXchRate.ReadOnly = true;
            this.numXchRate.RequiredField = false;
            this.numXchRate.Size = new System.Drawing.Size(140, 26);
            this.numXchRate.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numXchRate.StyleSetName = "Default";
            this.numXchRate.TabIndex = 16;
            this.numXchRate.uniALT = "Exchange Rate";
            this.numXchRate.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.ExchangeRate;
            this.numXchRate.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numXchRate.Value = null;
            this.numXchRate.AfterExitEditMode += new System.EventHandler(this.numXchRate_AfterExitEditMode);
            // 
            // numVatRate
            // 
            this.numVatRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numVatRate.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.numVatRate.Location = new System.Drawing.Point(136, 212);
            this.numVatRate.LockedField = false;
            this.numVatRate.Margin = new System.Windows.Forms.Padding(0);
            this.numVatRate.Name = "numVatRate";
            this.numVatRate.Nullable = true;
            this.numVatRate.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numVatRate.QueryIfEnterKeyPressed = true;
            this.numVatRate.RequiredField = false;
            this.numVatRate.Size = new System.Drawing.Size(140, 26);
            this.numVatRate.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numVatRate.StyleSetName = "Default";
            this.numVatRate.TabIndex = 18;
            this.numVatRate.uniALT = "VAT Rate";
            this.numVatRate.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.ExchangeRate;
            this.numVatRate.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numVatRate.Value = null;
            this.numVatRate.AfterExitEditMode += new System.EventHandler(this.numXchRate_AfterExitEditMode);
            // 
            // tbl2
            // 
            this.tbl2.AutoFit = false;
            this.tbl2.AutoFitColumnCount = 4;
            this.tbl2.AutoFitRowCount = 4;
            this.tbl2.BackColor = System.Drawing.Color.Transparent;
            this.tbl2.ColumnCount = 2;
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 126F));
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl2.Controls.Add(this.popCurrency, 0, 0);
            this.tbl2.Controls.Add(this.numNetAmt, 1, 0);
            this.tbl2.DefaultRowSize = 23;
            this.tbl2.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.tbl2.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.tbl2.HEIGHT_TYPE_01 = 6F;
            this.tbl2.HEIGHT_TYPE_01_CONDITION = 38F;
            this.tbl2.HEIGHT_TYPE_02 = 9F;
            this.tbl2.HEIGHT_TYPE_02_DATA = 0F;
            this.tbl2.HEIGHT_TYPE_03 = 3F;
            this.tbl2.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.tbl2.HEIGHT_TYPE_04 = 1F;
            this.tbl2.Location = new System.Drawing.Point(624, 120);
            this.tbl2.Margin = new System.Windows.Forms.Padding(0);
            this.tbl2.Name = "tbl2";
            this.tbl2.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.tbl2.RowCount = 1;
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl2.Size = new System.Drawing.Size(264, 23);
            this.tbl2.SizeTD5 = 14F;
            this.tbl2.SizeTD6 = 36F;
            this.tbl2.TabIndex = 11;
            this.tbl2.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.tbl2.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // popCurrency
            // 
            this.popCurrency.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popCurrency.AutoPopupCodeParameter = null;
            this.popCurrency.AutoPopupID = null;
            this.popCurrency.AutoPopupNameParameter = null;
            this.popCurrency.CodeMaxLength = 3;
            this.popCurrency.CodeName = "";
            this.popCurrency.CodeSize = 100;
            this.popCurrency.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCurrency.CodeTextBoxName = null;
            this.popCurrency.CodeValue = "";
            this.popCurrency.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popCurrency.Location = new System.Drawing.Point(0, 2);
            this.popCurrency.LockedField = false;
            this.popCurrency.Margin = new System.Windows.Forms.Padding(0);
            this.popCurrency.Name = "popCurrency";
            this.popCurrency.NameDisplay = false;
            this.popCurrency.NameId = null;
            this.popCurrency.NameMaxLength = 50;
            this.popCurrency.NamePopup = false;
            this.popCurrency.NameSize = 100;
            this.popCurrency.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCurrency.Parameter = null;
            this.popCurrency.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popCurrency.PopupId = null;
            this.popCurrency.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popCurrency.QueryIfEnterKeyPressed = true;
            this.popCurrency.RequiredField = false;
            this.popCurrency.Size = new System.Drawing.Size(121, 21);
            this.popCurrency.TabIndex = 0;
            this.popCurrency.uniALT = "Currency Unit";
            this.popCurrency.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popCurrency.UseDynamicFormat = false;
            this.popCurrency.ValueTextBoxName = null;
            this.popCurrency.OnChange += new System.EventHandler(this.popCurrency_OnChange);
            this.popCurrency.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popCurrency_BeforePopupOpen_1);
            this.popCurrency.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popCurrency_AfterPopupClosed_1);
            // 
            // numNetAmt
            // 
            this.numNetAmt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numNetAmt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.numNetAmt.Location = new System.Drawing.Point(126, 0);
            this.numNetAmt.LockedField = false;
            this.numNetAmt.Margin = new System.Windows.Forms.Padding(0);
            this.numNetAmt.Name = "numNetAmt";
            this.numNetAmt.Nullable = true;
            this.numNetAmt.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numNetAmt.QueryIfEnterKeyPressed = true;
            this.numNetAmt.RequiredField = false;
            this.numNetAmt.Size = new System.Drawing.Size(138, 26);
            this.numNetAmt.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numNetAmt.StyleSetName = "Default";
            this.numNetAmt.TabIndex = 1;
            this.numNetAmt.uniALT = "Order Amount";
            this.numNetAmt.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.UserDefined9;
            this.numNetAmt.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numNetAmt.Value = null;
            this.numNetAmt.AfterExitEditMode += new System.EventHandler(this.numNetAmt_AfterExitEditMode);
            // 
            // txtRemark
            // 
            this.txtRemark.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance27.TextVAlignAsString = "Bottom";
            this.txtRemark.Appearance = appearance27;
            this.uniTBL_MainData.SetColumnSpan(this.txtRemark, 3);
            this.txtRemark.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.txtRemark.Location = new System.Drawing.Point(136, 310);
            this.txtRemark.LockedField = false;
            this.txtRemark.Margin = new System.Windows.Forms.Padding(0);
            this.txtRemark.Multiline = true;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.QueryIfEnterKeyPressed = true;
            this.txtRemark.RequiredField = false;
            this.uniTBL_MainData.SetRowSpan(this.txtRemark, 3);
            this.txtRemark.Size = new System.Drawing.Size(424, 63);
            this.txtRemark.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtRemark.StyleSetName = "Default";
            this.txtRemark.TabIndex = 57;
            this.txtRemark.uniALT = "Remark";
            this.txtRemark.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtRemark.UseDynamicFormat = false;
            // 
            // lblRemark
            // 
            appearance28.TextHAlignAsString = "Left";
            appearance28.TextVAlignAsString = "Middle";
            this.lblRemark.Appearance = appearance28;
            this.lblRemark.AutoPopupID = null;
            this.lblRemark.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRemark.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRemark.Location = new System.Drawing.Point(15, 351);
            this.lblRemark.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(121, 22);
            this.lblRemark.StyleSetName = "Default";
            this.lblRemark.TabIndex = 58;
            this.lblRemark.Text = "Remark";
            this.lblRemark.UseMnemonic = false;
            // 
            // lblSulgye
            // 
            appearance29.TextHAlignAsString = "Left";
            appearance29.TextVAlignAsString = "Middle";
            this.lblSulgye.Appearance = appearance29;
            this.lblSulgye.AutoPopupID = null;
            this.lblSulgye.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSulgye.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSulgye.Location = new System.Drawing.Point(15, 374);
            this.lblSulgye.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSulgye.Name = "lblSulgye";
            this.lblSulgye.Size = new System.Drawing.Size(121, 22);
            this.lblSulgye.StyleSetName = "Default";
            this.lblSulgye.TabIndex = 60;
            this.lblSulgye.Text = "설계담당";
            this.lblSulgye.UseMnemonic = false;
            // 
            // lblBaljugb
            // 
            appearance30.TextHAlignAsString = "Left";
            appearance30.TextVAlignAsString = "Middle";
            this.lblBaljugb.Appearance = appearance30;
            this.lblBaljugb.AutoPopupID = null;
            this.lblBaljugb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBaljugb.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBaljugb.Location = new System.Drawing.Point(15, 397);
            this.lblBaljugb.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblBaljugb.Name = "lblBaljugb";
            this.lblBaljugb.Size = new System.Drawing.Size(121, 22);
            this.lblBaljugb.StyleSetName = "Default";
            this.lblBaljugb.TabIndex = 61;
            this.lblBaljugb.Text = "발주구분";
            this.lblBaljugb.UseMnemonic = false;
            // 
            // lblReqman
            // 
            appearance31.TextHAlignAsString = "Left";
            appearance31.TextVAlignAsString = "Middle";
            this.lblReqman.Appearance = appearance31;
            this.lblReqman.AutoPopupID = null;
            this.lblReqman.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReqman.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReqman.Location = new System.Drawing.Point(15, 420);
            this.lblReqman.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReqman.Name = "lblReqman";
            this.lblReqman.Size = new System.Drawing.Size(121, 21);
            this.lblReqman.StyleSetName = "Default";
            this.lblReqman.TabIndex = 62;
            this.lblReqman.Text = "전자결재 요청자";
            this.lblReqman.UseMnemonic = false;
            // 
            // lblCusmng
            // 
            appearance32.TextHAlignAsString = "Left";
            appearance32.TextVAlignAsString = "Middle";
            this.lblCusmng.Appearance = appearance32;
            this.lblCusmng.AutoPopupID = null;
            this.lblCusmng.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCusmng.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCusmng.Location = new System.Drawing.Point(15, 442);
            this.lblCusmng.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCusmng.Name = "lblCusmng";
            this.lblCusmng.Size = new System.Drawing.Size(121, 23);
            this.lblCusmng.StyleSetName = "Default";
            this.lblCusmng.TabIndex = 63;
            this.lblCusmng.Text = "고객담당자";
            this.lblCusmng.UseMnemonic = false;
            // 
            // lblCusmngnum
            // 
            appearance33.TextHAlignAsString = "Left";
            appearance33.TextVAlignAsString = "Middle";
            this.lblCusmngnum.Appearance = appearance33;
            this.lblCusmngnum.AutoPopupID = null;
            this.lblCusmngnum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCusmngnum.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCusmngnum.Location = new System.Drawing.Point(15, 466);
            this.lblCusmngnum.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCusmngnum.Name = "lblCusmngnum";
            this.lblCusmngnum.Size = new System.Drawing.Size(121, 22);
            this.lblCusmngnum.StyleSetName = "Default";
            this.lblCusmngnum.TabIndex = 64;
            this.lblCusmngnum.Text = "고객담당자(연락처)";
            this.lblCusmngnum.UseMnemonic = false;
            // 
            // lblCsmng
            // 
            appearance34.TextHAlignAsString = "Left";
            appearance34.TextVAlignAsString = "Middle";
            this.lblCsmng.Appearance = appearance34;
            this.lblCsmng.AutoPopupID = null;
            this.lblCsmng.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCsmng.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCsmng.Location = new System.Drawing.Point(503, 374);
            this.lblCsmng.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCsmng.Name = "lblCsmng";
            this.lblCsmng.Size = new System.Drawing.Size(121, 22);
            this.lblCsmng.StyleSetName = "Default";
            this.lblCsmng.TabIndex = 65;
            this.lblCsmng.Text = "CS담당";
            this.lblCsmng.UseMnemonic = false;
            // 
            // lblBaljudt
            // 
            appearance35.TextHAlignAsString = "Left";
            appearance35.TextVAlignAsString = "Middle";
            this.lblBaljudt.Appearance = appearance35;
            this.lblBaljudt.AutoPopupID = null;
            this.lblBaljudt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBaljudt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBaljudt.Location = new System.Drawing.Point(503, 397);
            this.lblBaljudt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblBaljudt.Name = "lblBaljudt";
            this.lblBaljudt.Size = new System.Drawing.Size(121, 22);
            this.lblBaljudt.StyleSetName = "Default";
            this.lblBaljudt.TabIndex = 66;
            this.lblBaljudt.Text = "발주일";
            this.lblBaljudt.UseMnemonic = false;
            // 
            // lblPaystat
            // 
            appearance36.TextHAlignAsString = "Left";
            appearance36.TextVAlignAsString = "Middle";
            this.lblPaystat.Appearance = appearance36;
            this.lblPaystat.AutoPopupID = null;
            this.lblPaystat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPaystat.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPaystat.Location = new System.Drawing.Point(503, 420);
            this.lblPaystat.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPaystat.Name = "lblPaystat";
            this.lblPaystat.Size = new System.Drawing.Size(121, 21);
            this.lblPaystat.StyleSetName = "Default";
            this.lblPaystat.TabIndex = 67;
            this.lblPaystat.Text = "결재상태";
            this.lblPaystat.UseMnemonic = false;
            // 
            // lblCusmngdept
            // 
            appearance37.TextHAlignAsString = "Left";
            appearance37.TextVAlignAsString = "Middle";
            this.lblCusmngdept.Appearance = appearance37;
            this.lblCusmngdept.AutoPopupID = null;
            this.lblCusmngdept.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCusmngdept.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCusmngdept.Location = new System.Drawing.Point(503, 442);
            this.lblCusmngdept.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCusmngdept.Name = "lblCusmngdept";
            this.lblCusmngdept.Size = new System.Drawing.Size(121, 23);
            this.lblCusmngdept.StyleSetName = "Default";
            this.lblCusmngdept.TabIndex = 68;
            this.lblCusmngdept.Text = "고객담당자(부서)";
            this.lblCusmngdept.UseMnemonic = false;
            // 
            // txtCusmng
            // 
            this.txtCusmng.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance38.TextVAlignAsString = "Bottom";
            this.txtCusmng.Appearance = appearance38;
            this.txtCusmng.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtCusmng.Location = new System.Drawing.Point(136, 441);
            this.txtCusmng.LockedField = false;
            this.txtCusmng.Margin = new System.Windows.Forms.Padding(0);
            this.txtCusmng.Name = "txtCusmng";
            this.txtCusmng.QueryIfEnterKeyPressed = true;
            this.txtCusmng.RequiredField = false;
            this.txtCusmng.Size = new System.Drawing.Size(271, 26);
            this.txtCusmng.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtCusmng.StyleSetName = "Default";
            this.txtCusmng.TabIndex = 72;
            this.txtCusmng.uniALT = null;
            this.txtCusmng.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCusmng.UseDynamicFormat = false;
            // 
            // txtCusmngnum
            // 
            this.txtCusmngnum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance39.TextVAlignAsString = "Bottom";
            this.txtCusmngnum.Appearance = appearance39;
            this.txtCusmngnum.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtCusmngnum.Location = new System.Drawing.Point(136, 465);
            this.txtCusmngnum.LockedField = false;
            this.txtCusmngnum.Margin = new System.Windows.Forms.Padding(0);
            this.txtCusmngnum.Name = "txtCusmngnum";
            this.txtCusmngnum.QueryIfEnterKeyPressed = true;
            this.txtCusmngnum.RequiredField = false;
            this.txtCusmngnum.Size = new System.Drawing.Size(271, 26);
            this.txtCusmngnum.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtCusmngnum.StyleSetName = "Default";
            this.txtCusmngnum.TabIndex = 73;
            this.txtCusmngnum.uniALT = null;
            this.txtCusmngnum.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCusmngnum.UseDynamicFormat = false;
            // 
            // txtCusmngdept
            // 
            this.txtCusmngdept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance40.TextVAlignAsString = "Bottom";
            this.txtCusmngdept.Appearance = appearance40;
            this.txtCusmngdept.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtCusmngdept.Location = new System.Drawing.Point(624, 441);
            this.txtCusmngdept.LockedField = false;
            this.txtCusmngdept.Margin = new System.Windows.Forms.Padding(0);
            this.txtCusmngdept.Name = "txtCusmngdept";
            this.txtCusmngdept.QueryIfEnterKeyPressed = true;
            this.txtCusmngdept.RequiredField = false;
            this.txtCusmngdept.Size = new System.Drawing.Size(100, 26);
            this.txtCusmngdept.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtCusmngdept.StyleSetName = "Default";
            this.txtCusmngdept.TabIndex = 75;
            this.txtCusmngdept.uniALT = null;
            this.txtCusmngdept.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCusmngdept.UseDynamicFormat = false;
            // 
            // cboBaljugb
            // 
            this.cboBaljugb.AddEmptyRow = false;
            this.cboBaljugb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboBaljugb.ComboFrom = "B_MINOR";
            this.cboBaljugb.ComboMajorCd = "";
            this.cboBaljugb.ComboSelect = "MINOR_CD AS CODE, MINOR_NM AS NAME";
            this.cboBaljugb.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.Query;
            this.cboBaljugb.ComboWhere = "MAJOR_CD=\'XPM01\' AND (minor_cd=\'PO\' OR minor_cd=\'PR\')";
            this.cboBaljugb.DropDownListWidth = -1;
            this.cboBaljugb.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboBaljugb.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.cboBaljugb.Location = new System.Drawing.Point(136, 396);
            this.cboBaljugb.LockedField = false;
            this.cboBaljugb.Margin = new System.Windows.Forms.Padding(0);
            this.cboBaljugb.Name = "cboBaljugb";
            this.cboBaljugb.RequiredField = false;
            this.cboBaljugb.Size = new System.Drawing.Size(144, 26);
            this.cboBaljugb.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboBaljugb.StyleSetName = "Default";
            this.cboBaljugb.TabIndex = 76;
            this.cboBaljugb.uniALT = "발주구분";
            // 
            // dtBaljudt
            // 
            this.dtBaljudt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance41.TextHAlignAsString = "Center";
            this.dtBaljudt.Appearance = appearance41;
            this.dtBaljudt.DateTime = new System.DateTime(2018, 6, 21, 0, 0, 0, 0);
            this.dtBaljudt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtBaljudt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtBaljudt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtBaljudt.Location = new System.Drawing.Point(624, 396);
            this.dtBaljudt.LockedField = false;
            this.dtBaljudt.Margin = new System.Windows.Forms.Padding(0);
            this.dtBaljudt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtBaljudt.Name = "dtBaljudt";
            this.dtBaljudt.QueryIfEnterKeyPressed = true;
            this.dtBaljudt.RequiredField = false;
            this.dtBaljudt.Size = new System.Drawing.Size(100, 26);
            this.dtBaljudt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtBaljudt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtBaljudt.StyleSetName = "Default";
            this.dtBaljudt.TabIndex = 77;
            this.dtBaljudt.uniALT = null;
            this.dtBaljudt.uniValue = new System.DateTime(2018, 6, 21, 0, 0, 0, 0);
            this.dtBaljudt.Value = new System.DateTime(2018, 6, 21, 0, 0, 0, 0);
            // 
            // popSulgye
            // 
            this.popSulgye.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSulgye.AutoPopupCodeParameter = null;
            this.popSulgye.AutoPopupID = null;
            this.popSulgye.AutoPopupNameParameter = null;
            this.popSulgye.CodeMaxLength = 10;
            this.popSulgye.CodeName = "";
            this.popSulgye.CodeSize = 100;
            this.popSulgye.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popSulgye.CodeTextBoxName = null;
            this.popSulgye.CodeValue = "";
            this.popSulgye.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popSulgye.Location = new System.Drawing.Point(136, 375);
            this.popSulgye.LockedField = false;
            this.popSulgye.Margin = new System.Windows.Forms.Padding(0);
            this.popSulgye.Name = "popSulgye";
            this.popSulgye.NameDisplay = true;
            this.popSulgye.NameId = null;
            this.popSulgye.NameMaxLength = 50;
            this.popSulgye.NamePopup = false;
            this.popSulgye.NameSize = 150;
            this.popSulgye.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popSulgye.Parameter = null;
            this.popSulgye.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSulgye.PopupId = null;
            this.popSulgye.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSulgye.QueryIfEnterKeyPressed = true;
            this.popSulgye.RequiredField = false;
            this.popSulgye.Size = new System.Drawing.Size(271, 21);
            this.popSulgye.TabIndex = 78;
            this.popSulgye.uniALT = "설계담당";
            this.popSulgye.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popSulgye.UseDynamicFormat = false;
            this.popSulgye.ValueTextBoxName = null;
            this.popSulgye.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSulgye_BeforePopupOpen);
            this.popSulgye.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSulgye_AfterPopupClosed);
            // 
            // popReqman
            // 
            this.popReqman.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popReqman.AutoPopupCodeParameter = null;
            this.popReqman.AutoPopupID = null;
            this.popReqman.AutoPopupNameParameter = null;
            this.popReqman.CodeMaxLength = 10;
            this.popReqman.CodeName = "";
            this.popReqman.CodeSize = 100;
            this.popReqman.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popReqman.CodeTextBoxName = null;
            this.popReqman.CodeValue = "";
            this.popReqman.Controls.Add(this.uniTextBox_Name);
            this.popReqman.Controls.Add(this.uniTextBox_Code);
            this.popReqman.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popReqman.Location = new System.Drawing.Point(136, 420);
            this.popReqman.LockedField = false;
            this.popReqman.Margin = new System.Windows.Forms.Padding(0);
            this.popReqman.Name = "popReqman";
            this.popReqman.NameDisplay = true;
            this.popReqman.NameId = null;
            this.popReqman.NameMaxLength = 50;
            this.popReqman.NamePopup = false;
            this.popReqman.NameSize = 150;
            this.popReqman.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popReqman.Parameter = null;
            this.popReqman.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popReqman.PopupId = null;
            this.popReqman.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popReqman.QueryIfEnterKeyPressed = true;
            this.popReqman.RequiredField = false;
            this.popReqman.Size = new System.Drawing.Size(271, 21);
            this.popReqman.TabIndex = 79;
            this.popReqman.uniALT = "전자결재 요청자";
            this.popReqman.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popReqman.UseDynamicFormat = false;
            this.popReqman.ValueTextBoxName = null;
            this.popReqman.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popReqman_BeforePopupOpen);
            this.popReqman.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popReqman_AfterPopupClosed);
            // 
            // uniTextBox_Name
            // 
            this.uniTextBox_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.Appearance = appearance42;
            this.uniTextBox_Name.AutoSize = false;
            this.uniTextBox_Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Name.Location = new System.Drawing.Point(121, 0);
            this.uniTextBox_Name.LockedField = false;
            this.uniTextBox_Name.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Name.MaxLength = 10;
            this.uniTextBox_Name.Name = "uniTextBox_Name";
            this.uniTextBox_Name.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Name.ReadOnly = true;
            this.uniTextBox_Name.RequiredField = false;
            this.uniTextBox_Name.Size = new System.Drawing.Size(98, 21);
            this.uniTextBox_Name.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Name.StyleSetName = "Lock";
            this.uniTextBox_Name.TabIndex = 0;
            this.uniTextBox_Name.TabStop = false;
            this.uniTextBox_Name.uniALT = null;
            this.uniTextBox_Name.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.uniTextBox_Name.UseDynamicFormat = false;
            this.uniTextBox_Name.WordWrap = false;
            // 
            // uniTextBox_Code
            // 
            this.uniTextBox_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.Appearance = appearance43;
            this.uniTextBox_Code.AutoSize = false;
            this.uniTextBox_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Code.Location = new System.Drawing.Point(0, 0);
            this.uniTextBox_Code.LockedField = false;
            this.uniTextBox_Code.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Code.MaxLength = 10;
            this.uniTextBox_Code.Name = "uniTextBox_Code";
            this.uniTextBox_Code.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Code.RequiredField = false;
            this.uniTextBox_Code.Size = new System.Drawing.Size(100, 21);
            this.uniTextBox_Code.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Code.StyleSetName = "Default";
            this.uniTextBox_Code.TabIndex = 0;
            this.uniTextBox_Code.uniALT = null;
            this.uniTextBox_Code.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.uniTextBox_Code.UseDynamicFormat = false;
            this.uniTextBox_Code.WordWrap = false;
            // 
            // popCsmng
            // 
            this.popCsmng.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popCsmng.AutoPopupCodeParameter = null;
            this.popCsmng.AutoPopupID = null;
            this.popCsmng.AutoPopupNameParameter = null;
            this.popCsmng.CodeMaxLength = 10;
            this.popCsmng.CodeName = "";
            this.popCsmng.CodeSize = 100;
            this.popCsmng.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popCsmng.CodeTextBoxName = null;
            this.popCsmng.CodeValue = "";
            this.popCsmng.Controls.Add(this.object_c2f684bf_1215_43eb_bceb_14274d5879ed);
            this.popCsmng.Controls.Add(this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68);
            this.popCsmng.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popCsmng.Location = new System.Drawing.Point(624, 375);
            this.popCsmng.LockedField = false;
            this.popCsmng.Margin = new System.Windows.Forms.Padding(0);
            this.popCsmng.Name = "popCsmng";
            this.popCsmng.NameDisplay = true;
            this.popCsmng.NameId = null;
            this.popCsmng.NameMaxLength = 50;
            this.popCsmng.NamePopup = false;
            this.popCsmng.NameSize = 150;
            this.popCsmng.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popCsmng.Parameter = null;
            this.popCsmng.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popCsmng.PopupId = null;
            this.popCsmng.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popCsmng.QueryIfEnterKeyPressed = true;
            this.popCsmng.RequiredField = false;
            this.popCsmng.Size = new System.Drawing.Size(264, 21);
            this.popCsmng.TabIndex = 80;
            this.popCsmng.uniALT = "CS담당";
            this.popCsmng.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popCsmng.UseDynamicFormat = false;
            this.popCsmng.ValueTextBoxName = null;
            this.popCsmng.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popCsmng_BeforePopupOpen);
            this.popCsmng.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popCsmng_AfterPopupClosed);
            // 
            // object_c2f684bf_1215_43eb_bceb_14274d5879ed
            // 
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.Appearance = appearance44;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.AutoSize = false;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.Location = new System.Drawing.Point(121, 0);
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.LockedField = false;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.Margin = new System.Windows.Forms.Padding(0);
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.MaxLength = 10;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.Name = "object_c2f684bf_1215_43eb_bceb_14274d5879ed";
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.QueryIfEnterKeyPressed = true;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.ReadOnly = true;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.RequiredField = false;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.Size = new System.Drawing.Size(98, 21);
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.StyleSetName = "Lock";
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.TabIndex = 0;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.TabStop = false;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.uniALT = null;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.UseDynamicFormat = false;
            this.object_c2f684bf_1215_43eb_bceb_14274d5879ed.WordWrap = false;
            // 
            // object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68
            // 
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.Appearance = appearance45;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.AutoSize = false;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.Location = new System.Drawing.Point(0, 0);
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.LockedField = false;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.Margin = new System.Windows.Forms.Padding(0);
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.MaxLength = 10;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.Name = "object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68";
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.QueryIfEnterKeyPressed = true;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.RequiredField = false;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.Size = new System.Drawing.Size(100, 21);
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.StyleSetName = "Default";
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.TabIndex = 0;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.uniALT = null;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.UseDynamicFormat = false;
            this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68.WordWrap = false;
            // 
            // uniTableLayoutPanel1
            // 
            this.uniTableLayoutPanel1.AutoFit = false;
            this.uniTableLayoutPanel1.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel1.AutoFitRowCount = 4;
            this.uniTableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel1.ColumnCount = 2;
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.uniTableLayoutPanel1.Controls.Add(this.txtPaystat, 0, 0);
            this.uniTableLayoutPanel1.Controls.Add(this.txtPaystatcd, 0, 0);
            this.uniTableLayoutPanel1.DefaultRowSize = 23;
            this.uniTableLayoutPanel1.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel1.Location = new System.Drawing.Point(624, 419);
            this.uniTableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel1.Name = "uniTableLayoutPanel1";
            this.uniTableLayoutPanel1.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTableLayoutPanel1.RowCount = 1;
            this.uniTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTableLayoutPanel1.Size = new System.Drawing.Size(172, 22);
            this.uniTableLayoutPanel1.SizeTD5 = 14F;
            this.uniTableLayoutPanel1.SizeTD6 = 36F;
            this.uniTableLayoutPanel1.TabIndex = 82;
            this.uniTableLayoutPanel1.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel1.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // txtPaystat
            // 
            this.txtPaystat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance46.TextVAlignAsString = "Bottom";
            this.txtPaystat.Appearance = appearance46;
            this.txtPaystat.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtPaystat.Location = new System.Drawing.Point(51, 0);
            this.txtPaystat.LockedField = false;
            this.txtPaystat.Margin = new System.Windows.Forms.Padding(0);
            this.txtPaystat.Name = "txtPaystat";
            this.txtPaystat.QueryIfEnterKeyPressed = true;
            this.txtPaystat.RequiredField = false;
            this.txtPaystat.Size = new System.Drawing.Size(100, 26);
            this.txtPaystat.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtPaystat.StyleSetName = "Default";
            this.txtPaystat.TabIndex = 76;
            this.txtPaystat.uniALT = null;
            this.txtPaystat.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPaystat.UseDynamicFormat = false;
            // 
            // txtPaystatcd
            // 
            this.txtPaystatcd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance47.TextVAlignAsString = "Bottom";
            this.txtPaystatcd.Appearance = appearance47;
            this.txtPaystatcd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtPaystatcd.Location = new System.Drawing.Point(0, 0);
            this.txtPaystatcd.LockedField = false;
            this.txtPaystatcd.Margin = new System.Windows.Forms.Padding(0);
            this.txtPaystatcd.Name = "txtPaystatcd";
            this.txtPaystatcd.QueryIfEnterKeyPressed = true;
            this.txtPaystatcd.RequiredField = false;
            this.txtPaystatcd.Size = new System.Drawing.Size(51, 26);
            this.txtPaystatcd.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtPaystatcd.StyleSetName = "Default";
            this.txtPaystatcd.TabIndex = 75;
            this.txtPaystatcd.uniALT = null;
            this.txtPaystatcd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPaystatcd.UseDynamicFormat = false;
            // 
            // lblLocal
            // 
            appearance48.TextHAlignAsString = "Left";
            appearance48.TextVAlignAsString = "Middle";
            this.lblLocal.Appearance = appearance48;
            this.lblLocal.AutoPopupID = null;
            this.lblLocal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLocal.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblLocal.Location = new System.Drawing.Point(503, 144);
            this.lblLocal.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblLocal.Name = "lblLocal";
            this.lblLocal.Size = new System.Drawing.Size(121, 22);
            this.lblLocal.StyleSetName = "Default";
            this.lblLocal.TabIndex = 33;
            this.lblLocal.Text = "S/O Amt(Local)";
            this.lblLocal.UseMnemonic = false;
            // 
            // lblReceipt
            // 
            appearance49.TextHAlignAsString = "Left";
            appearance49.TextVAlignAsString = "Middle";
            this.lblReceipt.Appearance = appearance49;
            this.lblReceipt.AutoPopupID = null;
            this.lblReceipt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReceipt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReceipt.Location = new System.Drawing.Point(503, 167);
            this.lblReceipt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReceipt.Name = "lblReceipt";
            this.lblReceipt.Size = new System.Drawing.Size(121, 22);
            this.lblReceipt.StyleSetName = "Default";
            this.lblReceipt.TabIndex = 34;
            this.lblReceipt.Text = "Receipt Type";
            this.lblReceipt.UseMnemonic = false;
            // 
            // lblVat
            // 
            appearance50.TextHAlignAsString = "Left";
            appearance50.TextVAlignAsString = "Middle";
            this.lblVat.Appearance = appearance50;
            this.lblVat.AutoPopupID = null;
            this.lblVat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVat.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblVat.Location = new System.Drawing.Point(503, 190);
            this.lblVat.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblVat.Name = "lblVat";
            this.lblVat.Size = new System.Drawing.Size(121, 22);
            this.lblVat.StyleSetName = "Default";
            this.lblVat.TabIndex = 35;
            this.lblVat.Text = "VAT Type";
            this.lblVat.UseMnemonic = false;
            // 
            // txtNetAmtLoc
            // 
            this.txtNetAmtLoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtNetAmtLoc.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtNetAmtLoc.Location = new System.Drawing.Point(624, 143);
            this.txtNetAmtLoc.LockedField = false;
            this.txtNetAmtLoc.Margin = new System.Windows.Forms.Padding(0);
            this.txtNetAmtLoc.Name = "txtNetAmtLoc";
            this.txtNetAmtLoc.Nullable = true;
            this.txtNetAmtLoc.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.txtNetAmtLoc.QueryIfEnterKeyPressed = true;
            this.txtNetAmtLoc.RequiredField = false;
            this.txtNetAmtLoc.Size = new System.Drawing.Size(140, 26);
            this.txtNetAmtLoc.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.txtNetAmtLoc.StyleSetName = "Default";
            this.txtNetAmtLoc.TabIndex = 59;
            this.txtNetAmtLoc.uniALT = "S/O Amt(Local)";
            this.txtNetAmtLoc.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.UserDefined9;
            this.txtNetAmtLoc.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtNetAmtLoc.Value = null;
            // 
            // popPayType
            // 
            this.popPayType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPayType.AutoPopupCodeParameter = null;
            this.popPayType.AutoPopupID = null;
            this.popPayType.AutoPopupNameParameter = null;
            this.popPayType.CodeMaxLength = 5;
            this.popPayType.CodeName = "";
            this.popPayType.CodeSize = 100;
            this.popPayType.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPayType.CodeTextBoxName = null;
            this.popPayType.CodeValue = "";
            this.popPayType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popPayType.Location = new System.Drawing.Point(624, 168);
            this.popPayType.LockedField = false;
            this.popPayType.Margin = new System.Windows.Forms.Padding(0);
            this.popPayType.Name = "popPayType";
            this.popPayType.NameDisplay = true;
            this.popPayType.NameId = null;
            this.popPayType.NameMaxLength = 40;
            this.popPayType.NamePopup = false;
            this.popPayType.NameSize = 150;
            this.popPayType.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPayType.Parameter = null;
            this.popPayType.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPayType.PopupId = null;
            this.popPayType.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPayType.QueryIfEnterKeyPressed = true;
            this.popPayType.RequiredField = false;
            this.popPayType.Size = new System.Drawing.Size(264, 21);
            this.popPayType.TabIndex = 15;
            this.popPayType.uniALT = "Receipt Type";
            this.popPayType.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPayType.UseDynamicFormat = false;
            this.popPayType.ValueTextBoxName = null;
            this.popPayType.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPayType_BeforePopupOpen);
            this.popPayType.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPayType_AfterPopupClosed);
            // 
            // popVatType
            // 
            this.popVatType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popVatType.AutoPopupCodeParameter = null;
            this.popVatType.AutoPopupID = null;
            this.popVatType.AutoPopupNameParameter = null;
            this.popVatType.CodeMaxLength = 5;
            this.popVatType.CodeName = "";
            this.popVatType.CodeSize = 100;
            this.popVatType.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popVatType.CodeTextBoxName = null;
            this.popVatType.CodeValue = "";
            this.popVatType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popVatType.Location = new System.Drawing.Point(624, 191);
            this.popVatType.LockedField = false;
            this.popVatType.Margin = new System.Windows.Forms.Padding(0);
            this.popVatType.Name = "popVatType";
            this.popVatType.NameDisplay = true;
            this.popVatType.NameId = null;
            this.popVatType.NameMaxLength = 40;
            this.popVatType.NamePopup = false;
            this.popVatType.NameSize = 150;
            this.popVatType.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popVatType.Parameter = null;
            this.popVatType.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popVatType.PopupId = null;
            this.popVatType.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popVatType.QueryIfEnterKeyPressed = true;
            this.popVatType.RequiredField = false;
            this.popVatType.Size = new System.Drawing.Size(264, 21);
            this.popVatType.TabIndex = 17;
            this.popVatType.uniALT = "VAT Type";
            this.popVatType.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popVatType.UseDynamicFormat = false;
            this.popVatType.ValueTextBoxName = null;
            this.popVatType.OnChange += new System.EventHandler(this.popVatType_OnChange);
            this.popVatType.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popVatType_BeforePopupOpen);
            this.popVatType.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popVatType_AfterPopupClosed);
            // 
            // lblInclusion
            // 
            appearance51.TextHAlignAsString = "Left";
            appearance51.TextVAlignAsString = "Middle";
            this.lblInclusion.Appearance = appearance51;
            this.lblInclusion.AutoPopupID = null;
            this.lblInclusion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInclusion.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblInclusion.Location = new System.Drawing.Point(503, 213);
            this.lblInclusion.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblInclusion.Name = "lblInclusion";
            this.lblInclusion.Size = new System.Drawing.Size(121, 22);
            this.lblInclusion.StyleSetName = "Default";
            this.lblInclusion.TabIndex = 36;
            this.lblInclusion.Text = "VAT inclusion ID";
            this.lblInclusion.UseMnemonic = false;
            // 
            // lblVatAmt
            // 
            appearance52.TextHAlignAsString = "Left";
            appearance52.TextVAlignAsString = "Middle";
            this.lblVatAmt.Appearance = appearance52;
            this.lblVatAmt.AutoPopupID = null;
            this.lblVatAmt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVatAmt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblVatAmt.Location = new System.Drawing.Point(503, 236);
            this.lblVatAmt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblVatAmt.Name = "lblVatAmt";
            this.lblVatAmt.Size = new System.Drawing.Size(121, 22);
            this.lblVatAmt.StyleSetName = "Default";
            this.lblVatAmt.TabIndex = 37;
            this.lblVatAmt.Text = "VAT Amt.";
            this.lblVatAmt.UseMnemonic = false;
            // 
            // lblState
            // 
            appearance53.TextHAlignAsString = "Left";
            appearance53.TextVAlignAsString = "Middle";
            this.lblState.Appearance = appearance53;
            this.lblState.AutoPopupID = null;
            this.lblState.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblState.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblState.Location = new System.Drawing.Point(503, 259);
            this.lblState.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(121, 22);
            this.lblState.StyleSetName = "Default";
            this.lblState.TabIndex = 38;
            this.lblState.Text = "Project State";
            this.lblState.UseMnemonic = false;
            // 
            // lblOutline
            // 
            appearance54.TextHAlignAsString = "Left";
            appearance54.TextVAlignAsString = "Middle";
            this.lblOutline.Appearance = appearance54;
            this.lblOutline.AutoPopupID = null;
            this.lblOutline.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOutline.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblOutline.Location = new System.Drawing.Point(503, 282);
            this.lblOutline.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblOutline.Name = "lblOutline";
            this.lblOutline.Size = new System.Drawing.Size(121, 22);
            this.lblOutline.StyleSetName = "Default";
            this.lblOutline.TabIndex = 39;
            this.lblOutline.Text = "Outline";
            this.lblOutline.UseMnemonic = false;
            // 
            // cboVatIncFlag
            // 
            this.cboVatIncFlag.AddEmptyRow = false;
            this.cboVatIncFlag.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboVatIncFlag.ComboFrom = "";
            this.cboVatIncFlag.ComboMajorCd = "S4035";
            this.cboVatIncFlag.ComboSelect = "";
            this.cboVatIncFlag.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboVatIncFlag.ComboWhere = "";
            this.cboVatIncFlag.DropDownListWidth = -1;
            this.cboVatIncFlag.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboVatIncFlag.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.cboVatIncFlag.Location = new System.Drawing.Point(624, 212);
            this.cboVatIncFlag.LockedField = false;
            this.cboVatIncFlag.Margin = new System.Windows.Forms.Padding(0);
            this.cboVatIncFlag.Name = "cboVatIncFlag";
            this.cboVatIncFlag.RequiredField = false;
            this.cboVatIncFlag.Size = new System.Drawing.Size(144, 26);
            this.cboVatIncFlag.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboVatIncFlag.StyleSetName = "Default";
            this.cboVatIncFlag.TabIndex = 19;
            this.cboVatIncFlag.uniALT = "VAT inclusion ID";
            // 
            // numVatAmt
            // 
            this.numVatAmt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numVatAmt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.numVatAmt.Location = new System.Drawing.Point(624, 235);
            this.numVatAmt.LockedField = false;
            this.numVatAmt.Margin = new System.Windows.Forms.Padding(0);
            this.numVatAmt.Name = "numVatAmt";
            this.numVatAmt.Nullable = true;
            this.numVatAmt.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numVatAmt.QueryIfEnterKeyPressed = true;
            this.numVatAmt.RequiredField = false;
            this.numVatAmt.Size = new System.Drawing.Size(140, 26);
            this.numVatAmt.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numVatAmt.StyleSetName = "Default";
            this.numVatAmt.TabIndex = 21;
            this.numVatAmt.uniALT = "VAT Amt";
            this.numVatAmt.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.UserDefined9;
            this.numVatAmt.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numVatAmt.Value = null;
            // 
            // txtState
            // 
            this.txtState.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance55.TextVAlignAsString = "Bottom";
            this.txtState.Appearance = appearance55;
            this.txtState.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtState.Location = new System.Drawing.Point(624, 258);
            this.txtState.LockedField = false;
            this.txtState.Margin = new System.Windows.Forms.Padding(0);
            this.txtState.MaxLength = 15;
            this.txtState.Name = "txtState";
            this.txtState.QueryIfEnterKeyPressed = true;
            this.txtState.RequiredField = false;
            this.txtState.Size = new System.Drawing.Size(100, 26);
            this.txtState.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtState.StyleSetName = "Default";
            this.txtState.TabIndex = 55;
            this.txtState.uniALT = "Project State";
            this.txtState.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtState.UseDynamicFormat = false;
            // 
            // txtDescription
            // 
            this.txtDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance56.TextVAlignAsString = "Bottom";
            this.txtDescription.Appearance = appearance56;
            this.txtDescription.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.txtDescription.Location = new System.Drawing.Point(624, 281);
            this.txtDescription.LockedField = false;
            this.txtDescription.Margin = new System.Windows.Forms.Padding(0);
            this.txtDescription.MaxLength = 120;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.QueryIfEnterKeyPressed = true;
            this.txtDescription.RequiredField = false;
            this.txtDescription.Size = new System.Drawing.Size(200, 26);
            this.txtDescription.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.txtDescription.StyleSetName = "Default";
            this.txtDescription.TabIndex = 25;
            this.txtDescription.uniALT = "Outline";
            this.txtDescription.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtDescription.UseDynamicFormat = false;
            // 
            // lblSubGoods
            // 
            appearance57.TextHAlignAsString = "Left";
            appearance57.TextVAlignAsString = "Middle";
            this.lblSubGoods.Appearance = appearance57;
            this.lblSubGoods.AutoPopupID = null;
            this.lblSubGoods.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSubGoods.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSubGoods.Location = new System.Drawing.Point(503, 466);
            this.lblSubGoods.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSubGoods.Name = "lblSubGoods";
            this.lblSubGoods.Size = new System.Drawing.Size(121, 22);
            this.lblSubGoods.StyleSetName = "Default";
            this.lblSubGoods.TabIndex = 90;
            this.lblSubGoods.Text = "도급품(자국)";
            this.lblSubGoods.UseMnemonic = false;
            // 
            // lblCostCom
            // 
            appearance58.TextHAlignAsString = "Left";
            appearance58.TextVAlignAsString = "Middle";
            this.lblCostCom.Appearance = appearance58;
            this.lblCostCom.AutoPopupID = null;
            this.lblCostCom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCostCom.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCostCom.Location = new System.Drawing.Point(503, 489);
            this.lblCostCom.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCostCom.Name = "lblCostCom";
            this.lblCostCom.Size = new System.Drawing.Size(121, 22);
            this.lblCostCom.StyleSetName = "Default";
            this.lblCostCom.TabIndex = 91;
            this.lblCostCom.Text = "자사 재료비(자국)";
            this.lblCostCom.UseMnemonic = false;
            // 
            // lblCostToT
            // 
            appearance59.TextHAlignAsString = "Left";
            appearance59.TextVAlignAsString = "Middle";
            this.lblCostToT.Appearance = appearance59;
            this.lblCostToT.AutoPopupID = null;
            this.lblCostToT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCostToT.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCostToT.Location = new System.Drawing.Point(503, 512);
            this.lblCostToT.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCostToT.Name = "lblCostToT";
            this.lblCostToT.Size = new System.Drawing.Size(121, 22);
            this.lblCostToT.StyleSetName = "Default";
            this.lblCostToT.TabIndex = 92;
            this.lblCostToT.Text = "총재료비(자국)";
            this.lblCostToT.UseMnemonic = false;
            // 
            // txtCostCom
            // 
            this.txtCostCom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtCostCom.Enabled = false;
            this.txtCostCom.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.txtCostCom.Location = new System.Drawing.Point(624, 488);
            this.txtCostCom.LockedField = false;
            this.txtCostCom.Margin = new System.Windows.Forms.Padding(0);
            this.txtCostCom.Name = "txtCostCom";
            this.txtCostCom.Nullable = true;
            this.txtCostCom.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.txtCostCom.QueryIfEnterKeyPressed = true;
            this.txtCostCom.RequiredField = false;
            this.txtCostCom.Size = new System.Drawing.Size(140, 26);
            this.txtCostCom.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.txtCostCom.StyleSetName = "Default";
            this.txtCostCom.TabIndex = 94;
            this.txtCostCom.uniALT = "VAT Amt";
            this.txtCostCom.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.UserDefined9;
            this.txtCostCom.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCostCom.Value = null;
            // 
            // txtCostToT
            // 
            this.txtCostToT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtCostToT.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtCostToT.Location = new System.Drawing.Point(624, 511);
            this.txtCostToT.LockedField = false;
            this.txtCostToT.Margin = new System.Windows.Forms.Padding(0);
            this.txtCostToT.Name = "txtCostToT";
            this.txtCostToT.Nullable = true;
            this.txtCostToT.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.txtCostToT.QueryIfEnterKeyPressed = true;
            this.txtCostToT.RequiredField = false;
            this.txtCostToT.Size = new System.Drawing.Size(140, 26);
            this.txtCostToT.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.txtCostToT.StyleSetName = "Default";
            this.txtCostToT.TabIndex = 95;
            this.txtCostToT.uniALT = "VAT Amt";
            this.txtCostToT.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.UserDefined9;
            this.txtCostToT.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCostToT.Value = null;
            // 
            // txtSubGoods
            // 
            this.txtSubGoods.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtSubGoods.Enabled = false;
            this.txtSubGoods.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.txtSubGoods.Location = new System.Drawing.Point(624, 465);
            this.txtSubGoods.LockedField = false;
            this.txtSubGoods.Margin = new System.Windows.Forms.Padding(0);
            this.txtSubGoods.Name = "txtSubGoods";
            this.txtSubGoods.Nullable = true;
            this.txtSubGoods.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.txtSubGoods.QueryIfEnterKeyPressed = true;
            this.txtSubGoods.RequiredField = false;
            this.txtSubGoods.Size = new System.Drawing.Size(140, 26);
            this.txtSubGoods.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.txtSubGoods.StyleSetName = "Default";
            this.txtSubGoods.TabIndex = 93;
            this.txtSubGoods.uniALT = "VAT Amt";
            this.txtSubGoods.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.UserDefined9;
            this.txtSubGoods.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtSubGoods.Value = null;
            // 
            // uniCheckBox1
            // 
            this.uniCheckBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.uniCheckBox1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.uniCheckBox1.Location = new System.Drawing.Point(624, 538);
            this.uniCheckBox1.LockedField = false;
            this.uniCheckBox1.Margin = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.uniCheckBox1.Name = "uniCheckBox1";
            this.uniCheckBox1.RequiredField = false;
            this.uniCheckBox1.Size = new System.Drawing.Size(140, 19);
            this.uniCheckBox1.StyleSetName = "Default";
            this.uniCheckBox1.TabIndex = 96;
            this.uniCheckBox1.Text = "재료비 입력";
            this.uniCheckBox1.uniALT = null;
            this.uniCheckBox1.CheckedChanged += new System.EventHandler(this.uniCheckBox1_CheckedChanged);
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.lblProject, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popProjectCode1, 1, 0);
            this.uniTBL_MainCondition.DefaultRowSize = 25;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 1;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(978, 38);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 0;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblProject
            // 
            appearance60.TextHAlignAsString = "Left";
            appearance60.TextVAlignAsString = "Middle";
            this.lblProject.Appearance = appearance60;
            this.lblProject.AutoPopupID = null;
            this.lblProject.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProject.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProject.Location = new System.Drawing.Point(15, 6);
            this.lblProject.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProject.Name = "lblProject";
            this.lblProject.Size = new System.Drawing.Size(121, 22);
            this.lblProject.StyleSetName = "Default";
            this.lblProject.TabIndex = 0;
            this.lblProject.Text = "Project";
            this.lblProject.UseMnemonic = false;
            // 
            // popProjectCode1
            // 
            this.popProjectCode1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popProjectCode1.AutoPopupCodeParameter = null;
            this.popProjectCode1.AutoPopupID = null;
            this.popProjectCode1.AutoPopupNameParameter = null;
            this.popProjectCode1.CodeMaxLength = 25;
            this.popProjectCode1.CodeName = "";
            this.popProjectCode1.CodeSize = 150;
            this.popProjectCode1.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProjectCode1.CodeTextBoxName = null;
            this.popProjectCode1.CodeValue = "";
            this.popProjectCode1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popProjectCode1.Location = new System.Drawing.Point(136, 7);
            this.popProjectCode1.LockedField = false;
            this.popProjectCode1.Margin = new System.Windows.Forms.Padding(0);
            this.popProjectCode1.Name = "popProjectCode1";
            this.popProjectCode1.NameDisplay = true;
            this.popProjectCode1.NameId = null;
            this.popProjectCode1.NameMaxLength = 120;
            this.popProjectCode1.NamePopup = false;
            this.popProjectCode1.NameSize = 150;
            this.popProjectCode1.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProjectCode1.Parameter = null;
            this.popProjectCode1.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popProjectCode1.PopupId = null;
            this.popProjectCode1.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popProjectCode1.QueryIfEnterKeyPressed = true;
            this.popProjectCode1.RequiredField = false;
            this.popProjectCode1.Size = new System.Drawing.Size(321, 21);
            this.popProjectCode1.TabIndex = 0;
            this.popProjectCode1.uniALT = "Project";
            this.popProjectCode1.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popProjectCode1.UseDynamicFormat = false;
            this.popProjectCode1.ValueTextBoxName = null;
            this.popProjectCode1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popProjectCode1_BeforePopupOpen);
            this.popProjectCode1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popProjectCode1_AfterPopupClosed);
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.Controls.Add(this.lblEstimateRef, 2, 0);
            this.uniTBL_MainReference.Controls.Add(this.lblChange, 1, 0);
            this.uniTBL_MainReference.DefaultRowSize = 25;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(978, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblEstimateRef
            // 
            appearance61.TextHAlignAsString = "Left";
            appearance61.TextVAlignAsString = "Middle";
            this.lblEstimateRef.Appearance = appearance61;
            this.lblEstimateRef.AutoPopupID = null;
            this.lblEstimateRef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEstimateRef.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblEstimateRef.Location = new System.Drawing.Point(878, 3);
            this.lblEstimateRef.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblEstimateRef.Name = "lblEstimateRef";
            this.lblEstimateRef.Size = new System.Drawing.Size(100, 15);
            this.lblEstimateRef.StyleSetName = "uniLabel_Reference";
            this.lblEstimateRef.TabIndex = 1;
            this.lblEstimateRef.Text = "Estimate Ref.";
            this.lblEstimateRef.UseMnemonic = false;
            this.lblEstimateRef.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblEstimateRef_BeforePopupOpen);
            this.lblEstimateRef.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblEstimateRef_AfterPopupClosed);
            // 
            // lblChange
            // 
            appearance62.TextHAlignAsString = "Left";
            appearance62.TextVAlignAsString = "Middle";
            this.lblChange.Appearance = appearance62;
            this.lblChange.AutoPopupID = null;
            this.lblChange.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblChange.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblChange.Location = new System.Drawing.Point(778, 3);
            this.lblChange.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(100, 15);
            this.lblChange.StyleSetName = "uniLabel_Reference";
            this.lblChange.TabIndex = 0;
            this.lblChange.Text = "Change History";
            this.lblChange.UseMnemonic = false;
            this.lblChange.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblChange_BeforePopupOpen);
            this.lblChange.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblChange_AfterPopupClosed);
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 8;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.uniTBL_MainBatch.Controls.Add(this.btnApprovalpro, 3, 0);
            this.uniTBL_MainBatch.Controls.Add(this.lblRegstration, 6, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnApproval, 2, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnPrint, 1, 0);
            this.uniTBL_MainBatch.Controls.Add(this.lblCompose, 7, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnPriview, 0, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnCancel, 4, 0);
            this.uniTBL_MainBatch.DefaultRowSize = 25;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 707);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(978, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnApprovalpro
            // 
            this.btnApprovalpro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnApprovalpro.AutoPopupID = null;
            this.btnApprovalpro.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnApprovalpro.Location = new System.Drawing.Point(289, 2);
            this.btnApprovalpro.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnApprovalpro.Name = "btnApprovalpro";
            this.btnApprovalpro.PopupID = null;
            this.btnApprovalpro.Size = new System.Drawing.Size(107, 23);
            this.btnApprovalpro.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnApprovalpro.TabIndex = 73;
            this.btnApprovalpro.Text = "결재(진행사항)";
            this.btnApprovalpro.UserDefinedText = null;
            this.btnApprovalpro.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.btnApprovalpro_BeforePopupOpen);
            // 
            // lblRegstration
            // 
            appearance63.TextHAlignAsString = "Left";
            appearance63.TextVAlignAsString = "Middle";
            this.lblRegstration.Appearance = appearance63;
            this.lblRegstration.AutoPopupID = null;
            this.lblRegstration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRegstration.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Jump;
            this.lblRegstration.Location = new System.Drawing.Point(678, 3);
            this.lblRegstration.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblRegstration.Name = "lblRegstration";
            this.lblRegstration.Size = new System.Drawing.Size(150, 22);
            this.lblRegstration.StyleSetName = "uniLabel_Jump";
            this.lblRegstration.TabIndex = 0;
            this.lblRegstration.Text = "Project resource regstration";
            this.lblRegstration.UseMnemonic = false;
            // 
            // btnApproval
            // 
            this.btnApproval.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnApproval.AutoPopupID = null;
            this.btnApproval.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnApproval.Location = new System.Drawing.Point(179, 2);
            this.btnApproval.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnApproval.Name = "btnApproval";
            this.btnApproval.PopupID = null;
            this.btnApproval.Size = new System.Drawing.Size(107, 23);
            this.btnApproval.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnApproval.TabIndex = 72;
            this.btnApproval.Text = "결재상신";
            this.btnApproval.UserDefinedText = null;
            this.btnApproval.Click += new System.EventHandler(this.btnApproval_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPrint.AutoPopupID = null;
            this.btnPrint.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnPrint.Location = new System.Drawing.Point(100, 2);
            this.btnPrint.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.PopupID = null;
            this.btnPrint.Size = new System.Drawing.Size(76, 23);
            this.btnPrint.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnPrint.TabIndex = 70;
            this.btnPrint.Text = "출력";
            this.btnPrint.UserDefinedText = null;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblCompose
            // 
            appearance64.TextHAlignAsString = "Left";
            appearance64.TextVAlignAsString = "Middle";
            this.lblCompose.Appearance = appearance64;
            this.lblCompose.AutoPopupID = null;
            this.lblCompose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompose.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Jump;
            this.lblCompose.Location = new System.Drawing.Point(828, 3);
            this.lblCompose.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblCompose.Name = "lblCompose";
            this.lblCompose.Size = new System.Drawing.Size(150, 22);
            this.lblCompose.StyleSetName = "uniLabel_Jump";
            this.lblCompose.TabIndex = 1;
            this.lblCompose.Text = "Project Compose";
            this.lblCompose.UseMnemonic = false;
            // 
            // btnPriview
            // 
            this.btnPriview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPriview.AutoPopupID = null;
            this.btnPriview.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnPriview.Location = new System.Drawing.Point(0, 2);
            this.btnPriview.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnPriview.Name = "btnPriview";
            this.btnPriview.PopupID = null;
            this.btnPriview.Size = new System.Drawing.Size(97, 23);
            this.btnPriview.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnPriview.TabIndex = 81;
            this.btnPriview.Text = "미리보기";
            this.btnPriview.UserDefinedText = null;
            this.btnPriview.Click += new System.EventHandler(this.btnPriview_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.AutoPopupID = null;
            this.btnCancel.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnCancel.Location = new System.Drawing.Point(399, 1);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.PopupID = null;
            this.btnCancel.Size = new System.Drawing.Size(107, 24);
            this.btnCancel.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnCancel.TabIndex = 82;
            this.btnCancel.Text = "상신취소";
            this.btnCancel.UserDefinedText = null;
            this.btnCancel.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.btnCancel_BeforePopupOpen);
            this.btnCancel.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.btnCancel_AfterPopupClosed);
            // 
            // uniTableLayoutPanel2
            // 
            this.uniTableLayoutPanel2.AutoFit = false;
            this.uniTableLayoutPanel2.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel2.AutoFitRowCount = 4;
            this.uniTableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel2.ColumnCount = 4;
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.27273F));
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.89773F));
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.875F));
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.95454F));
            this.uniTableLayoutPanel2.Controls.Add(this.uniButton2, 0, 0);
            this.uniTableLayoutPanel2.DefaultRowSize = 23;
            this.uniTableLayoutPanel2.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.uniTableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel2.Name = "uniTableLayoutPanel2";
            this.uniTableLayoutPanel2.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTableLayoutPanel2.RowCount = 1;
            this.uniTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTableLayoutPanel2.Size = new System.Drawing.Size(200, 100);
            this.uniTableLayoutPanel2.SizeTD5 = 14F;
            this.uniTableLayoutPanel2.SizeTD6 = 36F;
            this.uniTableLayoutPanel2.TabIndex = 0;
            this.uniTableLayoutPanel2.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel2.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniButton2
            // 
            this.uniButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.uniButton2.AutoPopupID = null;
            this.uniButton2.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.uniButton2.Location = new System.Drawing.Point(0, 74);
            this.uniButton2.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.uniButton2.Name = "uniButton2";
            this.uniButton2.PopupID = null;
            this.uniButton2.Size = new System.Drawing.Size(51, 23);
            this.uniButton2.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.uniButton2.TabIndex = 81;
            this.uniButton2.Text = "미리보기";
            this.uniButton2.UserDefinedText = null;
            // 
            // uniButton3
            // 
            this.uniButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.uniButton3.AutoPopupID = null;
            this.uniButton3.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.uniButton3.Location = new System.Drawing.Point(96, 1);
            this.uniButton3.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.uniButton3.Name = "uniButton3";
            this.uniButton3.PopupID = null;
            this.uniButton3.Size = new System.Drawing.Size(60, 2);
            this.uniButton3.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.uniButton3.TabIndex = 70;
            this.uniButton3.Text = "출력";
            this.uniButton3.UserDefinedText = null;
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(990, 760);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            this.uniTBL_MainData.PerformLayout();
            this.tbl1.ResumeLayout(false);
            this.tbl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPrjType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDlvyDt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimateDegreeForm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRevenue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoGroupPrjFlg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboProjectType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboProjectType1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXchRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVatRate)).EndInit();
            this.tbl2.ResumeLayout(false);
            this.tbl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNetAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCusmng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCusmngnum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCusmngdept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboBaljugb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtBaljudt)).EndInit();
            this.popReqman.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).EndInit();
            this.popCsmng.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_c2f684bf_1215_43eb_bceb_14274d5879ed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68)).EndInit();
            this.uniTableLayoutPanel1.ResumeLayout(false);
            this.uniTableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaystat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaystatcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNetAmtLoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboVatIncFlag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVatAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDescription)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCostCom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCostToT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubGoods)).EndInit();
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainReference.ResumeLayout(false);
            this.uniTBL_MainBatch.ResumeLayout(false);
            this.uniTableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProject;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popProjectCode1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblChange;
        private uniERP.AppFramework.UI.Controls.uniLabel lblEstimateRef;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCompose;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel2;
        private uniERP.AppFramework.UI.Controls.uniButton uniButton2;
        private uniERP.AppFramework.UI.Controls.uniButton uniButton3;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCode;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDegree;
        private uniERP.AppFramework.UI.Controls.uniLabel lblType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDeliveryDate;
        private uniERP.AppFramework.UI.Controls.uniLabel lblManager;
        private uniERP.AppFramework.UI.Controls.uniLabel lblName;
        private uniERP.AppFramework.UI.Controls.uniLabel lblGroup;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPayMethod;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRate;
        private uniERP.AppFramework.UI.Controls.uniLabel lblVatRate;
        private uniERP.AppFramework.UI.Controls.uniLabel lblComparison;
        private uniERP.AppFramework.UI.Controls.uniLabel lblFlag;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectCode;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel tbl1;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtProjectCode;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtVer;
        private uniERP.AppFramework.UI.Controls.uniCombo cboPrjType;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtDlvyDt;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPmResourceCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popBpCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSalesGrp;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPayMeth;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtEstimateDegreeForm;
        private uniERP.AppFramework.UI.Controls.uniCombo cboRevenue;
        private uniERP.AppFramework.UI.Controls.uniRadioButton rdoGroupPrjFlg;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popGroupPrjCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectName;
        private uniERP.AppFramework.UI.Controls.uniLabel lblEstimateNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectPeriod;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectType1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCurrency;
        private uniERP.AppFramework.UI.Controls.uniLabel lblLocal;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReceipt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblVat;
        private uniERP.AppFramework.UI.Controls.uniLabel lblInclusion;
        private uniERP.AppFramework.UI.Controls.uniLabel lblVatAmt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblState;
        private uniERP.AppFramework.UI.Controls.uniLabel lblOutline;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtProjectNm;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtEstimate;
        private uniERP.AppFramework.UI.Controls.uniDateTerm dtPlanStartDt;
        private uniERP.AppFramework.UI.Controls.uniCombo cboProjectType;
        private uniERP.AppFramework.UI.Controls.uniCombo cboProjectType1;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPayType;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popVatType;
        private uniERP.AppFramework.UI.Controls.uniCombo cboVatIncFlag;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtDescription;
        private uniERP.AppFramework.UI.Controls.uniNumeric numXchRate;
        private uniERP.AppFramework.UI.Controls.uniNumeric numVatRate;
        private uniERP.AppFramework.UI.Controls.uniNumeric numVatAmt;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel tbl2;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popCurrency;
        private uniERP.AppFramework.UI.Controls.uniNumeric numNetAmt;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtState;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtRemark;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRemark;
        private uniERP.AppFramework.UI.Controls.uniNumeric txtNetAmtLoc;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSulgye;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBaljugb;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReqman;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCusmng;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCusmngnum;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCsmng;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBaljudt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPaystat;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCusmngdept;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtCusmng;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtCusmngnum;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtCusmngdept;
        private uniERP.AppFramework.UI.Controls.uniCombo cboBaljugb;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtBaljudt;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSulgye;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popReqman;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Name;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Code;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popCsmng;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_c2f684bf_1215_43eb_bceb_14274d5879ed;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_c1315b5b_1fbd_42ca_9ea5_ba4756807c68;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel1;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtPaystat;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtPaystatcd;
        private uniERP.AppFramework.UI.Controls.uniButton btnApprovalpro;
        private uniERP.AppFramework.UI.Controls.uniButton btnPrint;
        private uniERP.AppFramework.UI.Controls.uniButton btnApproval;
        private uniERP.AppFramework.UI.Controls.uniButton btnPriview;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRegstration;
        private uniERP.AppFramework.UI.Controls.uniButton btnCancel;
        private AppFramework.UI.Controls.uniLabel lblSubGoods;
        private AppFramework.UI.Controls.uniLabel lblCostCom;
        private AppFramework.UI.Controls.uniLabel lblCostToT;
        private AppFramework.UI.Controls.uniNumeric txtSubGoods;
        private AppFramework.UI.Controls.uniNumeric txtCostCom;
        private AppFramework.UI.Controls.uniNumeric txtCostToT;
        private AppFramework.UI.Controls.uniCheckBox uniCheckBox1;

    }
}
