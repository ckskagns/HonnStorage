
/*******************************************************************************************/
/*****   TABLE NAME   : S_SHIPPING_INFOR_KO883                                         *****/
/*****   OWNER        : ����	                                                       *****/
/*****   CREATE DATE  : 2018-06-01                                                     *****/
/*****   DESCRIPTION  : 1. ��������(��ǰ)���                                          *****/
/*****                  2. ���� :                                                      *****/
/*****                  3. ����ȭ�� : CS�������							           *****/
/*****   MODIFIED BY   : ������                                                        *****/
/*****   MODIFIED DATE : 2018-06-01                                                    *****/
/*****   VERSION       : 20180601LGP: ���ʹݿ�                                         *****/
/*****                 :									                           *****/
/*******************************************************************************************/
IF EXISTS (SELECT *
             FROM dbo.sysobjects
            WHERE id = object_id(N'[dbo].[S_SHIPPING_INFOR_KO883]')
              AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[S_SHIPPING_INFOR_KO883]
GO

CREATE TABLE [dbo].[S_SHIPPING_INFOR_KO883](
	[SERIAL_NO] [nvarchar](50) NOT NULL,    -- Serial No
	[PLANT_CD] [nvarchar](20) NOT NULL,		-- ����
	[ITEM_CD] [nvarchar](50) NOT NULL,		-- ǰ��
	[UNIT_CD] [nvarchar](10) NOT NULL,		-- ����
	[BP_CD] [nvarchar](10) NOT NULL,		-- ������
	[ISSUE_DT] [datetime] NOT NULL,			-- �����
	[PROJECT_CODE] [nvarchar](25) NOT NULL, -- Project No
	[TRACKING_NO] [nvarchar](25) NOT NULL,  -- Tracking No
	[LOCATION] [nvarchar](200) NOT NULL,    -- LOCATION
	[WAR_FR_DT] [datetime] NULL,			-- Warranty �Ⱓ(From)
	[WAR_TO_DT] [datetime] NULL,			-- Warranty �Ⱓ(TO)
	[CON_FR_DT] [datetime] NULL,			-- �������� �Ⱓ(From)
	[CON_TO_DT] [datetime] NULL,			-- �������� �Ⱓ(TO)
	[SETUP_REQ_DT] [datetime] NULL,         -- SETUP ��û��
	[SETUP_PRN] [nvarchar](100) NULL,		-- SETUP ���
	[SO_NO] [nvarchar](30) NULL,			-- ���ֹ�ȣ
	[SO_SEQ] [numeric](4, 0) NULL,			-- ���ּ���
	[DN_NO] [nvarchar](30) NULL,			-- ���Ϲ�ȣ
	[DN_SEQ] [numeric](4, 0) NULL,			-- ���ϼ���
	[ITEM_DOCUMENT_NO] [nvarchar](30) NULL,	-- ���ҹ�ȣ(�̵���ȣ)
	[SEQ_NO] [numeric](4, 0) NULL,			-- ���Ҽ���
	[REMARK] [nvarchar](1024) NULL,
	[INSRT_USER_ID] [nvarchar](13) NOT NULL,
	[INSRT_DT] [datetime] NOT NULL,
	[UPDT_USER_ID] [nvarchar](13) NOT NULL,
	[UPDT_DT] [datetime] NOT NULL,
	[LOCATION2] [nvarchar](200) NULL,       -- LOCATION �߰�1
	[LOCATION3] [nvarchar](200) NULL,       -- LOCATION �߰�2
	[LOCATION4] [nvarchar](200) NULL,       -- LOCATION �߰�3
	[EXT1_CD] [nvarchar](20) NULL,
	[EXT1_QTY] [numeric](18, 6) NULL,
	[EXT1_AMT] [numeric](18, 2) NULL,
	[EXT1_RT] [numeric](15, 6) NULL,
	[EXT2_CD] [nvarchar](20) NULL,
	[EXT2_QTY] [numeric](18, 6) NULL,
	[EXT2_AMT] [numeric](18, 2) NULL,
	[EXT2_RT] [numeric](15, 6) NULL,
	[EXT3_CD] [nvarchar](20) NULL,
	[EXT3_QTY] [numeric](18, 6) NULL,
	[EXT3_AMT] [numeric](18, 2) NULL,
	[EXT3_RT] [numeric](15, 6) NULL,

 CONSTRAINT [PK_S_SHIPPING_INFOR_KO883] PRIMARY KEY CLUSTERED 
(
	[SERIAL_NO] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

