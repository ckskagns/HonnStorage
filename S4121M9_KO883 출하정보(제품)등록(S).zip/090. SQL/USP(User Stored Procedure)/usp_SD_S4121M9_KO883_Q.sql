ALTER PROC dbo.usp_SD_S4121M9RE_KO883_Q          
(          
  @SERIAL_NO  NVARCHAR(25),          
  @PLANT_CD  NVARCHAR(10),          
  @ITEM_CD  NVARCHAR(50),          
  @BP_CD   NVARCHAR(10),          
  @PROJECT_CD  NVARCHAR(25),          
  @TRACKING_NO NVARCHAR(25),      
  @PROJECT_TYPE NVARCHAR(25),          
  @FR_DT   NVARCHAR(10),          
  @TO_DT   NVARCHAR(10)          
)AS          
BEGIN          
  --DECLARE @SERIAL_NO  NVARCHAR(25),          
  --  @PLANT_CD  NVARCHAR(10),          
  --  @ITEM_CD  NVARCHAR(50),          
  --  @BP_CD   NVARCHAR(10),          
  --  @PROJECT_CD  NVARCHAR(25),          
  --  @TRACKING_NO NVARCHAR(25),          
  --  @FR_DT   NVARCHAR(10),          
  --  @TO_DT   NVARCHAR(10)          
          
  --SET  @SERIAL_NO  = ''          
  --SET  @PLANT_CD  = ''          
  --SET  @ITEM_CD  = ''          
  --SET  @BP_CD   = ''          
  --SET  @PROJECT_CD  = ''          
  --SET  @TRACKING_NO = ''          
  --SET  @FR_DT   = '2018-05-01'          
  --SET  @TO_DT   = '2018-06-21'          
  SELECT  A.PLANT_CD, PL.PLANT_NM,          
     A.ITEM_CD, IT.ITEM_NM, IT.SPEC, A.UNIT_CD, A.QTY          
     , A.SERIAL_NO          
     , A.BP_CD, BP.BP_NM          
     , A.ISSUE_DT        --�����          
     , A.PROJECT_CODE       --������Ʈ��ȣ          
     , A.TRACKING_NO        --TRACKING_NO          
     , A.LOCATION        --LOCATION          
     , A.WAR_FR_DT, A.WAR_TO_DT     --Warranty �Ⱓ(FR,TO)                    
     , A.SETUP_REQ_DT       --SETUP ��û��          
     , ISNULL(A.SETUP_PRN,'') AS SETUP_PRN --SETUP �����          
     , ISNULL(A.REMARK,'')  AS REMARK  --���          
     , ISNULL(A.SO_NO, '') AS SO_NO, ISNULL(A.SO_SEQ,0) AS SO_SEQ  --���ֹ�ȣ/����          
     , ISNULL(A.DN_NO, '') AS DN_NO, ISNULL(A.DN_SEQ,0) AS DN_SEQ  --���Ϲ�ȣ/����          
     , ISNULL(A.ITEM_DOCUMENT_NO,'') AS ITEM_DOCUMENT_NO    --�̵���ȣ          
     , ISNULL(A.SEQ_NO,0)   AS SEQ_NO       --�̵���ȣ����          
     , ISNULL(A.LOCATION2, '') AS LOCATION2, ISNULL(A.LOCATION3, '') AS LOCATION3, ISNULL(A.LOCATION4, '') AS LOCATION4 --LOCATION �߰�1, �߰�2, �߰�3          
     , A.CON_FR_DT, A.CON_TO_DT     --��������Ⱓ(FR,TO)          
     , CASE A.PROJECT_TYPE -- ������Ʈ ����          
  WHEN '100' THEN '����'        
  WHEN '200' THEN '����(Conversion)'        
  WHEN '300' THEN '�ΰǺ�'        
  WHEN '400' THEN 'DEMO'        
  WHEN '500' THEN 'CS����'        
  WHEN '600' THEN 'PART'        
  WHEN '700' THEN 'Software'        
  WHEN '900' THEN '����'        
  ELSE A.PROJECT_TYPE        
  END as PROJECT_TYPE        
     , A.SETUP_REQ_DT -- SETUP������          
     , A.SETUP_DATE --SETUP�Ⱓ(��)    
  , A.SETUP_REQ_DT + A.SETUP_DATE as SETUP_END_TEMP          
     , A.SETUP_END_DT --SETUP�Ϸ��ǥ��          
     , A.MBO_DT  --MBO�Ϸ���          
     , A.FAT_DT  --FAT�Ϸ���
	 , A.SERIAL_SUB          
     , A.WAR_MONTH --Warranty�Ⱓ(��)          
               
          
  FROM  S_SHIPPING_INFOR_KO883 A(NOLOCK)          
  INNER JOIN B_PLANT     PL(NOLOCK) ON A.PLANT_CD = PL.PLANT_CD          
  INNER JOIN B_ITEM     IT(NOLOCK) ON A.ITEM_CD = IT.ITEM_CD          
  INNER JOIN B_BIZ_PARTNER   BP(NOLOCK) ON A.BP_CD = BP.BP_CD          
          
  WHERE  1 = 1          
  AND   ( @SERIAL_NO = '' OR A.SERIAL_NO = @SERIAL_NO )          
  AND   ( @PLANT_CD  = '' OR A.PLANT_CD = @PLANT_CD )          
  AND   ( @ITEM_CD  = '' OR A.ITEM_CD = @ITEM_CD )          
  AND   ( @BP_CD  = '' OR A.BP_CD = @BP_CD )          
  AND   ( @PROJECT_CD = '' OR A.PROJECT_CODE = @PROJECT_CD )          
  AND   ( @TRACKING_NO = '' OR A.SERIAL_NO = @TRACKING_NO )      
  AND   ( @PROJECT_TYPE = '' OR       
   A.PROJECT_TYPE =   
   CASE @PROJECT_TYPE      
   WHEN '����' THEN '100'      
   WHEN '����(Conversion)' THEN '200'      
   WHEN '�ΰǺ�' THEN '300'      
   WHEN 'DEMO' THEN '400'      
   WHEN 'CS����' THEN '500'      
   WHEN 'Part' THEN '600'      
   WHEN 'SoftWare' THEN '700'      
   WHEN '����' THEN '900'      
   ELSE @PROJECT_TYPE      
   END      
    )           
  AND   ( A.ISSUE_DT BETWEEN @FR_DT AND @TO_DT )          
END   
  
