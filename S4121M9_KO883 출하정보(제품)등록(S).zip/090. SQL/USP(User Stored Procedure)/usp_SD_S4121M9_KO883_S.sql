/*      
--S_SHIPPING_INFOR_KO883      
DROP PROC usp_SD_S4121M9_KO883_S      
DROP TYPE dbo.UTP_SD_S4121M9_KO883      
CREATE TYPE dbo.UTP_SD_S4121M9_KO883 AS TABLE      
(      
 SERIAL_NO   nvarchar(50) --1      
, PLANT_CD   nvarchar(20) --2      
, ITEM_CD    nvarchar(50) --3      
, UNIT_CD    nvarchar(10) --4      
, QTY     numeric(18,6) --5      
, BP_CD    nvarchar(10) --6      
, ISSUE_DT   datetime  --7      
, PROJECT_CODE  nvarchar(25) --8      
, TRACKING_NO   nvarchar(25) --9      
, LOCATION   nvarchar(200) --10      
, WAR_FR_DT   datetime  --11      
, WAR_TO_DT   datetime  --12      
, SETUP_REQ_DT  datetime  --13      
, SETUP_PRN   nvarchar(100) --14      
, SO_NO    nvarchar(30) --15      
, SO_SEQ    numeric(4,0) --16      
, DN_NO    nvarchar(30) --17      
, DN_SEQ    numeric(4,0) --18      
, ITEM_DOCUMENT_NO nvarchar(30) --19      
, SEQ_NO    numeric(4,0) --20      
, REMARK    nvarchar(1024) --21      
, LOCATION2   nvarchar(200) --22      
, LOCATION3   nvarchar(200) --23      
, LOCATION4   nvarchar(200) --24      
, CON_FR_DT   datetime  --25      
, CON_TO_DT   datetime  --26      
, PROJECT_TYPE nvarchar(40) --27    
, WAR_MONTH  int  --28    
, SETUP_DATE int  --29    
, SETUP_END_DT datetime  --30    
, MBO_DT     datetime    --31    
, FAT_DT     datetime    --32
, Serial_Sub SmallInt    --33    
, CUD_CHAR   NVARCHAR(01) --34      
, ROW_NUM    INT    --35      
    
)      
*/      
/********************************************************************************************/      
/***** PROCEDURE NAME : usp_SD_S4121M9_KO883_S          *****/      
/***** AUTHOR   : JIHU.KIM             *****/      
/***** CREATE DATE  : 2018-06-22                *****/      
/***** DESCRIPTION  : ��������(��ǰ)���              *****/       
/***** HISTORY   :                   *****/      
/********************************************************************************************/      
CREATE PROCEDURE dbo.usp_SD_S4121M9_KO883_S      
(      
 @TBL_DATA  UTP_SD_S4121M9_KO883  READONLY      
, @USER_ID  NVARCHAR(30)      
, @MSG_CD   NVARCHAR(06) = NULL OUTPUT      
, @MESSAGE  NVARCHAR(500) = NULL OUTPUT      
, @ERR_POS  BIGINT   = NULL OUTPUT      
)      
AS      
BEGIN      
 SET NOCOUNT ON;      
      
 DECLARE @ERROR_NUMBER INT      
      
 /*üũ����*/      
       
 DECLARE @CUR_SERIAL_NO   nvarchar(50) --1      
  , @CUR_PLANT_CD   nvarchar(20) --2      
  , @CUR_ITEM_CD   nvarchar(50) --3      
  , @CUR_UNIT_CD   nvarchar(10) --4      
  , @CUR_QTY    numeric(18,6) --5      
  , @CUR_BP_CD    nvarchar(10) --6      
  , @CUR_ISSUE_DT   datetime  --7      
  , @CUR_PROJECT_CODE  nvarchar(25) --8      
  , @CUR_TRACKING_NO  nvarchar(25) --9      
  , @CUR_LOCATION   nvarchar(200) --10      
  , @CUR_WAR_FR_DT   datetime  --11      
  , @CUR_WAR_TO_DT   datetime  --12      
  , @CUR_SETUP_REQ_DT  datetime  --13      
  , @CUR_SETUP_PRN   nvarchar(100) --14      
  , @CUR_SO_NO    nvarchar(30) --15      
  , @CUR_SO_SEQ    numeric(4,0) --16      
  , @CUR_DN_NO    nvarchar(30) --17      
  , @CUR_DN_SEQ    numeric(4,0) --18      
  , @CUR_ITEM_DOCUMENT_NO nvarchar(30) --19      
  , @CUR_SEQ_NO    numeric(4,0) --20      
  , @CUR_REMARK    nvarchar(1024) --21      
  , @CUR_LOCATION2   nvarchar(200) --22      
  , @CUR_LOCATION3   nvarchar(200) --23      
  , @CUR_LOCATION4   nvarchar(200) --24      
  , @CUR_CON_FR_DT   datetime  --25      
  , @CUR_CON_TO_DT   datetime  --26    
  , @CUR_PROJECT_TYPE nvarchar(40) --27    
  , @CUR_WAR_MONTH  numeric(5,4)  --28    
  , @CUR_SETUP_DATE    numeric(5,4)   --29    
  , @CUR_SETUP_END_DT  datetime   --30    
  , @CUR_MBO_DT        datetime   --31    
  , @CUR_FAT_DT        datetime   --32  
  , @CUR_Serial_Sub    SmallInt   --33    
  , @CUR_CUD_CHAR   NVARCHAR(01) --34      
  , @CUR_ROW_NUM   INT    --35      
  , @TRAN_YN    CHAR(01)      
      
 IF @@TRANCOUNT > 0      
  SET @TRAN_YN = 'N'      
 ELSE      
 BEGIN      
  SET @TRAN_YN = 'Y'      
  BEGIN TRANSACTION      
 END      
      
 BEGIN TRY      
  DECLARE Cur_WorkList CURSOR LOCAL FOR      
      
  SELECT A.SERIAL_NO      
   , A.PLANT_CD      
   , A.ITEM_CD      
   , A.UNIT_CD      
   , A.QTY      
   , A.BP_CD      
   , A.ISSUE_DT      
   , A.PROJECT_CODE      
   , A.TRACKING_NO      
   , A.LOCATION      
   , A.WAR_FR_DT      
   , A.WAR_TO_DT      
   , A.SETUP_REQ_DT      
   , A.SETUP_PRN      
   , A.SO_NO      
   , A.SO_SEQ      
   , A.DN_NO      
   , A.DN_SEQ      
   , A.ITEM_DOCUMENT_NO      
   , A.SEQ_NO      
   , A.REMARK      
   , A.LOCATION2      
   , A.LOCATION3      
   , A.LOCATION4      
   , A.CON_FR_DT      
   , A.CON_TO_DT    
   , A.PROJECT_TYPE    
   , A.WAR_MONTH    
   , A.SETUP_DATE    
   , A.SETUP_END_DT    
   , A.MBO_DT    
   , A.FAT_DT
   , A.SERIAL_SUB      
   , A.CUD_CHAR      
   , A.ROW_NUM      
            
  FROM @TBL_DATA A      
       
  OPEN Cur_WorkList      
      
  FETCH NEXT FROM Cur_WorkList      
  INTO @CUR_SERIAL_NO, @CUR_PLANT_CD, @CUR_ITEM_CD,  @CUR_UNIT_CD,  @CUR_QTY,       
    @CUR_BP_CD,  @CUR_ISSUE_DT, @CUR_PROJECT_CODE, @CUR_TRACKING_NO, @CUR_LOCATION      
   , @CUR_WAR_FR_DT, @CUR_WAR_TO_DT, @CUR_SETUP_REQ_DT, @CUR_SETUP_PRN      
   , @CUR_SO_NO,  @CUR_SO_SEQ, @CUR_DN_NO,   @CUR_DN_SEQ,  @CUR_ITEM_DOCUMENT_NO, @CUR_SEQ_NO, @CUR_REMARK      
   , @CUR_LOCATION2, @CUR_LOCATION3, @CUR_LOCATION4,  @CUR_CON_FR_DT,  @CUR_CON_TO_DT    
   , @CUR_PROJECT_TYPE, @CUR_WAR_MONTH, @CUR_SETUP_DATE, @CUR_SETUP_END_DT, @CUR_MBO_DT, @CUR_FAT_DT ,@CUR_Serial_Sub     
   , @CUR_CUD_CHAR, @CUR_ROW_NUM      
      
  WHILE(@@FETCH_STATUS = 0)      
  BEGIN      
   SET @ERR_POS  = @CUR_ROW_NUM      
      
   IF @CUR_CUD_CHAR = 'C'      
   BEGIN      
     IF(@CUR_QTY = 0)      
     BEGIN      
      
     SET @MSG_CD = '169918'      
      
     ROLLBACK TRANSACTION      
     RETURN -1      
      
     END      
      
     IF EXISTS(SELECT 1 FROM S_SHIPPING_INFOR_KO883 WHERE SERIAL_NO = @CUR_SERIAL_NO and SERIAL_SUB = @CUR_Serial_Sub)      
     BEGIN      
       SET @MSG_CD = '970001'      
       SET @MESSAGE = @CUR_SERIAL_NO      
      
       ROLLBACK TRANSACTION      
       RETURN -1      
     END      
      
     INSERT INTO S_SHIPPING_INFOR_KO883      
     (      
      SERIAL_NO, PLANT_CD, ITEM_CD, UNIT_CD, BP_CD,       
      ISSUE_DT, PROJECT_CODE, TRACKING_NO, LOCATION,       
      WAR_FR_DT, WAR_TO_DT, CON_FR_DT, CON_TO_DT, SETUP_REQ_DT, SETUP_PRN,       
      SO_NO, SO_SEQ, DN_NO, DN_SEQ, ITEM_DOCUMENT_NO, SEQ_NO, REMARK,    
   PROJECT_TYPE,WAR_MONTH,SETUP_DATE,SETUP_END_DT,MBO_DT,FAT_DT, SERIAL_SUB  ,     
      INSRT_USER_ID, INSRT_DT, UPDT_USER_ID, UPDT_DT, QTY      
     )      
     VALUES      
     (      
      @CUR_SERIAL_NO, @CUR_PLANT_CD, @CUR_ITEM_CD, @CUR_UNIT_CD, @CUR_BP_CD,       
      @CUR_ISSUE_DT, @CUR_PROJECT_CODE, @CUR_TRACKING_NO, @CUR_LOCATION,       
      @CUR_WAR_FR_DT, @CUR_WAR_TO_DT, @CUR_CON_FR_DT, @CUR_CON_TO_DT, @CUR_SETUP_REQ_DT, @CUR_SETUP_PRN,       
      @CUR_SO_NO, @CUR_SO_SEQ, @CUR_DN_NO, @CUR_DN_SEQ, @CUR_ITEM_DOCUMENT_NO, @CUR_SEQ_NO, @CUR_REMARK,      
      CONVERT(nvarchar(40),@CUR_PROJECT_TYPE), @CUR_WAR_MONTH, @CUR_SETUP_DATE, @CUR_SETUP_END_DT, @CUR_MBO_DT, @CUR_FAT_DT, @CUR_Serial_Sub , 
      @USER_ID,GETDATE(),@USER_ID,GETDATE(), @CUR_QTY      
     )      
   END      
      
      
   IF @CUR_CUD_CHAR = 'U'      
   BEGIN      
      
    IF(@CUR_QTY = 0)      
    BEGIN      
      
     SET @MSG_CD = '169918'      
      
     ROLLBACK TRANSACTION      
     RETURN -1      
      
    END     
	 
	 
	 

       UPDATE S_SHIPPING_INFOR_KO883      
      SET  PLANT_CD  = @CUR_PLANT_CD      
    ,  ITEM_CD   = @CUR_ITEM_CD      
    ,  UNIT_CD   = @CUR_UNIT_CD      
    ,  BP_CD   = @CUR_BP_CD      
    ,  ISSUE_DT  = @CUR_ISSUE_DT      
    ,  PROJECT_CODE = @CUR_PROJECT_CODE      
    ,  TRACKING_NO  = @CUR_TRACKING_NO      
    ,  LOCATION  = @CUR_LOCATION      
    ,  WAR_FR_DT  = @CUR_WAR_FR_DT      
    ,  WAR_TO_DT  = @CUR_WAR_TO_DT      
    ,  CON_FR_DT  = @CUR_CON_FR_DT      
    ,  CON_TO_DT  = @CUR_CON_TO_DT      
    ,  SETUP_REQ_DT = @CUR_SETUP_REQ_DT      
    ,  SETUP_PRN  = @CUR_SETUP_PRN      
    ,  SO_NO   = @CUR_SO_NO      
    ,  SO_SEQ   = @CUR_SO_SEQ      
    ,  DN_NO   = @CUR_DN_NO      
    ,  DN_SEQ   = @CUR_DN_SEQ      
    ,  ITEM_DOCUMENT_NO= @CUR_ITEM_DOCUMENT_NO      
    ,  SEQ_NO   = @CUR_SEQ_NO      
    ,  REMARK   = @CUR_REMARK         
    ,  LOCATION2  = @CUR_LOCATION2      
    ,  LOCATION3  = @CUR_LOCATION3      
    ,  LOCATION4  = @CUR_LOCATION4    
    ,  PROJECT_TYPE = CONVERT(nvarchar(40),@CUR_PROJECT_TYPE)  
    ,  WAR_MONTH  = @CUR_WAR_MONTH    
    ,  SETUP_DATE = @CUR_SETUP_DATE    
    ,  SETUP_END_DT = @CUR_SETUP_END_DT    
    ,  MBO_DT = @CUR_MBO_DT    
    ,  FAT_DT = @CUR_FAT_DT
	,  SERIAL_SUB = @CUR_Serial_Sub         
    ,  UPDT_USER_ID = @USER_ID      
    ,  UPDT_DT   = GETDATE()      
    ,  QTY   = @CUR_QTY      
    WHERE SERIAL_NO  = @CUR_SERIAL_NO   
	 AND SERIAL_SUB = @CUR_Serial_Sub
          
   END      
      
   IF @CUR_CUD_CHAR = 'D'      
   BEGIN      
    IF EXISTS(SELECT 1 FROM S_CS_RECEIPT_KO883(NOLOCK) WHERE SERIAL_NO = @CUR_SERIAL_NO)      
    BEGIN      
     SET @MSG_CD = 'DT9999'      
     SET @MESSAGE = 'CS����(S_CS_RECEIPT_KO883)���� Serial No �������Դϴ�.'      
      
     ROLLBACK TRANSACTION      
     RETURN -1      
    END      
    ELSE      
    BEGIN      
     DELETE FROM S_SHIPPING_INFOR_KO883      
     WHERE  SERIAL_NO  = @CUR_SERIAL_NO    AND SERIAL_SUB = @CUR_Serial_Sub
    END      
   END      
      
   FETCH NEXT FROM Cur_WorkList      
   INTO @CUR_SERIAL_NO, @CUR_PLANT_CD, @CUR_ITEM_CD,  @CUR_UNIT_CD,  @CUR_QTY,       
     @CUR_BP_CD,  @CUR_ISSUE_DT, @CUR_PROJECT_CODE, @CUR_TRACKING_NO, @CUR_LOCATION      
    , @CUR_WAR_FR_DT, @CUR_WAR_TO_DT, @CUR_SETUP_REQ_DT, @CUR_SETUP_PRN      
    , @CUR_SO_NO,  @CUR_SO_SEQ, @CUR_DN_NO,   @CUR_DN_SEQ,  @CUR_ITEM_DOCUMENT_NO, @CUR_SEQ_NO, @CUR_REMARK      
    , @CUR_LOCATION2, @CUR_LOCATION3, @CUR_LOCATION4,  @CUR_CON_FR_DT,  @CUR_CON_TO_DT    
 , @CUR_PROJECT_TYPE, @CUR_WAR_MONTH, @CUR_SETUP_DATE, @CUR_SETUP_END_DT, @CUR_MBO_DT, @CUR_FAT_DT ,@CUR_Serial_Sub    
    , @CUR_CUD_CHAR, @CUR_ROW_NUM      
  END -- WHILE END      
      
  CLOSE Cur_WorkList      
  DEALLOCATE Cur_WorkList      
 END TRY      
 BEGIN CATCH      
  SET @ERROR_NUMBER = ERROR_NUMBER()      
      
  IF @ERROR_NUMBER = 2627  --%1! ���� ���� '%2!'��(��) �����߽��ϴ�. ��ü '%3!'�� �ߺ� Ű�� ������ �� �����ϴ�. �ߺ� Ű ���� %4!�Դϴ�.        
   SET @MSG_CD   = '970001' -- %1 ��(��) �̹� �����մϴ�.        
  ELSE IF @ERROR_NUMBER = 547  -- %1! ���� %2! ���� ���� "%3!"��(��) �浹�߽��ϴ�. �����ͺ��̽� "%4!", ���̺� "%5!"%6!%7!%8!���� �浹�� �߻��߽��ϴ�.      
   SET @MSG_CD   = '971000' -- %1 ��(��) �����ϰ� �ִ� �����Ͱ� �ֽ��ϴ�. �۾��� ������ �� �����ϴ�.      
  ELSE IF @ERROR_NUMBER = 1205  -- Ʈ�����(���μ��� ID %1!)�� %2! ���ҽ����� �ٸ� ���μ������� ���� ���°� �߻��Ͽ� ������ �����Ǿ����ϴ�. Ʈ������� �ٽ� �����Ͻʽÿ�.      
   SET @MSG_CD   = '122918' -- %1 ���忡 �����߽��ϴ�.      
  ELSE IF ISNULL(@MESSAGE,'') = ''      
   SET @MESSAGE  = ERROR_MESSAGE()      
      
  GOTO __ERROR      
 END CATCH      
      
 IF @TRAN_YN = 'Y' AND @@TRANCOUNT > 0 COMMIT TRANSACTION      
 RETURN 1      
      
__ERROR:      
 IF @TRAN_YN = 'Y' AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION      
      
 IF CURSOR_STATUS('local','Cur_WorkList') >= 0      
 BEGIN      
  CLOSE Cur_WorkList      
  DEALLOCATE Cur_WorkList      
 END      
      
 RETURN -1      
END      
      