﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Common.Exceptions;

#endregion

namespace uniERP.App.UI.SD.S4121M9_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①namespace</NameSpace>
        /// <Module>②module name</Module>
        /// <Class>③class name</Class>
        /// <Desc>④
        ///   This part describe the summary information about class 
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="creator" Date="created date">Make …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        #endregion

        #region ■ 1.4 Class global constants (grid)


        #endregion

        #region ■ 1.5 Class global variables (grid)

        // change your code
        private DsMaster cqtDs = new DsMaster();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(this.cqtDs);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.Common);  // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format
        }

        protected override void Form_Load_Completed()
        {
            //ControlName.Focus();                // Set focus
            //uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.DeleteRow, false);
            DateTime getToDate = uniBase.UDate.GetDBServerDateTime();
            dtDate.uniDateTimeF.Value = getToDate.AddMonths(-3);
            dtDate.uniDateTimeT.Value = getToDate;
            popPlantCd.CodeValue = CommonVariable.gPlant;
            popPlantCd.CodeName = CommonVariable.gPlantNm;
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            // init Dataset Row : change your code
            cqtDs.Clear();
        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            // Assign default value to controls
                       
            return;
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            // Example: Set ComboBox List (Column Name, Select, From, Where)
            //uniBase.UData.ComboMajorAdd("TaxPolicy", "B0004");
            //uniBase.UData.ComboCustomAdd("MSG_TYPE", "MINOR_CD , MINOR_NM ", "B_MINOR", "MAJOR_CD='A1001'");
        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆
            base.viewTB19029.ggUserDefined6.DecPoint = 0;
            base.viewTB19029.ggUserDefined6.Integeral = 15;
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            DsMaster.E_TableDataTable uniGridTB1 = cqtDs.E_Table;

            this.uniGrid1.SSSetEdit(uniGridTB1.PLANT_CDColumn.ColumnName, "공장", 55, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.PLANT_NMColumn.ColumnName, "공장명", 100, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);

            this.uniGrid1.SSSetEdit(uniGridTB1.ITEM_CDColumn.ColumnName, "품목", 130, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.ITEM_NMColumn.ColumnName, "품목명", 130, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.SPECColumn.ColumnName, "규격", 130, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.UNIT_CDColumn.ColumnName, "단위", 80, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Center);
            this.uniGrid1.SSSetFloat(uniGridTB1.QTYColumn.ColumnName, "수량", 80, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.SERIAL_NOColumn.ColumnName, "Serial No", enumDef.FieldType.NotNull);

            this.uniGrid1.SSSetEdit(uniGridTB1.BP_CDColumn.ColumnName, "고객사", 100, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.BP_NMColumn.ColumnName, "고객사명", 120, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);

            this.uniGrid1.SSSetDate(uniGridTB1.ISSUE_DTColumn.ColumnName, "출고일", enumDef.FieldType.NotNull, CommonVariable.gDateFormat);

            this.uniGrid1.SSSetEdit(uniGridTB1.PROJECT_CODEColumn.ColumnName, "프로젝트 번호", 120, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.TRACKING_NOColumn.ColumnName, "Tracking No.", 120, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);

            this.uniGrid1.SSSetEdit(uniGridTB1.LOCATIONColumn.ColumnName, "Location", 100, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);

            this.uniGrid1.SSSetDate(uniGridTB1.WAR_FR_DTColumn.ColumnName, "Warranty기간(From)", enumDef.FieldType.Default, CommonVariable.gDateFormat);
            this.uniGrid1.SSSetDate(uniGridTB1.WAR_TO_DTColumn.ColumnName, "Warranty기간(To)", enumDef.FieldType.Default, CommonVariable.gDateFormat);
            this.uniGrid1.SSSetDate(uniGridTB1.SETUP_REQ_DTColumn.ColumnName, "SETUP요청일", enumDef.FieldType.Default, CommonVariable.gDateFormat);

            this.uniGrid1.SSSetEdit(uniGridTB1.SERUP_PRNColumn.ColumnName, "SETUP담당", 100, enumDef.FieldType.Default, enumDef.CharCase.Default, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.REMARKColumn.ColumnName, "비고", 100, enumDef.FieldType.Default, enumDef.CharCase.Default, false, enumDef.HAlign.Left);

            this.uniGrid1.SSSetEdit(uniGridTB1.SO_NOColumn.ColumnName, "수주번호", 100, enumDef.FieldType.Default, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetFloat(uniGridTB1.SO_SEQColumn.ColumnName, "수주순번", 80, viewTB19029.ggUserDefined6, enumDef.FieldType.Default, enumDef.HAlign.Right, false, enumDef.PosZero.Default, 0, 999);

            this.uniGrid1.SSSetEdit(uniGridTB1.DN_NOColumn.ColumnName, "출하번호", 100, enumDef.FieldType.Default, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetFloat(uniGridTB1.DN_SEQColumn.ColumnName, "출하순번", 80, viewTB19029.ggUserDefined6, enumDef.FieldType.Default, enumDef.HAlign.Right, false, enumDef.PosZero.Default, 0, 999);

            this.uniGrid1.SSSetEdit(uniGridTB1.ITEM_DOCUMENT_NOColumn.ColumnName, "이동번호", 100, enumDef.FieldType.Default, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetFloat(uniGridTB1.SEQ_NOColumn.ColumnName, "이동번호순번", 80, viewTB19029.ggUserDefined6, enumDef.FieldType.Default, enumDef.HAlign.Right, false, enumDef.PosZero.Default, 0, 999);

            this.uniGrid1.SSSetEdit(uniGridTB1.LOCATION2Column.ColumnName, "Location 추가1", 110, enumDef.FieldType.Default, enumDef.CharCase.Default, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.LOCATION3Column.ColumnName, "Location 추가2", 110, enumDef.FieldType.Default, enumDef.CharCase.Default, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB1.LOCATION4Column.ColumnName, "Location 추가3", 110, enumDef.FieldType.Default, enumDef.CharCase.Default, false, enumDef.HAlign.Left);

            this.uniGrid1.SSSetDate(uniGridTB1.CON_FR_DTColumn.ColumnName, "하자이행기간(From)", 130, enumDef.FieldType.Default, CommonVariable.gDateFormat, enumDef.HAlign.Center);
            this.uniGrid1.SSSetDate(uniGridTB1.CON_TO_DTColumn.ColumnName, "하자이행기간(To)", 130, enumDef.FieldType.Default, CommonVariable.gDateFormat, enumDef.HAlign.Center);          

            //this.uniGrid1.SSSetEdit(uniGridTB1.QTYColumn.ColumnName, "공장명", 80, enumDef.FieldType.ReadOnly, false);
            //this.uniGrid1.SSSetEdit(uniGridTB1.SO_NOColumn.ColumnName, "수주번호", 100, enumDef.FieldType.Default, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            //this.uniGrid1.SSSetEdit(uniGridTB1.DN_NOColumn.ColumnName, "출하번호", 100, enumDef.FieldType.Default, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            
            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            // Hidden Column Setting
            //this.uniGrid1.SSSetColHidden(uniGridTB1.cmb_colColumn.ColumnName);

            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
            // TO-DO: 컨트롤을 초기화(또는 초기값)할때 할일 
            // SetDefaultVal과의 차이점은 전자는 Form_Load 시점에 콘트롤에 초기값을 세팅하는것이고
            // 후자는 특정 시점(조회후 또는 행추가후 등 특정이벤트)에서 초기값을 셋팅한다.
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            // Grid binding with global dataset variable.
            this.InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(this.cqtDs.E_Table);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //TO-DO : code business oriented logic

            return DBQuery();
        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)

        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic

            return DBSave();
        }

        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic
            if (this.uniGrid1.ActiveRow != null)
            {
                this.uniGrid1.ActiveRow.Cells["ISSUE_DT"].Value = uniBase.UDate.GetDBServerDateTime();
                this.uniGrid1.ActiveRow.Cells["QTY"].Value = 1;

                if (popPlantCd.CodeValue.Trim() != "")
                {
                    this.uniGrid1.ActiveRow.Cells["PLANT_CD"].Value = popPlantCd.CodeValue.Trim();
                    this.uniGrid1.ActiveRow.Cells["PLANT_NM"].Value = popPlantCd.CodeName.Trim();                    
                }

            }
            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            //wsMyBizFL.TypedDataSet iqtdsTypedDataSet = new wsMyBizFL.TypedDataSet();
            //wsMyBizFL.TypedDataSet iqtdsICondition = new wsMyBizFL.TypedDataSet();

            string pSerialNo = popSerialNo.CodeValue.Trim();
            string pPlantCd = popPlantCd.CodeValue.Trim();
            string pItemCd = popItemCd.CodeValue.Trim();
            string pBpCd = popBpCd.CodeValue.Trim();
            string pProjectCd = popProjectCd.CodeValue.Trim();
            string pTrackingNo = popTrackingNo.CodeValue.Trim();
            string pIssuedFrDt = dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? "1900-01-01" : dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd");
            string pIssuedToDt = dtDate.uniDateTimeF.uniValue.ToString("yyyy-MM-dd") == "0001-01-01" ? "2999-12-31" : dtDate.uniDateTimeT.uniValue.ToString("yyyy-MM-dd");

            DataSet iqtDs = new DataSet();

            try
            {
                /*
                    @SERIAL_NO		NVARCHAR(25),
		            @PLANT_CD		NVARCHAR(10),
		            @ITEM_CD		NVARCHAR(50),
		            @BP_CD			NVARCHAR(10),
		            @PROJECT_CD		NVARCHAR(25),
		            @TRACKING_NO	NVARCHAR(25),
		            @FR_DT			NVARCHAR(10),
		            @TO_DT			NVARCHAR(10)
                 */


                using (uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetStoredProcCommand("dbo.usp_SD_S4121M9_KO883_Q"))
                {
                    uniBase.UDatabase.AddInParameter(uniCmd, "@SERIAL_NO", SqlDbType.NVarChar, 25, pSerialNo);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@PLANT_CD", SqlDbType.NVarChar, 10, pPlantCd);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@ITEM_CD", SqlDbType.NVarChar, 50, pItemCd);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@BP_CD", SqlDbType.NVarChar, 10, pBpCd);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@PROJECT_CD", SqlDbType.NVarChar, 25, pProjectCd);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@TRACKING_NO", SqlDbType.NVarChar, 25, pTrackingNo);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@FR_DT", SqlDbType.NVarChar, 10, pIssuedFrDt);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@TO_DT", SqlDbType.NVarChar, 10, pIssuedToDt);

                    iqtDs = uniBase.UDatabase.ExecuteDataSet(uniCmd);

                    if (iqtDs == null || iqtDs.Tables[0].Rows.Count < 1)
                    {
                        uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    }
                    else
                    {
                        cqtDs.E_Table.Merge(iqtDs.Tables[0], false, MissingSchemaAction.Ignore);
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                if (iqtDs != null) iqtDs.Dispose();
            }

            return true;
        }

        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            //TO-DO : code business oriented logic
            this.uniGrid1.UpdateData();
            
            DataTable iqtDt = new DataTable();

            try
            {
                
                iqtDt.Merge(new DsMaster.I_TableDataTable(), false, MissingSchemaAction.Add);
                iqtDt.Merge(cqtDs.E_Table.GetChanges(), false, MissingSchemaAction.Ignore);
                iqtDt.AcceptChanges();

                using (uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetStoredProcCommand("dbo.usp_SD_S4121M9_KO883_S"))
                {
                    uniBase.UDatabase.AddInParameter(uniCmd, "@TBL_DATA", SqlDbType.Structured, iqtDt);                    
                    uniBase.UDatabase.AddInParameter(uniCmd, "@USER_ID", SqlDbType.NVarChar, 13, CommonVariable.gUsrID);
                    uniBase.UDatabase.AddOutParameter(uniCmd, "@MSG_CD", SqlDbType.NVarChar, 6);
                    uniBase.UDatabase.AddOutParameter(uniCmd, "@MESSAGE", SqlDbType.NVarChar, 200);
                    uniBase.UDatabase.AddOutParameter(uniCmd, "@ERR_POS", SqlDbType.Int, 3);

                    uniBase.UDatabase.AddReturnParameter(uniCmd, "RETURN_VALUE", SqlDbType.Int, 1);

                    uniBase.UDatabase.ExecuteNonQuery(uniCmd, false);

                    int iReturn = (int)uniBase.UDatabase.GetParameterValue(uniCmd, "RETURN_VALUE");

                    if (iReturn < 0)
                    {
                        string sMsgCd = uniBase.UDatabase.GetParameterValue(uniCmd, "@MSG_CD") as string;
                        string sMessage = uniBase.UDatabase.GetParameterValue(uniCmd, "@MESSAGE") as string;

                        if (string.IsNullOrEmpty(sMsgCd)) sMsgCd = "DT9999";
                        else
                            uniBase.UMessage.DisplayMessageBox(sMsgCd, MessageBoxButtons.OK, sMessage);

                        return false;
                    }
                    else if (iReturn == 0)
                    {
                        uniBase.UMessage.DisplayMessageBox("990000", MessageBoxButtons.OK);
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                if (iqtDt != null) iqtDt.Dispose();
            }

            return true;
        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        #region ■■ 5.2.1 ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ButtonClicked >>> ClickCellButton

        #region ■■ 5.2.2 Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeExitEditMode(object sender, Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs e)
        {
        }

      
        #endregion ■■ Change >>> CellChange

        #region ■■ 5.2.3 Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
        }
        #endregion ■■ Click >>> AfterSelectChange

        #region ■■ 5.2.4 ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ComboSelChange >>> CellListSelect

        #region ■■ 5.2.5 DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
        }
        #endregion ■■ DblClick >>> DoubleClickCell

        #region ■■ 5.2.6 MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
        }
        #endregion ■■ MouseDown >>> MouseDown

        #region ■■ 5.2.7 ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
        }
        #endregion ■■ ScriptLeaveCell >>> BeforeCellDeactivate

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors
            //CommonPopup cp = new CommonUtil.CommonPopup(PopupType.AutoNumbering);

            //string[] arrRet = cp.showModalDialog(InputParam1);

            #endregion

            #region ▶▶▶ 10.1.2.2 Setting Returned Data

            //if (iWhere) 
            //{
            //    txtMinor.value = arrRet[0];
            //    txtMinorNm.value = arrRet[1];
            //}
            //else
            //{
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingCd].value = arrRet[0];
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingNm].value = arrRet[1];

            //    if (arrRet[2].Length > 0) 
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = arrRet[2];
            //    else
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = "18";

            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.PrefixCd].value = arrRet[0];

            //}

            #endregion

            //CommonVariable.lgBlnFlgChgValue = true;  // 사용자 액션 발생 알림
        }

        #endregion

        #endregion       

        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        #region popSerialNo
        
        private void popSerialNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Serial No";
            e.PopupPassData.ConditionCaption = "Serial No";

            e.PopupPassData.SQLFromStatements = string.Format(@" 
            (       SELECT	A.SERIAL_NO, A.ITEM_CD, B.ITEM_NM, B.SPEC 
                    FROM    S_SHIPPING_INFOR_KO883	A(NOLOCK)
                    JOIN	B_ITEM					B(NOLOCK) ON A.ITEM_CD = B.ITEM_CD) X");

            e.PopupPassData.SQLWhereStatements = "";//" PROJECT_CODE = " + uniBase.UCommon.FilterVariable(popPROJECTCD.CodeValue.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.SQLWhereInputCodeValue = popSerialNo.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.PopupWinWidth = 600;
            e.PopupPassData.PopupWinHeight = 500;            

            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[4];
            e.PopupPassData.GridCellCaption = new String[4];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[4];
            e.PopupPassData.GridCellLength = new int[4];

            e.PopupPassData.GridCellCode[0] = "X.SERIAL_NO";
            e.PopupPassData.GridCellCode[1] = "X.ITEM_CD";
            e.PopupPassData.GridCellCode[2] = "X.ITEM_NM";
            e.PopupPassData.GridCellCode[3] = "X.SPEC";            

            e.PopupPassData.GridCellCaption[0] = "Serial No";
            e.PopupPassData.GridCellCaption[1] = "품목";
            e.PopupPassData.GridCellCaption[2] = "품목명";
            e.PopupPassData.GridCellCaption[3] = "규격";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;

            e.PopupPassData.GridCellLength[0] = 90;
            e.PopupPassData.GridCellLength[1] = 110;
            e.PopupPassData.GridCellLength[2] = 130;
            e.PopupPassData.GridCellLength[3] = 130;
        }

        private void popSerialNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popSerialNo.CodeValue = iDataSet.Tables[0].Rows[0]["SERIAL_NO"].ToString();            
        }

        #endregion

        #region ProjectCd
        private void popProjectCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "프로젝트";
            e.PopupPassData.ConditionCaption = "프로젝트 번호";

            e.PopupPassData.SQLFromStatements = " PMS_PROJECT(nolock) ";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.SQLWhereInputCodeValue = popProjectCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.PopupWinWidth = 400;
            e.PopupPassData.PopupWinHeight = 500;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new Int32[2];

            e.PopupPassData.GridCellCode[0] = "Project_CODE";
            e.PopupPassData.GridCellCode[1] = "Project_NM";

            e.PopupPassData.GridCellCaption[0] = "프로젝트번호";
            e.PopupPassData.GridCellCaption[1] = "프로젝트명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;


            e.PopupPassData.GridCellLength[0] = 110;
            e.PopupPassData.GridCellLength[1] = 180;


        }
        private void popProjectCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popProjectCd.CodeValue = iDataSet.Tables[0].Rows[0]["Project_CODE"].ToString();
            popProjectCd.CodeName = iDataSet.Tables[0].Rows[0]["Project_NM"].ToString();
        }
        #endregion

        #region popPlantCd
        
        private void popPlantCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "공장";
            e.PopupPassData.ConditionCaption = "공장";

            e.PopupPassData.PopupWinWidth = 400;
            e.PopupPassData.PopupWinHeight = 500;

            e.PopupPassData.SQLFromStatements = " B_PLANT(nolock) ";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.SQLWhereInputCodeValue = popPlantCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new Int32[2];

            e.PopupPassData.GridCellCode[0] = "PLANT_CD";
            e.PopupPassData.GridCellCode[1] = "PLANT_NM";

            e.PopupPassData.GridCellCaption[0] = "공장";
            e.PopupPassData.GridCellCaption[1] = "공장명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

            e.PopupPassData.GridCellLength[0] = 100;
            e.PopupPassData.GridCellLength[1] = 100;
        }

        private void popPlantCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPlantCd.CodeValue = iDataSet.Tables[0].Rows[0]["PLANT_CD"].ToString();
            popPlantCd.CodeName = iDataSet.Tables[0].Rows[0]["PLANT_NM"].ToString();
            popPlantCd.Focus();
        }

        #endregion

        #region popItemCd:품목
        private void popItemCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.S3112PA2";
            e.PopupPassData.PopupWinTitle = "Item";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;
            //tang modified
            DataSet iDs = new DataSet();
            DataTable iDt = new DataTable();
            iDs.Tables.Add(iDt);
            iDt.Columns.Add("Item");
            iDt.Columns.Add("Plant");
            DataRow iRow = iDt.NewRow();
            iDt.Rows.Add(iRow);
            iDt.Rows[0]["Item"] = popItemCd.CodeValue.Trim();
            iDt.Rows[0]["Plant"] = popPlantCd.CodeValue.Trim() == "" ? CommonVariable.gPlant : popPlantCd.CodeValue.Trim();
            e.PopupPassData.Data = iDs;
        }
        private void popItemCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popItemCd.CodeValue = iDataSet.Tables[0].Rows[0]["ITEM_CD"].ToString();
            popItemCd.CodeName = iDataSet.Tables[0].Rows[0]["ITEM_NM"].ToString();
            popItemCd.Focus();
        }

        #endregion

        #region popBpCd:고객사

        private void popBpCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "고객사";
            e.PopupPassData.ConditionCaption = "고객사";

            e.PopupPassData.SQLFromStatements = "dbo.B_BIZ_PARTNER BP (nolock) INNER JOIN dbo.B_COUNTRY CT (nolock) ON (CT.COUNTRY_CD = BP.CONTRY_CD) ";
            e.PopupPassData.SQLWhereStatements = "BP.BP_TYPE IN ('C','CS') AND EXISTS (SELECT * FROM B_BIZ_PARTNER_FTN BPF (nolock) WHERE BPF.PARTNER_BP_CD = BP.BP_CD AND BPF.PARTNER_FTN = 'SSH')";
            e.PopupPassData.SQLWhereInputCodeValue = popBpCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.PopupWinWidth = 550;
            e.PopupPassData.PopupWinHeight = 600;
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[4];
            e.PopupPassData.GridCellCaption = new String[4];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[4];
            e.PopupPassData.GridCellLength = new Int32[4];

            e.PopupPassData.GridCellCode[0] = "BP.BP_CD";
            e.PopupPassData.GridCellCode[1] = "BP.BP_NM";
            e.PopupPassData.GridCellCode[2] = "BP.CONTRY_CD";
            e.PopupPassData.GridCellCode[3] = "CT.COUNTRY_NM";

            e.PopupPassData.GridCellCaption[0] = "고객사코드";
            e.PopupPassData.GridCellCaption[1] = "고객사명";
            e.PopupPassData.GridCellCaption[2] = "국가코드";
            e.PopupPassData.GridCellCaption[3] = "국가명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;

            e.PopupPassData.GridCellLength[0] = 90;
            e.PopupPassData.GridCellLength[1] = 100;
            e.PopupPassData.GridCellLength[2] = 80;
            e.PopupPassData.GridCellLength[3] = 80;

        }

        private void popBpCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popBpCd.CodeValue = iDataSet.Tables[0].Rows[0]["BP_CD"].ToString();
            popBpCd.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
            popBpCd.Focus();
        }

        #endregion

        #region popTrackingNo:Tracking No
        private void popTrackingNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Tracking No.";
            e.PopupPassData.ConditionCaption = "Tracking No.";

            e.PopupPassData.SQLFromStatements = " (SELECT DISTINCT PROJECT_CODE, TRACKING_NO FROM PMS_PRJ_PRODUCTS) A ";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.SQLWhereInputCodeValue = popTrackingNo.CodeValue.ToString().Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.PopupWinWidth = 400;
            e.PopupPassData.PopupWinHeight = 500;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new Int32[2];

            e.PopupPassData.GridCellCode[0] = "TRACKING_NO";
            e.PopupPassData.GridCellCode[1] = "PROJECT_CODE";

            e.PopupPassData.GridCellCaption[0] = "Tracking No.";
            e.PopupPassData.GridCellCaption[1] = "Project Code";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

            e.PopupPassData.GridCellLength[0] = 110;
            e.PopupPassData.GridCellLength[1] = 130;
        }

        private void popTrackingNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popTrackingNo.CodeValue = iDataSet.Tables[0].Rows[0]["TRACKING_NO"].ToString();
        }

        #endregion

        #region uniGrid1:공장,품목코드,단위,고객사,프로젝트번호,TrackingNo,수주번호,출하번호,이동번호
        
        private void uniGrid1_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (uniGrid1.ActiveRow == null)
                return;       

            string sActiveColumnKey = uniGrid1.ActiveCell.Column.Key.ToUpper();
            string pCode = uniGrid1.ActiveRow.Cells[sActiveColumnKey].Value.ToString();
            string pPlantCd = uniGrid1.ActiveRow.Cells["PLANT_CD"].Value.ToString().Trim();

            switch (uniGrid1.ActiveCell.Column.Key.ToUpper())
            {
                case "PLANT_CD":
                    #region PLANT_CD
                    e.PopupPassData.PopupWinTitle = "공장";
                    e.PopupPassData.ConditionCaption = "공장";
                    e.PopupPassData.PopupWinWidth = 400;
                    e.PopupPassData.PopupWinHeight = 500;

                    e.PopupPassData.SQLFromStatements = " B_PLANT(nolock) ";
                    e.PopupPassData.SQLWhereStatements = "";
                    e.PopupPassData.SQLWhereInputCodeValue = pCode;
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.DistinctOrNot = true;

                    e.PopupPassData.GridCellCode = new String[2];
                    e.PopupPassData.GridCellCaption = new String[2];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

                    e.PopupPassData.GridCellCode[0] = "PLANT_CD";
                    e.PopupPassData.GridCellCode[1] = "PLANT_NM";

                    e.PopupPassData.GridCellCaption[0] = "공장";
                    e.PopupPassData.GridCellCaption[1] = "공장명";

                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
                    #endregion
                    break;

                case "ITEM_CD":
                    #region ITEM_CD
                    if (pPlantCd == "")
                    {
                        //205152	A	2	%1 을(를) 먼저 입력하세요.
                        string sColumnKeyName = uniGrid1.getColumnHeader("PLANT_CD");
                        uniBase.UMessage.DisplayMessageBox("205152", MessageBoxButtons.OK, sColumnKeyName);
                        e.Cancel = true;
                        return;
                    }
                    
                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.S3112PA2";
                    e.PopupPassData.PopupWinTitle = "Item";
                    e.PopupPassData.PopupWinWidth = 800;
                    e.PopupPassData.PopupWinHeight = 700;
                    //tang modified
                    DataSet iDs = new DataSet();
                    DataTable iDt = new DataTable();
                    iDs.Tables.Add(iDt);
                    iDt.Columns.Add("Item");
                    iDt.Columns.Add("Plant");
                    DataRow iRow = iDt.NewRow();
                    iDt.Rows.Add(iRow);
                    iDt.Rows[0]["Item"] = pCode;
                    iDt.Rows[0]["Plant"] = pPlantCd;
                    e.PopupPassData.Data = iDs;
                    #endregion
                    break;

                case "UNIT_CD":
                    #region UNIT_CD
                    e.PopupPassData.PopupWinTitle = "단위";
                    e.PopupPassData.ConditionCaption = "단위";

                    e.PopupPassData.SQLFromStatements = " B_UNIT_OF_MEASURE(NOLOCK) "; 
                    e.PopupPassData.SQLWhereStatements = "";
                    e.PopupPassData.SQLWhereInputCodeValue = pCode;
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.DistinctOrNot = true;

                    e.PopupPassData.PopupWinWidth = 400;
                    e.PopupPassData.PopupWinHeight = 500;

                    e.PopupPassData.GridCellCode = new String[2];
                    e.PopupPassData.GridCellCaption = new String[2];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
                    e.PopupPassData.GridCellLength = new Int32[2];

                    e.PopupPassData.GridCellCode[0] = "UNIT";
                    e.PopupPassData.GridCellCode[1] = "UNIT_NM";

                    e.PopupPassData.GridCellCaption[0] = "단위";
                    e.PopupPassData.GridCellCaption[1] = "단위명";

                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
                    #endregion
                    break;

                case "BP_CD":
                    #region BP_CD
                    e.PopupPassData.PopupWinTitle = "고객사";
                    e.PopupPassData.ConditionCaption = "고객사";

                    e.PopupPassData.SQLFromStatements = "dbo.B_BIZ_PARTNER BP (nolock) INNER JOIN dbo.B_COUNTRY CT (nolock) ON (CT.COUNTRY_CD = BP.CONTRY_CD) ";
                    e.PopupPassData.SQLWhereStatements = "BP.BP_TYPE IN ('C','CS') AND EXISTS (SELECT * FROM B_BIZ_PARTNER_FTN BPF (nolock) WHERE BPF.PARTNER_BP_CD = BP.BP_CD AND BPF.PARTNER_FTN = 'SSH')";
                    e.PopupPassData.SQLWhereInputCodeValue = pCode;
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.PopupWinWidth = 550;
                    e.PopupPassData.PopupWinHeight = 600;
                    e.PopupPassData.DistinctOrNot = false;

                    e.PopupPassData.GridCellCode = new String[4];
                    e.PopupPassData.GridCellCaption = new String[4];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[4];
                    e.PopupPassData.GridCellLength = new Int32[4];

                    e.PopupPassData.GridCellCode[0] = "BP.BP_CD";
                    e.PopupPassData.GridCellCode[1] = "BP.BP_NM";
                    e.PopupPassData.GridCellCode[2] = "BP.CONTRY_CD";
                    e.PopupPassData.GridCellCode[3] = "CT.COUNTRY_NM";

                    e.PopupPassData.GridCellCaption[0] = "고객사코드";
                    e.PopupPassData.GridCellCaption[1] = "고객사명";
                    e.PopupPassData.GridCellCaption[0] = "국가코드";
                    e.PopupPassData.GridCellCaption[1] = "국가명";

                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;

                    e.PopupPassData.GridCellLength[0] = 90;
                    e.PopupPassData.GridCellLength[1] = 100;
                    e.PopupPassData.GridCellLength[2] = 80;
                    e.PopupPassData.GridCellLength[3] = 80;
                    #endregion
                    break;

                case "PROJECT_CODE":
                    #region PROJECT_CODE
                    e.PopupPassData.PopupWinTitle = "프로젝트";
                    e.PopupPassData.ConditionCaption = "프로젝트 번호";

                    e.PopupPassData.SQLFromStatements = " PMS_PROJECT(nolock) ";
                    e.PopupPassData.SQLWhereStatements = "";
                    e.PopupPassData.SQLWhereInputCodeValue = pCode;
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.DistinctOrNot = true;

                    e.PopupPassData.PopupWinWidth = 400;
                    e.PopupPassData.PopupWinHeight = 500;

                    e.PopupPassData.GridCellCode = new String[2];
                    e.PopupPassData.GridCellCaption = new String[2];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
                    e.PopupPassData.GridCellLength = new Int32[2];

                    e.PopupPassData.GridCellCode[0] = "Project_CODE";
                    e.PopupPassData.GridCellCode[1] = "Project_NM";

                    e.PopupPassData.GridCellCaption[0] = "프로젝트번호";
                    e.PopupPassData.GridCellCaption[1] = "프로젝트명";

                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;


                    e.PopupPassData.GridCellLength[0] = 110;
                    e.PopupPassData.GridCellLength[1] = 180;
                    #endregion
                    break;

                case "TRACKING_NO":

                    #region TRACKING_NO
                    e.PopupPassData.PopupWinTitle = "Tracking No.";
                    e.PopupPassData.ConditionCaption = "Tracking No.";

                    e.PopupPassData.SQLFromStatements = " (SELECT DISTINCT PROJECT_CODE, TRACKING_NO FROM PMS_PRJ_PRODUCTS) A ";
                    e.PopupPassData.SQLWhereStatements = "";
                    e.PopupPassData.SQLWhereInputCodeValue = popTrackingNo.CodeValue.ToString().Trim();
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.DistinctOrNot = true;

                    e.PopupPassData.PopupWinWidth = 400;
                    e.PopupPassData.PopupWinHeight = 500;

                    e.PopupPassData.GridCellCode = new String[2];
                    e.PopupPassData.GridCellCaption = new String[2];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
                    e.PopupPassData.GridCellLength = new Int32[2];

                    e.PopupPassData.GridCellCode[0] = "TRACKING_NO";
                    e.PopupPassData.GridCellCode[1] = "PROJECT_CODE";

                    e.PopupPassData.GridCellCaption[0] = "Tracking No.";
                    e.PopupPassData.GridCellCaption[1] = "Project Code";

                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

                    e.PopupPassData.GridCellLength[0] = 110;
                    e.PopupPassData.GridCellLength[1] = 130;
                    #endregion

                    break;

                case "SO_NO":

                    #region SO_NO
                    //SO_NO코드 체크
                    //if (cstrSONo == null || cstrSONo == "" || cstrSONo == String.Empty)//(popConSoNo.CodeValue == null || popConSoNo.CodeValue.Trim().Equals(string.Empty))
                    //{
                    //    uniBase.UMessage.DisplayMessageBox("900002", MessageBoxButtons.OK);
                    //    e.Cancel = true;
                    //    return;
                    //}

                    //확정체크
                    //if (cstrConfirmFlg == "N")
                    //{
                    //    uniBase.UMessage.DisplayMessageBox("203022", MessageBoxButtons.OK);
                    //    e.Cancel = true;
                    //    return;
                    //}

                    //DataSet ids = uniBase.UDataAccess.CommonQueryRs(" A.PROJECT_CODE , A.PROJECT_NM ", " PMS_PROJECT A ", "  " );
                    //    //+ uniBase.UCommon.FilterVariable(popConSoNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));

                    //if (!(ids == null || ids.Tables.Count == 0 || ids.Tables[0].Rows.Count == 0
                    //    || ids.Tables[0].Rows[0][0] == null || ids.Tables[0].Rows[0][0].ToString().Trim() == ""))
                    //{
                    //    uniBase.UMessage.DisplayMessageBox("YM0049", MessageBoxButtons.OK);
                    //    e.Cancel = true;
                    //    return;
                    //}

                    //if (cstrRetItemFlag == "Y")
                    //{
                    //    //if (cPreSONo.Equals(string.Empty))
                    //    //{
                    //    //    uniBase.UMessage.DisplayMessageBox("203156", MessageBoxButtons.OK);
                    //    //    e.Cancel = true;
                    //    //    return;
                    //    //}
                    //    DataSet itmpds = new DataSet();
                    //    DataTable idt = new DataTable();
                    //    idt.Columns.Add("SONO");
                    //    idt.Columns.Add("SOLDTOPARTY");
                    //    idt.Columns.Add("SOLDTOPARTYNM");
                    //    idt.Columns.Add("SOTYPE");
                    //    idt.Columns.Add("CURRENCY");
                    //    DataRow iRow = idt.NewRow();
                    //    idt.Rows.Add(iRow);
                    //    idt.Rows[0]["SONO"] = pCode;
                    //    idt.Rows[0]["SOLDTOPARTY"] = txtSoldToParty.Text.Trim();
                    //    idt.Rows[0]["SOLDTOPARTYNM"] = txtSoldToPartyNm.Text.Trim();
                    //    idt.Rows[0]["SOTYPE"] = cstrSoType;
                    //    idt.Rows[0]["CURRENCY"] = txtCurrency.Text.Trim();
                    //    itmpds.Tables.Add(idt);
                    //    e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.S3112RA4";
                    //    e.PopupPassData.PopupWinTitle = "S/O Ref.";
                    //    e.PopupPassData.PopupWinWidth = 800;
                    //    e.PopupPassData.PopupWinHeight = 700;
                    //    e.PopupPassData.Data = itmpds;
                    //}
                    //else
                    //{
                        DataSet itmpds = new DataSet();
                        DataTable idt = new DataTable();
                        idt.Columns.Add("SONO");
                        idt.Columns.Add("SOLDTOPARTY");
                        idt.Columns.Add("SOLDTOPARTYNM");
                        idt.Columns.Add("SOTYPE");
                        idt.Columns.Add("CURRENCY");
                        DataRow iRow1 = idt.NewRow();
                        idt.Rows.Add(iRow1);
                        idt.Rows[0]["SONO"] = pCode;//popConSoNo.CodeValue.Trim();
                        idt.Rows[0]["SOLDTOPARTY"] = "";// txtSoldToParty.Text.Trim();
                        idt.Rows[0]["SOLDTOPARTYNM"] = "";// txtSoldToPartyNm.Text.Trim();
                        idt.Rows[0]["SOTYPE"] = "";// cstrSoType;
                        idt.Rows[0]["CURRENCY"] = "KRW";// txtCurrency.Text.Trim();
                        itmpds.Tables.Add(idt);
                        e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.S3112RA41";
                        e.PopupPassData.PopupWinTitle = "S/O Ref.";
                        e.PopupPassData.PopupWinWidth = 800;
                        e.PopupPassData.PopupWinHeight = 700;
                        e.PopupPassData.Data = itmpds;
                    //}
                    #endregion

                    break;

                case "DN_NO":

                    #region DN_NO
                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.S3112BA3";
                    e.PopupPassData.PopupWinTitle = "Shipment Detail Ref.";
                    e.PopupPassData.PopupWinWidth = 780;
                    e.PopupPassData.PopupWinHeight = 650;

                    string[] appParam = new string[16];
                    appParam[0] = "";//수주번호 txtSoNo.Text.Trim();
                    appParam[1] = "";//납품처 txtSoldtoParty.Text.Trim();
                    appParam[2] = "";//납품처명 txtSoldtoPartyNm.Text.Trim();
                    appParam[3] = "";//구매그룹 strHSalesGrpCd;
                    appParam[4] = "";//구매그룹명 strHSalesGrpNm;
                    appParam[5] = "";// Pay_Meth txtPayTermsCd.Text.Trim();
                    appParam[6] = ""; //txtPayTermsNm.Text.Trim();

                    appParam[7] = "";//통화txtCurrency.Text.Trim();
                    appParam[8] = ""; //strHBillDt;
                    appParam[9] = "";//strHVatRate;

                    //부가세적용기준
                    //if (this.rdoVatCalcType.CheckedIndex == 0)
                    //{
                    //    appParam[10] = "%";
                    //    appParam[11] = "1";
                    //    appParam[12] = "%";
                    //}
                    //else
                    //{
                    //    appParam[10] = strHVatType;

                    //    if (this.raoVatIncFlag.CheckedIndex == 0)
                    //    {
                    //        appParam[11] = "2";
                    //        appParam[12] = "1";
                    //    }
                    //    else
                    //    {
                    //        appParam[11] = "2";
                    //        appParam[12] = "2";
                    //    }
                    //}

                    //환율                    
                    //appParam[13] = numXchgRate.Text.Trim();
                    //
                    //appParam[14] = strXchgOp;//부가세금액?
                    //appParam[15] = strBillTypeCd;//매출채권형태

                    e.PopupPassData.Data = appParam;
                    #endregion

                    break;

                case "ITEM_DOCUMENT_NO":

                    #region ITEM_DOCUMENT_NO
                    if (pPlantCd == "")
                    {
                        //205152	A	2	%1 을(를) 먼저 입력하세요.
                        string sColumnKeyName = uniGrid1.getColumnHeader("PLANT_CD");
                        uniBase.UMessage.DisplayMessageBox("205152", MessageBoxButtons.OK, sColumnKeyName);
                        e.Cancel = true;
                        return;
                    }

                    string iParam1 = "";
                    string iParam2 = "";
                    string iParam3 = "";
                    string iParam4 = "";
                    
                    //if (string.IsNullOrEmpty(this.popPlantCd1.CodeValue))
                    //{
                    //    uniBase.UMessage.DisplayMessageBox("169901", MessageBoxButtons.OK, "", "");
                    //    this.popPlantCd1.Focus();
                    //    e.Cancel = true;
                    //    return;
                    //}

                    //iParam1 = this.popDocumentNo1.CodeValue.Trim();
                    //iParam2 = this.dtYear.DateTime.Year.ToString();
                    //iParam3 = "ST";
                    //iParam4 = this.popPlantCd1.CodeValue.Trim();

                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.I1111PA1";
                    e.PopupPassData.PopupWinTitle = "Document No. Popup";
                    e.PopupPassData.PopupWinWidth = 800;
                    e.PopupPassData.PopupWinHeight = 740;

                    DsI1111PA1 idsI1111PA1 = new DsI1111PA1();
                    DsI1111PA1.DtI1111PA1DataTable idtI1111PA1 = new DsI1111PA1.DtI1111PA1DataTable();
                    DsI1111PA1.DtI1111PA1Row idrI1111PA1 = idtI1111PA1.NewDtI1111PA1Row();
                    idrI1111PA1.Document_No = iParam1;
                    idrI1111PA1.year = iParam2;
                    idrI1111PA1.trns_type = iParam3;
                    idrI1111PA1.plant_cd = iParam4;

                    idtI1111PA1.Rows.Add(idrI1111PA1);
                    idsI1111PA1.DtI1111PA1.Merge(idtI1111PA1);

                    e.PopupPassData.Data = idsI1111PA1;
                    #endregion

                    break;
            }

        }

        private void uniGrid1_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            switch (uniGrid1.ActiveCell.Column.Key.ToUpper())
            {
                case "PLANT_CD":
                    uniGrid1.ActiveRow.Cells["PLANT_CD"].Value = iDataSet.Tables[0].Rows[0]["PLANT_CD"].ToString();
                    uniGrid1.ActiveRow.Cells["PLANT_NM"].Value = iDataSet.Tables[0].Rows[0]["PLANT_NM"].ToString();    
                    break;

                case "ITEM_CD":
                    uniGrid1.ActiveRow.Cells["ITEM_CD"].Value = iDataSet.Tables[0].Rows[0]["item_cd"].ToString();
                    uniGrid1.ActiveRow.Cells["ITEM_NM"].Value = iDataSet.Tables[0].Rows[0]["item_nm"].ToString();
                    uniGrid1.ActiveRow.Cells["SPEC"].Value = iDataSet.Tables[0].Rows[0]["spec"].ToString();

                    ItemByHScodeChange();
                    //uniGrid1.ActiveRow.Cells["UNIT_CD"].Value = iDataSet.Tables[0].Rows[0]["UNIT"].ToString();    
                    break;

                case "UNIT_CD":
                    uniGrid1.ActiveRow.Cells["UNIT_CD"].Value = iDataSet.Tables[0].Rows[0]["UNIT"].ToString();                    
                    break;

                case "BP_CD":
                    uniGrid1.ActiveRow.Cells["BP_CD"].Value = iDataSet.Tables[0].Rows[0]["BP_CD"].ToString();
                    uniGrid1.ActiveRow.Cells["BP_NM"].Value = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();                    
                    break;

                case "PROJECT_CODE":
                    uniGrid1.ActiveRow.Cells["PROJECT_CODE"].Value = iDataSet.Tables[0].Rows[0]["Project_CODE"].ToString();                    
                    break;

                case "TRACKING_NO":
                    uniGrid1.ActiveRow.Cells["TRACKING_NO"].Value = iDataSet.Tables[0].Rows[0]["TRACKING_NO"].ToString();   
                    break;

                case "SO_NO":
                    uniGrid1.ActiveRow.Cells["SO_NO"].Value = iDataSet.Tables[0].Rows[0]["SO_NO"].ToString();
                    break;

                case "DN_NO":
                    uniGrid1.ActiveRow.Cells["DN_NO"].Value = iDataSet.Tables[0].Rows[0]["DN_NO"].ToString();
                    break;

                case "ITEM_DOCUMENT_NO":
                    uniGrid1.ActiveRow.Cells["ITEM_DOCUMENT_NO"].Value = iDataSet.Tables[0].Rows[0]["ITEM_DOCUMENT_NO"].ToString();
                    break;
            }
        }

        #endregion

        #region uniGrid1_AfterExitEditMode
        
        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {
            switch (uniGrid1.ActiveCell.Column.Key.ToUpper())
            {
                case "ITEM_CD":
                    ItemByHScodeChange();
                break;
            }
        }

        #endregion

        # region ItemByHScodeChange
        private void ItemByHScodeChange()
        {
            string s_item_cd = uniGrid1.ActiveRow.Cells["item_cd"].Value.ToString().Trim();
            s_item_cd = uniBase.UCommon.FilterVariable(s_item_cd, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);

            string s_plant_cd = uniGrid1.ActiveRow.Cells["plant_cd"].Value.ToString().Trim();
            s_plant_cd = uniBase.UCommon.FilterVariable(s_plant_cd, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);

            string strSelect = " item_nm, spec, hs_cd, basic_unit, vat_type, tracking_flg  ";
            string strFrom1 = "  Dbo.ufn_s_ListItemInfo(" + s_item_cd + "," + s_plant_cd + ") ";
            string strFrom2 = " Dbo.ufn_s_ListItemInfo(" + s_item_cd + ") ";

            DataSet dataSet = new DataSet();
            if (s_plant_cd != null && !s_plant_cd.Equals(String.Empty))
            {
                dataSet = uniBase.UDataAccess.CommonQueryRs(strSelect, strFrom1, "");
            }
            else
            {
                dataSet = uniBase.UDataAccess.CommonQueryRs(strSelect, strFrom2, "");
            }

            string s_item_nm = String.Empty;
            string s_spec = String.Empty;
            string s_hs_cd = String.Empty;
            string s_basic_unit = String.Empty;
            string s_vat_type = String.Empty;
            string s_tracking_flg = String.Empty;
            string s_sl_cd = string.Empty;

            if (dataSet != null)
            {
                if (dataSet.Tables.Count > 0)
                {
                    if (dataSet.Tables[0].Rows.Count > 0)
                    {
                        s_item_nm = dataSet.Tables[0].Rows[0]["item_nm"].ToString();
                        s_spec = dataSet.Tables[0].Rows[0]["spec"].ToString();
                        s_hs_cd = dataSet.Tables[0].Rows[0]["hs_cd"].ToString();
                        s_basic_unit = dataSet.Tables[0].Rows[0]["basic_unit"].ToString();
                        s_vat_type = dataSet.Tables[0].Rows[0]["vat_type"].ToString();
                        s_tracking_flg = dataSet.Tables[0].Rows[0]["tracking_flg"].ToString();
                        //s_sl_cd = dataSet.Tables[0].Rows[0]["sl_cd"].ToString();
                    }
                }
            }
            int index = uniGrid1.ActiveRow.Index;
            uniGrid1.ActiveRow.Cells["ITEM_NM"].Value = s_item_nm;
            uniGrid1.ActiveRow.Cells["SPEC"].Value = s_spec;            
            uniGrid1.ActiveRow.Cells["UNIT_CD"].Value = s_basic_unit;            
        }
        # endregion

        #region ItemByHScodeChange_popItemCd
        private void ItemByHScodeChange_popItemCd()
        {
            string s_item_cd = popItemCd.CodeValue.Trim();

            string s_plant_cd = popPlantCd.CodeValue.Trim();            

            string strSelect = " item_nm, spec, hs_cd, basic_unit, vat_type, tracking_flg  ";
            string strFrom1 = "  Dbo.ufn_s_ListItemInfo(" + s_item_cd + "," + s_plant_cd + ") ";
            string strFrom2 = " Dbo.ufn_s_ListItemInfo(" + s_item_cd + ") ";

            DataSet dataSet = new DataSet();
            if (s_plant_cd != null && !s_plant_cd.Equals(String.Empty))
            {
                dataSet = uniBase.UDataAccess.CommonQueryRs(strSelect, strFrom1, "");
            }
            else
            {
                dataSet = uniBase.UDataAccess.CommonQueryRs(strSelect, strFrom2, "");
            }

            string s_item_nm = String.Empty;

            if (dataSet != null)
            {
                if (dataSet.Tables.Count > 0)
                {
                    if (dataSet.Tables[0].Rows.Count > 0)
                    {
                        s_item_nm = dataSet.Tables[0].Rows[0]["item_nm"].ToString();                        
                    }
                }
            }

            popItemCd.CodeValue = s_item_cd;
            popItemCd.CodeName = s_item_nm;
            
            
        }
        #endregion

        private void popItemCd_OnChange(object sender, EventArgs e)
        {
            string pPlantCd = popPlantCd.CodeValue.Trim();

            if (pPlantCd == "")
            {
                //205152	A	2	%1 을(를) 먼저 입력하세요.
                string sColumnKeyName = popPlantCd.uniALT;
                uniBase.UMessage.DisplayMessageBox("205152", MessageBoxButtons.OK, sColumnKeyName);                
                return;
            }

            ItemByHScodeChange_popItemCd();
        }


        #endregion

        #endregion

    }
}