﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.SD.S4121M9_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblSerialNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPlantCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblItemCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblBpCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProjectCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblTrackingNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDate = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popSerialNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popPlantCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popItemCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popBpCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popProjectCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popTrackingNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.dtDate = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.uniTBL_MainCondition.SuspendLayout();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.PathInfo;
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(1092, 703);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 143);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(1092, 528);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 0;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance26.BackColor = System.Drawing.SystemColors.Window;
            appearance26.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance26;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance27.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance27.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance27.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance27;
            appearance28.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance28;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance29.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance29.BackColor2 = System.Drawing.SystemColors.Control;
            appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance29.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance29;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance30.BackColor = System.Drawing.SystemColors.Window;
            appearance30.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance30;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance31.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance31;
            appearance32.BorderColor = System.Drawing.Color.Silver;
            appearance32.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance32;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance33.BackColor = System.Drawing.SystemColors.Control;
            appearance33.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance33.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance33.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance33;
            appearance34.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance34;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance35.BackColor = System.Drawing.SystemColors.Window;
            appearance35.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance35;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance36.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance36;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(1092, 528);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.AfterExitEditMode += new System.EventHandler(this.uniGrid1_AfterExitEditMode);
            this.uniGrid1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.uniGrid1_BeforePopupOpen);
            this.uniGrid1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.uniGrid1_AfterPopupClosed);
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.lblSerialNo, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblPlantCd, 2, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblItemCd, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblBpCd, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblProjectCd, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblTrackingNo, 2, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblDate, 0, 3);
            this.uniTBL_MainCondition.Controls.Add(this.popSerialNo, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popPlantCd, 3, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popItemCd, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popBpCd, 3, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popProjectCd, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.popTrackingNo, 3, 2);
            this.uniTBL_MainCondition.Controls.Add(this.dtDate, 1, 3);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 5;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(1092, 107);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblSerialNo
            // 
            appearance19.TextHAlignAsString = "Left";
            appearance19.TextVAlignAsString = "Middle";
            this.lblSerialNo.Appearance = appearance19;
            this.lblSerialNo.AutoPopupID = null;
            this.lblSerialNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSerialNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSerialNo.Location = new System.Drawing.Point(15, 6);
            this.lblSerialNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSerialNo.Name = "lblSerialNo";
            this.lblSerialNo.Size = new System.Drawing.Size(137, 22);
            this.lblSerialNo.StyleSetName = "Default";
            this.lblSerialNo.TabIndex = 0;
            this.lblSerialNo.Text = "Serial No";
            this.lblSerialNo.UseMnemonic = false;
            // 
            // lblPlantCd
            // 
            appearance20.TextHAlignAsString = "Left";
            appearance20.TextVAlignAsString = "Middle";
            this.lblPlantCd.Appearance = appearance20;
            this.lblPlantCd.AutoPopupID = null;
            this.lblPlantCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPlantCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPlantCd.Location = new System.Drawing.Point(560, 6);
            this.lblPlantCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPlantCd.Name = "lblPlantCd";
            this.lblPlantCd.Size = new System.Drawing.Size(137, 22);
            this.lblPlantCd.StyleSetName = "Default";
            this.lblPlantCd.TabIndex = 1;
            this.lblPlantCd.Text = "공장";
            this.lblPlantCd.UseMnemonic = false;
            // 
            // lblItemCd
            // 
            appearance21.TextHAlignAsString = "Left";
            appearance21.TextVAlignAsString = "Middle";
            this.lblItemCd.Appearance = appearance21;
            this.lblItemCd.AutoPopupID = null;
            this.lblItemCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblItemCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblItemCd.Location = new System.Drawing.Point(15, 29);
            this.lblItemCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblItemCd.Name = "lblItemCd";
            this.lblItemCd.Size = new System.Drawing.Size(137, 22);
            this.lblItemCd.StyleSetName = "Default";
            this.lblItemCd.TabIndex = 2;
            this.lblItemCd.Text = "품목";
            this.lblItemCd.UseMnemonic = false;
            // 
            // lblBpCd
            // 
            appearance22.TextHAlignAsString = "Left";
            appearance22.TextVAlignAsString = "Middle";
            this.lblBpCd.Appearance = appearance22;
            this.lblBpCd.AutoPopupID = null;
            this.lblBpCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBpCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBpCd.Location = new System.Drawing.Point(560, 29);
            this.lblBpCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblBpCd.Name = "lblBpCd";
            this.lblBpCd.Size = new System.Drawing.Size(137, 22);
            this.lblBpCd.StyleSetName = "Default";
            this.lblBpCd.TabIndex = 3;
            this.lblBpCd.Text = "고객사";
            this.lblBpCd.UseMnemonic = false;
            // 
            // lblProjectCd
            // 
            appearance23.TextHAlignAsString = "Left";
            appearance23.TextVAlignAsString = "Middle";
            this.lblProjectCd.Appearance = appearance23;
            this.lblProjectCd.AutoPopupID = null;
            this.lblProjectCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectCd.Location = new System.Drawing.Point(15, 52);
            this.lblProjectCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectCd.Name = "lblProjectCd";
            this.lblProjectCd.Size = new System.Drawing.Size(137, 22);
            this.lblProjectCd.StyleSetName = "Default";
            this.lblProjectCd.TabIndex = 4;
            this.lblProjectCd.Text = "프로젝트 번호";
            this.lblProjectCd.UseMnemonic = false;
            // 
            // lblTrackingNo
            // 
            appearance24.TextHAlignAsString = "Left";
            appearance24.TextVAlignAsString = "Middle";
            this.lblTrackingNo.Appearance = appearance24;
            this.lblTrackingNo.AutoPopupID = null;
            this.lblTrackingNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTrackingNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblTrackingNo.Location = new System.Drawing.Point(560, 52);
            this.lblTrackingNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblTrackingNo.Name = "lblTrackingNo";
            this.lblTrackingNo.Size = new System.Drawing.Size(137, 22);
            this.lblTrackingNo.StyleSetName = "Default";
            this.lblTrackingNo.TabIndex = 5;
            this.lblTrackingNo.Text = "Tracking No";
            this.lblTrackingNo.UseMnemonic = false;
            // 
            // lblDate
            // 
            appearance25.TextHAlignAsString = "Left";
            appearance25.TextVAlignAsString = "Middle";
            this.lblDate.Appearance = appearance25;
            this.lblDate.AutoPopupID = null;
            this.lblDate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDate.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDate.Location = new System.Drawing.Point(15, 75);
            this.lblDate.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(137, 22);
            this.lblDate.StyleSetName = "Default";
            this.lblDate.TabIndex = 6;
            this.lblDate.Text = "출고일";
            this.lblDate.UseMnemonic = false;
            // 
            // popSerialNo
            // 
            this.popSerialNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSerialNo.AutoPopupCodeParameter = null;
            this.popSerialNo.AutoPopupID = null;
            this.popSerialNo.AutoPopupNameParameter = null;
            this.popSerialNo.CodeMaxLength = 50;
            this.popSerialNo.CodeName = "";
            this.popSerialNo.CodeSize = 150;
            this.popSerialNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSerialNo.CodeTextBoxName = null;
            this.popSerialNo.CodeValue = "";
            this.popSerialNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popSerialNo.Location = new System.Drawing.Point(152, 7);
            this.popSerialNo.LockedField = false;
            this.popSerialNo.Margin = new System.Windows.Forms.Padding(0);
            this.popSerialNo.Name = "popSerialNo";
            this.popSerialNo.NameDisplay = false;
            this.popSerialNo.NameId = null;
            this.popSerialNo.NameMaxLength = 50;
            this.popSerialNo.NamePopup = false;
            this.popSerialNo.NameSize = 150;
            this.popSerialNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popSerialNo.Parameter = null;
            this.popSerialNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSerialNo.PopupId = null;
            this.popSerialNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSerialNo.QueryIfEnterKeyPressed = true;
            this.popSerialNo.RequiredField = false;
            this.popSerialNo.Size = new System.Drawing.Size(171, 21);
            this.popSerialNo.TabIndex = 7;
            this.popSerialNo.uniALT = "Serial No.";
            this.popSerialNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popSerialNo.UseDynamicFormat = false;
            this.popSerialNo.ValueTextBoxName = null;
            this.popSerialNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSerialNo_BeforePopupOpen);
            this.popSerialNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSerialNo_AfterPopupClosed);
            // 
            // popPlantCd
            // 
            this.popPlantCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPlantCd.AutoPopupCodeParameter = null;
            this.popPlantCd.AutoPopupID = null;
            this.popPlantCd.AutoPopupNameParameter = null;
            this.popPlantCd.CodeMaxLength = 10;
            this.popPlantCd.CodeName = "";
            this.popPlantCd.CodeSize = 100;
            this.popPlantCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popPlantCd.CodeTextBoxName = null;
            this.popPlantCd.CodeValue = "";
            this.popPlantCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popPlantCd.Location = new System.Drawing.Point(697, 7);
            this.popPlantCd.LockedField = false;
            this.popPlantCd.Margin = new System.Windows.Forms.Padding(0);
            this.popPlantCd.Name = "popPlantCd";
            this.popPlantCd.NameDisplay = true;
            this.popPlantCd.NameId = null;
            this.popPlantCd.NameMaxLength = 50;
            this.popPlantCd.NamePopup = false;
            this.popPlantCd.NameSize = 150;
            this.popPlantCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popPlantCd.Parameter = null;
            this.popPlantCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPlantCd.PopupId = null;
            this.popPlantCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPlantCd.QueryIfEnterKeyPressed = true;
            this.popPlantCd.RequiredField = false;
            this.popPlantCd.Size = new System.Drawing.Size(271, 21);
            this.popPlantCd.TabIndex = 8;
            this.popPlantCd.uniALT = "공장";
            this.popPlantCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPlantCd.UseDynamicFormat = false;
            this.popPlantCd.ValueTextBoxName = null;
            this.popPlantCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPlantCd_BeforePopupOpen);
            this.popPlantCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPlantCd_AfterPopupClosed);
            // 
            // popItemCd
            // 
            this.popItemCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popItemCd.AutoPopupCodeParameter = null;
            this.popItemCd.AutoPopupID = null;
            this.popItemCd.AutoPopupNameParameter = null;
            this.popItemCd.CodeMaxLength = 50;
            this.popItemCd.CodeName = "";
            this.popItemCd.CodeSize = 150;
            this.popItemCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popItemCd.CodeTextBoxName = null;
            this.popItemCd.CodeValue = "";
            this.popItemCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popItemCd.Location = new System.Drawing.Point(152, 30);
            this.popItemCd.LockedField = false;
            this.popItemCd.Margin = new System.Windows.Forms.Padding(0);
            this.popItemCd.Name = "popItemCd";
            this.popItemCd.NameDisplay = true;
            this.popItemCd.NameId = null;
            this.popItemCd.NameMaxLength = 50;
            this.popItemCd.NamePopup = false;
            this.popItemCd.NameSize = 150;
            this.popItemCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popItemCd.Parameter = null;
            this.popItemCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popItemCd.PopupId = null;
            this.popItemCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popItemCd.QueryIfEnterKeyPressed = true;
            this.popItemCd.RequiredField = false;
            this.popItemCd.Size = new System.Drawing.Size(321, 21);
            this.popItemCd.TabIndex = 9;
            this.popItemCd.uniALT = "품목";
            this.popItemCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popItemCd.UseDynamicFormat = false;
            this.popItemCd.ValueTextBoxName = null;
            this.popItemCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popItemCd_BeforePopupOpen);
            this.popItemCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popItemCd_AfterPopupClosed);
            this.popItemCd.OnChange += new System.EventHandler(this.popItemCd_OnChange);
            // 
            // popBpCd
            // 
            this.popBpCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popBpCd.AutoPopupCodeParameter = null;
            this.popBpCd.AutoPopupID = null;
            this.popBpCd.AutoPopupNameParameter = null;
            this.popBpCd.CodeMaxLength = 10;
            this.popBpCd.CodeName = "";
            this.popBpCd.CodeSize = 100;
            this.popBpCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popBpCd.CodeTextBoxName = null;
            this.popBpCd.CodeValue = "";
            this.popBpCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popBpCd.Location = new System.Drawing.Point(697, 30);
            this.popBpCd.LockedField = false;
            this.popBpCd.Margin = new System.Windows.Forms.Padding(0);
            this.popBpCd.Name = "popBpCd";
            this.popBpCd.NameDisplay = true;
            this.popBpCd.NameId = null;
            this.popBpCd.NameMaxLength = 50;
            this.popBpCd.NamePopup = false;
            this.popBpCd.NameSize = 150;
            this.popBpCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popBpCd.Parameter = null;
            this.popBpCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popBpCd.PopupId = null;
            this.popBpCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popBpCd.QueryIfEnterKeyPressed = true;
            this.popBpCd.RequiredField = false;
            this.popBpCd.Size = new System.Drawing.Size(271, 21);
            this.popBpCd.TabIndex = 10;
            this.popBpCd.uniALT = "고객사";
            this.popBpCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popBpCd.UseDynamicFormat = false;
            this.popBpCd.ValueTextBoxName = null;
            this.popBpCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popBpCd_BeforePopupOpen);
            this.popBpCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popBpCd_AfterPopupClosed);
            // 
            // popProjectCd
            // 
            this.popProjectCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popProjectCd.AutoPopupCodeParameter = null;
            this.popProjectCd.AutoPopupID = null;
            this.popProjectCd.AutoPopupNameParameter = null;
            this.popProjectCd.CodeMaxLength = 25;
            this.popProjectCd.CodeName = "";
            this.popProjectCd.CodeSize = 150;
            this.popProjectCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProjectCd.CodeTextBoxName = null;
            this.popProjectCd.CodeValue = "";
            this.popProjectCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popProjectCd.Location = new System.Drawing.Point(152, 53);
            this.popProjectCd.LockedField = false;
            this.popProjectCd.Margin = new System.Windows.Forms.Padding(0);
            this.popProjectCd.Name = "popProjectCd";
            this.popProjectCd.NameDisplay = true;
            this.popProjectCd.NameId = null;
            this.popProjectCd.NameMaxLength = 50;
            this.popProjectCd.NamePopup = false;
            this.popProjectCd.NameSize = 150;
            this.popProjectCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProjectCd.Parameter = null;
            this.popProjectCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popProjectCd.PopupId = null;
            this.popProjectCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popProjectCd.QueryIfEnterKeyPressed = true;
            this.popProjectCd.RequiredField = false;
            this.popProjectCd.Size = new System.Drawing.Size(321, 21);
            this.popProjectCd.TabIndex = 11;
            this.popProjectCd.uniALT = "프로젝트 번호";
            this.popProjectCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popProjectCd.UseDynamicFormat = false;
            this.popProjectCd.ValueTextBoxName = null;
            this.popProjectCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popProjectCd_BeforePopupOpen);
            this.popProjectCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popProjectCd_AfterPopupClosed);
            // 
            // popTrackingNo
            // 
            this.popTrackingNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popTrackingNo.AutoPopupCodeParameter = null;
            this.popTrackingNo.AutoPopupID = null;
            this.popTrackingNo.AutoPopupNameParameter = null;
            this.popTrackingNo.CodeMaxLength = 25;
            this.popTrackingNo.CodeName = "";
            this.popTrackingNo.CodeSize = 100;
            this.popTrackingNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popTrackingNo.CodeTextBoxName = null;
            this.popTrackingNo.CodeValue = "";
            this.popTrackingNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popTrackingNo.Location = new System.Drawing.Point(697, 53);
            this.popTrackingNo.LockedField = false;
            this.popTrackingNo.Margin = new System.Windows.Forms.Padding(0);
            this.popTrackingNo.Name = "popTrackingNo";
            this.popTrackingNo.NameDisplay = false;
            this.popTrackingNo.NameId = null;
            this.popTrackingNo.NameMaxLength = 50;
            this.popTrackingNo.NamePopup = false;
            this.popTrackingNo.NameSize = 150;
            this.popTrackingNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popTrackingNo.Parameter = null;
            this.popTrackingNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popTrackingNo.PopupId = null;
            this.popTrackingNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popTrackingNo.QueryIfEnterKeyPressed = true;
            this.popTrackingNo.RequiredField = false;
            this.popTrackingNo.Size = new System.Drawing.Size(171, 21);
            this.popTrackingNo.TabIndex = 12;
            this.popTrackingNo.uniALT = "Tracking No.";
            this.popTrackingNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popTrackingNo.UseDynamicFormat = false;
            this.popTrackingNo.ValueTextBoxName = null;
            this.popTrackingNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popTrackingNo_BeforePopupOpen);
            this.popTrackingNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popTrackingNo_AfterPopupClosed);
            // 
            // dtDate
            // 
            this.dtDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtDate.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.YYYYMMDD;
            this.dtDate.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtDate.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtDate.Location = new System.Drawing.Point(152, 76);
            this.dtDate.Margin = new System.Windows.Forms.Padding(0);
            this.dtDate.Name = "dtDate";
            this.dtDate.Size = new System.Drawing.Size(225, 21);
            this.dtDate.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.dtDate.TabIndex = 13;
            this.dtDate.uniFromALT = "출고일(시작)";
            this.dtDate.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtDate.uniTabSameValue = false;
            this.dtDate.uniToALT = "출고일(종료)";
            this.dtDate.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.DefaultRowSize = 23;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(1092, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 5;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.DefaultRowSize = 23;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 674);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(1092, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(1103, 723);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSerialNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPlantCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblItemCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBpCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblTrackingNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDate;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSerialNo;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPlantCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popItemCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popBpCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popProjectCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popTrackingNo;
        private uniERP.AppFramework.UI.Controls.uniDateTerm dtDate;

    }
}
