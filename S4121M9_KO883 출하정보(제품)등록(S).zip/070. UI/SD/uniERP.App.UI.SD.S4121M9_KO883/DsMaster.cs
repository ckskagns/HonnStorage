﻿namespace uniERP.App.UI.SD.S4121M9_KO883
{
    
    
    public partial class DsMaster {
        partial class E_TableDataTable
        {
        }
    }
}
