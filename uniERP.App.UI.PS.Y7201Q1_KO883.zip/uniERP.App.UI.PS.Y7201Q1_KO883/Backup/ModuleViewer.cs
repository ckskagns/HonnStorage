﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.DataBridge;

#endregion

namespace uniERP.App.UI.PS.Y7201Q1_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>uniERP.App.UI.PS.Y7201Q1_KO883</TemplateVersion>
        /// <NameSpace>①uniERP.App.UI.PS.Y7201Q1_KO883</NameSpace>
        /// <Module>②PS</Module>
        /// <Class>③class name</Class>
        /// <Desc>④
        ///   프로젝트 상세정보를 조회한다.
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="LYK" Date="2018-06-22">프로젝트상세조회(S) …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)
        private Y7201QA1 cqtdsY7201QA1 = new Y7201QA1();

        #endregion

        #region ■ 1.4 Class global constants (grid)

        #endregion

        #region ■ 1.5 Class global variables (grid)


        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Query, enumDef.ModuleInformation.ProjectManagement);

            this.LoadCustomInfTB19029();
        }

        protected override void Form_Load_Completed()
        {
            DateTime today = uniBase.UDate.GetDBServerDateTime();

            dtPerFromTo.uniFromValue = today.AddMonths(-1);
            dtPerFromTo.uniToValue = today;
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            return;
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {
            #region User Define Numeric Format Data Setting  ☆
            base.viewTB19029.ggUserDefined6.DecPoint = 0;
            base.viewTB19029.ggUserDefined6.Integeral = 15;
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            Y7201QA1.PMS_PRJ_PRODUCTSDataTable uniGridTB1 = new Y7201QA1.PMS_PRJ_PRODUCTSDataTable();
            uniGrid1.SSSetEdit(uniGridTB1.sales_grpColumn.ColumnName, "영업그룹", 90, enumDef.FieldType.ReadOnly);  //영업그룹
            uniGrid1.SSSetEdit(uniGridTB1.STATEColumn.ColumnName, "상태", 50, enumDef.FieldType.ReadOnly);      //진행상태
            uniGrid1.SSSetDate(uniGridTB1.plan_start_dtColumn.ColumnName, "시작일",enumDef.FieldType.ReadOnly, CommonVariable.CDT_YYYY_MM_DD);

            uniGrid1.SSSetEdit(uniGridTB1.PROJECT_CODEColumn.ColumnName, "Project", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.PROJECT_NMColumn.ColumnName, "Project Name", 150, enumDef.FieldType.ReadOnly);

            uniGrid1.SSSetEdit(uniGridTB1.project_typeColumn.ColumnName, "프로젝트종류", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.project_type_nmColumn.ColumnName, "프로젝트종류명", 130, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.project_type1Column.ColumnName, "프로젝트종류1", 130, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.project_type1_nmColumn.ColumnName, "프로젝트종류1명", 140, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext3_cd_ko883Column.ColumnName, "발주구분", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext3_nmColumn.ColumnName, "발주구분명", 110, enumDef.FieldType.ReadOnly);

            uniGrid1.SSSetEdit(uniGridTB1.SO_NOColumn.ColumnName, "수주번호", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.BP_CDColumn.ColumnName, "Sold to Party", enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.BP_NMColumn.ColumnName, "Sold to Party Name", 170, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.PLANT_CDColumn.ColumnName, "Plant",80,enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.PLANT_NMColumn.ColumnName, "Plant Name", 110, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ITEM_CDColumn.ColumnName, "Item", 150, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ITEM_NMColumn.ColumnName, "Item Desc", 200, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.SPECColumn.ColumnName, "Specification", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.TRACKING_NOColumn.ColumnName, "Tracking No.", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.CURRENCYColumn.ColumnName, "Currency", 90,  enumDef.FieldType.ReadOnly,enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            uniGrid1.SSSetFloat(uniGridTB1.SO_QTYColumn.ColumnName, "Qty",85, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.SO_PRICEColumn.ColumnName, "Price",120, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);

            //180821
            uniGrid1.SSSetFloat(uniGridTB1.xch_rateColumn.ColumnName, "환율", 120, viewTB19029.ggExchRate, enumDef.FieldType.ReadOnly); 
            uniGrid1.SSSetFloat(uniGridTB1.net_amtColumn.ColumnName, "금액", 120, viewTB19029.ggAmtOfMoney, enumDef.FieldType.ReadOnly); 
            uniGrid1.SSSetFloat(uniGridTB1.NET_AMT_LOCColumn.ColumnName, "Net Amt.", 120, viewTB19029.ggAmtOfMoney, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.vat_typeColumn.ColumnName, "부가세유형", 110, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.vat_type_nmColumn.ColumnName, "부가세유형명", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.vat_rateColumn.ColumnName, "부가세율", 90, viewTB19029.ggExchRate, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.vat_amtColumn.ColumnName, "부가세금액", 105, viewTB19029.ggAmtOfMoney, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.vat_amt_locColumn.ColumnName, "부가세금액(자국)", 140, viewTB19029.ggAmtOfMoney, enumDef.FieldType.ReadOnly);
        
            uniGrid1.SSSetDate(uniGridTB1.DLVY_DTColumn.ColumnName, "S/O Date", enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.MINOR_NMColumn.ColumnName, "Proc.Status", enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            uniGrid1.SSSetEdit(uniGridTB1.ext1_cd_ko883Column.ColumnName, "설계담당", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext1_nmColumn.ColumnName, "설계담당명", 130, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext2_cd_ko883Column.ColumnName, "CS담당", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext2_nmColumn.ColumnName, "CS담당명", 130, enumDef.FieldType.ReadOnly);

            uniGrid1.SSSetDate(uniGridTB1.ext1_dt_ko883Column.ColumnName, "발주일", enumDef.FieldType.ReadOnly, CommonVariable.CDT_YYYY_MM_DD);
            uniGrid1.SSSetEdit(uniGridTB1.ext4_cd_ko883Column.ColumnName, "전자결재요청자", 130, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext4_nmColumn.ColumnName, "전자결재요청자명", 150, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.approval_rtnColumn.ColumnName, "결재상태", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.approval_rtn_nmColumn.ColumnName, "결재상태명", 110, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            uniGrid1.SSSetEdit(uniGridTB1.ext5_cd_ko883Column.ColumnName, "고객담당자", 130, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext6_cd_ko883Column.ColumnName, "고객담당자(부서)", 150, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext7_cd_ko883Column.ColumnName, "고객담당자(연락처)", 160, enumDef.FieldType.ReadOnly);
           
            

            #endregion

            #region ■■ 3.1.2 Formatting grid information

            uniGrid1.flagInformation("select_char", "row");
            uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.Yes, enumDef.IsSearch.Yes);
            uniGrid1.DisplayLayout.Override.HeaderClickAction = HeaderClickAction.ExternalSortMulti;

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            // Hidden Column Setting
            //uniGrid1.SSSetColHidden(uniGridTB1.project_type1Column.ColumnName);
            //uniGrid1.SSSetColHidden(uniGridTB1.project_type1_nmColumn.ColumnName);
            //uniGrid1.SSSetColHidden(uniGridTB1.project_typeColumn.ColumnName);
            //uniGrid1.SSSetColHidden(uniGridTB1.project_type_nmColumn.ColumnName);
            uniGrid1.SSSetColHidden(uniGridTB1.sales_grpColumn.ColumnName);
            uniGrid1.SSSetColHidden(uniGridTB1.STATEColumn.ColumnName);
            uniGrid1.SSSetColHidden(uniGridTB1.plan_start_dtColumn.ColumnName);

            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            InitSpreadSheet();

            this.uniGrid1.uniGridSetDataBinding(cqtdsY7201QA1.PMS_PRJ_PRODUCTS);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //if (dtPerFromTo.uniFromValue > dtPerFromTo.uniToValue)
            //{
            //    uniBase.UMessage.DisplayMessageBox("970023", MessageBoxButtons.OK, dtPerFromTo.uniToALT, dtPerFromTo.uniFromALT);

            //    return true;
            //}

            //return DBQuery();
            if ((dtPerFromTo.uniDateTimeF.Value != null) && (dtPerFromTo.uniDateTimeT.Value != null))    //date값이 필수가 아닐 경우
            {
                if (!uniBase.UDate.CompareDateBetween(dtPerFromTo.uniDateTimeF, dtPerFromTo.uniDateTimeT, "970023"))    //%1 은(는) %2 보다 크거나 같아야합니다.
                {
                    dtPerFromTo.Focus();
                    return false;
                }
            }
            return DBQuery();

        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)

        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic

            return DBSave();
        }

        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            //TO-DO : code business oriented logic
            DataSet pDataSet = null;

            //string[] UNISqlId = new string[1] { "Y7201QA1" };
            //string[][] UNIValue = new string[1][];
            //UNIValue[0] = new string[4];

            //if (popProject.CodeValue.Trim() != "")
            //{
            //    UNIValue[0][0] = " AND A.PROJECT_CODE like " + uniBase.UCommon.FilterVariable("%" + popProject.CodeValue + "%", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            //}

            //if (popSalesGrp.CodeValue.Trim() != "")
            //{
            //    UNIValue[0][1] = " AND B.SALES_GRP like " + uniBase.UCommon.FilterVariable("%" + popSalesGrp.CodeValue + "%", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            //}

            //if (popOrg.CodeValue.Trim() != "")
            //{
            //    UNIValue[0][2] = " AND B.BP_CD like " + uniBase.UCommon.FilterVariable("%" + popOrg.CodeValue + "%", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            //}

            //if (cboState.Text != "")
            //{
            //    UNIValue[0][3] = " AND B.STATE = " + cboState.Value;
            //}

            //UNIValue[0][3] = UNIValue[0][3] + " AND B.PLAN_START_DT BETWEEN " + uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD, true);
            //UNIValue[0][3] = UNIValue[0][3] + " AND " + uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeT, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD, true);

            string dtPerFr = uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD, false);
            string dtPerTo = uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeT, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD, false);
    
            try
            {
                using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_PAMTEK_Y7201Q1_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@BP_CD", SqlDbType.NVarChar, popOrg.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@SALES_GRP", SqlDbType.NVarChar, popSalesGrp.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PROJECT_CD", SqlDbType.NVarChar, popProject.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@STATE", SqlDbType.Int, cboState.Value);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PROJECT_FROM", SqlDbType.NVarChar, dtPerFr);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PROJECT_TO", SqlDbType.NVarChar, dtPerTo);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@EXT2_CD", SqlDbType.NVarChar, popExt2Cd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@EXT1_CD", SqlDbType.NVarChar, popExt1Cd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@EXT3_CD", SqlDbType.NVarChar, popExt3Cd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@EXT5_CD", SqlDbType.NVarChar, popExt5Cd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@APPRV_STATE", SqlDbType.NVarChar, popApprvStatus.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@SO_NO", SqlDbType.NVarChar, txtSoNo.Value);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PROJECT_TYPE", SqlDbType.NVarChar, popProjectType.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PROJECT_TYPE1", SqlDbType.NVarChar, popProjectType1.CodeValue.Trim());

                    pDataSet = uniBase.UDatabase.ExecuteDataSet(iuniCommand);

                }
              //  pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables.Count == 0 || pDataSet.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return false;
                }
                else
                {
                    uniBase.UData.MergeDataTable(cqtdsY7201QA1.PMS_PRJ_PRODUCTS, pDataSet.Tables[0], false, MissingSchemaAction.Ignore);

                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }

            //cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Merge(pDataSet.Tables[0]);

            // total value and color setting
            //for (int i = 0; i < cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows.Count; i++)
            //{
            //    if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "소계")
            //    {
            //        uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(204, 255, 153);
            //    }
            //    if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "총계")
            //    {
            //        uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(176, 234, 244);
            //    }
            //    if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "3")
            //    {
            //        uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(224, 206, 244);
            //    }
            //    if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "4")
            //    {
            //        uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(251, 226, 153);
            //    }
            //    if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "5")
            //    {
            //        uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 153);
            //    }


            //    if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_qty"].ToString() == "" || cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_qty"] == null)
            //    {
            //        cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_qty"] = 0;
            //    }

            //    if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_price"].ToString() == "" || cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_price"] == null)
            //    {
            //        cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_price"] = 0;
            //    }

            //    if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["net_amt_loc"].ToString() == "" || cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["net_amt_loc"] == null)
            //    {
            //        cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["net_amt_loc"] = 0;
            //    }
            //}

            for (int i = 0; i < cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows.Count; i++)
            {
                if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "소계")
                {
                    uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(204, 255, 153);
                    
                }
                if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "총계")
                {
                    uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(176, 234, 244);
                }
                if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "3")
                {
                    uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(224, 206, 244);
                }
                if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "4")
                {
                    uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(251, 226, 153);
                }
                if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["project_code"].ToString() == "5")
                {
                    uniGrid1.Rows[i].Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 153);
                }


                if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_qty"].ToString() == "" || cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_qty"] == null)
                {
                    cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_qty"] = 0;
                }

                if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_price"].ToString() == "" || cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_price"] == null)
                {
                    cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["so_price"] = 0;
                }

                if (cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["net_amt_loc"].ToString() == "" || cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["net_amt_loc"] == null)
                {
                    cqtdsY7201QA1.PMS_PRJ_PRODUCTS.Rows[i]["net_amt_loc"] = 0;
                }
            }


            return true;
        }

        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {

            return true;
        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        #region ■■ 5.2.1 ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ButtonClicked >>> ClickCellButton

        #region ■■ 5.2.2 Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeExitEditMode(object sender, Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs e)
        {
        }

        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {

        }
        #endregion ■■ Change >>> CellChange

        #region ■■ 5.2.3 Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
        }
        #endregion ■■ Click >>> AfterSelectChange

        #region ■■ 5.2.4 ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ComboSelChange >>> CellListSelect

        #region ■■ 5.2.5 DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
        }
        #endregion ■■ DblClick >>> DoubleClickCell

        #region ■■ 5.2.6 MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
        }
        #endregion ■■ MouseDown >>> MouseDown

        #region ■■ 5.2.7 ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
        }
        #endregion ■■ ScriptLeaveCell >>> BeforeCellDeactivate

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        private void popOrg_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Customer";
            e.PopupPassData.ConditionCaption = "Customer";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER(nolock)";
            e.PopupPassData.SQLWhereStatements = " BP_TYPE in('C','CS') AND usage_flag = 'Y'";
            e.PopupPassData.SQLWhereInputCodeValue = popOrg.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "BP_CD";
            e.PopupPassData.GridCellCode[1] = "BP_NM";
            e.PopupPassData.GridCellCode[2] = "BP_RGST_NO";

            e.PopupPassData.GridCellCaption[0] = "Customer";
            e.PopupPassData.GridCellCaption[1] = "Customer Name";
            e.PopupPassData.GridCellCaption[2] = "Corp. Registration No.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }

        private void popSalesGrp_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Sales Group";
            e.PopupPassData.ConditionCaption = "Sales Group";

            e.PopupPassData.SQLFromStatements = "B_SALES_GRP(nolock)";
            e.PopupPassData.SQLWhereStatements = " USAGE_FLAG = 'Y'";
            e.PopupPassData.SQLWhereInputCodeValue = popSalesGrp.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "SALES_GRP";
            e.PopupPassData.GridCellCode[1] = "SALES_GRP_NM";

            e.PopupPassData.GridCellCaption[0] = "Sales Group";
            e.PopupPassData.GridCellCaption[1] = "Sales Group Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popOrg_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null) return;

            iDataSet = (DataSet)e.ResultData.Data;

            popOrg.CodeValue = iDataSet.Tables[0].Rows[0]["BP_CD"].ToString();
            popOrg.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
        }

        private void popSalesGrp_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null) return;

            iDataSet = (DataSet)e.ResultData.Data;

            popSalesGrp.CodeValue = iDataSet.Tables[0].Rows[0]["SALES_GRP"].ToString();
            popSalesGrp.CodeName = iDataSet.Tables[0].Rows[0]["SALES_GRP_NM"].ToString();
        }

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void popProject_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
        //    e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.Y8204PA5_KO883";
        //    e.PopupPassData.PopupWinTitle = "Project No PopUp";
        //    e.PopupPassData.PopupWinWidth = 800;
        //    e.PopupPassData.PopupWinHeight = 700;

        //    DataSet iqtds = new DataSet();
        //    DataTable iqtbl = new DataTable();
        //    iqtbl.Columns.Add("ProjectCd");
        //    iqtbl.Columns.Add("BpCd");
        //    iqtbl.Columns.Add("frDt");
        //    iqtbl.Columns.Add("toDt");
        //    iqtbl.Columns.Add("BPNm");
        //    iqtbl.Columns.Add("ProjectNm");

        //    DataRow row1 = iqtbl.NewRow();
        //    row1["ProjectCd"] = popProject.CodeValue.Trim().ToString();
        //    row1["BpCd"] = popOrg.CodeValue.Trim().ToString();
        //    if (dtPerFromTo.uniDateTimeF.Value == null)
        //    {
        //        row1["frDt"] = "";
        //    }
        //    else
        //    {
        //        row1["frDt"] = dtPerFromTo.uniDateTimeF.Value.ToString();
        //    }

        //    if (dtPerFromTo.uniDateTimeT.Value == null)
        //    {
        //        row1["toDt"] = "";
        //    }
        //    else
        //    {
        //        row1["toDt"] = dtPerFromTo.uniDateTimeT.Value.ToString();
        //    }
        //    row1["BPNm"] = popOrg.CodeName.Trim().ToString();
        //    row1["ProjectNm"] = popProject.CodeName.Trim().ToString();

        //    iqtbl.Rows.Add(row1);
        //    iqtds.Tables.Add(iqtbl);

        //    e.PopupPassData.Data = iqtds;
            
            e.PopupPassData.PopupWinTitle = "프로젝트";
            e.PopupPassData.ConditionCaption = "프로젝트";

            e.PopupPassData.SQLFromStatements = "PMS_PROJECT(nolock)";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.SQLWhereInputCodeValue = popProject.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;


            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "PROJECT_CODE";
            e.PopupPassData.GridCellCode[1] = "PROJECT_NM";

            e.PopupPassData.GridCellCaption[0] = "프로젝트코드";
            e.PopupPassData.GridCellCaption[1] = "프로젝트명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popProject_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            //DataSet iDataSet = new DataSet();

            //if (e.ResultData.Data == null)
            //    return;

            //iDataSet = (DataSet)e.ResultData.Data;

            //popProject.CodeValue = iDataSet.Tables[0].Rows[0][0].ToString();
            //popProject.CodeName = iDataSet.Tables[0].Rows[0][1].ToString();
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popProject.CodeValue = iDataSet.Tables[0].Rows[0]["PROJECT_CODE"].ToString();
            popProject.CodeName = iDataSet.Tables[0].Rows[0]["PROJECT_NM"].ToString();
        }

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors

            #endregion

            #region ▶▶▶ 10.1.2.2 Setting Returned Data

            #endregion
        }

        #endregion

        private void popProject_OnExitEditCode(object sender, EventArgs e)
        {
            //DataSet iDataSet = new DataSet();

            //string strWhere = "";

            //if (popProject.CodeValue.Trim().ToString() == "")
            //{
            //    popProject.CodeValue = "";
            //    popProject.CodeName = "";
            //}
            //else
            //{
            //    strWhere = " PROJECT_CODE = " + uniBase.UCommon.FilterVariable(popProject.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);

            //    iDataSet = uniBase.UDataAccess.CommonQueryRs(" PROJECT_NM", " PMS_PROJECT", strWhere);

            //    if (iDataSet == null || iDataSet.Tables[0].Rows.Count == 0)
            //    {
            //        popProject.CodeName = "";
            //    }
            //    else
            //    {
            //        popProject.CodeName = iDataSet.Tables[0].Rows[0][0].ToString();
            //    }
            //}
        }

        #endregion

        //CS담당팝업
        private void popExt2Cd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "CS담당";
            e.PopupPassData.ConditionCaption = "CS담당";

            e.PopupPassData.SQLFromStatements = "PMS_PROJECT A(NOLOCK) LEFT JOIN HAA010T B(NOLOCK) ON A.EXT2_CD_KO883 = B.EMP_NO";
            e.PopupPassData.SQLWhereInputCodeValue = popExt2Cd.CodeValue.Trim();
            e.PopupPassData.SQLWhereStatements = "ISNULL(A.EXT2_CD_KO883,'')<>''";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new string[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];
            e.PopupPassData.GridCellCodeAlias = new string[2];

            e.PopupPassData.GridCellCode[0] = "A.EXT2_CD_KO883";
            e.PopupPassData.GridCellCode[1] = "B.NAME";

            e.PopupPassData.GridCellCodeAlias[0] = "CODE";
            e.PopupPassData.GridCellCodeAlias[1] = "NAME";

            e.PopupPassData.GridCellCaption[0] = "CS담당";
            e.PopupPassData.GridCellCaption[1] = "CS담당명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popExt2Cd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popExt2Cd.CodeValue = iDataSet.Tables[0].Rows[0]["CODE"].ToString();
            popExt2Cd.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();

        }

        //설계담당
        private void popExt1Cd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "설계담당";
            e.PopupPassData.ConditionCaption = "설계담당";

            e.PopupPassData.SQLFromStatements = "PMS_PROJECT A(NOLOCK) LEFT JOIN HAA010T B(NOLOCK) ON A.EXT1_CD_KO883 = B.EMP_NO";
            e.PopupPassData.SQLWhereInputCodeValue = popExt1Cd.CodeValue.Trim();
            e.PopupPassData.SQLWhereStatements = "ISNULL(A.EXT1_CD_KO883,'')<>''";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new string[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];
            e.PopupPassData.GridCellCodeAlias = new string[2];

            e.PopupPassData.GridCellCode[0] = "A.EXT1_CD_KO883";
            e.PopupPassData.GridCellCode[1] = "B.NAME";

            e.PopupPassData.GridCellCodeAlias[0] = "CODE";
            e.PopupPassData.GridCellCodeAlias[1] = "NAME";

            e.PopupPassData.GridCellCaption[0] = "설계담당";
            e.PopupPassData.GridCellCaption[1] = "설계담당명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popExt1Cd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popExt1Cd.CodeValue = iDataSet.Tables[0].Rows[0]["CODE"].ToString();
            popExt1Cd.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();
        }

        //발주구분
        private void popExt3Cd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "발주구분";
            e.PopupPassData.ConditionCaption = "발주구분";

            e.PopupPassData.SQLFromStatements = "B_MINOR(NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popExt3Cd.CodeValue.Trim();
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD = 'XPM01' AND (minor_cd='PO' OR minor_cd='PR')";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new string[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];
            e.PopupPassData.GridCellCodeAlias = new string[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCodeAlias[0] = "CODE";
            e.PopupPassData.GridCellCodeAlias[1] = "NAME";

            e.PopupPassData.GridCellCaption[0] = "발주구분";
            e.PopupPassData.GridCellCaption[1] = "발주구분명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        

        private void popExt3Cd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popExt3Cd.CodeValue = iDataSet.Tables[0].Rows[0]["CODE"].ToString();
            popExt3Cd.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();
        }

        //전자결재요청자
        private void popExt5Cd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "전자결재요청";
            e.PopupPassData.ConditionCaption = "전자결재요청";

            e.PopupPassData.SQLFromStatements = "PMS_PROJECT A(NOLOCK) LEFT JOIN HAA010T B(NOLOCK) ON A.EXT4_CD_KO883 = B.EMP_NO";
            e.PopupPassData.SQLWhereInputCodeValue = popExt5Cd.CodeValue.Trim();
            e.PopupPassData.SQLWhereStatements = "ISNULL(A.EXT4_CD_KO883,'')<>''";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new string[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];
            e.PopupPassData.GridCellCodeAlias = new string[2];

            e.PopupPassData.GridCellCode[0] = "A.EXT4_CD_KO883";
            e.PopupPassData.GridCellCode[1] = "B.NAME";

            e.PopupPassData.GridCellCodeAlias[0] = "CODE";
            e.PopupPassData.GridCellCodeAlias[1] = "NAME";

            e.PopupPassData.GridCellCaption[0] = "전자결재요청";
            e.PopupPassData.GridCellCaption[1] = "전자결재요청자";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popExt5Cd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popExt5Cd.CodeValue = iDataSet.Tables[0].Rows[0]["CODE"].ToString();
            popExt5Cd.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();
        }

        //결재상태
        private void popApprvStatus_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "결재상태";
            e.PopupPassData.ConditionCaption = "결재상태";

            e.PopupPassData.SQLFromStatements = "B_MINOR(NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popApprvStatus.CodeValue.Trim();
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD = 'SM003'";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new string[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];
            e.PopupPassData.GridCellCodeAlias = new string[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCodeAlias[0] = "CODE";
            e.PopupPassData.GridCellCodeAlias[1] = "NAME";

            e.PopupPassData.GridCellCaption[0] = "결재상태";
            e.PopupPassData.GridCellCaption[1] = "결재상태명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popApprvStatus_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popApprvStatus.CodeValue = iDataSet.Tables[0].Rows[0]["CODE"].ToString();
            popApprvStatus.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();
        }
        
        //미리보기btn
        private void btnPreview_Click(object sender, EventArgs e)
        {
            PrintEasyBaseDocument(enumDef.EasyBaseActionType.View);
        }
        #region PrintEasyBaseDocument
        private void PrintEasyBaseDocument(enumDef.EasyBaseActionType pEasyBaseActionType)
        {
            StringBuilder isbURL = new StringBuilder();
            string istrEasyBaseID;


            if (!uniBase.UCommon.CheckRequiredFields(enumDef.PanelType.Condition))                      //TO-DO : check fields
                return;
            else if (uniGrid1.ActiveRow == null)
            {
                uniBase.UMessage.DisplayMessageBox("J10066", MessageBoxButtons.OK);
                return;
            }
            else if (uniGrid1.ActiveRow.Cells["PROJECT_CODE"].Value.ToString() == "소계")
            {
                return;
            }
            else if (uniGrid1.ActiveRow.Cells["PROJECT_CODE"].Value.ToString() == "총계")
            {
                return;
            }
            //TO-DO : Batch , SP or DLL Call
            this.Presenter.ProgressBarController.DisplayProgressBar();
            try
            {
                if (!SetPrintConditionValue(isbURL, out istrEasyBaseID))                                    //TO-DO : set EasyBase file name and parameters
                    return;

                switch (pEasyBaseActionType)                                                                  //TO-DO : EasyBase Start
                {
                    case enumDef.EasyBaseActionType.View:
                        uniBase.UEasyBase.PreviewEBRDocument(istrEasyBaseID, isbURL.ToString());
                        break;
                    case enumDef.EasyBaseActionType.Print:
                        uniBase.UEasyBase.PrintEBRDocument(istrEasyBaseID, isbURL.ToString());
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                this.Presenter.ProgressBarController.HideProgressBar();
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
            this.Presenter.ProgressBarController.HideProgressBar();
        } 
        #endregion
        
        #region SetPrintConditionValue
        private bool SetPrintConditionValue(StringBuilder psbURL, out string pstrEasyBaseID)
        {
            string cstrEasyBaseID = "";
         
            cstrEasyBaseID = "y7201q1_ko883";   
            pstrEasyBaseID = uniBase.UEasyBase.AskEBDocumentName(cstrEasyBaseID, enumDef.EasyBaseDocType.EBR.ToString());

            //if (uniGrid1.ActiveRow == null)
            //{
            //    uniBase.UMessage.DisplayMessageBox("J10066", MessageBoxButtons.OK);
            //    return false;
            //}
            
                //if(dtPerFromTo.uniDateTimeF.Value == null)      //dt값이 null일경우 전체검색 되도록
                //{
                //    dtPerFromTo.uniDateTimeF.Value = CommonVariable.gMinimumDate;
                //}
                //if (dtPerFromTo.uniDateTimeT.Value == null)
                //{
                //    dtPerFromTo.uniDateTimeT.Value = CommonVariable.gMaximumDate;
                //}

                //psbURL.Append("BP_CD|").Append(popOrg.CodeValue.Trim());
                //psbURL.Append("|SALES_GRP|").Append(popSalesGrp.CodeValue.Trim());
                //psbURL.Append("|PROJECT_CD|").Append(popProject.CodeValue.Trim());
                //psbURL.Append("|STATE|").Append(cboState.Value.ToString());
                //psbURL.Append("|PROJECT_FROM|").Append(dtPerFromTo.uniDateTimeF.uniValue.ToString(CommonVariable.CDT_YYYY_MM_DD));
                //psbURL.Append("|PROJECT_TO|").Append(dtPerFromTo.uniDateTimeT.uniValue.ToString(CommonVariable.CDT_YYYY_MM_DD));
                //psbURL.Append("|EXT2_CD|").Append(popExt2Cd.CodeValue.Trim());
                //psbURL.Append("|EXT1_CD|").Append(popExt1Cd.CodeValue.Trim());
                //psbURL.Append("|EXT3_CD|").Append(popExt3Cd.CodeValue.Trim());
                //psbURL.Append("|EXT5_CD|").Append(popExt5Cd.CodeValue.Trim());
                //psbURL.Append("|APPRV_STATE|").Append(popApprvStatus.CodeValue.Trim());
                //psbURL.Append("|SO_NO|").Append(txtSoNo.Text.Trim());

                psbURL.Append("BP_CD|").Append(uniGrid1.ActiveRow.Cells["BP_CD"].Value);    //고객
                psbURL.Append("|SALES_GRP|").Append(uniGrid1.ActiveRow.Cells["SALES_GRP"].Value);   //영업그룹
                psbURL.Append("|PROJECT_CD|").Append(uniGrid1.ActiveRow.Cells["PROJECT_CODE"].Value);   //프로젝트번호
                psbURL.Append("|STATE|").Append(uniGrid1.ActiveRow.Cells["STATE"].Value);   //진행상태
                psbURL.Append("|PLAN_START_DT|").Append(uniGrid1.ActiveRow.Cells["PLAN_START_DT"].Value.ToString().Substring(0, 10));   //프로젝트기간
                psbURL.Append("|EXT2_CD|").Append(uniGrid1.ActiveRow.Cells["EXT2_CD_KO883"].Value); //CS담당
                psbURL.Append("|EXT1_CD|").Append(uniGrid1.ActiveRow.Cells["EXT1_CD_KO883"].Value); //설계담당
                psbURL.Append("|EXT3_CD|").Append(uniGrid1.ActiveRow.Cells["EXT3_CD_KO883"].Value); //발주구분
                psbURL.Append("|EXT5_CD|").Append(uniGrid1.ActiveRow.Cells["EXT5_CD_KO883"].Value); //전자결재요청자
                psbURL.Append("|APPRV_STATE|").Append(uniGrid1.ActiveRow.Cells["APPROVAL_RTN"].Value);  //결재상태
                psbURL.Append("|SO_NO|").Append(uniGrid1.ActiveRow.Cells["SO_NO"].Value);   //수주번호
                return true;

            
        }
        #endregion

        //출력btn
        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintEasyBaseDocument(enumDef.EasyBaseActionType.Print);
        }
        //결재(진행사항)Btn
        private void btnApprv_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {

            if (this.uniGrid1.ActiveCell == null && this.uniGrid1.ActiveRow == null)
            {
                e.Cancel = true;    //팝업띄우기 취소
                return;
            }
            if (this.uniGrid1.Rows.Count == 0)
            {
                // 조회를 먼저 하십시오.
                uniBase.UMessage.DisplayMessageBox("900002", MessageBoxButtons.OK);
                e.Cancel = true;
                return;
            }
     
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.Y7204P1_KO883";
            e.PopupPassData.PopupWinTitle = "Project 진행 요청서";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 600;

            string[] appParam = new String[5];
            appParam[0] = uniGrid1.ActiveRow.Cells["PROJECT_TYPE1_NM"].Value.ToString().Trim();
            appParam[1] = uniGrid1.ActiveRow.Cells["PROJECT_CODE"].Value.ToString().Trim();
            appParam[2] = uniGrid1.ActiveRow.Cells["PROJECT_NM"].Value.ToString();
            appParam[3] = uniGrid1.ActiveRow.Cells["PROJECT_TYPE_NM"].Value.ToString().Trim();
            appParam[4] = uniGrid1.ActiveRow.Cells["PROJECT_CODE"].Value.ToString().Trim(); ;

            e.PopupPassData.Data = appParam;

        }

        private void popProjectType_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "프로젝트종류";
            e.PopupPassData.ConditionCaption = "프로젝트종류";


            //string strSQL = string.Format(@"SELECT PROJECT_TYPE, DBO.ufn_GetCodeName('Y0003', A.PROJECT_TYPE) AS PROJECT_TYPE_NM FROM PMS_PROJECT(nolock)");
            e.PopupPassData.SQLFromStatements = "B_MINOR B (NOLOCK)";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD = 'Y0003'";
            e.PopupPassData.SQLWhereInputCodeValue = popProjectType.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;


            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "프로젝트종류";
            e.PopupPassData.GridCellCaption[1] = "프로젝트종류명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popProjectType_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popProjectType.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popProjectType.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }

        private void popProjectType1_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "프로젝트종류1";
            e.PopupPassData.ConditionCaption = "프로젝트종류1";


            //string strSQL = string.Format(@"SELECT PROJECT_TYPE, DBO.ufn_GetCodeName('Y0003', A.PROJECT_TYPE) AS PROJECT_TYPE_NM FROM PMS_PROJECT(nolock)");
            e.PopupPassData.SQLFromStatements = "B_MINOR B (NOLOCK)";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD = 'Y0011'";
            e.PopupPassData.SQLWhereInputCodeValue = popProjectType1.CodeValue.Trim().ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;


            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "프로젝트종류1";
            e.PopupPassData.GridCellCaption[1] = "프로젝트종류1명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popProjectType1_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popProjectType1.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popProjectType1.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }


        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        #endregion

        #endregion

    }
}