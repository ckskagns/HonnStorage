﻿using System.Windows.Forms;

using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

using uniERP.AppFramework.UI.Module;


namespace uniERP.App.UI.POPUP.Y7204P1_KO883
{

    public class ModuleInitializer : PopupModule
    {

        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterPopupViewer()
        {
            base.AddModule<PopupViewer>();
        }

    }
    partial class PopupViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.txtProjectType = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblProjectNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProjectType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProjectType1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTableLayoutPanel1 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.txtProjectNo = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblProjectNm = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtProjectNm = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTableLayoutPanel2 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.txtProjectType1 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.txtDocId = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblDocId = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnOK = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTableLayoutPanel3 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniGrid2 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_MainCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectType)).BeginInit();
            this.uniTableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectNm)).BeginInit();
            this.uniTableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectType1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDocId)).BeginInit();
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainReference.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            this.uniTableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).BeginInit();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.Location = new System.Drawing.Point(-5, 0);
            this.uniLabel_Path.Size = new System.Drawing.Size(0, 0);
            this.uniLabel_Path.Visible = false;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 2;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.52282F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 85.47718F));
            this.uniTBL_MainCondition.Controls.Add(this.txtProjectType, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblProjectNo, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblProjectType, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblProjectType1, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.uniTableLayoutPanel1, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.uniTableLayoutPanel2, 1, 2);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 40F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 4;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(950, 85);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // txtProjectType
            // 
            this.txtProjectType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance1.TextVAlignAsString = "Bottom";
            this.txtProjectType.Appearance = appearance1;
            this.txtProjectType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtProjectType.Location = new System.Drawing.Point(137, 7);
            this.txtProjectType.LockedField = false;
            this.txtProjectType.Margin = new System.Windows.Forms.Padding(0);
            this.txtProjectType.Name = "txtProjectType";
            this.txtProjectType.QueryIfEnterKeyPressed = true;
            this.txtProjectType.RequiredField = false;
            this.txtProjectType.Size = new System.Drawing.Size(150, 21);
            this.txtProjectType.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtProjectType.StyleSetName = "Default";
            this.txtProjectType.TabIndex = 7;
            this.txtProjectType.uniALT = null;
            this.txtProjectType.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProjectType.UseDynamicFormat = false;
            // 
            // lblProjectNo
            // 
            appearance2.TextHAlignAsString = "Left";
            appearance2.TextVAlignAsString = "Middle";
            this.lblProjectNo.Appearance = appearance2;
            this.lblProjectNo.AutoPopupID = null;
            this.lblProjectNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectNo.Location = new System.Drawing.Point(15, 29);
            this.lblProjectNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectNo.Name = "lblProjectNo";
            this.lblProjectNo.Size = new System.Drawing.Size(122, 22);
            this.lblProjectNo.StyleSetName = "Default";
            this.lblProjectNo.TabIndex = 3;
            this.lblProjectNo.Text = "PROJECT NO.";
            this.lblProjectNo.UseMnemonic = false;
            // 
            // lblProjectType
            // 
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.lblProjectType.Appearance = appearance3;
            this.lblProjectType.AutoPopupID = null;
            this.lblProjectType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectType.Location = new System.Drawing.Point(15, 6);
            this.lblProjectType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectType.Name = "lblProjectType";
            this.lblProjectType.Size = new System.Drawing.Size(122, 22);
            this.lblProjectType.StyleSetName = "Default";
            this.lblProjectType.TabIndex = 1;
            this.lblProjectType.Text = "구분";
            this.lblProjectType.UseMnemonic = false;
            // 
            // lblProjectType1
            // 
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.lblProjectType1.Appearance = appearance4;
            this.lblProjectType1.AutoPopupID = null;
            this.lblProjectType1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectType1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectType1.Location = new System.Drawing.Point(15, 52);
            this.lblProjectType1.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectType1.Name = "lblProjectType1";
            this.lblProjectType1.Size = new System.Drawing.Size(122, 22);
            this.lblProjectType1.StyleSetName = "Default";
            this.lblProjectType1.TabIndex = 2;
            this.lblProjectType1.Text = "프로젝트 종류";
            this.lblProjectType1.UseMnemonic = false;
            // 
            // uniTableLayoutPanel1
            // 
            this.uniTableLayoutPanel1.AutoFit = false;
            this.uniTableLayoutPanel1.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel1.AutoFitRowCount = 4;
            this.uniTableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel1.ColumnCount = 3;
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.60899F));
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.78202F));
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.60899F));
            this.uniTableLayoutPanel1.Controls.Add(this.txtProjectNo, 0, 0);
            this.uniTableLayoutPanel1.Controls.Add(this.lblProjectNm, 1, 0);
            this.uniTableLayoutPanel1.Controls.Add(this.txtProjectNm, 2, 0);
            this.uniTableLayoutPanel1.DefaultRowSize = 23;
            this.uniTableLayoutPanel1.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel1.Location = new System.Drawing.Point(137, 28);
            this.uniTableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel1.Name = "uniTableLayoutPanel1";
            this.uniTableLayoutPanel1.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTableLayoutPanel1.RowCount = 1;
            this.uniTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTableLayoutPanel1.Size = new System.Drawing.Size(619, 23);
            this.uniTableLayoutPanel1.SizeTD5 = 14F;
            this.uniTableLayoutPanel1.SizeTD6 = 36F;
            this.uniTableLayoutPanel1.TabIndex = 4;
            this.uniTableLayoutPanel1.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel1.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // txtProjectNo
            // 
            this.txtProjectNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance5.TextVAlignAsString = "Bottom";
            this.txtProjectNo.Appearance = appearance5;
            this.txtProjectNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtProjectNo.Location = new System.Drawing.Point(0, 2);
            this.txtProjectNo.LockedField = false;
            this.txtProjectNo.Margin = new System.Windows.Forms.Padding(0);
            this.txtProjectNo.Name = "txtProjectNo";
            this.txtProjectNo.QueryIfEnterKeyPressed = true;
            this.txtProjectNo.RequiredField = false;
            this.txtProjectNo.Size = new System.Drawing.Size(150, 21);
            this.txtProjectNo.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtProjectNo.StyleSetName = "Default";
            this.txtProjectNo.TabIndex = 6;
            this.txtProjectNo.uniALT = null;
            this.txtProjectNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProjectNo.UseDynamicFormat = false;
            // 
            // lblProjectNm
            // 
            appearance6.TextHAlignAsString = "Left";
            appearance6.TextVAlignAsString = "Middle";
            this.lblProjectNm.Appearance = appearance6;
            this.lblProjectNm.AutoPopupID = null;
            this.lblProjectNm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectNm.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectNm.Location = new System.Drawing.Point(272, 1);
            this.lblProjectNm.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectNm.Name = "lblProjectNm";
            this.lblProjectNm.Size = new System.Drawing.Size(88, 22);
            this.lblProjectNm.StyleSetName = "Default";
            this.lblProjectNm.TabIndex = 4;
            this.lblProjectNm.Text = "PROJECT 명";
            this.lblProjectNm.UseMnemonic = false;
            // 
            // txtProjectNm
            // 
            this.txtProjectNm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance7.TextVAlignAsString = "Bottom";
            this.txtProjectNm.Appearance = appearance7;
            this.txtProjectNm.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtProjectNm.Location = new System.Drawing.Point(360, 2);
            this.txtProjectNm.LockedField = false;
            this.txtProjectNm.Margin = new System.Windows.Forms.Padding(0);
            this.txtProjectNm.Name = "txtProjectNm";
            this.txtProjectNm.QueryIfEnterKeyPressed = true;
            this.txtProjectNm.RequiredField = false;
            this.txtProjectNm.Size = new System.Drawing.Size(150, 21);
            this.txtProjectNm.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtProjectNm.StyleSetName = "Default";
            this.txtProjectNm.TabIndex = 5;
            this.txtProjectNm.uniALT = null;
            this.txtProjectNm.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProjectNm.UseDynamicFormat = false;
            // 
            // uniTableLayoutPanel2
            // 
            this.uniTableLayoutPanel2.AutoFit = false;
            this.uniTableLayoutPanel2.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel2.AutoFitRowCount = 4;
            this.uniTableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel2.ColumnCount = 3;
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.60899F));
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.78202F));
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.60899F));
            this.uniTableLayoutPanel2.Controls.Add(this.txtProjectType1, 0, 0);
            this.uniTableLayoutPanel2.Controls.Add(this.txtDocId, 2, 0);
            this.uniTableLayoutPanel2.Controls.Add(this.lblDocId, 1, 0);
            this.uniTableLayoutPanel2.DefaultRowSize = 23;
            this.uniTableLayoutPanel2.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel2.Location = new System.Drawing.Point(137, 51);
            this.uniTableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel2.Name = "uniTableLayoutPanel2";
            this.uniTableLayoutPanel2.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTableLayoutPanel2.RowCount = 1;
            this.uniTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTableLayoutPanel2.Size = new System.Drawing.Size(619, 23);
            this.uniTableLayoutPanel2.SizeTD5 = 14F;
            this.uniTableLayoutPanel2.SizeTD6 = 36F;
            this.uniTableLayoutPanel2.TabIndex = 5;
            this.uniTableLayoutPanel2.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel2.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // txtProjectType1
            // 
            this.txtProjectType1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance8.TextVAlignAsString = "Bottom";
            this.txtProjectType1.Appearance = appearance8;
            this.txtProjectType1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtProjectType1.Location = new System.Drawing.Point(0, 2);
            this.txtProjectType1.LockedField = false;
            this.txtProjectType1.Margin = new System.Windows.Forms.Padding(0);
            this.txtProjectType1.Name = "txtProjectType1";
            this.txtProjectType1.QueryIfEnterKeyPressed = true;
            this.txtProjectType1.RequiredField = false;
            this.txtProjectType1.Size = new System.Drawing.Size(150, 21);
            this.txtProjectType1.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtProjectType1.StyleSetName = "Default";
            this.txtProjectType1.TabIndex = 7;
            this.txtProjectType1.uniALT = null;
            this.txtProjectType1.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProjectType1.UseDynamicFormat = false;
            // 
            // txtDocId
            // 
            this.txtDocId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance9.TextVAlignAsString = "Bottom";
            this.txtDocId.Appearance = appearance9;
            this.txtDocId.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtDocId.Location = new System.Drawing.Point(360, 2);
            this.txtDocId.LockedField = false;
            this.txtDocId.Margin = new System.Windows.Forms.Padding(0);
            this.txtDocId.Name = "txtDocId";
            this.txtDocId.QueryIfEnterKeyPressed = true;
            this.txtDocId.RequiredField = false;
            this.txtDocId.Size = new System.Drawing.Size(150, 21);
            this.txtDocId.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtDocId.StyleSetName = "Default";
            this.txtDocId.TabIndex = 6;
            this.txtDocId.uniALT = null;
            this.txtDocId.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtDocId.UseDynamicFormat = false;
            // 
            // lblDocId
            // 
            appearance10.TextHAlignAsString = "Left";
            appearance10.TextVAlignAsString = "Middle";
            this.lblDocId.Appearance = appearance10;
            this.lblDocId.AutoPopupID = null;
            this.lblDocId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDocId.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDocId.Location = new System.Drawing.Point(272, 1);
            this.lblDocId.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDocId.Name = "lblDocId";
            this.lblDocId.Size = new System.Drawing.Size(88, 22);
            this.lblDocId.StyleSetName = "Default";
            this.lblDocId.TabIndex = 4;
            this.lblDocId.Text = "DOC ID";
            this.lblDocId.UseMnemonic = false;
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 2);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(10, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 5;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 85F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(950, 595);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 1;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 5;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.Controls.Add(this.btnOK, 4, 0);
            this.uniTBL_MainReference.DefaultRowSize = 23;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 567);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(950, 28);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 3;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnOK
            // 
            this.btnOK.AutoPopupID = null;
            this.btnOK.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnOK.Location = new System.Drawing.Point(850, 1);
            this.btnOK.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnOK.Name = "btnOK";
            this.btnOK.PopupID = null;
            this.btnOK.Size = new System.Drawing.Size(97, 24);
            this.btnOK.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnOK.TabIndex = 2;
            this.btnOK.Text = "확인";
            this.btnOK.UserDefinedText = null;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTBL_MainData.Controls.Add(this.uniTableLayoutPanel3, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 94);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(950, 468);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 4;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTableLayoutPanel3
            // 
            this.uniTableLayoutPanel3.AutoFit = false;
            this.uniTableLayoutPanel3.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel3.AutoFitRowCount = 4;
            this.uniTableLayoutPanel3.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel3.ColumnCount = 3;
            this.uniTableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.18367F));
            this.uniTableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.81633F));
            this.uniTableLayoutPanel3.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTableLayoutPanel3.Controls.Add(this.uniGrid2, 2, 0);
            this.uniTableLayoutPanel3.DefaultRowSize = 23;
            this.uniTableLayoutPanel3.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel3.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel3.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel3.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel3.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel3.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel3.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel3.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel3.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.uniTableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel3.Name = "uniTableLayoutPanel3";
            this.uniTableLayoutPanel3.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTableLayoutPanel3.RowCount = 1;
            this.uniTableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTableLayoutPanel3.Size = new System.Drawing.Size(950, 468);
            this.uniTableLayoutPanel3.SizeTD5 = 14F;
            this.uniTableLayoutPanel3.SizeTD6 = 36F;
            this.uniTableLayoutPanel3.TabIndex = 0;
            this.uniTableLayoutPanel3.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel3.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance11.BackColor = System.Drawing.SystemColors.Window;
            appearance11.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance11;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance12.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance12.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance12;
            appearance13.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance13;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance14.BackColor2 = System.Drawing.SystemColors.Control;
            appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance14.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance14;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance15.BackColor = System.Drawing.SystemColors.Window;
            appearance15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance15;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance16.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance16;
            appearance17.BorderColor = System.Drawing.Color.Silver;
            appearance17.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance17;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance18.BackColor = System.Drawing.SystemColors.Control;
            appearance18.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance18.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance18.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance18;
            appearance19.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance19;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance20.BackColor = System.Drawing.SystemColors.Window;
            appearance20.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance20;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance21.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance21;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(560, 468);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 3;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            // 
            // uniGrid2
            // 
            this.uniGrid2.AddEmptyRow = false;
            this.uniGrid2.DirectPaste = false;
            appearance22.BackColor = System.Drawing.SystemColors.Window;
            appearance22.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid2.DisplayLayout.Appearance = appearance22;
            this.uniGrid2.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid2.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance23.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance23.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance23.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.GroupByBox.Appearance = appearance23;
            appearance24.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.BandLabelAppearance = appearance24;
            this.uniGrid2.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance25.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance25.BackColor2 = System.Drawing.SystemColors.Control;
            appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance25.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.PromptAppearance = appearance25;
            this.uniGrid2.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid2.DisplayLayout.MaxRowScrollRegions = 1;
            appearance26.BackColor = System.Drawing.SystemColors.Window;
            appearance26.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid2.DisplayLayout.Override.ActiveCellAppearance = appearance26;
            this.uniGrid2.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid2.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid2.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance27.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.CardAreaAppearance = appearance27;
            appearance28.BorderColor = System.Drawing.Color.Silver;
            appearance28.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid2.DisplayLayout.Override.CellAppearance = appearance28;
            this.uniGrid2.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid2.DisplayLayout.Override.CellPadding = 0;
            appearance29.BackColor = System.Drawing.SystemColors.Control;
            appearance29.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance29.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance29.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.GroupByRowAppearance = appearance29;
            appearance30.TextHAlignAsString = "Left";
            this.uniGrid2.DisplayLayout.Override.HeaderAppearance = appearance30;
            this.uniGrid2.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid2.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance31.BackColor = System.Drawing.SystemColors.Window;
            appearance31.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid2.DisplayLayout.Override.RowAppearance = appearance31;
            this.uniGrid2.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance32.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid2.DisplayLayout.Override.TemplateAddRowAppearance = appearance32;
            this.uniGrid2.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid2.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid2.EnableContextMenu = true;
            this.uniGrid2.EnableGridInfoContextMenu = true;
            this.uniGrid2.ExceptInExcel = false;
            this.uniGrid2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid2.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid2.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid2.Location = new System.Drawing.Point(563, 0);
            this.uniGrid2.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid2.Name = "uniGrid2";
            this.uniGrid2.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid2.PopupDeleteMenuVisible = true;
            this.uniGrid2.PopupInsertMenuVisible = true;
            this.uniGrid2.PopupUndoMenuVisible = true;
            this.uniGrid2.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid2.ShowHeaderCheck = true;
            this.uniGrid2.Size = new System.Drawing.Size(387, 468);
            this.uniGrid2.StyleSetName = "uniGrid_Query";
            this.uniGrid2.TabIndex = 4;
            this.uniGrid2.Text = "uniGrid2";
            this.uniGrid2.UseDynamicFormat = false;
            // 
            // PopupViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "PopupViewer";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Size = new System.Drawing.Size(970, 615);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectType)).EndInit();
            this.uniTableLayoutPanel1.ResumeLayout(false);
            this.uniTableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectNm)).EndInit();
            this.uniTableLayoutPanel2.ResumeLayout(false);
            this.uniTableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectType1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDocId)).EndInit();
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainReference.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            this.uniTableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        //        private System.Windows.Forms.BindingSource autoNumViewBindingSource;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniButton btnOK;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectType1;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectNm;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel2;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDocId;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtProjectNo;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtProjectNm;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtDocId;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtProjectType;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtProjectType1;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel3;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid2;

    }
}
