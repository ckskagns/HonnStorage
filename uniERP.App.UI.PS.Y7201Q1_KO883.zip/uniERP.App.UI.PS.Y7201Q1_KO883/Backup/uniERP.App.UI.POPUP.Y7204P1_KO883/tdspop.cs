﻿namespace uniERP.App.UI.POPUP.Y7204P1_KO883 {
    
    
    public partial class tdspop {
        partial class E_PMS_PROJECT_APRDataTable
        {
       }

        partial class E_PMS_PROJECT_HAPDataTable
        {
        }
    }
}
