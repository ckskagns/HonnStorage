﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.PS.Y7201Q1_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance115 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance116 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance117 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance118 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance119 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance120 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance121 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance122 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance123 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance124 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance125 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance101 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance102 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance103 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance104 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance105 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance106 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance107 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance108 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance109 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance110 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance111 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance112 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance113 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance114 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.cboState = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.lblCustomer = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProNum = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProPer = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblSale = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblStatus = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popOrg = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popProject = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popSalesGrp = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.dtPerFromTo = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.lblExt2Cd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popExt2Cd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblExt1Cd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popExt1Cd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblExt3Cd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popExt3Cd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblExt5Cd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popExt5Cd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblApprvStatus = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popApprvStatus = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblSoNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtSoNo = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnPreview = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnPrint = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnApprv = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.lblProjectType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popProjectType = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblProjectType1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popProjectType1 = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.uniTBL_MainCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoNo)).BeginInit();
            this.uniTBL_MainBatch.SuspendLayout();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.PathInfo;
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.DefaultRowSize = 25;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 176F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(979, 740);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 25;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 212);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(979, 496);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 0;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance115.BackColor = System.Drawing.SystemColors.Window;
            appearance115.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance115;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance116.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance116.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance116.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance116.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance116;
            appearance117.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance117;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance118.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance118.BackColor2 = System.Drawing.SystemColors.Control;
            appearance118.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance118.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance118;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance119.BackColor = System.Drawing.SystemColors.Window;
            appearance119.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance119;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance120.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance120;
            appearance121.BorderColor = System.Drawing.Color.Silver;
            appearance121.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance121;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance122.BackColor = System.Drawing.SystemColors.Control;
            appearance122.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance122.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance122.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance122.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance122;
            appearance123.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance123;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance124.BackColor = System.Drawing.SystemColors.Window;
            appearance124.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance124;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance125.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance125;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(979, 496);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.cboState, 3, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblCustomer, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblProNum, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblProPer, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblSale, 2, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblStatus, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popOrg, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popProject, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popSalesGrp, 3, 0);
            this.uniTBL_MainCondition.Controls.Add(this.dtPerFromTo, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblExt2Cd, 2, 2);
            this.uniTBL_MainCondition.Controls.Add(this.popExt2Cd, 3, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblExt1Cd, 0, 3);
            this.uniTBL_MainCondition.Controls.Add(this.popExt1Cd, 1, 3);
            this.uniTBL_MainCondition.Controls.Add(this.lblExt3Cd, 2, 3);
            this.uniTBL_MainCondition.Controls.Add(this.popExt3Cd, 3, 3);
            this.uniTBL_MainCondition.Controls.Add(this.lblExt5Cd, 0, 4);
            this.uniTBL_MainCondition.Controls.Add(this.popExt5Cd, 1, 4);
            this.uniTBL_MainCondition.Controls.Add(this.lblApprvStatus, 2, 4);
            this.uniTBL_MainCondition.Controls.Add(this.popApprvStatus, 3, 4);
            this.uniTBL_MainCondition.Controls.Add(this.lblSoNo, 0, 5);
            this.uniTBL_MainCondition.Controls.Add(this.txtSoNo, 1, 5);
            this.uniTBL_MainCondition.Controls.Add(this.lblProjectType, 2, 5);
            this.uniTBL_MainCondition.Controls.Add(this.popProjectType, 3, 5);
            this.uniTBL_MainCondition.Controls.Add(this.lblProjectType1, 0, 6);
            this.uniTBL_MainCondition.Controls.Add(this.popProjectType1, 1, 6);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 7;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(979, 176);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // cboState
            // 
            this.cboState.AddEmptyRow = true;
            this.cboState.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboState.ComboFrom = "";
            this.cboState.ComboMajorCd = "Y0004";
            this.cboState.ComboSelect = "";
            this.cboState.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboState.ComboWhere = "";
            this.cboState.DropDownListWidth = -1;
            this.cboState.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboState.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.cboState.Location = new System.Drawing.Point(626, 29);
            this.cboState.LockedField = false;
            this.cboState.Margin = new System.Windows.Forms.Padding(0);
            this.cboState.Name = "cboState";
            this.cboState.RequiredField = false;
            this.cboState.Size = new System.Drawing.Size(144, 22);
            this.cboState.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboState.StyleSetName = "Default";
            this.cboState.TabIndex = 9;
            this.cboState.uniALT = "Proc.Status";
            // 
            // lblCustomer
            // 
            appearance101.TextHAlignAsString = "Left";
            appearance101.TextVAlignAsString = "Middle";
            this.lblCustomer.Appearance = appearance101;
            this.lblCustomer.AutoPopupID = null;
            this.lblCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCustomer.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCustomer.Location = new System.Drawing.Point(15, 6);
            this.lblCustomer.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(122, 22);
            this.lblCustomer.StyleSetName = "Default";
            this.lblCustomer.TabIndex = 1;
            this.lblCustomer.Text = "Customer";
            this.lblCustomer.UseMnemonic = false;
            // 
            // lblProNum
            // 
            appearance102.TextHAlignAsString = "Left";
            appearance102.TextVAlignAsString = "Middle";
            this.lblProNum.Appearance = appearance102;
            this.lblProNum.AutoPopupID = null;
            this.lblProNum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProNum.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProNum.Location = new System.Drawing.Point(15, 29);
            this.lblProNum.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProNum.Name = "lblProNum";
            this.lblProNum.Size = new System.Drawing.Size(122, 22);
            this.lblProNum.StyleSetName = "Default";
            this.lblProNum.TabIndex = 2;
            this.lblProNum.Text = "Project Number";
            this.lblProNum.UseMnemonic = false;
            // 
            // lblProPer
            // 
            appearance103.TextHAlignAsString = "Left";
            appearance103.TextVAlignAsString = "Middle";
            this.lblProPer.Appearance = appearance103;
            this.lblProPer.AutoPopupID = null;
            this.lblProPer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProPer.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProPer.Location = new System.Drawing.Point(15, 52);
            this.lblProPer.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProPer.Name = "lblProPer";
            this.lblProPer.Size = new System.Drawing.Size(122, 22);
            this.lblProPer.StyleSetName = "Default";
            this.lblProPer.TabIndex = 3;
            this.lblProPer.Text = "Project Period";
            this.lblProPer.UseMnemonic = false;
            // 
            // lblSale
            // 
            appearance104.TextHAlignAsString = "Left";
            appearance104.TextVAlignAsString = "Middle";
            this.lblSale.Appearance = appearance104;
            this.lblSale.AutoPopupID = null;
            this.lblSale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSale.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSale.Location = new System.Drawing.Point(504, 6);
            this.lblSale.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSale.Name = "lblSale";
            this.lblSale.Size = new System.Drawing.Size(122, 22);
            this.lblSale.StyleSetName = "Default";
            this.lblSale.TabIndex = 4;
            this.lblSale.Text = "Sales Group";
            this.lblSale.UseMnemonic = false;
            // 
            // lblStatus
            // 
            appearance105.TextHAlignAsString = "Left";
            appearance105.TextVAlignAsString = "Middle";
            this.lblStatus.Appearance = appearance105;
            this.lblStatus.AutoPopupID = null;
            this.lblStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblStatus.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblStatus.Location = new System.Drawing.Point(504, 29);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(122, 22);
            this.lblStatus.StyleSetName = "Default";
            this.lblStatus.TabIndex = 5;
            this.lblStatus.Text = "Proc.Status";
            this.lblStatus.UseMnemonic = false;
            // 
            // popOrg
            // 
            this.popOrg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popOrg.AutoPopupCodeParameter = null;
            this.popOrg.AutoPopupID = null;
            this.popOrg.AutoPopupNameParameter = null;
            this.popOrg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.popOrg.CodeMaxLength = 10;
            this.popOrg.CodeName = "";
            this.popOrg.CodeSize = 100;
            this.popOrg.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popOrg.CodeTextBoxName = null;
            this.popOrg.CodeValue = "";
            this.popOrg.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popOrg.Location = new System.Drawing.Point(137, 7);
            this.popOrg.LockedField = false;
            this.popOrg.Margin = new System.Windows.Forms.Padding(0);
            this.popOrg.Name = "popOrg";
            this.popOrg.NameDisplay = true;
            this.popOrg.NameId = null;
            this.popOrg.NameMaxLength = 13;
            this.popOrg.NamePopup = false;
            this.popOrg.NameSize = 150;
            this.popOrg.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popOrg.Parameter = null;
            this.popOrg.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popOrg.PopupId = null;
            this.popOrg.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popOrg.QueryIfEnterKeyPressed = true;
            this.popOrg.RequiredField = false;
            this.popOrg.Size = new System.Drawing.Size(271, 21);
            this.popOrg.TabIndex = 6;
            this.popOrg.uniALT = "Customer";
            this.popOrg.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popOrg.UseDynamicFormat = false;
            this.popOrg.ValueTextBoxName = null;
            this.popOrg.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popOrg_BeforePopupOpen);
            this.popOrg.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popOrg_AfterPopupClosed);
            // 
            // popProject
            // 
            this.popProject.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popProject.AutoPopupCodeParameter = null;
            this.popProject.AutoPopupID = null;
            this.popProject.AutoPopupNameParameter = null;
            this.popProject.CodeMaxLength = 25;
            this.popProject.CodeName = "";
            this.popProject.CodeSize = 150;
            this.popProject.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProject.CodeTextBoxName = null;
            this.popProject.CodeValue = "";
            this.popProject.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popProject.Location = new System.Drawing.Point(137, 30);
            this.popProject.LockedField = false;
            this.popProject.Margin = new System.Windows.Forms.Padding(0);
            this.popProject.Name = "popProject";
            this.popProject.NameDisplay = true;
            this.popProject.NameId = null;
            this.popProject.NameMaxLength = 15;
            this.popProject.NamePopup = false;
            this.popProject.NameSize = 150;
            this.popProject.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProject.Parameter = null;
            this.popProject.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popProject.PopupId = null;
            this.popProject.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popProject.QueryIfEnterKeyPressed = true;
            this.popProject.RequiredField = false;
            this.popProject.Size = new System.Drawing.Size(321, 21);
            this.popProject.TabIndex = 8;
            this.popProject.uniALT = "Project Number";
            this.popProject.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popProject.UseDynamicFormat = false;
            this.popProject.ValueTextBoxName = null;
            this.popProject.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popProject_BeforePopupOpen);
            this.popProject.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popProject_OnExitEditCode);
            this.popProject.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popProject_AfterPopupClosed);
            // 
            // popSalesGrp
            // 
            this.popSalesGrp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSalesGrp.AutoPopupCodeParameter = null;
            this.popSalesGrp.AutoPopupID = null;
            this.popSalesGrp.AutoPopupNameParameter = null;
            this.popSalesGrp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.popSalesGrp.CodeMaxLength = 4;
            this.popSalesGrp.CodeName = "";
            this.popSalesGrp.CodeSize = 100;
            this.popSalesGrp.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSalesGrp.CodeTextBoxName = null;
            this.popSalesGrp.CodeValue = "";
            this.popSalesGrp.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popSalesGrp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.popSalesGrp.Location = new System.Drawing.Point(626, 7);
            this.popSalesGrp.LockedField = false;
            this.popSalesGrp.Margin = new System.Windows.Forms.Padding(0);
            this.popSalesGrp.Name = "popSalesGrp";
            this.popSalesGrp.NameDisplay = true;
            this.popSalesGrp.NameId = null;
            this.popSalesGrp.NameMaxLength = 10;
            this.popSalesGrp.NamePopup = false;
            this.popSalesGrp.NameSize = 150;
            this.popSalesGrp.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSalesGrp.Parameter = null;
            this.popSalesGrp.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSalesGrp.PopupId = null;
            this.popSalesGrp.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSalesGrp.QueryIfEnterKeyPressed = true;
            this.popSalesGrp.RequiredField = false;
            this.popSalesGrp.Size = new System.Drawing.Size(271, 21);
            this.popSalesGrp.TabIndex = 7;
            this.popSalesGrp.uniALT = "Sales Group";
            this.popSalesGrp.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popSalesGrp.UseDynamicFormat = false;
            this.popSalesGrp.ValueTextBoxName = null;
            this.popSalesGrp.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSalesGrp_BeforePopupOpen);
            this.popSalesGrp.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSalesGrp_AfterPopupClosed);
            // 
            // dtPerFromTo
            // 
            this.dtPerFromTo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtPerFromTo.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtPerFromTo.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtPerFromTo.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtPerFromTo.Location = new System.Drawing.Point(137, 53);
            this.dtPerFromTo.Margin = new System.Windows.Forms.Padding(0);
            this.dtPerFromTo.Name = "dtPerFromTo";
            this.dtPerFromTo.Size = new System.Drawing.Size(225, 21);
            this.dtPerFromTo.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtPerFromTo.TabIndex = 10;
            this.dtPerFromTo.uniFromALT = "Project Period(FROM)";
            this.dtPerFromTo.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtPerFromTo.uniTabSameValue = false;
            this.dtPerFromTo.uniToALT = "Project Period(TO)";
            this.dtPerFromTo.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // lblExt2Cd
            // 
            appearance106.TextHAlignAsString = "Left";
            appearance106.TextVAlignAsString = "Middle";
            this.lblExt2Cd.Appearance = appearance106;
            this.lblExt2Cd.AutoPopupID = null;
            this.lblExt2Cd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblExt2Cd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblExt2Cd.Location = new System.Drawing.Point(504, 52);
            this.lblExt2Cd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblExt2Cd.Name = "lblExt2Cd";
            this.lblExt2Cd.Size = new System.Drawing.Size(122, 22);
            this.lblExt2Cd.StyleSetName = "Default";
            this.lblExt2Cd.TabIndex = 11;
            this.lblExt2Cd.Text = "CS담당";
            this.lblExt2Cd.UseMnemonic = false;
            // 
            // popExt2Cd
            // 
            this.popExt2Cd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popExt2Cd.AutoPopupCodeParameter = null;
            this.popExt2Cd.AutoPopupID = null;
            this.popExt2Cd.AutoPopupNameParameter = null;
            this.popExt2Cd.CodeMaxLength = 10;
            this.popExt2Cd.CodeName = "";
            this.popExt2Cd.CodeSize = 100;
            this.popExt2Cd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popExt2Cd.CodeTextBoxName = null;
            this.popExt2Cd.CodeValue = "";
            this.popExt2Cd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popExt2Cd.Location = new System.Drawing.Point(626, 53);
            this.popExt2Cd.LockedField = false;
            this.popExt2Cd.Margin = new System.Windows.Forms.Padding(0);
            this.popExt2Cd.Name = "popExt2Cd";
            this.popExt2Cd.NameDisplay = true;
            this.popExt2Cd.NameId = null;
            this.popExt2Cd.NameMaxLength = 50;
            this.popExt2Cd.NamePopup = false;
            this.popExt2Cd.NameSize = 150;
            this.popExt2Cd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popExt2Cd.Parameter = null;
            this.popExt2Cd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popExt2Cd.PopupId = null;
            this.popExt2Cd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popExt2Cd.QueryIfEnterKeyPressed = true;
            this.popExt2Cd.RequiredField = false;
            this.popExt2Cd.Size = new System.Drawing.Size(271, 21);
            this.popExt2Cd.TabIndex = 12;
            this.popExt2Cd.uniALT = null;
            this.popExt2Cd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popExt2Cd.UseDynamicFormat = false;
            this.popExt2Cd.ValueTextBoxName = null;
            this.popExt2Cd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popExt2Cd_BeforePopupOpen);
            this.popExt2Cd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popExt2Cd_AfterPopupClosed);
            // 
            // lblExt1Cd
            // 
            appearance107.TextHAlignAsString = "Left";
            appearance107.TextVAlignAsString = "Middle";
            this.lblExt1Cd.Appearance = appearance107;
            this.lblExt1Cd.AutoPopupID = null;
            this.lblExt1Cd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblExt1Cd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblExt1Cd.Location = new System.Drawing.Point(15, 75);
            this.lblExt1Cd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblExt1Cd.Name = "lblExt1Cd";
            this.lblExt1Cd.Size = new System.Drawing.Size(122, 22);
            this.lblExt1Cd.StyleSetName = "Default";
            this.lblExt1Cd.TabIndex = 13;
            this.lblExt1Cd.Text = "설계담당";
            this.lblExt1Cd.UseMnemonic = false;
            // 
            // popExt1Cd
            // 
            this.popExt1Cd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popExt1Cd.AutoPopupCodeParameter = null;
            this.popExt1Cd.AutoPopupID = null;
            this.popExt1Cd.AutoPopupNameParameter = null;
            this.popExt1Cd.CodeMaxLength = 10;
            this.popExt1Cd.CodeName = "";
            this.popExt1Cd.CodeSize = 100;
            this.popExt1Cd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popExt1Cd.CodeTextBoxName = null;
            this.popExt1Cd.CodeValue = "";
            this.popExt1Cd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popExt1Cd.Location = new System.Drawing.Point(137, 76);
            this.popExt1Cd.LockedField = false;
            this.popExt1Cd.Margin = new System.Windows.Forms.Padding(0);
            this.popExt1Cd.Name = "popExt1Cd";
            this.popExt1Cd.NameDisplay = true;
            this.popExt1Cd.NameId = null;
            this.popExt1Cd.NameMaxLength = 50;
            this.popExt1Cd.NamePopup = false;
            this.popExt1Cd.NameSize = 150;
            this.popExt1Cd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popExt1Cd.Parameter = null;
            this.popExt1Cd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popExt1Cd.PopupId = null;
            this.popExt1Cd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popExt1Cd.QueryIfEnterKeyPressed = true;
            this.popExt1Cd.RequiredField = false;
            this.popExt1Cd.Size = new System.Drawing.Size(271, 21);
            this.popExt1Cd.TabIndex = 14;
            this.popExt1Cd.uniALT = null;
            this.popExt1Cd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popExt1Cd.UseDynamicFormat = false;
            this.popExt1Cd.ValueTextBoxName = null;
            this.popExt1Cd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popExt1Cd_BeforePopupOpen);
            this.popExt1Cd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popExt1Cd_AfterPopupClosed);
            // 
            // lblExt3Cd
            // 
            appearance108.TextHAlignAsString = "Left";
            appearance108.TextVAlignAsString = "Middle";
            this.lblExt3Cd.Appearance = appearance108;
            this.lblExt3Cd.AutoPopupID = null;
            this.lblExt3Cd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblExt3Cd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblExt3Cd.Location = new System.Drawing.Point(504, 75);
            this.lblExt3Cd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblExt3Cd.Name = "lblExt3Cd";
            this.lblExt3Cd.Size = new System.Drawing.Size(122, 22);
            this.lblExt3Cd.StyleSetName = "Default";
            this.lblExt3Cd.TabIndex = 15;
            this.lblExt3Cd.Text = "발주구분";
            this.lblExt3Cd.UseMnemonic = false;
            // 
            // popExt3Cd
            // 
            this.popExt3Cd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popExt3Cd.AutoPopupCodeParameter = null;
            this.popExt3Cd.AutoPopupID = null;
            this.popExt3Cd.AutoPopupNameParameter = null;
            this.popExt3Cd.CodeMaxLength = 10;
            this.popExt3Cd.CodeName = "";
            this.popExt3Cd.CodeSize = 100;
            this.popExt3Cd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popExt3Cd.CodeTextBoxName = null;
            this.popExt3Cd.CodeValue = "";
            this.popExt3Cd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popExt3Cd.Location = new System.Drawing.Point(626, 76);
            this.popExt3Cd.LockedField = false;
            this.popExt3Cd.Margin = new System.Windows.Forms.Padding(0);
            this.popExt3Cd.Name = "popExt3Cd";
            this.popExt3Cd.NameDisplay = true;
            this.popExt3Cd.NameId = null;
            this.popExt3Cd.NameMaxLength = 50;
            this.popExt3Cd.NamePopup = false;
            this.popExt3Cd.NameSize = 150;
            this.popExt3Cd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popExt3Cd.Parameter = null;
            this.popExt3Cd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popExt3Cd.PopupId = null;
            this.popExt3Cd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popExt3Cd.QueryIfEnterKeyPressed = true;
            this.popExt3Cd.RequiredField = false;
            this.popExt3Cd.Size = new System.Drawing.Size(271, 21);
            this.popExt3Cd.TabIndex = 16;
            this.popExt3Cd.uniALT = null;
            this.popExt3Cd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popExt3Cd.UseDynamicFormat = false;
            this.popExt3Cd.ValueTextBoxName = null;
            this.popExt3Cd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popExt3Cd_BeforePopupOpen);
            this.popExt3Cd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popExt3Cd_AfterPopupClosed);
            // 
            // lblExt5Cd
            // 
            appearance109.TextHAlignAsString = "Left";
            appearance109.TextVAlignAsString = "Middle";
            this.lblExt5Cd.Appearance = appearance109;
            this.lblExt5Cd.AutoPopupID = null;
            this.lblExt5Cd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblExt5Cd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblExt5Cd.Location = new System.Drawing.Point(15, 98);
            this.lblExt5Cd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblExt5Cd.Name = "lblExt5Cd";
            this.lblExt5Cd.Size = new System.Drawing.Size(122, 22);
            this.lblExt5Cd.StyleSetName = "Default";
            this.lblExt5Cd.TabIndex = 17;
            this.lblExt5Cd.Text = "전자결재요청자";
            this.lblExt5Cd.UseMnemonic = false;
            // 
            // popExt5Cd
            // 
            this.popExt5Cd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popExt5Cd.AutoPopupCodeParameter = null;
            this.popExt5Cd.AutoPopupID = null;
            this.popExt5Cd.AutoPopupNameParameter = null;
            this.popExt5Cd.CodeMaxLength = 10;
            this.popExt5Cd.CodeName = "";
            this.popExt5Cd.CodeSize = 100;
            this.popExt5Cd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popExt5Cd.CodeTextBoxName = null;
            this.popExt5Cd.CodeValue = "";
            this.popExt5Cd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popExt5Cd.Location = new System.Drawing.Point(137, 99);
            this.popExt5Cd.LockedField = false;
            this.popExt5Cd.Margin = new System.Windows.Forms.Padding(0);
            this.popExt5Cd.Name = "popExt5Cd";
            this.popExt5Cd.NameDisplay = true;
            this.popExt5Cd.NameId = null;
            this.popExt5Cd.NameMaxLength = 50;
            this.popExt5Cd.NamePopup = false;
            this.popExt5Cd.NameSize = 150;
            this.popExt5Cd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popExt5Cd.Parameter = null;
            this.popExt5Cd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popExt5Cd.PopupId = null;
            this.popExt5Cd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popExt5Cd.QueryIfEnterKeyPressed = true;
            this.popExt5Cd.RequiredField = false;
            this.popExt5Cd.Size = new System.Drawing.Size(271, 21);
            this.popExt5Cd.TabIndex = 18;
            this.popExt5Cd.uniALT = null;
            this.popExt5Cd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popExt5Cd.UseDynamicFormat = false;
            this.popExt5Cd.ValueTextBoxName = null;
            this.popExt5Cd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popExt5Cd_BeforePopupOpen);
            this.popExt5Cd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popExt5Cd_AfterPopupClosed);
            // 
            // lblApprvStatus
            // 
            appearance110.TextHAlignAsString = "Left";
            appearance110.TextVAlignAsString = "Middle";
            this.lblApprvStatus.Appearance = appearance110;
            this.lblApprvStatus.AutoPopupID = null;
            this.lblApprvStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblApprvStatus.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblApprvStatus.Location = new System.Drawing.Point(504, 98);
            this.lblApprvStatus.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblApprvStatus.Name = "lblApprvStatus";
            this.lblApprvStatus.Size = new System.Drawing.Size(122, 22);
            this.lblApprvStatus.StyleSetName = "Default";
            this.lblApprvStatus.TabIndex = 19;
            this.lblApprvStatus.Text = "결재상태";
            this.lblApprvStatus.UseMnemonic = false;
            // 
            // popApprvStatus
            // 
            this.popApprvStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popApprvStatus.AutoPopupCodeParameter = null;
            this.popApprvStatus.AutoPopupID = null;
            this.popApprvStatus.AutoPopupNameParameter = null;
            this.popApprvStatus.CodeMaxLength = 10;
            this.popApprvStatus.CodeName = "";
            this.popApprvStatus.CodeSize = 100;
            this.popApprvStatus.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popApprvStatus.CodeTextBoxName = null;
            this.popApprvStatus.CodeValue = "";
            this.popApprvStatus.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popApprvStatus.Location = new System.Drawing.Point(626, 99);
            this.popApprvStatus.LockedField = false;
            this.popApprvStatus.Margin = new System.Windows.Forms.Padding(0);
            this.popApprvStatus.Name = "popApprvStatus";
            this.popApprvStatus.NameDisplay = true;
            this.popApprvStatus.NameId = null;
            this.popApprvStatus.NameMaxLength = 50;
            this.popApprvStatus.NamePopup = false;
            this.popApprvStatus.NameSize = 150;
            this.popApprvStatus.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popApprvStatus.Parameter = null;
            this.popApprvStatus.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popApprvStatus.PopupId = null;
            this.popApprvStatus.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popApprvStatus.QueryIfEnterKeyPressed = true;
            this.popApprvStatus.RequiredField = false;
            this.popApprvStatus.Size = new System.Drawing.Size(271, 21);
            this.popApprvStatus.TabIndex = 20;
            this.popApprvStatus.uniALT = null;
            this.popApprvStatus.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popApprvStatus.UseDynamicFormat = false;
            this.popApprvStatus.ValueTextBoxName = null;
            this.popApprvStatus.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popApprvStatus_BeforePopupOpen);
            this.popApprvStatus.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popApprvStatus_AfterPopupClosed);
            // 
            // lblSoNo
            // 
            appearance111.TextHAlignAsString = "Left";
            appearance111.TextVAlignAsString = "Middle";
            this.lblSoNo.Appearance = appearance111;
            this.lblSoNo.AutoPopupID = null;
            this.lblSoNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSoNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSoNo.Location = new System.Drawing.Point(15, 121);
            this.lblSoNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSoNo.Name = "lblSoNo";
            this.lblSoNo.Size = new System.Drawing.Size(122, 22);
            this.lblSoNo.StyleSetName = "Default";
            this.lblSoNo.TabIndex = 21;
            this.lblSoNo.Text = "수주번호";
            this.lblSoNo.UseMnemonic = false;
            // 
            // txtSoNo
            // 
            this.txtSoNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance112.TextVAlignAsString = "Bottom";
            this.txtSoNo.Appearance = appearance112;
            this.txtSoNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtSoNo.Location = new System.Drawing.Point(137, 121);
            this.txtSoNo.LockedField = false;
            this.txtSoNo.Margin = new System.Windows.Forms.Padding(0);
            this.txtSoNo.Name = "txtSoNo";
            this.txtSoNo.QueryIfEnterKeyPressed = true;
            this.txtSoNo.RequiredField = false;
            this.txtSoNo.Size = new System.Drawing.Size(151, 22);
            this.txtSoNo.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtSoNo.StyleSetName = "Default";
            this.txtSoNo.TabIndex = 22;
            this.txtSoNo.uniALT = null;
            this.txtSoNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoNo.UseDynamicFormat = false;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.DefaultRowSize = 25;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(979, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 5;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.Controls.Add(this.btnPreview, 0, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnPrint, 1, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnApprv, 2, 0);
            this.uniTBL_MainBatch.DefaultRowSize = 25;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 711);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(979, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnPreview
            // 
            this.btnPreview.AutoPopupID = null;
            this.btnPreview.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPreview.Location = new System.Drawing.Point(0, 1);
            this.btnPreview.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.PopupID = null;
            this.btnPreview.Size = new System.Drawing.Size(97, 24);
            this.btnPreview.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnPreview.TabIndex = 0;
            this.btnPreview.Text = "미리보기";
            this.btnPreview.UserDefinedText = null;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.AutoPopupID = null;
            this.btnPrint.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnPrint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPrint.Location = new System.Drawing.Point(100, 1);
            this.btnPrint.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.PopupID = null;
            this.btnPrint.Size = new System.Drawing.Size(97, 24);
            this.btnPrint.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnPrint.TabIndex = 1;
            this.btnPrint.Text = "출력";
            this.btnPrint.UserDefinedText = null;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnApprv
            // 
            this.btnApprv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnApprv.AutoPopupID = null;
            this.btnApprv.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnApprv.Location = new System.Drawing.Point(200, 2);
            this.btnApprv.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnApprv.Name = "btnApprv";
            this.btnApprv.PopupID = null;
            this.btnApprv.Size = new System.Drawing.Size(138, 23);
            this.btnApprv.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnApprv.TabIndex = 2;
            this.btnApprv.Text = "결재(진행사항)";
            this.btnApprv.UserDefinedText = null;
            this.btnApprv.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.btnApprv_BeforePopupOpen);
            // 
            // lblProjectType
            // 
            appearance113.TextHAlignAsString = "Left";
            appearance113.TextVAlignAsString = "Middle";
            this.lblProjectType.Appearance = appearance113;
            this.lblProjectType.AutoPopupID = null;
            this.lblProjectType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectType.Location = new System.Drawing.Point(504, 121);
            this.lblProjectType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectType.Name = "lblProjectType";
            this.lblProjectType.Size = new System.Drawing.Size(122, 22);
            this.lblProjectType.StyleSetName = "Default";
            this.lblProjectType.TabIndex = 23;
            this.lblProjectType.Text = "프로젝트종류";
            this.lblProjectType.UseMnemonic = false;
            // 
            // popProjectType
            // 
            this.popProjectType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popProjectType.AutoPopupCodeParameter = null;
            this.popProjectType.AutoPopupID = null;
            this.popProjectType.AutoPopupNameParameter = null;
            this.popProjectType.CodeMaxLength = 10;
            this.popProjectType.CodeName = "";
            this.popProjectType.CodeSize = 100;
            this.popProjectType.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProjectType.CodeTextBoxName = null;
            this.popProjectType.CodeValue = "";
            this.popProjectType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popProjectType.Location = new System.Drawing.Point(626, 122);
            this.popProjectType.LockedField = false;
            this.popProjectType.Margin = new System.Windows.Forms.Padding(0);
            this.popProjectType.Name = "popProjectType";
            this.popProjectType.NameDisplay = true;
            this.popProjectType.NameId = null;
            this.popProjectType.NameMaxLength = 50;
            this.popProjectType.NamePopup = false;
            this.popProjectType.NameSize = 150;
            this.popProjectType.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProjectType.Parameter = null;
            this.popProjectType.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popProjectType.PopupId = null;
            this.popProjectType.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popProjectType.QueryIfEnterKeyPressed = true;
            this.popProjectType.RequiredField = false;
            this.popProjectType.Size = new System.Drawing.Size(271, 21);
            this.popProjectType.TabIndex = 24;
            this.popProjectType.uniALT = "프로젝트종류";
            this.popProjectType.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popProjectType.UseDynamicFormat = false;
            this.popProjectType.ValueTextBoxName = null;
            this.popProjectType.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popProjectType_BeforePopupOpen);
            this.popProjectType.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popProjectType_AfterPopupClosed);
            // 
            // lblProjectType1
            // 
            appearance114.TextHAlignAsString = "Left";
            appearance114.TextVAlignAsString = "Middle";
            this.lblProjectType1.Appearance = appearance114;
            this.lblProjectType1.AutoPopupID = null;
            this.lblProjectType1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectType1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblProjectType1.Location = new System.Drawing.Point(15, 144);
            this.lblProjectType1.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblProjectType1.Name = "lblProjectType1";
            this.lblProjectType1.Size = new System.Drawing.Size(122, 22);
            this.lblProjectType1.StyleSetName = "Default";
            this.lblProjectType1.TabIndex = 25;
            this.lblProjectType1.Text = "프로젝트종류1";
            this.lblProjectType1.UseMnemonic = false;
            // 
            // popProjectType1
            // 
            this.popProjectType1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popProjectType1.AutoPopupCodeParameter = null;
            this.popProjectType1.AutoPopupID = null;
            this.popProjectType1.AutoPopupNameParameter = null;
            this.popProjectType1.CodeMaxLength = 10;
            this.popProjectType1.CodeName = "";
            this.popProjectType1.CodeSize = 100;
            this.popProjectType1.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProjectType1.CodeTextBoxName = null;
            this.popProjectType1.CodeValue = "";
            this.popProjectType1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popProjectType1.Location = new System.Drawing.Point(137, 145);
            this.popProjectType1.LockedField = false;
            this.popProjectType1.Margin = new System.Windows.Forms.Padding(0);
            this.popProjectType1.Name = "popProjectType1";
            this.popProjectType1.NameDisplay = true;
            this.popProjectType1.NameId = null;
            this.popProjectType1.NameMaxLength = 50;
            this.popProjectType1.NamePopup = false;
            this.popProjectType1.NameSize = 150;
            this.popProjectType1.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProjectType1.Parameter = null;
            this.popProjectType1.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popProjectType1.PopupId = null;
            this.popProjectType1.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popProjectType1.QueryIfEnterKeyPressed = true;
            this.popProjectType1.RequiredField = false;
            this.popProjectType1.Size = new System.Drawing.Size(271, 21);
            this.popProjectType1.TabIndex = 26;
            this.popProjectType1.uniALT = "프로젝트종류1";
            this.popProjectType1.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popProjectType1.UseDynamicFormat = false;
            this.popProjectType1.ValueTextBoxName = null;
            this.popProjectType1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popProjectType1_BeforePopupOpen);
            this.popProjectType1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popProjectType1_AfterPopupClosed);
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(990, 760);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoNo)).EndInit();
            this.uniTBL_MainBatch.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniCombo cboState;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCustomer;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProNum;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProPer;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSale;
        private uniERP.AppFramework.UI.Controls.uniLabel lblStatus;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popOrg;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popProject;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSalesGrp;
        private uniERP.AppFramework.UI.Controls.uniDateTerm dtPerFromTo;
        private uniERP.AppFramework.UI.Controls.uniButton btnPreview;
        private uniERP.AppFramework.UI.Controls.uniButton btnPrint;
        private uniERP.AppFramework.UI.Controls.uniButton btnApprv;
        private uniERP.AppFramework.UI.Controls.uniLabel lblExt2Cd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popExt2Cd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblExt1Cd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popExt1Cd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblExt3Cd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popExt3Cd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblExt5Cd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popExt5Cd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblApprvStatus;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popApprvStatus;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSoNo;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtSoNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectType;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popProjectType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectType1;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popProjectType1;

    }
}
