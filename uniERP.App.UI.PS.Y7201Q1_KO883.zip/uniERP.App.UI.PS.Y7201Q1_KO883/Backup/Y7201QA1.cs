﻿namespace uniERP.App.UI.PS.Y7201Q1_KO883 {
    
    
    public partial class Y7201QA1 {
    }
}
namespace uniERP.App.UI.PS.Y7201Q1_KO883.Y7201QA1TableAdapters
{
    
    
    public partial class Y7201QA1 {
    }
}
