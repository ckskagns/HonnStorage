﻿namespace uniERP.App.UI.HR.H4007M5_KO883.tdsY8101M2_KO883TableAdapters
{
}
namespace uniERP.App.UI.HR.H4007M5_KO883 {
    
    
    public partial class tdsY8101M2_KO883 {
        partial class E_PMS_PROJECT_RATEDataTable
        {
        }
    
        partial class I_PMS_PROJECT_RATEDataTable
        {
        }
    }
}
