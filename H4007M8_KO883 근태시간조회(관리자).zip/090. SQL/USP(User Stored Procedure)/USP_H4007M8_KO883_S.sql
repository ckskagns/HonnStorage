    
    
--���̺� ���� ����� ����    
    
/*            
--WT_SG1_KO883           
DROP PROC usp_H4007M8_KO883_S             
DROP TYPE dbo.UTP_H4007M8_KO883            
CREATE TYPE dbo.UTP_H4007M8_KO883 AS TABLE            
(     
     CHECK_FLG INT    --0
    ,EMP_NO  nvarchar(24) --1    
    ,NAME  nvarchar(24) --2    
    ,ROLL_PSTN_NM   nvarchar(24) --3    
    ,DEPT_NM  nvarchar(24) --4    
    ,WORK_DT  nvarchar(24) --5    
    ,DAY_WEEK  nvarchar(24) --6    
    ,START_TIME  nvarchar(24) --7    
    ,END_TIME  nvarchar(24) --8    
    ,TOT_TIME  nvarchar(24) --9    
    ,OT  nvarchar(24) --10    
    ,HT  nvarchar(24) --11    
    ,TT  nvarchar(24) --12    
    ,ETC1  nvarchar(24) --13    
	,ETC2  nvarchar(24) --14
 ,CUD_CHAR   NVARCHAR(01) --15            
    ,ROW_NUM    INT    --16              
)            
*/            
/********************************************************************************************/            
/***** PROCEDURE NAME : usp_H4007M8_KO883_S          *****/            
/***** AUTHOR   : CHA            *****/            
/***** CREATE DATE  : 2020-12-28                *****/            
/***** DESCRIPTION  : ���½ð���ȸ(������)              *****/             
/***** HISTORY   :                   *****/            
/********************************************************************************************/                      
ALTER PROCEDURE [dbo].[usp_H4007M8_KO883_S]                
(                 
  @TBL_DATA   UTP_H4007M8_KO883 READONLY                
, @USER_ID    NVARCHAR(13)                
, @MSG_CD     NVARCHAR(06)  OUTPUT                
, @MESSAGE    NVARCHAR(200)  OUTPUT                
, @ERR_POS    INT     OUTPUT                
)                
AS                
                
BEGIN                
 SET NOCOUNT ON                
                
 DECLARE                      
     @CHECK_FLG   INT    -- 0
    ,@CUR_EMP_NO  nvarchar(24) --1    
    ,@CUR_NAME  nvarchar(24) --2    
    ,@CUR_ROLL_PSTN_NM   nvarchar(24) --3    
    ,@CUR_DEPT_NM  nvarchar(24) --4    
    ,@CUR_WORK_DT  nvarchar(24) --5    
    ,@CUR_DAY_WEEK  nvarchar(24) --6    
    ,@CUR_START_TIME nvarchar(24) --7    
    ,@CUR_END_TIME  nvarchar(24)    --8    
    ,@CUR_TOT_TIME  nvarchar(24)    --9    
    ,@CUR_OT  nvarchar(24) --10    
    ,@CUR_HT  nvarchar(24) --11    
    ,@CUR_TT  nvarchar(24) --12    
    ,@CUR_ETC1  nvarchar(24) --13      
	,@CUR_ETC2  nvarchar(24) --14
    ,@CUR_CUD_CHAR   NVARCHAR(01) --15
    ,@CUR_ROW_NUM   INT    --16     
    ,@ERROR_NUMBER INT     --17
      
                
  BEGIN TRY                
  BEGIN TRANSACTION                
                
                 
  DECLARE Cur_WorkList CURSOR LOCAL FOR                
                
    
     
 SELECT
     A.CHECK_FLG     
    ,A.EMP_NO      
    ,A.NAME      
    ,A.ROLL_PSTN_NM     
    ,A.DEPT_NM      
    ,A.WORK_DT      
    ,A.DAY_WEEK      
    ,A.START_TIME      
    ,A.END_TIME      
    ,A.TOT_TIME      
    ,A.OT       
    ,A.HT       
    ,A.TT       
    ,A.ETC1     
	,A.ETC2
    ,A.CUD_CHAR        
    ,A.ROW_NUM               
                  
  FROM @TBL_DATA A                     
                
  OPEN Cur_WorkList                 
  FETCH NEXT FROM Cur_WorkList                
  INTO                 
   @CHECK_FLG 
  ,@CUR_EMP_NO     
  ,@CUR_NAME      
  ,@CUR_ROLL_PSTN_NM      
  ,@CUR_DEPT_NM      
  ,@CUR_WORK_DT      
  ,@CUR_DAY_WEEK      
  ,@CUR_START_TIME     
  ,@CUR_END_TIME      
  ,@CUR_TOT_TIME      
  ,@CUR_OT      
  ,@CUR_HT      
  ,@CUR_TT      
  ,@CUR_ETC1     
  ,@CUR_ETC2
  ,@CUR_CUD_CHAR          
  ,@CUR_ROW_NUM      
      
                      
  WHILE(@@FETCH_STATUS=0)                
  BEGIN                
   SET @ERR_POS = @CUR_ROW_NUM          
       
   IF convert(char(8),@CUR_TOT_TIME ,108) < convert(char(8),'00:00:00',108)    
   SET @CUR_TOT_TIME = convert(char(8),'00:00:00',108)    
                
  IF (@CUR_CUD_CHAR = 'C')                
  BEGIN                
         
    INSERT INTO WT_SG1_KO883                
    (                
     EMP_NO      
    ,NAME      
    ,ROLL_PSTN_NM     
    ,DEPT_NM      
    ,WORK_DT      
    ,DAY_WEEK      
    ,START_TIME      
    ,END_TIME      
    ,TOT_TIME      
    ,OT       
    ,HT       
    ,TT       
    ,ETC1
	,ETC2     
 ,INSRT_DT    
 ,INSRT_USER_ID    
 ,UPDT_DT      
                    
    )                
    VALUES                
    (                
      @CUR_EMP_NO     
     ,@CUR_NAME      
     ,@CUR_ROLL_PSTN_NM      
     ,@CUR_DEPT_NM      
     ,convert(char(10),Substring(@CUR_WORK_DT,1,10),23)         
	 ,(SELECT MINOR_NM FROM B_MINOR WHERE MAJOR_CD = 'XH004' AND (MINOR_CD = @CUR_DAY_WEEK or MINOR_NM = @CUR_DAY_WEEK))    
     ,convert(char(8),Substring(@CUR_START_TIME,12,8),108)
     ,convert(char(8),Substring(@CUR_END_TIME,12,8),108) 
     ,convert(char(8),Substring(@CUR_TOT_TIME,12,8),108)   
     ,convert(char(8),Substring(@CUR_OT,12,8),108)
     ,convert(char(8),Substring(@CUR_HT,12,8),108) 
     ,convert(char(8),Substring(@CUR_TT,12,8),108) 
     , (SELECT DILIG_NM FROM hca010t WHERE ( DILIG_NM = '' or (DILIG_NM = @CUR_ETC1))  )
	 ,@CUR_ETC2    
  ,GETDATE()    
  ,@USER_ID    
  ,GETDATE()    
                    
    )                
  END                
  ELSE     
  IF (@CUR_CUD_CHAR = 'U')                    
  BEGIN                
     UPDATE WT_SG1_KO883    
    SET    
      EMP_NO    =  @CUR_EMP_NO     
        ,NAME    =  @CUR_NAME      
        ,ROLL_PSTN_NM =  @CUR_ROLL_PSTN_NM    
        ,DEPT_NM   =  @CUR_DEPT_NM      
        ,WORK_DT   =  convert(char(10),Substring(@CUR_WORK_DT,1,10),23)  
        ,DAY_WEEK   =  (SELECT MINOR_NM FROM B_MINOR WHERE MAJOR_CD = 'XH004' AND (MINOR_CD = @CUR_DAY_WEEK or MINOR_NM = @CUR_DAY_WEEK))        
        ,START_TIME   =  convert(char(8),Substring(@CUR_START_TIME,12,8),108)    
        ,END_TIME   =  convert(char(8),Substring(@CUR_END_TIME,12,8),108)     
        ,TOT_TIME   =  convert(char(8),Substring(@CUR_TOT_TIME,12,8),108)     
        ,OT     =  convert(char(8),Substring(@CUR_OT,12,8),108)    
        ,HT     =  convert(char(8),Substring(@CUR_HT,12,8),108)    
        ,TT     =  convert(char(8),Substring(@CUR_TT,12,8),108)    
        --,ETC1    =  (SELECT MINOR_NM FROM B_MINOR WHERE MAJOR_CD = 'XH005' AND (MINOR_CD = @CUR_ETC1 or MINOR_NM = @CUR_ETC1 )) 
		,ETC1    =  (SELECT DILIG_NM FROM hca010t WHERE ( DILIG_NM = '' or (DILIG_NM = @CUR_ETC1))  )-- �������� �˾��� ���������� �߰� ����'21.01.12
		,ETC2    = @CUR_ETC2   
        ,UPDT_USER_ID = @USER_ID    
        ,UPDT_DT      = GETDATE()    
       WHERE ISNULL(EMP_NO,'') = ISNULL(@CUR_EMP_NO,'') AND ISNULL(WORK_DT,'') = ISNULL(@CUR_WORK_DT,'') AND  ISNULL(ETC1,'') = ISNULL(@CUR_ETC1,'')   AND @CHECK_FLG = 1    
    
      
                    
                
  END                
  ELSE IF (@CUR_CUD_CHAR = 'D')                
  BEGIN                
                    
    DELETE FROM WT_SG1_KO883                 
    WHERE ISNULL(EMP_NO,'') = ISNULL(@CUR_EMP_NO,'') AND ISNULL(WORK_DT,'') = ISNULL(@CUR_WORK_DT,'')  AND  ISNULL(ETC1,'') = ISNULL(@CUR_ETC1,'')   AND @CHECK_FLG = 1    
	--,ISNULL(TOT_TIME,''),108) = convert(char(8),ISNULL(@CUR_TOT_TIME,''),108) 
        
                
  END                
            
         
                 
  FETCH NEXT FROM Cur_WorkList                
  INTO                 
     @CHECK_FLG  
    ,@CUR_EMP_NO     
    ,@CUR_NAME      
    ,@CUR_ROLL_PSTN_NM       
    ,@CUR_DEPT_NM      
    ,@CUR_WORK_DT      
    ,@CUR_DAY_WEEK      
    ,@CUR_START_TIME     
    ,@CUR_END_TIME      
    ,@CUR_TOT_TIME      
    ,@CUR_OT      
    ,@CUR_HT      
    ,@CUR_TT      
    ,@CUR_ETC1   
	,@CUR_ETC2  
    ,@CUR_CUD_CHAR           
    ,@CUR_ROW_NUM              
                
                
  END --WHILE END                
                 
                
 CLOSE Cur_WorkList                
 DEALLOCATE Cur_WorkList                           
                
 END TRY                
 BEGIN CATCH                
                 
 SET @ERROR_NUMBER = ERROR_NUMBER()                
                  
  IF @ERROR_NUMBER = 2627  --%1! ���� ���� '%2!'��(��) �����߽��ϴ�. ��ü '%3!'�� �ߺ� Ű�� ������ �� �����ϴ�. �ߺ� Ű ���� %4!�Դϴ�.                
   BEGIN                
    SET @MSG_CD   = '970001' -- %1 ��(��) �̹� �����մϴ�.                   
   END                
                
  ELSE IF @ERROR_NUMBER = 547  -- %1! ���� %2! ���� ���� "%3!"��(��) �浹�߽��ϴ�. �����ͺ��̽� "%4!", ���̺� "%5!"%6!%7!%8!���� �浹�� �߻��߽��ϴ�.                
   BEGIN                
    SET @MSG_CD   = '971000' -- %1 ��(��) �����ϰ� �ִ� �����Ͱ� �ֽ��ϴ�. �۾��� ������ �� �����ϴ�.                     
   END                
                
  ELSE IF @ERROR_NUMBER = 1205  -- Ʈ�����(���μ��� ID %1!)�� %2! ���ҽ����� �ٸ� ���μ������� ���� ���°� �߻��Ͽ� ������ �����Ǿ����ϴ�. Ʈ������� �ٽ� �����Ͻʽÿ�.                
   BEGIN                
    SET @MSG_CD   = '122918' -- %1 ���忡 �����߽��ϴ�.                        
   END                
                
  ELSE                
   SET @MESSAGE  = ERROR_MESSAGE()                
                
  GOTO __ERROR                
 END CATCH                
                
 IF @@TRANCOUNT > 0 COMMIT TRANSACTION                
 RETURN 1                
                
 __ERROR:                
 IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION                
 RETURN -1                
END 