                  
                    
ALTER PROCEDURE [dbo].[USP_H4007M2_KO883]                    
 (          
 @EMP_NO nvarchar(26), -- ���        
 @DEPT_NO nvarchar(26), -- �μ���ȣ        
 @Work_From nvarchar(26), -- �ٹ�����From           
    @Work_To  nvarchar(26)  -- �ٹ�����To        
                     
 ) AS                              
                        
 BEGIN                                                  
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                            
                                               
SET NOCOUNT ON                            
        
  IF @Work_From IS NULL OR @Work_From = '' SET @Work_From ='1900-01-01'             
  IF @Work_To IS NULL OR @Work_To = '' SET @Work_To ='2099-12-31'         
  
        

      
select  distinct      

      
  A.EMP_NO    ,       
  A.NAME      ,      
  B.DEPT_NM     ,  
  dbo.ufn_getcodename('h0002', roll_pstn) as ROLL_PSTN_NM,  
  CONVERT (varchar,A.WORK_DT,23) as WORK_DT , 
  A.DAY_WEEK ,     
 CASE ISNULL(G.EMP_NO,'')  -- �����ٹ��� ���̺��� �����Ͱ� ���� �� , ���ϱ��еڿ� �ٹ����� �ؽ�Ʈ�� �߰��ϴ� ��
 WHEN ''
 THEN A.WORK_DAY
 --(SELECT MINOR_NM FROM B_MINOR WHERE MAJOR_CD = 'XH004' AND MINOR_CD = A.DAY_WEEK) 
 ELSE CASE H.HOLI_TYPE
      WHEN 'H'
	  THEN A.WORK_DAY
	  ELSE A.WORK_DAY + '_' + LEFT((SELECT MINOR_NM FROM B_MINOR WHERE MAJOR_CD = 'XH006' AND MINOR_CD = G.FLEX_SYS),2)
	  END
 END
 AS WORK_DAY,  

 CASE ISNULL(G.EMP_NO,'')
 WHEN ''
 THEN CASE H.HOLI_TYPE
      WHEN 'H'
	  THEN     
        CASE E.APPROVAL_RTN
              WHEN '1'
        	  THEN CASE F.REPORT_TYPE
        	       WHEN '2'
        		   THEN CASE D.DILIG_NM
        		        WHEN '���ϱٹ�1'
        				THEN convert(char(8),dateadd(n,(C.DILIG_HH_FR * 60) + C.DILIG_MM_FR , 0),108) 
        				ELSE convert(char(8),'00:00:00' ,108)
        				END
        			ELSE convert(char(8),'00:00:00' ,108)
        			END
        	  ELSE convert(char(8),'00:00:00' ,108)
        	  END
	ELSE
	    CASE E.APPROVAL_RTN  
              WHEN '1'  
              THEN CASE F.REPORT_TYPE  
                   WHEN '1'  
                   THEN CASE D.DILIG_NM  
                        WHEN '����ٹ�1'  
                        THEN CASE ISNULL(convert(char(8),A.START_TIME,108),'')
        				     WHEN ''
        					 THEN convert(char(8),'09:00:00',108)
        					 ELSE convert(char(8),A.START_TIME,108)
        					 END
        				WHEN '����(����)'
        				THEN convert(char(8),'14:00:00',108)  
        				WHEN '����(����)'
        				THEN convert(char(8),'09:00:00',108)  
						ELSE convert(char(8),'00:00:00' ,108)
        		        END 
        		   WHEN '2'
        		   THEN CASE D.DILIG_NM  
                        WHEN '����ٹ�1'  
                        THEN  convert(char(8),A.START_TIME ,108)
						ELSE convert(char(8),'00:00:00' ,108)
        		        END
        		   ELSE convert(char(8),'00:00:00' ,108)
        		   END
        	  ELSE CASE ISNULL(A.START_TIME,'')  
                   WHEN ''  
                   THEN  CASE ISNULL(A.END_TIME,'')  
                         WHEN ''  
                         THEN '00:00:00'  
                         ELSE '09:00:00'  
                         END  
                   ELSE convert(char(8),A.START_TIME,108)   
                   END  
        	  END
	END
ELSE CASE H.HOLI_TYPE
     WHEN 'H'
	 THEN     CASE E.APPROVAL_RTN
              WHEN '1'
        	  THEN CASE F.REPORT_TYPE
        	       WHEN '2'
        		   THEN CASE D.DILIG_NM
        		        WHEN '���ϱٹ�1'
        				THEN convert(char(8),dateadd(n,(C.DILIG_HH_FR * 60) + C.DILIG_MM_FR , 0),108) 
        				ELSE convert(char(8),'00:00:00' ,108)
        				END
        			ELSE convert(char(8),'00:00:00' ,108)
        			END
        	  ELSE convert(char(8),'00:00:00' ,108)
        	  END
	  ELSE
      CASE ISNULL(E.APPROVAL_RTN,'')   -- �����ٹ��� ���̺��� �����Ͱ� ������ ó���ϴ½�
	  WHEN ''
	  THEN CASE ISNULL(A.START_TIME,'')
	       WHEN ''
		   THEN
		        CASE ISNULL(A.END_TIME,'')
				WHEN ''
				THEN convert(char(8),'00:00:00' ,108)
				ELSE convert(char(8),G.START_TIME,108)
				END
		   ELSE convert(char(8),A.START_TIME,108)
		   END
      WHEN '1'  
      THEN CASE F.REPORT_TYPE  
           WHEN '1'  
           THEN CASE D.DILIG_NM  
                WHEN '����ٹ�1'  
                THEN CASE ISNULL(convert(char(8),G.START_TIME,108),'')
      		         WHEN ''
      			     THEN convert(char(8),'09:00:00',108)
      			     ELSE convert(char(8),G.START_TIME,108)
      			     END
      		    WHEN '����(����)'
      		    --THEN convert(char(8),'14:00:00',108)
				THEN  convert(char(8),dateadd(n,datediff(n,0,G.START_TIME) + 300 , 0),108)   --����(����)�� ��, �����ٹ������̺��� ��ٽð����� 5�ð��� ���ϴ½�
      		    WHEN '����(����)'
      		    THEN convert(char(8),G.START_TIME,108)
				ELSE convert(char(8),'00:00:00' ,108)
                END 
           WHEN '2'
           THEN CASE D.DILIG_NM  
                  WHEN '����ٹ�1'  
                  THEN  convert(char(8),G.START_TIME ,108)
                END
           ELSE convert(char(8),'00:00:00' ,108)
           END
      ELSE CASE ISNULL(G.START_TIME,'')  
           WHEN ''  
           THEN  '�����ٹ���NULL������Ȯ��'  
		   ELSE convert(char(8),G.START_TIME ,108)
           END
	  END
	END
END   
  as START_TIME,
CASE ISNULL(G.EMP_NO,'')
WHEN ''
THEN
      CASE ISNULL(E.APPROVAL_RTN,'')  
      WHEN ''  
      THEN CASE H.HOLI_TYPE
	       WHEN 'H'
		   THEN '00:00:00' 
           ELSE CASE ISNULL(D.DILIG_NM,'')  
                WHEN ''  
                THEN CASE ISNULL(A.END_TIME,'')  
                     WHEN ''  
                     THEN CASE ISNULL(A.START_TIME,'')  
                          WHEN ''  
                          THEN convert(char(8),'00:00:00',108)
                          ELSE convert(char(8),'18:00:00',108)
                          END  
                    ELSE convert(char(8),'18:00:00',108) 
                    END  
                ELSE CASE ISNULL(A.END_TIME,'')  
                     WHEN ''  
                     THEN CASE ISNULL(A.START_TIME,'')  
                          WHEN ''  
                          THEN convert(char(8),'00:00:00',108)  
                          ELSE convert(char(8),'18:00:00',108) 
                          END  
                     ELSE convert(char(8),'18:00:00',108) 
                     END  
                END
		     END  
      WHEN '1'  
      THEN       CASE H.HOLI_TYPE  
                 WHEN 'H'  
                 THEN CASE ISNULL(D.DILIG_NM,'')  
                      WHEN ''  
                      THEN '00:00:00'  
                      WHEN '���ϱٹ�1'  
                      THEN   
                           CASE F.REPORT_TYPE  
                           WHEN '2'  
                           THEN convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO , 0),108)  
                           ELSE convert(char(8),'00:00:00',108)  
                           END  
                      ELSE convert(char(8),'00:00:00',108)  
                      END
         		ELSE
                   	   CASE ISNULL(D.DILIG_NM,'')  
                       WHEN ''  
                       THEN CASE ISNULL(A.END_TIME,'')  
                            WHEN ''  
                            THEN CASE ISNULL(A.START_TIME,'')  
                                 WHEN ''  
                                 THEN '00:00:00'  
                                 ELSE '18:00:00'  
                                 END  
                            ELSE convert(char(8), A.END_TIME,108)  
                            END  
                       WHEN '����(����)' -- ���� �����϶� �ٹ��ð� ��� CASE��  
                       THEN '18:00:00'  
                       WHEN '����(����)' -- ���� �����϶� �ٹ��ð� ��� CASE��  
                       THEN '14:00:00'  
                       WHEN '����ٹ�1'   
                       THEN  CASE F.REPORT_TYPE
                             WHEN '1'
	                         THEN CASE ISNULL(convert(char(8),A.END_TIME,108),'')
	                              WHEN ''
	                              THEN convert(char(8),'18:00:00',108)
	                              ELSE convert(char(8),A.END_TIME,108)
	                              END  
                             WHEN '2'  
                             THEN   
                                  CASE
                                  WHEN ISNULL(convert(char(8),A.END_TIME,108),'00:00:00') >= convert(char(8),dateadd(n, (C.DILIG_HH_TO * 60) + C.DILIG_MM_TO ,0),108) -- �����ǽð��� ����ٹ� ��ٽð� ���� ũ�ų� ������ ������� ���
   	                              THEN convert(char(8),dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO  , 0),108) 
		          				  WHEN ISNULL(convert(char(8),A.END_TIME,108),'00:00:00') < convert(char(8),dateadd(n, (C.DILIG_HH_TO * 60) + C.DILIG_MM_TO ,0),108) -- �����ǽð��� ����ٹ� ��ٽð� ���� ������ ���� ���� ��� 
		          				  THEN CASE ISNULL(A.END_TIME,'')  
                                       WHEN ''  
                                       THEN convert(char(8),dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO  , 0),108)    -- ��ٽð��� ���������� ���ڰ����� ����ٹ��ð��� �ҷ��� ����ϴ½�  
                                       ELSE convert(char(8),A.END_TIME,108)  
                                       END
                                  ELSE CASE ISNULL(A.END_TIME,'')  
                                       WHEN ''  
                                       THEN convert(char(8),dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO  , 0),108)   -- ��ٽð��� ���������� ���ڰ����� ����ٹ��ð��� �ҷ��� ����ϴ½�  
                                       ELSE convert(char(8),A.END_TIME,108)  
                                       END
                                  END
							 ELSE convert(char(8),'00:00:00' ,108)
							 END
                       ELSE CASE ISNULL(A.END_TIME,'')  
                            WHEN ''  
                            THEN convert(char(8),'00:00:00' ,108)  
                            ELSE convert(char(8), A.END_TIME,108)  
                            END  
                       END
				END
	  ELSE  CASE H.HOLI_TYPE
            WHEN 'H'    
            THEN  convert(char(8),'00:00:00' ,108)    
            ELSE CASE ISNULL(D.DILIG_NM,'')  -- ����,������ ������ ��� ����Ǽ��� ��ٽð� ��� ��    
                 WHEN ''    
                 THEN CASE ISNULL(A.END_TIME,'')    
                      WHEN ''    
                      THEN CASE ISNULL(A.START_TIME,'')    
                           WHEN ''    
                           THEN '00:00:00'    
                           ELSE '18:00:00'    
                           END    
                      ELSE convert(char(8),'18:00:00',108)   
                      END  
                 ELSE CASE ISNULL(A.END_TIME,'')    
                      WHEN ''    
                      THEN CASE ISNULL(A.START_TIME,'')    
                           WHEN ''    
                           THEN convert(char(8),'00:00:00',108)    
                           ELSE convert(char(8),'18:00:00',108)    
                           END    
                      ELSE convert(char(8),'18:00:00',108)   
                      END    
                  END
            
		    END
      END

ELSE CASE H.HOLI_TYPE
     WHEN 'H'
	 THEN CASE ISNULL(E.APPROVAL_RTN,'')
	      WHEN ''
	      THEN convert(char(8),'00:00:00',108) 
		  WHEN '1'
		  THEN CASE ISNULL(D.DILIG_NM,'')  
               WHEN ''  
               THEN '00:00:00'  
               WHEN '���ϱٹ�1'  
               THEN   
                    CASE F.REPORT_TYPE  
                    WHEN '2'  
                    THEN convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO , 0),108)  
                    ELSE convert(char(8),'00:00:00',108)  
                    END  
               ELSE convert(char(8),'00:00:00',108)  
               END
		  ELSE convert(char(8),'00:00:00',108) 
		  END
	 ELSE 
      CASE ISNULL(E.APPROVAL_RTN,'')  
      WHEN ''  
      THEN  CASE ISNULL(D.DILIG_NM,'')  
            WHEN ''  
            THEN CASE ISNULL(A.END_TIME,'')  
                 WHEN ''  
                 THEN CASE ISNULL(A.START_TIME,'')
				      WHEN ''
					  THEN convert(char(8),'00:00:00',108) 
					  ELSE convert(char(8),G.END_TIME ,108)
					  END
                 ELSE convert(char(8),A.END_TIME ,108) 
                 END  
            ELSE CASE ISNULL(A.END_TIME,'')  
                 WHEN ''  
                 THEN CASE ISNULL(A.START_TIME,'')
				      WHEN ''
					  THEN convert(char(8),'00:00:00',108) 
					  ELSE convert(char(8),G.END_TIME ,108)
					  END
                 ELSE convert(char(8),A.END_TIME ,108) 
                 END  
            END  
            
       WHEN '1'  
       THEN   CASE ISNULL(D.DILIG_NM,'')  
              WHEN ''  
              THEN convert(char(8),G.END_TIME ,108)  
              WHEN '����(����)' -- ���� �����϶� �ٹ��ð� ��� CASE��  
              THEN convert(char(8),G.END_TIME ,108) 
              WHEN '����(����)' -- ���� �����϶� �ٹ��ð� ��� CASE��  
              --THEN '14:00:00'
			  THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 240 , 0),108)  
              WHEN '����ٹ�1'   
              THEN  CASE F.REPORT_TYPE
                    WHEN '1'
      	            THEN CASE ISNULL(convert(char(8),A.END_TIME,108),'')
      	                 WHEN ''
      	                 THEN convert(char(8),G.END_TIME ,108)
      	                 ELSE convert(char(8),A.END_TIME,108)  -- ���޵����Ͱ� NULL�϶��� �����ٹ��� ������ �ð��� �����ֵ�, NULL�̾ƴҶ����� ���޵����͸� �����ִ� ��
      	                 END  
                    WHEN '2'  
                    THEN  CASE ISNULL(A.END_TIME,'')  
                          WHEN ''  
                          THEN convert(char(8),dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO  , 0),108)    -- ��ٽð��� ���������� ���ڰ����� ����ٹ��ð��� �ҷ��� ����ϴ½�  
                          ELSE convert(char(8),A.END_TIME,108)  
                          END
                   ELSE convert(char(8),'00:00:00',108)  
                   END   
             ELSE  CASE ISNULL(A.END_TIME,'')  
                   WHEN ''  
                   THEN CASE ISNULL(A.START_TIME,'')
				        WHEN ''
				  	    THEN convert(char(8),'00:00:00',108) 
				  	    ELSE convert(char(8),G.END_TIME ,108)
				  	    END
                   ELSE convert(char(8),A.END_TIME ,108) 
                   END 
             END
	    ELSE  CASE ISNULL(A.END_TIME,'')  
                 WHEN ''  
                 THEN CASE ISNULL(A.START_TIME,'')
				      WHEN ''
					  THEN convert(char(8),'00:00:00',108) 
					  ELSE convert(char(8),G.END_TIME ,108)
					  END
                 ELSE convert(char(8),A.END_TIME ,108) 
                 END
        END
END
END
 as END_TIME,
CASE ISNULL(G.EMP_NO,'')
WHEN ''
THEN 
    CASE ISNULL(A.END_TIME,'')  
    WHEN ''  
    THEN CASE H.HOLI_TYPE
         WHEN 'D'
    	 THEN  
              CASE ISNULL(A.START_TIME,'')  
              WHEN ''  
              THEN convert(char(8),'00:00:00',108)  
              ELSE convert(char(8),'00:00:00',108)  
              END
    	 ELSE convert(char(8),'00:00:00',108)
    	 END
    ELSE convert(char(8),A.END_TIME,108) 
    END
ELSE
     CASE H.HOLI_TYPE
	 WHEN 'H'
	 THEN CASE ISNULL(E.APPROVAL_RTN,'')
	      WHEN ''
		  THEN convert(char(8),'00:00:00',108)
		  WHEN '1'
		  THEN convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO , 0),108)  
		  ELSE convert(char(8),'00:00:00',108)
		  END
	 ELSE
          CASE ISNULL(A.END_TIME,'')  
          WHEN ''  
          THEN CASE ISNULL(A.START_TIME,'')
		       WHEN ''
		       THEN convert(char(8),'00:00:00',108) 
		       ELSE convert(char(8),'00:00:00',108)
		       END
          ELSE convert(char(8),A.END_TIME ,108) 
          END
	 END
END
 as END_TIME_S,  
convert(varchar(12),    
CAST(    
DATEDIFF(n,  -- �ѱٹ� Hour���    
CASE ISNULL(G.EMP_NO,'')
WHEN ''
THEN
     CASE ISNULL(E.APPROVAL_RTN,'')      
     WHEN ''      
     THEN CASE H.HOLI_TYPE
          WHEN 'H'     
          THEN  convert(char(8),'00:00:00',108)
		  ELSE  CASE ISNULL(A.START_TIME ,'')      
                WHEN ''      
                THEN CASE ISNULL(A.END_TIME,'')      
                     WHEN ''      
                     THEN convert(char(8),'00:00:00',108)      
                     ELSE convert(char(8),'09:00:00',108)      
                     END         
                ELSE   CASE        -- ��ٽð��� 9�� �����϶��� ��ٽð��� 9�÷� �����ϴ� CASE��        
                       WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'18:00:00',108)   -- 18�� �̻��϶� (CS�ٹ�)�ð� �ӽ��� �ٹ��ð� 8�ð����� ������  
                       THEN convert(char(8),'09:00:00',108)    
                       WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)      
                       THEN convert(char(8),'09:00:00',108)     
                       ELSE convert(char(8),'09:00:00',108)      
                       END      
                END
		  END      
        
     WHEN '1'      
     THEN CASE ISNULL(D.DILIG_NM,'')      
          WHEN ''      
          THEN  CASE H.HOLI_TYPE         
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'09:00:00',108)      
                END      
          WHEN '����(����)'      
          THEN  convert(char(8),'00:00:00',108) 
          WHEN '����(����)'      
          THEN  convert(char(8),'00:00:00',108)     
          WHEN '����ٹ�1'    
          THEN  CASE F.REPORT_TYPE  
                WHEN '2'  
                THEN convert(char(8),'00:00:00',108)    
				ELSE convert(char(8),'00:00:00',108)    
                END 
		  WHEN '���ϱٹ�1'    
          THEN CASE F.REPORT_TYPE  
               WHEN '2'  
               THEN  
                   CASE H.HOLI_TYPE
                   WHEN 'H'    
                   THEN convert(char(8),'00:00:00',108)  
                   ELSE convert(char(8),'00:00:00',108)    
                   END  
               ELSE convert(char(8),'00:00:00',108)    
               END     
          ELSE CASE H.HOLI_TYPE      
               WHEN 'D'     
               THEN convert(char(8),'09:00:00',108)
               ELSE convert(char(8),'00:00:00',108)      
               END      
          END      
     ELSE CASE H.HOLI_TYPE
          WHEN 'D'     
          THEN  CASE ISNULL(A.START_TIME ,'')      
                WHEN ''      
                THEN CASE ISNULL(A.END_TIME,'')      
                     WHEN ''      
                     THEN convert(char(8),'00:00:00',108)      
                     ELSE convert(char(8),'09:00:00',108)      
                     END      
                ELSE      
                     CASE        -- ��ٽð��� 9�� �����϶��� ��ٽð��� 9�÷� �����ϴ� CASE��   
                     WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'18:00:00',108)   -- 18�� �̻��϶� (CS�ٹ�)�ð� �ӽ��� �ٹ��ð� 8�ð����� ������  
                     THEN convert(char(8),'09:00:00',108)       
                     WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)      
                     THEN convert(char(8), A.START_TIME,108)      
                     WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)      
                     THEN convert(char(8),'09:00:00',108)    
                     ELSE convert(char(8),'09:00:00',108)      
                     END      
               END      
       WHEN 'H'      
       THEN convert(char(8),'00:00:00',108)
       ELSE convert(char(8),'00:00:00',108)      
       END      
     END
ELSE  CASE H.HOLI_TYPE
      WHEN 'H'
	  THEN convert(char(8),'00:00:00',108)
	  ELSE
        CASE ISNULL(E.APPROVAL_RTN,'')      -- �����ٹ��� �����Ͱ� ������, �ٹ��ð� ��� �� --
        WHEN ''      
        THEN   
		     CASE ISNULL(A.START_TIME,'')
			 WHEN ''
			 THEN CASE ISNULL(A.END_TIME,'')
			      WHEN ''
				  THEN convert(char(8),'00:00:00',108)
				  ELSE    
			           CASE       
                       WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                       THEN convert(char(8),G.START_TIME,108)       
                       ELSE convert(char(8),G.START_TIME,108)      
                       END
				 END
			 ELSE
			      CASE       
                  WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                  THEN convert(char(8),A.START_TIME,108)      
                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                  THEN convert(char(8),G.START_TIME,108)       
                  ELSE convert(char(8),G.START_TIME,108)      
                  END
			 END         
        WHEN '1'      
        THEN CASE ISNULL(D.DILIG_NM,'')      
             WHEN ''      
             THEN  convert(char(8),G.START_TIME,108)      
             WHEN '����(����)'      
             THEN  convert(char(8),'00:00:00',108)
             WHEN '����(����)'      
             THEN  convert(char(8),'00:00:00',108)      
             WHEN '����ٹ�1'    
             THEN  CASE F.REPORT_TYPE
			       WHEN '1'  
                   THEN convert(char(8),G.START_TIME,108) 
                   WHEN '2'  
                   THEN convert(char(8),'00:00:00',108)  
                   ELSE convert(char(8),'00:00:00',108)   
                   END  
             ELSE 
			      CASE ISNULL(A.START_TIME,'')
			      WHEN ''
			      THEN CASE ISNULL(A.END_TIME,'')
			           WHEN ''
			      	   THEN convert(char(8),'00:00:00',108)
			      	   ELSE convert(char(8),G.START_TIME,108)     
					   END
				  ELSE convert(char(8),G.START_TIME,108)     
				  END
             END      
        ELSE CASE ISNULL(A.START_TIME,'')
			 WHEN ''
			 THEN CASE ISNULL(A.END_TIME,'')
			      WHEN ''
				  THEN convert(char(8),'00:00:00',108)
				  ELSE    
			           CASE       
                       WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                       THEN convert(char(8),G.START_TIME,108)       
                       ELSE convert(char(8),G.START_TIME,108)      
                       END
				 END
			 ELSE
			      CASE       
                  WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                  THEN convert(char(8),A.START_TIME,108)      
                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                  THEN convert(char(8),G.START_TIME,108)       
                  ELSE convert(char(8),G.START_TIME,108)      
                  END
			 END
        END
	END
END      
        ,   --// ��ٽð��� ���� //
CASE ISNULL( G.EMP_NO,'')
WHEN ''
THEN 
     CASE ISNULL(E.APPROVAL_RTN,'')      
     WHEN ''      
     THEN CASE H.HOLI_TYPE  
          WHEN 'D'     
          THEN   CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN  CASE ISNULL(A.END_TIME,'')      
                       WHEN ''      
                       THEN CASE ISNULL(A.START_TIME,'')      
                            WHEN ''      
                            THEN convert(char(8),'00:00:00',108)      
                            ELSE convert(char(8),'17:00:00',108)      
                            END      
                       ELSE convert(char(8),'17:00:00',108)      
                       END      
                 ELSE CASE ISNULL(A.END_TIME,'')      
                      WHEN ''      
                      THEN CASE ISNULL(A.START_TIME,'')      
                           WHEN ''      
                           THEN convert(char(8),'00:00:00',108)      
                           ELSE convert(char(8),'17:00:00',108)      
                           END      
                      ELSE convert(char(8),'17:00:00',108)      
                      END      
                END      
           WHEN 'H'      
           THEN convert(char(8),'00:00:00',108)     
     	  ELSE convert(char(8),'00:00:00',108)      
           END      
     WHEN '1'      
     THEN         
           CASE ISNULL(D.DILIG_NM,'')      
           WHEN ''      
           THEN CASE H.HOLI_TYPE
                WHEN 'D'     
                THEN convert(char(8),'17:00:00',108)      
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)      
                ELSE convert(char(8),'17:00:00',108)      
                END  
           WHEN '����(����)'  
           THEN CASE H.HOLI_TYPE
                WHEN 'D' 
                THEN convert(char(8),'04:00:00',108)
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'00:00:00',108)      
                END         
           WHEN '����(����)'      
           THEN CASE H.HOLI_TYPE 
                WHEN 'D' 
                THEN convert(char(8),'04:00:00',108)
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'00:00:00',108)      
                END      
           WHEN '����ٹ�1'      
           THEN CASE H.HOLI_TYPE
                WHEN 'D'
     		   THEN
     	            CASE F.REPORT_TYPE
     			    WHEN '1'
     			    THEN convert(char(8),'08:00:00',108)
     	            WHEN '2'
     			    THEN    
     	                 CASE 
     		             WHEN ISNULL(A.START_TIME,'') = ''
     					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108) -- ��(minute)������� �߰� '21.01.12
     		   	    	 WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)
     					 THEN convert(char(8),convert(datetime,dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0)) -convert(datetime,A.TT,108) ,108)  
     					 WHEN ISNULL(A.END_TIME,'') =''
     					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108)
     					 WHEN convert(char(8),A.END_TIME,108) < convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO,0),108)
     					 THEN  CASE
     					       WHEN convert(char(8),A.END_TIME,108) > convert(char(8),A.START_TIME,108)
     						   THEN
     					           convert(char(8), dateadd(n, datediff(n,0, convert(char(8),A.END_TIME,108) )   - 
     					                                                                      CASE 
     														                                  WHEN ISNULL(A.START_TIME ,'') = ''
     														                                  THEN datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  WHEN convert(char(8),A.START_TIME,108) >= convert(char(8),'09:00:00',108)
     														                                  THEN datediff(n,0,A.START_TIME)
     														                                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)
     														                                  THEN datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  ELSE datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  END  -90  
     																						           ,0)
     													                                                 ,108)
                               ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108)
     						  END
     					 ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108) -- ��(minute)������� �߰� '21.01.12
     		   	    	 END
     		   	    ELSE  convert(char(8),'00:00:00',108)
     			    END 
                 WHEN 'H'    
                 THEN convert(char(8),'00:00:00',108)
                 ELSE convert(char(8),'00:00:00',108)     
                 END      
            WHEN '���ϱٹ�1'    
            THEN CASE F.REPORT_TYPE
     	        WHEN '2'
     			THEN 
     	          CASE H.HOLI_TYPE
                   WHEN 'H'  
     			  THEN CASE 
     			       WHEN convert(char(8),dateadd(hh,C.DILIG_HH , 0),108) >= '05:00:00' -- �ް��ٹ��ð��� 5�ð� �̻��϶� ���ɽð� 1�ð� ���� ��
     			       THEN convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM - 60 , 0),108) -- ��(minute)������� �߰� '21.01.12
     			       ELSE convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM , 0),108)
     			  	   END 
                   ELSE convert(char(8),'00:00:00',108)  
                   END
     			ELSE  convert(char(8),'00:00:00',108)  
     			END   
            ELSE convert(char(8),'00:00:00',108)      
            END
     ELSE CASE H.HOLI_TYPE
          WHEN 'D'     
          THEN   CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN  CASE ISNULL(A.END_TIME,'')      
                       WHEN ''      
                       THEN CASE ISNULL(A.START_TIME,'')      
                            WHEN ''      
                            THEN convert(char(8),'00:00:00',108)      
                            ELSE convert(char(8),'17:00:00',108)      
                            END      
                       ELSE convert(char(8),'17:00:00',108)      
                       END      
                 ELSE CASE ISNULL(A.END_TIME,'')      
                      WHEN ''      
                      THEN CASE ISNULL(A.START_TIME,'')      
                           WHEN ''      
                           THEN convert(char(8),'00:00:00',108)      
                           ELSE convert(char(8),'17:00:00',108)      
                           END      
                      ELSE convert(char(8),'17:00:00',108)      
                      END      
                END      
           WHEN 'H'      
           THEN convert(char(8),'00:00:00',108)      
     	  ELSE convert(char(8),'00:00:00',108)      
           END      
     END
ELSE CASE H.HOLI_TYPE
     WHEN 'H'
	 THEN CASE ISNULL(E.APPROVAL_RTN,'')
	      WHEN ''
		  THEN convert(char(8),'00:00:00',108)  
		  WHEN '1'
		  THEN CASE ISNULL(D.DILIG_NM,'')
		       WHEN ''
			   THEN convert(char(8),'00:00:00',108)  
			   WHEN '���ϱٹ�1'
			   THEN CASE F.REPORT_TYPE
     	            WHEN '2'
     			    THEN 
     	                    CASE 
     			             WHEN convert(char(8),dateadd(hh,C.DILIG_HH , 0),108) >= '05:00:00' -- �ް��ٹ��ð��� 5�ð� �̻��϶� ���ɽð� 1�ð� ���� ��
     			             THEN convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM - 60 , 0),108) -- ��(minute)������� �߰� '21.01.12
     			             ELSE convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM , 0),108)
     			      	     END 
     			    ELSE  convert(char(8),'00:00:00',108)  
     			    END
			 ELSE convert(char(8),'00:00:00',108) 
			 END
		ELSE convert(char(8),'00:00:00',108) 
		END  
	 ELSE       
           CASE ISNULL(E.APPROVAL_RTN,'')      
           WHEN ''      
           THEN CASE ISNULL(D.DILIG_NM,'')      
                WHEN ''      
                --THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)        
				THEN
				      CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END
                --ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
				ELSE CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END
                END         
           WHEN '1'      
           THEN         
                 CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN convert(char(8),G.END_TIME,108)  
                 WHEN '����(����)'  
                 THEN convert(char(8),dateadd(n,(datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 60)/2 , 0),108)     -- ����(����,����)����Ƕ�, ��ٽð�-��ٽð�-�߽�(1�ð�) ���� ������2�� �� �ð����� ���   
                 WHEN '����(����)'      
                 THEN convert(char(8),dateadd(n,(datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 60)/2 , 0),108)      
                 WHEN '����ٹ�1'      
                 THEN 
           	            CASE F.REPORT_TYPE
           			    WHEN '1'
           			    THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108) 
           	            WHEN '2'
           			    THEN    
           	                 CASE 
           		             WHEN ISNULL(A.START_TIME,'') = ''
           					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108) -- ����ٹ��ð� + (��ٽð�-��ٽð�) - 90 ���� �߰�
           		   	    	 WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))
           					 THEN convert(char(8),convert(datetime,dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0)) -convert(datetime,A.TT,108) ,108)  
           					 WHEN ISNULL(A.END_TIME,'') =''
           					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           					 WHEN convert(char(8),A.END_TIME,108) < convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO,0),108)
           					 THEN  CASE
           					       WHEN convert(char(8),A.END_TIME,108) > convert(char(8),A.START_TIME,108)
           						   THEN
           					           convert(char(8), dateadd(n, datediff(n,0, A.END_TIME ) - 
           					                                                                      CASE 
           														                                  WHEN ISNULL(A.START_TIME ,'') = ''
           														                                  THEN datediff(n,0, G.START_TIME )
           														                                  WHEN convert(char(8),A.START_TIME,108) >= convert(char(8),G.START_TIME,108)
           														                                  THEN datediff(n,0,A.START_TIME)
           														                                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)
           														                                  THEN datediff(n,0, G.START_TIME )
           														                                  ELSE datediff(n,0, G.START_TIME )
           														                                  END  -90  
           																						           ,0)
           													                                                 ,108)
                                     ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           						  END
           					 ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           		   	    	 END
           		   	    ELSE  convert(char(8),'00:00:00',108)
           			    END 
                ELSE   
				     CASE ISNULL(A.START_TIME,'')
					 WHEN ''
					 THEN CASE ISNULL(A.END_TIME,'')
					      WHEN ''
						  THEN convert(char(8),'00:00:00',108)
						  ELSE 
				               CASE ISNULL(D.DILIG_NM,'')      
                               WHEN ''      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                               END   
						  END
					ELSE 
					      CASE ISNULL(D.DILIG_NM,'')      
                          WHEN ''      
                          THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                          ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                          END  
					END
                 
                END
		  --ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)
		  ELSE CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END  
          END 
	 END
END
    )/60 as varchar(4) ) + ':' +    
  -- �ѱٹ� Minute���    
   case     
 when      
DATEDIFF(n,  -- �ѱٹ� Hour���    
CASE ISNULL(G.EMP_NO,'')
WHEN ''
THEN
     CASE ISNULL(E.APPROVAL_RTN,'')      
     WHEN ''      
     THEN CASE H.HOLI_TYPE
          WHEN 'H'     
          THEN  convert(char(8),'00:00:00',108)
		  ELSE  CASE ISNULL(A.START_TIME ,'')      
                WHEN ''      
                THEN CASE ISNULL(A.END_TIME,'')      
                     WHEN ''      
                     THEN convert(char(8),'00:00:00',108)      
                     ELSE convert(char(8),'09:00:00',108)      
                     END         
                ELSE   CASE        -- ��ٽð��� 9�� �����϶��� ��ٽð��� 9�÷� �����ϴ� CASE��        
                       WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'18:00:00',108)   -- 18�� �̻��϶� (CS�ٹ�)�ð� �ӽ��� �ٹ��ð� 8�ð����� ������  
                       THEN convert(char(8),'09:00:00',108)    
                       WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)      
                       THEN convert(char(8),'09:00:00',108)     
                       ELSE convert(char(8),'09:00:00',108)      
                       END      
                END
		  END      
        
     WHEN '1'      
     THEN CASE ISNULL(D.DILIG_NM,'')      
          WHEN ''      
          THEN  CASE H.HOLI_TYPE         
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'09:00:00',108)      
                END      
          WHEN '����(����)'      
          THEN  convert(char(8),'00:00:00',108) 
          WHEN '����(����)'      
          THEN  convert(char(8),'00:00:00',108)     
          WHEN '����ٹ�1'    
          THEN  CASE F.REPORT_TYPE  
                WHEN '2'  
                THEN convert(char(8),'00:00:00',108)    
				ELSE convert(char(8),'00:00:00',108)    
                END 
		  WHEN '���ϱٹ�1'    
          THEN CASE F.REPORT_TYPE  
               WHEN '2'  
               THEN  
                   CASE H.HOLI_TYPE
                   WHEN 'H'    
                   THEN convert(char(8),'00:00:00',108)  
                   ELSE convert(char(8),'00:00:00',108)    
                   END  
               ELSE convert(char(8),'00:00:00',108)    
               END     
          ELSE CASE H.HOLI_TYPE      
               WHEN 'D'     
               THEN convert(char(8),'09:00:00',108)
               ELSE convert(char(8),'00:00:00',108)      
               END      
          END      
     ELSE CASE H.HOLI_TYPE
          WHEN 'D'     
          THEN  CASE ISNULL(A.START_TIME ,'')      
                WHEN ''      
                THEN CASE ISNULL(A.END_TIME,'')      
                     WHEN ''      
                     THEN convert(char(8),'00:00:00',108)      
                     ELSE convert(char(8),'09:00:00',108)      
                     END      
                ELSE      
                     CASE        -- ��ٽð��� 9�� �����϶��� ��ٽð��� 9�÷� �����ϴ� CASE��   
                     WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'18:00:00',108)   -- 18�� �̻��϶� (CS�ٹ�)�ð� �ӽ��� �ٹ��ð� 8�ð����� ������  
                     THEN convert(char(8),'09:00:00',108)       
                     WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)      
                     THEN convert(char(8), A.START_TIME,108)      
                     WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)      
                     THEN convert(char(8),'09:00:00',108)    
                     ELSE convert(char(8),'09:00:00',108)      
                     END      
               END      
       WHEN 'H'      
       THEN convert(char(8),'00:00:00',108)
       ELSE convert(char(8),'00:00:00',108)      
       END      
     END
ELSE  CASE H.HOLI_TYPE
      WHEN 'H'
	  THEN convert(char(8),'00:00:00',108)
	  ELSE
        CASE ISNULL(E.APPROVAL_RTN,'')      -- �����ٹ��� �����Ͱ� ������, �ٹ��ð� ��� �� --
        WHEN ''      
        THEN   
		     CASE ISNULL(A.START_TIME,'')
			 WHEN ''
			 THEN CASE ISNULL(A.END_TIME,'')
			      WHEN ''
				  THEN convert(char(8),'00:00:00',108)
				  ELSE    
			           CASE       
                       WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                       THEN convert(char(8),G.START_TIME,108)       
                       ELSE convert(char(8),G.START_TIME,108)      
                       END
				 END
			 ELSE
			      CASE       
                  WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                  THEN convert(char(8),A.START_TIME,108)      
                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                  THEN convert(char(8),G.START_TIME,108)       
                  ELSE convert(char(8),G.START_TIME,108)      
                  END
			 END         
        WHEN '1'      
        THEN CASE ISNULL(D.DILIG_NM,'')      
             WHEN ''      
             THEN  convert(char(8),G.START_TIME,108)      
             WHEN '����(����)'      
             THEN  convert(char(8),'00:00:00',108)
             WHEN '����(����)'      
             THEN  convert(char(8),'00:00:00',108)      
             WHEN '����ٹ�1'    
             THEN  CASE F.REPORT_TYPE
			       WHEN '1'  
                   THEN convert(char(8),G.START_TIME,108) 
                   WHEN '2'  
                   THEN convert(char(8),'00:00:00',108)  
                   ELSE convert(char(8),'00:00:00',108)   
                   END  
             ELSE 
			      CASE ISNULL(A.START_TIME,'')
			      WHEN ''
			      THEN CASE ISNULL(A.END_TIME,'')
			           WHEN ''
			      	   THEN convert(char(8),'00:00:00',108)
			      	   ELSE convert(char(8),G.START_TIME,108)     
					   END
				  ELSE convert(char(8),G.START_TIME,108)     
				  END
             END      
        ELSE CASE ISNULL(A.START_TIME,'')
			 WHEN ''
			 THEN CASE ISNULL(A.END_TIME,'')
			      WHEN ''
				  THEN convert(char(8),'00:00:00',108)
				  ELSE    
			           CASE       
                       WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                       THEN convert(char(8),G.START_TIME,108)       
                       ELSE convert(char(8),G.START_TIME,108)      
                       END
				 END
			 ELSE
			      CASE       
                  WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                  THEN convert(char(8),A.START_TIME,108)      
                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                  THEN convert(char(8),G.START_TIME,108)       
                  ELSE convert(char(8),G.START_TIME,108)      
                  END
			 END
        END
	END
END      
        ,   --// ��ٽð��� ���� //
CASE ISNULL( G.EMP_NO,'')
WHEN ''
THEN 
     CASE ISNULL(E.APPROVAL_RTN,'')      
     WHEN ''      
     THEN CASE H.HOLI_TYPE  
          WHEN 'D'     
          THEN   CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN  CASE ISNULL(A.END_TIME,'')      
                       WHEN ''      
                       THEN CASE ISNULL(A.START_TIME,'')      
                            WHEN ''      
                            THEN convert(char(8),'00:00:00',108)      
                            ELSE convert(char(8),'17:00:00',108)      
                            END      
                       ELSE convert(char(8),'17:00:00',108)      
                       END      
                 ELSE CASE ISNULL(A.END_TIME,'')      
                      WHEN ''      
                      THEN CASE ISNULL(A.START_TIME,'')      
                           WHEN ''      
                           THEN convert(char(8),'00:00:00',108)      
                           ELSE convert(char(8),'17:00:00',108)      
                           END      
                      ELSE convert(char(8),'17:00:00',108)      
                      END      
                END      
           WHEN 'H'      
           THEN convert(char(8),'00:00:00',108)     
     	  ELSE convert(char(8),'00:00:00',108)      
           END      
     WHEN '1'      
     THEN         
           CASE ISNULL(D.DILIG_NM,'')      
           WHEN ''      
           THEN CASE H.HOLI_TYPE
                WHEN 'D'     
                THEN convert(char(8),'17:00:00',108)      
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)      
                ELSE convert(char(8),'17:00:00',108)      
                END  
           WHEN '����(����)'  
           THEN CASE H.HOLI_TYPE
                WHEN 'D' 
                THEN convert(char(8),'04:00:00',108)
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'00:00:00',108)      
                END         
           WHEN '����(����)'      
           THEN CASE H.HOLI_TYPE 
                WHEN 'D' 
                THEN convert(char(8),'04:00:00',108)
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'00:00:00',108)      
                END      
           WHEN '����ٹ�1'      
           THEN CASE H.HOLI_TYPE
                WHEN 'D'
     		   THEN
     	            CASE F.REPORT_TYPE
     			    WHEN '1'
     			    THEN convert(char(8),'08:00:00',108)
     	            WHEN '2'
     			    THEN    
     	                 CASE 
     		             WHEN ISNULL(A.START_TIME,'') = ''
     					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108) -- ��(minute)������� �߰� '21.01.12
     		   	    	 WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)
     					 THEN convert(char(8),convert(datetime,dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0)) -convert(datetime,A.TT,108) ,108)  
     					 WHEN ISNULL(A.END_TIME,'') =''
     					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108)
     					 WHEN convert(char(8),A.END_TIME,108) < convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO,0),108)
     					 THEN  CASE
     					       WHEN convert(char(8),A.END_TIME,108) > convert(char(8),A.START_TIME,108)
     						   THEN
     					           convert(char(8), dateadd(n, datediff(n,0, convert(char(8),A.END_TIME,108) )   - 
     					                                                                      CASE 
     														                                  WHEN ISNULL(A.START_TIME ,'') = ''
     														                                  THEN datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  WHEN convert(char(8),A.START_TIME,108) >= convert(char(8),'09:00:00',108)
     														                                  THEN datediff(n,0,A.START_TIME)
     														                                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)
     														                                  THEN datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  ELSE datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  END  -90  
     																						           ,0)
     													                                                 ,108)
                               ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108)
     						  END
     					 ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108) -- ��(minute)������� �߰� '21.01.12
     		   	    	 END
     		   	    ELSE  convert(char(8),'00:00:00',108)
     			    END 
                 WHEN 'H'    
                 THEN convert(char(8),'00:00:00',108)
                 ELSE convert(char(8),'00:00:00',108)     
                 END      
            WHEN '���ϱٹ�1'    
            THEN CASE F.REPORT_TYPE
     	        WHEN '2'
     			THEN 
     	          CASE H.HOLI_TYPE
                   WHEN 'H'  
     			  THEN CASE 
     			       WHEN convert(char(8),dateadd(hh,C.DILIG_HH , 0),108) >= '05:00:00' -- �ް��ٹ��ð��� 5�ð� �̻��϶� ���ɽð� 1�ð� ���� ��
     			       THEN convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM - 60 , 0),108) -- ��(minute)������� �߰� '21.01.12
     			       ELSE convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM , 0),108)
     			  	   END 
                   ELSE convert(char(8),'00:00:00',108)  
                   END
     			ELSE  convert(char(8),'00:00:00',108)  
     			END   
            ELSE convert(char(8),'00:00:00',108)      
            END
     ELSE CASE H.HOLI_TYPE
          WHEN 'D'     
          THEN   CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN  CASE ISNULL(A.END_TIME,'')      
                       WHEN ''      
                       THEN CASE ISNULL(A.START_TIME,'')      
                            WHEN ''      
                            THEN convert(char(8),'00:00:00',108)      
                            ELSE convert(char(8),'17:00:00',108)      
                            END      
                       ELSE convert(char(8),'17:00:00',108)      
                       END      
                 ELSE CASE ISNULL(A.END_TIME,'')      
                      WHEN ''      
                      THEN CASE ISNULL(A.START_TIME,'')      
                           WHEN ''      
                           THEN convert(char(8),'00:00:00',108)      
                           ELSE convert(char(8),'17:00:00',108)      
                           END      
                      ELSE convert(char(8),'17:00:00',108)      
                      END      
                END      
           WHEN 'H'      
           THEN convert(char(8),'00:00:00',108)      
     	  ELSE convert(char(8),'00:00:00',108)      
           END      
     END
ELSE CASE H.HOLI_TYPE
     WHEN 'H'
	 THEN CASE ISNULL(E.APPROVAL_RTN,'')
	      WHEN ''
		  THEN convert(char(8),'00:00:00',108)  
		  WHEN '1'
		  THEN CASE ISNULL(D.DILIG_NM,'')
		       WHEN ''
			   THEN convert(char(8),'00:00:00',108)  
			   WHEN '���ϱٹ�1'
			   THEN CASE F.REPORT_TYPE
     	            WHEN '2'
     			    THEN 
     	                    CASE 
     			             WHEN convert(char(8),dateadd(hh,C.DILIG_HH , 0),108) >= '05:00:00' -- �ް��ٹ��ð��� 5�ð� �̻��϶� ���ɽð� 1�ð� ���� ��
     			             THEN convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM - 60 , 0),108) -- ��(minute)������� �߰� '21.01.12
     			             ELSE convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM , 0),108)
     			      	     END 
     			    ELSE  convert(char(8),'00:00:00',108)  
     			    END
			 ELSE convert(char(8),'00:00:00',108) 
			 END
		ELSE convert(char(8),'00:00:00',108) 
		END  
	 ELSE       
           CASE ISNULL(E.APPROVAL_RTN,'')      
           WHEN ''      
           THEN CASE ISNULL(D.DILIG_NM,'')      
                WHEN ''      
                --THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)        
				THEN
				      CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END
                --ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
				ELSE CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END
                END         
           WHEN '1'      
           THEN         
                 CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN convert(char(8),G.END_TIME,108)  
                 WHEN '����(����)'  
                 THEN convert(char(8),dateadd(n,(datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 60)/2 , 0),108)     -- ����(����,����)����Ƕ�, ��ٽð�-��ٽð�-�߽�(1�ð�) ���� ������2�� �� �ð����� ���   
                 WHEN '����(����)'      
                 THEN convert(char(8),dateadd(n,(datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 60)/2 , 0),108)      
                 WHEN '����ٹ�1'      
                 THEN 
           	            CASE F.REPORT_TYPE
           			    WHEN '1'
           			    THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108) 
           	            WHEN '2'
           			    THEN    
           	                 CASE 
           		             WHEN ISNULL(A.START_TIME,'') = ''
           					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108) -- ����ٹ��ð� + (��ٽð�-��ٽð�) - 90 ���� �߰�
           		   	    	 WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))
           					 THEN convert(char(8),convert(datetime,dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0)) -convert(datetime,A.TT,108) ,108)  
           					 WHEN ISNULL(A.END_TIME,'') =''
           					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           					 WHEN convert(char(8),A.END_TIME,108) < convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO,0),108)
           					 THEN  CASE
           					       WHEN convert(char(8),A.END_TIME,108) > convert(char(8),A.START_TIME,108)
           						   THEN
           					           convert(char(8), dateadd(n, datediff(n,0, A.END_TIME ) - 
           					                                                                      CASE 
           														                                  WHEN ISNULL(A.START_TIME ,'') = ''
           														                                  THEN datediff(n,0, G.START_TIME )
           														                                  WHEN convert(char(8),A.START_TIME,108) >= convert(char(8),G.START_TIME,108)
           														                                  THEN datediff(n,0,A.START_TIME)
           														                                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)
           														                                  THEN datediff(n,0, G.START_TIME )
           														                                  ELSE datediff(n,0, G.START_TIME )
           														                                  END  -90  
           																						           ,0)
           													                                                 ,108)
                                     ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           						  END
           					 ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           		   	    	 END
           		   	    ELSE  convert(char(8),'00:00:00',108)
           			    END 
                ELSE   
				     CASE ISNULL(A.START_TIME,'')
					 WHEN ''
					 THEN CASE ISNULL(A.END_TIME,'')
					      WHEN ''
						  THEN convert(char(8),'00:00:00',108)
						  ELSE 
				               CASE ISNULL(D.DILIG_NM,'')      
                               WHEN ''      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                               END   
						  END
					ELSE 
					      CASE ISNULL(D.DILIG_NM,'')      
                          WHEN ''      
                          THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                          ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                          END  
					END
                 
                END
		  --ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)
		  ELSE CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END  
          END 
	 END
END
    )%60   < 10 THEN '0' + CAST(    
DATEDIFF(n,  -- �ѱٹ� Hour���    
CASE ISNULL(G.EMP_NO,'')
WHEN ''
THEN
     CASE ISNULL(E.APPROVAL_RTN,'')      
     WHEN ''      
     THEN CASE H.HOLI_TYPE
          WHEN 'H'     
          THEN  convert(char(8),'00:00:00',108)
		  ELSE  CASE ISNULL(A.START_TIME ,'')      
                WHEN ''      
                THEN CASE ISNULL(A.END_TIME,'')      
                     WHEN ''      
                     THEN convert(char(8),'00:00:00',108)      
                     ELSE convert(char(8),'09:00:00',108)      
                     END         
                ELSE   CASE        -- ��ٽð��� 9�� �����϶��� ��ٽð��� 9�÷� �����ϴ� CASE��        
                       WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'18:00:00',108)   -- 18�� �̻��϶� (CS�ٹ�)�ð� �ӽ��� �ٹ��ð� 8�ð����� ������  
                       THEN convert(char(8),'09:00:00',108)    
                       WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)      
                       THEN convert(char(8),'09:00:00',108)     
                       ELSE convert(char(8),'09:00:00',108)      
                       END      
                END
		  END      
        
     WHEN '1'      
     THEN CASE ISNULL(D.DILIG_NM,'')      
          WHEN ''      
          THEN  CASE H.HOLI_TYPE         
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'09:00:00',108)      
                END      
          WHEN '����(����)'      
          THEN  convert(char(8),'00:00:00',108) 
          WHEN '����(����)'      
          THEN  convert(char(8),'00:00:00',108)     
          WHEN '����ٹ�1'    
          THEN  CASE F.REPORT_TYPE  
                WHEN '2'  
                THEN convert(char(8),'00:00:00',108)    
				ELSE convert(char(8),'00:00:00',108)    
                END 
		  WHEN '���ϱٹ�1'    
          THEN CASE F.REPORT_TYPE  
               WHEN '2'  
               THEN  
                   CASE H.HOLI_TYPE
                   WHEN 'H'    
                   THEN convert(char(8),'00:00:00',108)  
                   ELSE convert(char(8),'00:00:00',108)    
                   END  
               ELSE convert(char(8),'00:00:00',108)    
               END     
          ELSE CASE H.HOLI_TYPE      
               WHEN 'D'     
               THEN convert(char(8),'09:00:00',108)
               ELSE convert(char(8),'00:00:00',108)      
               END      
          END      
     ELSE CASE H.HOLI_TYPE
          WHEN 'D'     
          THEN  CASE ISNULL(A.START_TIME ,'')      
                WHEN ''      
                THEN CASE ISNULL(A.END_TIME,'')      
                     WHEN ''      
                     THEN convert(char(8),'00:00:00',108)      
                     ELSE convert(char(8),'09:00:00',108)      
                     END      
                ELSE      
                     CASE        -- ��ٽð��� 9�� �����϶��� ��ٽð��� 9�÷� �����ϴ� CASE��   
                     WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'18:00:00',108)   -- 18�� �̻��϶� (CS�ٹ�)�ð� �ӽ��� �ٹ��ð� 8�ð����� ������  
                     THEN convert(char(8),'09:00:00',108)       
                     WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)      
                     THEN convert(char(8), A.START_TIME,108)      
                     WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)      
                     THEN convert(char(8),'09:00:00',108)    
                     ELSE convert(char(8),'09:00:00',108)      
                     END      
               END      
       WHEN 'H'      
       THEN convert(char(8),'00:00:00',108)
       ELSE convert(char(8),'00:00:00',108)      
       END      
     END
ELSE  CASE H.HOLI_TYPE
      WHEN 'H'
	  THEN convert(char(8),'00:00:00',108)
	  ELSE
        CASE ISNULL(E.APPROVAL_RTN,'')      -- �����ٹ��� �����Ͱ� ������, �ٹ��ð� ��� �� --
        WHEN ''      
        THEN   
		     CASE ISNULL(A.START_TIME,'')
			 WHEN ''
			 THEN CASE ISNULL(A.END_TIME,'')
			      WHEN ''
				  THEN convert(char(8),'00:00:00',108)
				  ELSE    
			           CASE       
                       WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                       THEN convert(char(8),G.START_TIME,108)       
                       ELSE convert(char(8),G.START_TIME,108)      
                       END
				 END
			 ELSE
			      CASE       
                  WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                  THEN convert(char(8),A.START_TIME,108)      
                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                  THEN convert(char(8),G.START_TIME,108)       
                  ELSE convert(char(8),G.START_TIME,108)      
                  END
			 END         
        WHEN '1'      
        THEN CASE ISNULL(D.DILIG_NM,'')      
             WHEN ''      
             THEN  convert(char(8),G.START_TIME,108)      
             WHEN '����(����)'      
             THEN  convert(char(8),'00:00:00',108)
             WHEN '����(����)'      
             THEN  convert(char(8),'00:00:00',108)      
             WHEN '����ٹ�1'    
             THEN  CASE F.REPORT_TYPE
			       WHEN '1'  
                   THEN convert(char(8),G.START_TIME,108) 
                   WHEN '2'  
                   THEN convert(char(8),'00:00:00',108)  
                   ELSE convert(char(8),'00:00:00',108)   
                   END  
             ELSE 
			      CASE ISNULL(A.START_TIME,'')
			      WHEN ''
			      THEN CASE ISNULL(A.END_TIME,'')
			           WHEN ''
			      	   THEN convert(char(8),'00:00:00',108)
			      	   ELSE convert(char(8),G.START_TIME,108)     
					   END
				  ELSE convert(char(8),G.START_TIME,108)     
				  END
             END      
        ELSE CASE ISNULL(A.START_TIME,'')
			 WHEN ''
			 THEN CASE ISNULL(A.END_TIME,'')
			      WHEN ''
				  THEN convert(char(8),'00:00:00',108)
				  ELSE    
			           CASE       
                       WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                       THEN convert(char(8),G.START_TIME,108)       
                       ELSE convert(char(8),G.START_TIME,108)      
                       END
				 END
			 ELSE
			      CASE       
                  WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                  THEN convert(char(8),A.START_TIME,108)      
                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                  THEN convert(char(8),G.START_TIME,108)       
                  ELSE convert(char(8),G.START_TIME,108)      
                  END
			 END
        END
	END
END      
        ,   --// ��ٽð��� ���� //
CASE ISNULL( G.EMP_NO,'')
WHEN ''
THEN 
     CASE ISNULL(E.APPROVAL_RTN,'')      
     WHEN ''      
     THEN CASE H.HOLI_TYPE  
          WHEN 'D'     
          THEN   CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN  CASE ISNULL(A.END_TIME,'')      
                       WHEN ''      
                       THEN CASE ISNULL(A.START_TIME,'')      
                            WHEN ''      
                            THEN convert(char(8),'00:00:00',108)      
                            ELSE convert(char(8),'17:00:00',108)      
                            END      
                       ELSE convert(char(8),'17:00:00',108)      
                       END      
                 ELSE CASE ISNULL(A.END_TIME,'')      
                      WHEN ''      
                      THEN CASE ISNULL(A.START_TIME,'')      
                           WHEN ''      
                           THEN convert(char(8),'00:00:00',108)      
                           ELSE convert(char(8),'17:00:00',108)      
                           END      
                      ELSE convert(char(8),'17:00:00',108)      
                      END      
                END      
           WHEN 'H'      
           THEN convert(char(8),'00:00:00',108)     
     	  ELSE convert(char(8),'00:00:00',108)      
           END      
     WHEN '1'      
     THEN         
           CASE ISNULL(D.DILIG_NM,'')      
           WHEN ''      
           THEN CASE H.HOLI_TYPE
                WHEN 'D'     
                THEN convert(char(8),'17:00:00',108)      
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)      
                ELSE convert(char(8),'17:00:00',108)      
                END  
           WHEN '����(����)'  
           THEN CASE H.HOLI_TYPE
                WHEN 'D' 
                THEN convert(char(8),'04:00:00',108)
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'00:00:00',108)      
                END         
           WHEN '����(����)'      
           THEN CASE H.HOLI_TYPE 
                WHEN 'D' 
                THEN convert(char(8),'04:00:00',108)
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'00:00:00',108)      
                END      
           WHEN '����ٹ�1'      
           THEN CASE H.HOLI_TYPE
                WHEN 'D'
     		   THEN
     	            CASE F.REPORT_TYPE
     			    WHEN '1'
     			    THEN convert(char(8),'08:00:00',108)
     	            WHEN '2'
     			    THEN    
     	                 CASE 
     		             WHEN ISNULL(A.START_TIME,'') = ''
     					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108) -- ��(minute)������� �߰� '21.01.12
     		   	    	 WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)
     					 THEN convert(char(8),convert(datetime,dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0)) -convert(datetime,A.TT,108) ,108)  
     					 WHEN ISNULL(A.END_TIME,'') =''
     					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108)
     					 WHEN convert(char(8),A.END_TIME,108) < convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO,0),108)
     					 THEN  CASE
     					       WHEN convert(char(8),A.END_TIME,108) > convert(char(8),A.START_TIME,108)
     						   THEN
     					           convert(char(8), dateadd(n, datediff(n,0, convert(char(8),A.END_TIME,108) )   - 
     					                                                                      CASE 
     														                                  WHEN ISNULL(A.START_TIME ,'') = ''
     														                                  THEN datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  WHEN convert(char(8),A.START_TIME,108) >= convert(char(8),'09:00:00',108)
     														                                  THEN datediff(n,0,A.START_TIME)
     														                                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)
     														                                  THEN datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  ELSE datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  END  -90  
     																						           ,0)
     													                                                 ,108)
                               ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108)
     						  END
     					 ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108) -- ��(minute)������� �߰� '21.01.12
     		   	    	 END
     		   	    ELSE  convert(char(8),'00:00:00',108)
     			    END 
                 WHEN 'H'    
                 THEN convert(char(8),'00:00:00',108)
                 ELSE convert(char(8),'00:00:00',108)     
                 END      
            WHEN '���ϱٹ�1'    
            THEN CASE F.REPORT_TYPE
     	        WHEN '2'
     			THEN 
     	          CASE H.HOLI_TYPE
                   WHEN 'H'  
     			  THEN CASE 
     			       WHEN convert(char(8),dateadd(hh,C.DILIG_HH , 0),108) >= '05:00:00' -- �ް��ٹ��ð��� 5�ð� �̻��϶� ���ɽð� 1�ð� ���� ��
     			       THEN convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM - 60 , 0),108) -- ��(minute)������� �߰� '21.01.12
     			       ELSE convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM , 0),108)
     			  	   END 
                   ELSE convert(char(8),'00:00:00',108)  
                   END
     			ELSE  convert(char(8),'00:00:00',108)  
     			END   
            ELSE convert(char(8),'00:00:00',108)      
            END
     ELSE CASE H.HOLI_TYPE
          WHEN 'D'     
          THEN   CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN  CASE ISNULL(A.END_TIME,'')      
                       WHEN ''      
                       THEN CASE ISNULL(A.START_TIME,'')      
                            WHEN ''      
                            THEN convert(char(8),'00:00:00',108)      
                            ELSE convert(char(8),'17:00:00',108)      
                            END      
                       ELSE convert(char(8),'17:00:00',108)      
                       END      
                 ELSE CASE ISNULL(A.END_TIME,'')      
                      WHEN ''      
                      THEN CASE ISNULL(A.START_TIME,'')      
                           WHEN ''      
                           THEN convert(char(8),'00:00:00',108)      
                           ELSE convert(char(8),'17:00:00',108)      
                           END      
                      ELSE convert(char(8),'17:00:00',108)      
                      END      
                END      
           WHEN 'H'      
           THEN convert(char(8),'00:00:00',108)      
     	  ELSE convert(char(8),'00:00:00',108)      
           END      
     END
ELSE CASE H.HOLI_TYPE
     WHEN 'H'
	 THEN CASE ISNULL(E.APPROVAL_RTN,'')
	      WHEN ''
		  THEN convert(char(8),'00:00:00',108)  
		  WHEN '1'
		  THEN CASE ISNULL(D.DILIG_NM,'')
		       WHEN ''
			   THEN convert(char(8),'00:00:00',108)  
			   WHEN '���ϱٹ�1'
			   THEN CASE F.REPORT_TYPE
     	            WHEN '2'
     			    THEN 
     	                    CASE 
     			             WHEN convert(char(8),dateadd(hh,C.DILIG_HH , 0),108) >= '05:00:00' -- �ް��ٹ��ð��� 5�ð� �̻��϶� ���ɽð� 1�ð� ���� ��
     			             THEN convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM - 60 , 0),108) -- ��(minute)������� �߰� '21.01.12
     			             ELSE convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM , 0),108)
     			      	     END 
     			    ELSE  convert(char(8),'00:00:00',108)  
     			    END
			 ELSE convert(char(8),'00:00:00',108) 
			 END
		ELSE convert(char(8),'00:00:00',108) 
		END  
	 ELSE       
           CASE ISNULL(E.APPROVAL_RTN,'')      
           WHEN ''      
           THEN CASE ISNULL(D.DILIG_NM,'')      
                WHEN ''      
                --THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)        
				THEN
				      CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END
                --ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
				ELSE CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END
                END         
           WHEN '1'      
           THEN         
                 CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN convert(char(8),G.END_TIME,108)  
                 WHEN '����(����)'  
                 THEN convert(char(8),dateadd(n,(datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 60)/2 , 0),108)     -- ����(����,����)����Ƕ�, ��ٽð�-��ٽð�-�߽�(1�ð�) ���� ������2�� �� �ð����� ���   
                 WHEN '����(����)'      
                 THEN convert(char(8),dateadd(n,(datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 60)/2 , 0),108)      
                 WHEN '����ٹ�1'      
                 THEN 
           	            CASE F.REPORT_TYPE
           			    WHEN '1'
           			    THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108) 
           	            WHEN '2'
           			    THEN    
           	                 CASE 
           		             WHEN ISNULL(A.START_TIME,'') = ''
           					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108) -- ����ٹ��ð� + (��ٽð�-��ٽð�) - 90 ���� �߰�
           		   	    	 WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))
           					 THEN convert(char(8),convert(datetime,dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0)) -convert(datetime,A.TT,108) ,108)  
           					 WHEN ISNULL(A.END_TIME,'') =''
           					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           					 WHEN convert(char(8),A.END_TIME,108) < convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO,0),108)
           					 THEN  CASE
           					       WHEN convert(char(8),A.END_TIME,108) > convert(char(8),A.START_TIME,108)
           						   THEN
           					           convert(char(8), dateadd(n, datediff(n,0, A.END_TIME ) - 
           					                                                                      CASE 
           														                                  WHEN ISNULL(A.START_TIME ,'') = ''
           														                                  THEN datediff(n,0, G.START_TIME )
           														                                  WHEN convert(char(8),A.START_TIME,108) >= convert(char(8),G.START_TIME,108)
           														                                  THEN datediff(n,0,A.START_TIME)
           														                                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)
           														                                  THEN datediff(n,0, G.START_TIME )
           														                                  ELSE datediff(n,0, G.START_TIME )
           														                                  END  -90  
           																						           ,0)
           													                                                 ,108)
                                     ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           						  END
           					 ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           		   	    	 END
           		   	    ELSE  convert(char(8),'00:00:00',108)
           			    END 
                ELSE   
				     CASE ISNULL(A.START_TIME,'')
					 WHEN ''
					 THEN CASE ISNULL(A.END_TIME,'')
					      WHEN ''
						  THEN convert(char(8),'00:00:00',108)
						  ELSE 
				               CASE ISNULL(D.DILIG_NM,'')      
                               WHEN ''      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                               END   
						  END
					ELSE 
					      CASE ISNULL(D.DILIG_NM,'')      
                          WHEN ''      
                          THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                          ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                          END  
					END
                 
                END
		  --ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)
		  ELSE CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END  
          END 
	 END
END
    )%60 as varchar(4) )     
          
       ELSE CAST(    
DATEDIFF(n,  -- �ѱٹ� Hour���    
CASE ISNULL(G.EMP_NO,'')
WHEN ''
THEN
     CASE ISNULL(E.APPROVAL_RTN,'')      
     WHEN ''      
     THEN CASE H.HOLI_TYPE
          WHEN 'H'     
          THEN  convert(char(8),'00:00:00',108)
		  ELSE  CASE ISNULL(A.START_TIME ,'')      
                WHEN ''      
                THEN CASE ISNULL(A.END_TIME,'')      
                     WHEN ''      
                     THEN convert(char(8),'00:00:00',108)      
                     ELSE convert(char(8),'09:00:00',108)      
                     END         
                ELSE   CASE        -- ��ٽð��� 9�� �����϶��� ��ٽð��� 9�÷� �����ϴ� CASE��        
                       WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'18:00:00',108)   -- 18�� �̻��϶� (CS�ٹ�)�ð� �ӽ��� �ٹ��ð� 8�ð����� ������  
                       THEN convert(char(8),'09:00:00',108)    
                       WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)      
                       THEN convert(char(8),'09:00:00',108)     
                       ELSE convert(char(8),'09:00:00',108)      
                       END      
                END
		  END      
        
     WHEN '1'      
     THEN CASE ISNULL(D.DILIG_NM,'')      
          WHEN ''      
          THEN  CASE H.HOLI_TYPE         
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'09:00:00',108)      
                END      
          WHEN '����(����)'      
          THEN  convert(char(8),'00:00:00',108) 
          WHEN '����(����)'      
          THEN  convert(char(8),'00:00:00',108)     
          WHEN '����ٹ�1'    
          THEN  CASE F.REPORT_TYPE  
                WHEN '2'  
                THEN convert(char(8),'00:00:00',108)    
				ELSE convert(char(8),'00:00:00',108)    
                END 
		  WHEN '���ϱٹ�1'    
          THEN CASE F.REPORT_TYPE  
               WHEN '2'  
               THEN  
                   CASE H.HOLI_TYPE
                   WHEN 'H'    
                   THEN convert(char(8),'00:00:00',108)  
                   ELSE convert(char(8),'00:00:00',108)    
                   END  
               ELSE convert(char(8),'00:00:00',108)    
               END     
          ELSE CASE H.HOLI_TYPE      
               WHEN 'D'     
               THEN convert(char(8),'09:00:00',108)
               ELSE convert(char(8),'00:00:00',108)      
               END      
          END      
     ELSE CASE H.HOLI_TYPE
          WHEN 'D'     
          THEN  CASE ISNULL(A.START_TIME ,'')      
                WHEN ''      
                THEN CASE ISNULL(A.END_TIME,'')      
                     WHEN ''      
                     THEN convert(char(8),'00:00:00',108)      
                     ELSE convert(char(8),'09:00:00',108)      
                     END      
                ELSE      
                     CASE        -- ��ٽð��� 9�� �����϶��� ��ٽð��� 9�÷� �����ϴ� CASE��   
                     WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'18:00:00',108)   -- 18�� �̻��϶� (CS�ٹ�)�ð� �ӽ��� �ٹ��ð� 8�ð����� ������  
                     THEN convert(char(8),'09:00:00',108)       
                     WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)      
                     THEN convert(char(8), A.START_TIME,108)      
                     WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)      
                     THEN convert(char(8),'09:00:00',108)    
                     ELSE convert(char(8),'09:00:00',108)      
                     END      
               END      
       WHEN 'H'      
       THEN convert(char(8),'00:00:00',108)
       ELSE convert(char(8),'00:00:00',108)      
       END      
     END
ELSE  CASE H.HOLI_TYPE
      WHEN 'H'
	  THEN convert(char(8),'00:00:00',108)
	  ELSE
        CASE ISNULL(E.APPROVAL_RTN,'')      -- �����ٹ��� �����Ͱ� ������, �ٹ��ð� ��� �� --
        WHEN ''      
        THEN   
		     CASE ISNULL(A.START_TIME,'')
			 WHEN ''
			 THEN CASE ISNULL(A.END_TIME,'')
			      WHEN ''
				  THEN convert(char(8),'00:00:00',108)
				  ELSE    
			           CASE       
                       WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                       THEN convert(char(8),G.START_TIME,108)       
                       ELSE convert(char(8),G.START_TIME,108)      
                       END
				 END
			 ELSE
			      CASE       
                  WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                  THEN convert(char(8),A.START_TIME,108)      
                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                  THEN convert(char(8),G.START_TIME,108)       
                  ELSE convert(char(8),G.START_TIME,108)      
                  END
			 END         
        WHEN '1'      
        THEN CASE ISNULL(D.DILIG_NM,'')      
             WHEN ''      
             THEN  convert(char(8),G.START_TIME,108)      
             WHEN '����(����)'      
             THEN  convert(char(8),'00:00:00',108)
             WHEN '����(����)'      
             THEN  convert(char(8),'00:00:00',108)      
             WHEN '����ٹ�1'    
             THEN  CASE F.REPORT_TYPE
			       WHEN '1'  
                   THEN convert(char(8),G.START_TIME,108) 
                   WHEN '2'  
                   THEN convert(char(8),'00:00:00',108)  
                   ELSE convert(char(8),'00:00:00',108)   
                   END  
             ELSE 
			      CASE ISNULL(A.START_TIME,'')
			      WHEN ''
			      THEN CASE ISNULL(A.END_TIME,'')
			           WHEN ''
			      	   THEN convert(char(8),'00:00:00',108)
			      	   ELSE convert(char(8),G.START_TIME,108)     
					   END
				  ELSE convert(char(8),G.START_TIME,108)     
				  END
             END      
        ELSE CASE ISNULL(A.START_TIME,'')
			 WHEN ''
			 THEN CASE ISNULL(A.END_TIME,'')
			      WHEN ''
				  THEN convert(char(8),'00:00:00',108)
				  ELSE    
			           CASE       
                       WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                       THEN convert(char(8),A.START_TIME,108)      
                       WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                       THEN convert(char(8),G.START_TIME,108)       
                       ELSE convert(char(8),G.START_TIME,108)      
                       END
				 END
			 ELSE
			      CASE       
                  WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                  THEN convert(char(8),A.START_TIME,108)      
                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                  THEN convert(char(8),G.START_TIME,108)       
                  ELSE convert(char(8),G.START_TIME,108)      
                  END
			 END
        END
	END
END      
        ,   --// ��ٽð��� ���� //
CASE ISNULL( G.EMP_NO,'')
WHEN ''
THEN 
     CASE ISNULL(E.APPROVAL_RTN,'')      
     WHEN ''      
     THEN CASE H.HOLI_TYPE  
          WHEN 'D'     
          THEN   CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN  CASE ISNULL(A.END_TIME,'')      
                       WHEN ''      
                       THEN CASE ISNULL(A.START_TIME,'')      
                            WHEN ''      
                            THEN convert(char(8),'00:00:00',108)      
                            ELSE convert(char(8),'17:00:00',108)      
                            END      
                       ELSE convert(char(8),'17:00:00',108)      
                       END      
                 ELSE CASE ISNULL(A.END_TIME,'')      
                      WHEN ''      
                      THEN CASE ISNULL(A.START_TIME,'')      
                           WHEN ''      
                           THEN convert(char(8),'00:00:00',108)      
                           ELSE convert(char(8),'17:00:00',108)      
                           END      
                      ELSE convert(char(8),'17:00:00',108)      
                      END      
                END      
           WHEN 'H'      
           THEN convert(char(8),'00:00:00',108)     
     	  ELSE convert(char(8),'00:00:00',108)      
           END      
     WHEN '1'      
     THEN         
           CASE ISNULL(D.DILIG_NM,'')      
           WHEN ''      
           THEN CASE H.HOLI_TYPE
                WHEN 'D'     
                THEN convert(char(8),'17:00:00',108)      
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)      
                ELSE convert(char(8),'17:00:00',108)      
                END  
           WHEN '����(����)'  
           THEN CASE H.HOLI_TYPE
                WHEN 'D' 
                THEN convert(char(8),'04:00:00',108)
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'00:00:00',108)      
                END         
           WHEN '����(����)'      
           THEN CASE H.HOLI_TYPE 
                WHEN 'D' 
                THEN convert(char(8),'04:00:00',108)
                WHEN 'H'      
                THEN convert(char(8),'00:00:00',108)
                ELSE convert(char(8),'00:00:00',108)      
                END      
           WHEN '����ٹ�1'      
           THEN CASE H.HOLI_TYPE
                WHEN 'D'
     		   THEN
     	            CASE F.REPORT_TYPE
     			    WHEN '1'
     			    THEN convert(char(8),'08:00:00',108)
     	            WHEN '2'
     			    THEN    
     	                 CASE 
     		             WHEN ISNULL(A.START_TIME,'') = ''
     					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108) -- ��(minute)������� �߰� '21.01.12
     		   	    	 WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)
     					 THEN convert(char(8),convert(datetime,dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0)) -convert(datetime,A.TT,108) ,108)  
     					 WHEN ISNULL(A.END_TIME,'') =''
     					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108)
     					 WHEN convert(char(8),A.END_TIME,108) < convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO,0),108)
     					 THEN  CASE
     					       WHEN convert(char(8),A.END_TIME,108) > convert(char(8),A.START_TIME,108)
     						   THEN
     					           convert(char(8), dateadd(n, datediff(n,0, convert(char(8),A.END_TIME,108) )   - 
     					                                                                      CASE 
     														                                  WHEN ISNULL(A.START_TIME ,'') = ''
     														                                  THEN datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  WHEN convert(char(8),A.START_TIME,108) >= convert(char(8),'09:00:00',108)
     														                                  THEN datediff(n,0,A.START_TIME)
     														                                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),'09:00:00',108)
     														                                  THEN datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  ELSE datediff(n,0,convert(char(8),'09:00:00',108))
     														                                  END  -90  
     																						           ,0)
     													                                                 ,108)
                               ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108)
     						  END
     					 ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + 450 ,0),108) -- ��(minute)������� �߰� '21.01.12
     		   	    	 END
     		   	    ELSE  convert(char(8),'00:00:00',108)
     			    END 
                 WHEN 'H'    
                 THEN convert(char(8),'00:00:00',108)
                 ELSE convert(char(8),'00:00:00',108)     
                 END      
            WHEN '���ϱٹ�1'    
            THEN CASE F.REPORT_TYPE
     	        WHEN '2'
     			THEN 
     	          CASE H.HOLI_TYPE
                   WHEN 'H'  
     			  THEN CASE 
     			       WHEN convert(char(8),dateadd(hh,C.DILIG_HH , 0),108) >= '05:00:00' -- �ް��ٹ��ð��� 5�ð� �̻��϶� ���ɽð� 1�ð� ���� ��
     			       THEN convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM - 60 , 0),108) -- ��(minute)������� �߰� '21.01.12
     			       ELSE convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM , 0),108)
     			  	   END 
                   ELSE convert(char(8),'00:00:00',108)  
                   END
     			ELSE  convert(char(8),'00:00:00',108)  
     			END   
            ELSE convert(char(8),'00:00:00',108)      
            END
     ELSE CASE H.HOLI_TYPE
          WHEN 'D'     
          THEN   CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN  CASE ISNULL(A.END_TIME,'')      
                       WHEN ''      
                       THEN CASE ISNULL(A.START_TIME,'')      
                            WHEN ''      
                            THEN convert(char(8),'00:00:00',108)      
                            ELSE convert(char(8),'17:00:00',108)      
                            END      
                       ELSE convert(char(8),'17:00:00',108)      
                       END      
                 ELSE CASE ISNULL(A.END_TIME,'')      
                      WHEN ''      
                      THEN CASE ISNULL(A.START_TIME,'')      
                           WHEN ''      
                           THEN convert(char(8),'00:00:00',108)      
                           ELSE convert(char(8),'17:00:00',108)      
                           END      
                      ELSE convert(char(8),'17:00:00',108)      
                      END      
                END      
           WHEN 'H'      
           THEN convert(char(8),'00:00:00',108)      
     	  ELSE convert(char(8),'00:00:00',108)      
           END      
     END
ELSE CASE H.HOLI_TYPE
     WHEN 'H'
	 THEN CASE ISNULL(E.APPROVAL_RTN,'')
	      WHEN ''
		  THEN convert(char(8),'00:00:00',108)  
		  WHEN '1'
		  THEN CASE ISNULL(D.DILIG_NM,'')
		       WHEN ''
			   THEN convert(char(8),'00:00:00',108)  
			   WHEN '���ϱٹ�1'
			   THEN CASE F.REPORT_TYPE
     	            WHEN '2'
     			    THEN 
     	                    CASE 
     			             WHEN convert(char(8),dateadd(hh,C.DILIG_HH , 0),108) >= '05:00:00' -- �ް��ٹ��ð��� 5�ð� �̻��϶� ���ɽð� 1�ð� ���� ��
     			             THEN convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM - 60 , 0),108) -- ��(minute)������� �߰� '21.01.12
     			             ELSE convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM , 0),108)
     			      	     END 
     			    ELSE  convert(char(8),'00:00:00',108)  
     			    END
			 ELSE convert(char(8),'00:00:00',108) 
			 END
		ELSE convert(char(8),'00:00:00',108) 
		END  
	 ELSE       
           CASE ISNULL(E.APPROVAL_RTN,'')      
           WHEN ''      
           THEN CASE ISNULL(D.DILIG_NM,'')      
                WHEN ''      
                --THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)        
				THEN
				      CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END
                --ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
				ELSE CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END
                END         
           WHEN '1'      
           THEN         
                 CASE ISNULL(D.DILIG_NM,'')      
                 WHEN ''      
                 THEN convert(char(8),G.END_TIME,108)  
                 WHEN '����(����)'  
                 THEN convert(char(8),dateadd(n,(datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 60)/2 , 0),108)     -- ����(����,����)����Ƕ�, ��ٽð�-��ٽð�-�߽�(1�ð�) ���� ������2�� �� �ð����� ���   
                 WHEN '����(����)'      
                 THEN convert(char(8),dateadd(n,(datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 60)/2 , 0),108)      
                 WHEN '����ٹ�1'      
                 THEN 
           	            CASE F.REPORT_TYPE
           			    WHEN '1'
           			    THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108) 
           	            WHEN '2'
           			    THEN    
           	                 CASE 
           		             WHEN ISNULL(A.START_TIME,'') = ''
           					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108) -- ����ٹ��ð� + (��ٽð�-��ٽð�) - 90 ���� �߰�
           		   	    	 WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))
           					 THEN convert(char(8),convert(datetime,dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0)) -convert(datetime,A.TT,108) ,108)  
           					 WHEN ISNULL(A.END_TIME,'') =''
           					 THEN convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           					 WHEN convert(char(8),A.END_TIME,108) < convert(char(8), dateadd(n,(C.DILIG_HH_TO * 60) + C.DILIG_MM_TO,0),108)
           					 THEN  CASE
           					       WHEN convert(char(8),A.END_TIME,108) > convert(char(8),A.START_TIME,108)
           						   THEN
           					           convert(char(8), dateadd(n, datediff(n,0, A.END_TIME ) - 
           					                                                                      CASE 
           														                                  WHEN ISNULL(A.START_TIME ,'') = ''
           														                                  THEN datediff(n,0, G.START_TIME )
           														                                  WHEN convert(char(8),A.START_TIME,108) >= convert(char(8),G.START_TIME,108)
           														                                  THEN datediff(n,0,A.START_TIME)
           														                                  WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)
           														                                  THEN datediff(n,0, G.START_TIME )
           														                                  ELSE datediff(n,0, G.START_TIME )
           														                                  END  -90  
           																						           ,0)
           													                                                 ,108)
                                     ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           						  END
           					 ELSE convert(char(8),dateadd(n, (C.DILIG_HH * 60) + C.DILIG_MM + datediff(n,0,G.END_TIME) - datediff(n,0,G.START_TIME) - 90 ,0),108)
           		   	    	 END
           		   	    ELSE  convert(char(8),'00:00:00',108)
           			    END 
                ELSE   
				     CASE ISNULL(A.START_TIME,'')
					 WHEN ''
					 THEN CASE ISNULL(A.END_TIME,'')
					      WHEN ''
						  THEN convert(char(8),'00:00:00',108)
						  ELSE 
				               CASE ISNULL(D.DILIG_NM,'')      
                               WHEN ''      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                               END   
						  END
					ELSE 
					      CASE ISNULL(D.DILIG_NM,'')      
                          WHEN ''      
                          THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                          ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)       
                          END  
					END
                 
                END
		  --ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)
		  ELSE CASE ISNULL(A.START_TIME,'')
					  WHEN ''
					  THEN CASE ISNULL(A.END_TIME,'')
					       WHEN ''
						   THEN convert(char(8),'00:00:00',108)
						   ELSE       
				               CASE   
                               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                               WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                               THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                               ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                               END
						   END
					  ELSE
					          CASE   
                              WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - (datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME)   ) - 60 , 0),108)      
                              WHEN convert(char(8),A.START_TIME,108) < convert(char(8),G.START_TIME,108)      
                              THEN convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)    
                              ELSE convert(char(8),dateadd(n,datediff(n,0,G.END_TIME) - 60 , 0),108)      
                              END
					  END  
          END 
	 END
END
    )%60 as varchar(4) )    
    END     
        
    ,114) as TOT_TIME,
CASE ISNULL(G.EMP_NO,'')
WHEN ''
THEN  CASE E.APPROVAL_RTN  
      WHEN '1'  
      THEN CASE F.REPORT_TYPE  
           WHEN '2'  
           THEN CASE H.HOLI_TYPE
                WHEN 'D'
      		   THEN
                    CASE D.DILIG_NM  
                    WHEN '����ٹ�1'  
      		       THEN CASE
      		            WHEN ISNULL(convert(char(8),A.END_TIME,108),'00:00:00') < convert(char(8),dateadd(n, (C.DILIG_HH_TO * 60) + C.DILIG_MM_TO ,0),108)
      		            THEN CASE ISNULL(A.END_TIME,'') 
      					     WHEN ''
      						 THEN CASE ISNULL(A.END_TIME,'')
							      WHEN ISNULL(A.START_TIME,'')
								  THEN convert(char(8),'00:00:00',108)
      						      ELSE convert(char(8),dateadd( n, (C.DILIG_HH * 60) + C.DILIG_MM - 30  ,0),108)
      						      END
							  ELSE convert(char(8),dateadd( n, (C.DILIG_HH * 60) + C.DILIG_MM - 30  ,0),108)
      						  END
      			    	ELSE convert(char(8),dateadd( n, (C.DILIG_HH * 60) + C.DILIG_MM - 30  ,0),108) -- ��(minute)������� �߰� '21.01.12
      			    	END
                    WHEN '����ٹ�2'  
                    THEN  convert(char(8),dateadd( n, (C.DILIG_HH * 60) + C.DILIG_MM  - 30 ,0),108) 
                    END
              
      		  ELSE convert(char(8),'00:00:00',108)
      		  END  
           ELSE convert(char(8),'00:00:00',108) 
           END  
      ELSE convert(char(8),'00:00:00',108)  
      END
 ELSE  CASE E.APPROVAL_RTN  
       WHEN '1'  
       THEN CASE F.REPORT_TYPE  
            WHEN '2'  
            THEN     CASE D.DILIG_NM  
                     WHEN '����ٹ�1'  
       		         THEN convert(char(8),dateadd( n, (C.DILIG_HH * 60) + C.DILIG_MM - 30  ,0),108) 
                     END
            ELSE convert(char(8),'00:00:00',108) 
            END  
       ELSE convert(char(8),'00:00:00',108)  
       END
 END
  as OT,      
CASE D.DILIG_NM  
WHEN '���ϱٹ�1'  
THEN CASE F.REPORT_TYPE  
     WHEN '2'  
     THEN    
         CASE E.APPROVAL_RTN  
         WHEN '1'  
         THEN CASE H.HOLI_TYPE
              WHEN 'H'  
              THEN CASE 
			       WHEN convert(char(8),dateadd(hh,C.DILIG_HH , 0),108) >= '05:00:00' -- �ް��ٹ��ð��� 5�ð� �̻��϶� ���ɽð� 1�ð� ���� ��
			       THEN convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM - 60 , 0),108) -- ��(minute)������� �߰� '21.01.12
			       ELSE convert(char(8),dateadd(n,(C.DILIG_HH * 60) + C.DILIG_MM , 0),108)
			  	   END
              ELSE convert(char(8),'00:00:00',108)  
              END  
         ELSE convert(char(8),'00:00:00',108)
         END  
     ELSE convert(char(8),'00:00:00',108)  
     END   
ELSE convert(char(8),'00:00:00',108)
END  as HT,
CASE ISNULL(G.EMP_NO,'')
WHEN ''
THEN  	      
  CASE H.HOLI_TYPE
  WHEN 'D' 
  THEN CASE  
       WHEN D.DILIG_NM <> '����(����)'  
       THEN  
            CASE   
            WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)
            THEN convert(char(8),dateadd(n,datediff(n,0,A.START_TIME) - 540 , 0),108)   
            ELSE convert(char(8),'00:00:00',108)   
            END
		WHEN ISNULL(D.DILIG_NM,'') = ''
		THEN  
            CASE   
            WHEN convert(char(8),A.START_TIME,108) > convert(char(8),'09:00:00',108)
            THEN convert(char(8),dateadd(n,datediff(n,0,A.START_TIME) - 540 , 0),108)   
            ELSE convert(char(8),'00:00:00',108)   
            END
	   ELSE convert(char(8),'00:00:00',108) 
       END
  ELSE convert(char(8),'00:00:00',108)
  END
ELSE 
     CASE H.HOLI_TYPE 
     WHEN 'H'
	 THEN convert(char(8),'00:00:00',108)
	 ELSE CASE  
          WHEN D.DILIG_NM = '����(����)'  
		  THEN convert(char(8),'00:00:00',108)
		  WHEN D.DILIG_NM = '����(����)'  
		  THEN convert(char(8),'00:00:00',108)
	   	  WHEN ISNULL(D.DILIG_NM,'') = ''
	   	  THEN  
                CASE   
                WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))
                THEN convert(char(8),dateadd(n,datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME) , 0),108)    
                ELSE convert(char(8),'00:00:00',108)   
                END
		  ELSE  
               CASE   
               WHEN datediff(n,0,convert(char(8),A.START_TIME,108)) > datediff(n,0,convert(char(8),G.START_TIME,108))
               THEN convert(char(8),dateadd(n,datediff(n,0,A.START_TIME) - datediff(n,0,G.START_TIME) , 0),108)   
               ELSE convert(char(8),'00:00:00',108)   
               END 
         END  
     END
END
  as TT  ,      
  A.ISRT_EMP_NO     ,       
  A.UPDT_EMP_NO ,      
  A.UPDT_DT,
CASE ISNULL(E.APPROVAL_RTN,'')
WHEN ''      
THEN NULL
WHEN '1'
THEN D.DILIG_NM
ELSE NULL
END  
   as ETC1,
CASE ISNULL(E.APPROVAL_RTN,'')
WHEN ''
THEN ''
WHEN '1'
THEN ''
ELSE CASE F.REPORT_TYPE
     WHEN '2'
  THEN
       CASE D.DILIG_NM
       WHEN '����ٹ�1'
    THEN '�̽���'
    WHEN '���ϱٹ�1'
    THEN '�̽���'
    ELSE NULL
    END
  ELSE NULL
  END
END AS ETC2,  
  CASE E.APPROVAL_RTN    
  WHEN '1'    
  THEN CASE D.DILIG_NM    
       WHEN '����ٹ�1'    
     THEN    
          CASE   
             WHEN F.REPORT_TYPE = '1'    
             THEN '��û'        
             ELSE NULL   
             END    
       WHEN '���ϱٹ�1'    
       THEN CASE F.REPORT_TYPE    
            WHEN '1'    
            THEN '��û'    
            ELSE NULL    
            END    
  ELSE NULL    
  END    
  ELSE NULL    
  END as FLG_REPORT1   , 
  CASE E.APPROVAL_RTN    
  WHEN '1'    
  THEN CASE D.DILIG_NM    
       WHEN '����ٹ�1'    
     THEN    
          CASE  
             WHEN F.REPORT_TYPE = '2'    
             THEN '���'    
             ELSE NULL    
             END    
       WHEN '���ϱٹ�1'    
       THEN CASE F.REPORT_TYPE   
            WHEN '2'    
            THEN '���'    
            ELSE NULL    
            END    
  ELSE NULL    
  END    
  ELSE NULL    
  END as FLG_REPORT2
  
from WT_MA_KO883 A  WITH (nolock)            
join HAA010T B on A.EMP_NO = B.EMP_NO      
LEFT OUTER join H4006M3_D_KO883 C on A.EMP_NO = C.DILIG_EMP_NO and A.WORK_DT = C.DILIG_DT_FR  
LEFT OUTER join HCA010T D on D.DILIG_CD = C.DILIG_CD  
LEFT OUTER join ERP_IF_APPROVAL E on C.DILIG_REQ_NO = E.DOC_NO   
LEFT JOIN H4006M3_H_KO883 F (NOLOCK) ON F.DILIG_REQ_NO = E.DOC_NO   
LEFT OUTER JOIN WT_FLEX_KO883 G on A.EMP_NO = G.EMP_NO and A.WORK_DT = G.WORK_DT
LEFT OUTER JOIN hca020t H on A.WORK_DT = H.DATE


where         
( @EMP_NO ='' or A.EMP_NO = @EMP_NO )      
and (@DEPT_NO = '' or B.DEPT_CD = @DEPT_NO)            
and CONVERT (DATETIME, A.WORK_DT) BETWEEN  CONVERT (DATETIME, @Work_From) AND  CONVERT (DATETIME, @Work_To ) 
--and H.WK_TYPE = 1

        
 order by EMP_NO,WORK_DT,HT,OT,ETC1
                    
 END     
    
 --select * from WT_MA_KO883