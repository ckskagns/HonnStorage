﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.MM.M2111MA4_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance37 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance38 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance39 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance40 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance41 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblPrNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popProdReqNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblUnitSalesGrpRef = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblTGSRef = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPoRef = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDvlyReqRef = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblBomRef = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblRef5 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnApproval = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.lblInfo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.btnPreview = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnPrint = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.lblEmpNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popEmpNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.btnCancel = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_Single = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTableLayoutPanel1 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.txtApproval = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.txtApprovalNm = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblPrNo2 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtPrNo = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblPlantCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popPlantCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblReqDept = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popReqDept = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblReqDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtReqDt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.lblRqPrsn = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popReqPrsn = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblPurOrz = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popPurOrz = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblPrSts = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTableLayoutPanel2 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.txtPrSts = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.txtPrStsNm = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lbldeliveryDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtDeliveryDt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.lblApproval = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblReqRsn = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtReqRsn = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblRemark = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtRemark = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainCondition.SuspendLayout();
            this.uniTBL_MainReference.SuspendLayout();
            this.uniTBL_MainBatch.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            this.uniTBL_Single.SuspendLayout();
            this.uniTableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtApproval)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprovalNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtReqDt)).BeginInit();
            this.uniTableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrSts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrStsNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDeliveryDt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReqRsn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 30F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 31F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 12);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(1168, 599);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.lblPrNo, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popProdReqNo, 1, 0);
            this.uniTBL_MainCondition.DefaultRowSize = 25;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 1;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(1168, 38);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblPrNo
            // 
            appearance1.TextHAlignAsString = "Left";
            appearance1.TextVAlignAsString = "Middle";
            this.lblPrNo.Appearance = appearance1;
            this.lblPrNo.AutoPopupID = null;
            this.lblPrNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPrNo.Location = new System.Drawing.Point(15, 6);
            this.lblPrNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPrNo.Name = "lblPrNo";
            this.lblPrNo.Size = new System.Drawing.Size(148, 22);
            this.lblPrNo.StyleSetName = "Default";
            this.lblPrNo.TabIndex = 0;
            this.lblPrNo.Text = "P/R No";
            this.lblPrNo.UseMnemonic = false;
            // 
            // popProdReqNo
            // 
            this.popProdReqNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popProdReqNo.AutoPopupCodeParameter = null;
            this.popProdReqNo.AutoPopupID = null;
            this.popProdReqNo.AutoPopupNameParameter = null;
            this.popProdReqNo.CodeMaxLength = 50;
            this.popProdReqNo.CodeName = "";
            this.popProdReqNo.CodeSize = 150;
            this.popProdReqNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProdReqNo.CodeTextBoxName = null;
            this.popProdReqNo.CodeValue = "";
            this.popProdReqNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popProdReqNo.Location = new System.Drawing.Point(163, 7);
            this.popProdReqNo.LockedField = false;
            this.popProdReqNo.Margin = new System.Windows.Forms.Padding(0);
            this.popProdReqNo.Name = "popProdReqNo";
            this.popProdReqNo.NameDisplay = true;
            this.popProdReqNo.NameId = null;
            this.popProdReqNo.NameMaxLength = 50;
            this.popProdReqNo.NamePopup = false;
            this.popProdReqNo.NameSize = 0;
            this.popProdReqNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popProdReqNo.Parameter = null;
            this.popProdReqNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popProdReqNo.PopupId = null;
            this.popProdReqNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.UserDefinedPopup;
            this.popProdReqNo.QueryIfEnterKeyPressed = true;
            this.popProdReqNo.RequiredField = false;
            this.popProdReqNo.Size = new System.Drawing.Size(171, 21);
            this.popProdReqNo.TabIndex = 1;
            this.popProdReqNo.uniALT = "P/O No";
            this.popProdReqNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popProdReqNo.UseDynamicFormat = false;
            this.popProdReqNo.ValueTextBoxName = null;
            this.popProdReqNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popProdReqNo_BeforePopupOpen);
            this.popProdReqNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popProdReqNo_AfterPopupClosed);
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 7;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.uniTBL_MainReference.Controls.Add(this.lblUnitSalesGrpRef, 1, 0);
            this.uniTBL_MainReference.Controls.Add(this.lblTGSRef, 2, 0);
            this.uniTBL_MainReference.Controls.Add(this.lblPoRef, 3, 0);
            this.uniTBL_MainReference.Controls.Add(this.lblDvlyReqRef, 4, 0);
            this.uniTBL_MainReference.Controls.Add(this.lblBomRef, 5, 0);
            this.uniTBL_MainReference.Controls.Add(this.lblRef5, 6, 0);
            this.uniTBL_MainReference.DefaultRowSize = 25;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(1168, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblUnitSalesGrpRef
            // 
            appearance2.TextHAlignAsString = "Left";
            appearance2.TextVAlignAsString = "Middle";
            this.lblUnitSalesGrpRef.Appearance = appearance2;
            this.lblUnitSalesGrpRef.AutoPopupID = null;
            this.lblUnitSalesGrpRef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblUnitSalesGrpRef.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblUnitSalesGrpRef.Location = new System.Drawing.Point(508, 3);
            this.lblUnitSalesGrpRef.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblUnitSalesGrpRef.Name = "lblUnitSalesGrpRef";
            this.lblUnitSalesGrpRef.Size = new System.Drawing.Size(110, 15);
            this.lblUnitSalesGrpRef.StyleSetName = "uniLabel_Reference";
            this.lblUnitSalesGrpRef.TabIndex = 0;
            this.lblUnitSalesGrpRef.Text = "Unit Sales Group Ref.";
            this.lblUnitSalesGrpRef.UseMnemonic = false;
            this.lblUnitSalesGrpRef.Visible = false;
            this.lblUnitSalesGrpRef.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblUnitSalesGrpRef_BeforePopupOpen);
            this.lblUnitSalesGrpRef.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblUnitSalesGrpRef_AfterPopupClosed);
            // 
            // lblTGSRef
            // 
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.lblTGSRef.Appearance = appearance3;
            this.lblTGSRef.AutoPopupID = null;
            this.lblTGSRef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTGSRef.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblTGSRef.Location = new System.Drawing.Point(618, 3);
            this.lblTGSRef.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblTGSRef.Name = "lblTGSRef";
            this.lblTGSRef.Size = new System.Drawing.Size(110, 15);
            this.lblTGSRef.StyleSetName = "uniLabel_Reference";
            this.lblTGSRef.TabIndex = 1;
            this.lblTGSRef.Text = "TGS Ref.";
            this.lblTGSRef.UseMnemonic = false;
            this.lblTGSRef.Visible = false;
            this.lblTGSRef.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblTGSRef_BeforePopupOpen);
            this.lblTGSRef.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblTGSRef_AfterPopupClosed);
            // 
            // lblPoRef
            // 
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.lblPoRef.Appearance = appearance4;
            this.lblPoRef.AutoPopupID = null;
            this.lblPoRef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPoRef.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblPoRef.Location = new System.Drawing.Point(728, 3);
            this.lblPoRef.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblPoRef.Name = "lblPoRef";
            this.lblPoRef.Size = new System.Drawing.Size(110, 15);
            this.lblPoRef.StyleSetName = "uniLabel_Reference";
            this.lblPoRef.TabIndex = 2;
            this.lblPoRef.Text = "P/O Ref.";
            this.lblPoRef.UseMnemonic = false;
            this.lblPoRef.Visible = false;
            this.lblPoRef.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblPoRef_BeforePopupOpen);
            this.lblPoRef.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblPoRef_AfterPopupClosed);
            // 
            // lblDvlyReqRef
            // 
            appearance5.TextHAlignAsString = "Left";
            appearance5.TextVAlignAsString = "Middle";
            this.lblDvlyReqRef.Appearance = appearance5;
            this.lblDvlyReqRef.AutoPopupID = null;
            this.lblDvlyReqRef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDvlyReqRef.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblDvlyReqRef.Location = new System.Drawing.Point(838, 3);
            this.lblDvlyReqRef.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblDvlyReqRef.Name = "lblDvlyReqRef";
            this.lblDvlyReqRef.Size = new System.Drawing.Size(110, 15);
            this.lblDvlyReqRef.StyleSetName = "uniLabel_Reference";
            this.lblDvlyReqRef.TabIndex = 3;
            this.lblDvlyReqRef.Text = "Delivery Request Ref.";
            this.lblDvlyReqRef.UseMnemonic = false;
            this.lblDvlyReqRef.Visible = false;
            this.lblDvlyReqRef.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblDvlyReqRef_BeforePopupOpen);
            this.lblDvlyReqRef.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblDvlyReqRef_AfterPopupClosed);
            // 
            // lblBomRef
            // 
            appearance6.TextHAlignAsString = "Left";
            appearance6.TextVAlignAsString = "Middle";
            this.lblBomRef.Appearance = appearance6;
            this.lblBomRef.AutoPopupID = null;
            this.lblBomRef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBomRef.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBomRef.Location = new System.Drawing.Point(948, 3);
            this.lblBomRef.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblBomRef.Name = "lblBomRef";
            this.lblBomRef.Size = new System.Drawing.Size(110, 15);
            this.lblBomRef.StyleSetName = "Default";
            this.lblBomRef.TabIndex = 4;
            this.lblBomRef.Text = "Bom Ref.";
            this.lblBomRef.UseMnemonic = false;
            this.lblBomRef.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblBomRef_BeforePopupOpen);
            this.lblBomRef.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblBomRef_AfterPopupClosed);
            // 
            // lblRef5
            // 
            appearance7.TextHAlignAsString = "Left";
            appearance7.TextVAlignAsString = "Middle";
            this.lblRef5.Appearance = appearance7;
            this.lblRef5.AutoPopupID = null;
            this.lblRef5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRef5.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRef5.Location = new System.Drawing.Point(1058, 3);
            this.lblRef5.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblRef5.Name = "lblRef5";
            this.lblRef5.Size = new System.Drawing.Size(110, 15);
            this.lblRef5.StyleSetName = "Default";
            this.lblRef5.TabIndex = 5;
            this.lblRef5.Text = "Project List Reference";
            this.lblRef5.UseMnemonic = false;
            this.lblRef5.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblRef5_BeforePopupOpen);
            this.lblRef5.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblRef5_AfterPopupClosed);
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 8;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 390F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.Controls.Add(this.btnApproval, 2, 0);
            this.uniTBL_MainBatch.Controls.Add(this.lblInfo, 4, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnPreview, 6, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnPrint, 7, 0);
            this.uniTBL_MainBatch.Controls.Add(this.lblEmpNo, 0, 0);
            this.uniTBL_MainBatch.Controls.Add(this.popEmpNo, 1, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnCancel, 3, 0);
            this.uniTBL_MainBatch.DefaultRowSize = 23;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 570);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(1168, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnApproval
            // 
            this.btnApproval.AutoPopupID = null;
            this.btnApproval.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnApproval.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnApproval.Location = new System.Drawing.Point(350, 1);
            this.btnApproval.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnApproval.Name = "btnApproval";
            this.btnApproval.PopupID = null;
            this.btnApproval.Size = new System.Drawing.Size(97, 24);
            this.btnApproval.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnApproval.TabIndex = 0;
            this.btnApproval.Text = "결재상신";
            this.btnApproval.UserDefinedText = null;
            this.btnApproval.Click += new System.EventHandler(this.uniButton1_Click);
            // 
            // lblInfo
            // 
            appearance8.TextHAlignAsString = "Left";
            appearance8.TextVAlignAsString = "Middle";
            this.lblInfo.Appearance = appearance8;
            this.lblInfo.AutoPopupID = null;
            this.lblInfo.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            appearance9.ForeColor = System.Drawing.Color.White;
            this.lblInfo.HotTrackAppearance = appearance9;
            this.lblInfo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Default_NoStyle;
            this.lblInfo.Location = new System.Drawing.Point(565, 1);
            this.lblInfo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(375, 27);
            this.lblInfo.StyleSetName = "uniLabel_NoStyle";
            this.lblInfo.TabIndex = 1;
            this.lblInfo.Text = "예산/체크로 로딩시간이 다소 걸립니다.(클릭 후 조금 기다리세요)";
            this.lblInfo.UseMnemonic = false;
            this.lblInfo.Visible = false;
            // 
            // btnPreview
            // 
            this.btnPreview.AutoPopupID = null;
            this.btnPreview.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPreview.Location = new System.Drawing.Point(968, 1);
            this.btnPreview.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.PopupID = null;
            this.btnPreview.Size = new System.Drawing.Size(97, 24);
            this.btnPreview.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnPreview.TabIndex = 2;
            this.btnPreview.Text = "미리보기";
            this.btnPreview.UserDefinedText = null;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.AutoPopupID = null;
            this.btnPrint.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnPrint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPrint.Location = new System.Drawing.Point(1068, 1);
            this.btnPrint.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.PopupID = null;
            this.btnPrint.Size = new System.Drawing.Size(97, 24);
            this.btnPrint.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnPrint.TabIndex = 3;
            this.btnPrint.Text = "출력";
            this.btnPrint.UserDefinedText = null;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblEmpNo
            // 
            appearance10.TextHAlignAsString = "Left";
            appearance10.TextVAlignAsString = "Middle";
            this.lblEmpNo.Appearance = appearance10;
            this.lblEmpNo.AutoPopupID = null;
            this.lblEmpNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmpNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblEmpNo.Location = new System.Drawing.Point(15, 1);
            this.lblEmpNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblEmpNo.Name = "lblEmpNo";
            this.lblEmpNo.Size = new System.Drawing.Size(85, 27);
            this.lblEmpNo.StyleSetName = "Default";
            this.lblEmpNo.TabIndex = 5;
            this.lblEmpNo.Text = "기안자사번";
            this.lblEmpNo.UseMnemonic = false;
            // 
            // popEmpNo
            // 
            this.popEmpNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popEmpNo.AutoPopupCodeParameter = null;
            this.popEmpNo.AutoPopupID = null;
            this.popEmpNo.AutoPopupNameParameter = null;
            this.popEmpNo.CodeMaxLength = 13;
            this.popEmpNo.CodeName = "";
            this.popEmpNo.CodeSize = 100;
            this.popEmpNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popEmpNo.CodeTextBoxName = null;
            this.popEmpNo.CodeValue = "";
            this.popEmpNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popEmpNo.Location = new System.Drawing.Point(100, 7);
            this.popEmpNo.LockedField = false;
            this.popEmpNo.Margin = new System.Windows.Forms.Padding(0);
            this.popEmpNo.Name = "popEmpNo";
            this.popEmpNo.NameDisplay = true;
            this.popEmpNo.NameId = null;
            this.popEmpNo.NameMaxLength = 50;
            this.popEmpNo.NamePopup = false;
            this.popEmpNo.NameSize = 150;
            this.popEmpNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popEmpNo.Parameter = null;
            this.popEmpNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popEmpNo.PopupId = null;
            this.popEmpNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popEmpNo.QueryIfEnterKeyPressed = true;
            this.popEmpNo.RequiredField = false;
            this.popEmpNo.Size = new System.Drawing.Size(250, 21);
            this.popEmpNo.TabIndex = 6;
            this.popEmpNo.uniALT = "사번";
            this.popEmpNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popEmpNo.UseDynamicFormat = false;
            this.popEmpNo.ValueTextBoxName = null;
            this.popEmpNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popEmpNo_BeforePopupOpen);
            this.popEmpNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popEmpNo_AfterPopupClosed);
            this.popEmpNo.OnChange += new System.EventHandler(this.popEmpNo_OnChange);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.AutoPopupID = null;
            this.btnCancel.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnCancel.Location = new System.Drawing.Point(450, 1);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.PopupID = null;
            this.btnCancel.Size = new System.Drawing.Size(97, 24);
            this.btnCancel.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "상신취소";
            this.btnCancel.UserDefinedText = null;
            this.btnCancel.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.btnCancel_BeforePopupOpen);
            this.btnCancel.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.btnCancel_AfterPopupClosed);
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniTBL_Single, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 1);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 40F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 74);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 2;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 153F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(1168, 493);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 4;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_Single
            // 
            this.uniTBL_Single.AutoFit = false;
            this.uniTBL_Single.AutoFitColumnCount = 4;
            this.uniTBL_Single.AutoFitRowCount = 4;
            this.uniTBL_Single.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_Single.ColumnCount = 4;
            this.uniTBL_Single.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_Single.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_Single.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_Single.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_Single.Controls.Add(this.uniTableLayoutPanel1, 3, 4);
            this.uniTBL_Single.Controls.Add(this.lblPrNo2, 0, 0);
            this.uniTBL_Single.Controls.Add(this.txtPrNo, 1, 0);
            this.uniTBL_Single.Controls.Add(this.lblPlantCd, 2, 0);
            this.uniTBL_Single.Controls.Add(this.popPlantCd, 3, 0);
            this.uniTBL_Single.Controls.Add(this.lblReqDept, 0, 1);
            this.uniTBL_Single.Controls.Add(this.popReqDept, 1, 1);
            this.uniTBL_Single.Controls.Add(this.lblReqDt, 2, 1);
            this.uniTBL_Single.Controls.Add(this.dtReqDt, 3, 1);
            this.uniTBL_Single.Controls.Add(this.lblRqPrsn, 0, 2);
            this.uniTBL_Single.Controls.Add(this.popReqPrsn, 1, 2);
            this.uniTBL_Single.Controls.Add(this.lblPurOrz, 0, 3);
            this.uniTBL_Single.Controls.Add(this.popPurOrz, 1, 3);
            this.uniTBL_Single.Controls.Add(this.lblPrSts, 2, 3);
            this.uniTBL_Single.Controls.Add(this.uniTableLayoutPanel2, 3, 3);
            this.uniTBL_Single.Controls.Add(this.lbldeliveryDt, 2, 2);
            this.uniTBL_Single.Controls.Add(this.dtDeliveryDt, 3, 2);
            this.uniTBL_Single.Controls.Add(this.lblApproval, 2, 4);
            this.uniTBL_Single.Controls.Add(this.lblReqRsn, 0, 4);
            this.uniTBL_Single.Controls.Add(this.txtReqRsn, 1, 4);
            this.uniTBL_Single.Controls.Add(this.lblRemark, 0, 5);
            this.uniTBL_Single.Controls.Add(this.txtRemark, 1, 5);
            this.uniTBL_Single.DefaultRowSize = 23;
            this.uniTBL_Single.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_Single.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_Single.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_Single.HEIGHT_TYPE_01 = 9F;
            this.uniTBL_Single.HEIGHT_TYPE_01_CONDITION = 40F;
            this.uniTBL_Single.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_Single.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_Single.HEIGHT_TYPE_03 = 9F;
            this.uniTBL_Single.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.uniTBL_Single.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_Single.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_Single.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_Single.Name = "uniTBL_Single";
            this.uniTBL_Single.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_Single.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_Single.RowCount = 6;
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_Single.Size = new System.Drawing.Size(1168, 153);
            this.uniTBL_Single.SizeTD5 = 14F;
            this.uniTBL_Single.SizeTD6 = 36F;
            this.uniTBL_Single.TabIndex = 0;
            this.uniTBL_Single.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_Single.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTableLayoutPanel1
            // 
            this.uniTableLayoutPanel1.AutoFit = false;
            this.uniTableLayoutPanel1.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel1.AutoFitRowCount = 4;
            this.uniTableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel1.ColumnCount = 3;
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.44444F));
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTableLayoutPanel1.Controls.Add(this.txtApproval, 0, 0);
            this.uniTableLayoutPanel1.Controls.Add(this.txtApprovalNm, 2, 0);
            this.uniTableLayoutPanel1.DefaultRowSize = 23;
            this.uniTableLayoutPanel1.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel1.Location = new System.Drawing.Point(746, 97);
            this.uniTableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel1.Name = "uniTableLayoutPanel1";
            this.uniTableLayoutPanel1.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTableLayoutPanel1.RowCount = 1;
            this.uniTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTableLayoutPanel1.Size = new System.Drawing.Size(200, 23);
            this.uniTableLayoutPanel1.SizeTD5 = 14F;
            this.uniTableLayoutPanel1.SizeTD6 = 36F;
            this.uniTableLayoutPanel1.TabIndex = 21;
            this.uniTableLayoutPanel1.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel1.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // txtApproval
            // 
            this.txtApproval.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance11.TextVAlignAsString = "Bottom";
            this.txtApproval.Appearance = appearance11;
            this.txtApproval.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApproval.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtApproval.Location = new System.Drawing.Point(0, 0);
            this.txtApproval.LockedField = false;
            this.txtApproval.Margin = new System.Windows.Forms.Padding(0);
            this.txtApproval.Name = "txtApproval";
            this.txtApproval.QueryIfEnterKeyPressed = true;
            this.txtApproval.RequiredField = false;
            this.txtApproval.Size = new System.Drawing.Size(88, 24);
            this.txtApproval.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtApproval.StyleSetName = "Default";
            this.txtApproval.TabIndex = 0;
            this.txtApproval.uniALT = "결재상태";
            this.txtApproval.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApproval.UseDynamicFormat = false;
            // 
            // txtApprovalNm
            // 
            this.txtApprovalNm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance12.TextVAlignAsString = "Bottom";
            this.txtApprovalNm.Appearance = appearance12;
            this.txtApprovalNm.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtApprovalNm.Location = new System.Drawing.Point(99, 0);
            this.txtApprovalNm.LockedField = false;
            this.txtApprovalNm.Margin = new System.Windows.Forms.Padding(0);
            this.txtApprovalNm.Name = "txtApprovalNm";
            this.txtApprovalNm.QueryIfEnterKeyPressed = true;
            this.txtApprovalNm.RequiredField = false;
            this.txtApprovalNm.Size = new System.Drawing.Size(100, 24);
            this.txtApprovalNm.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtApprovalNm.StyleSetName = "Default";
            this.txtApprovalNm.TabIndex = 1;
            this.txtApprovalNm.uniALT = "결재상태명";
            this.txtApprovalNm.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtApprovalNm.UseDynamicFormat = false;
            // 
            // lblPrNo2
            // 
            appearance13.TextHAlignAsString = "Left";
            appearance13.TextVAlignAsString = "Middle";
            this.lblPrNo2.Appearance = appearance13;
            this.lblPrNo2.AutoPopupID = null;
            this.lblPrNo2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrNo2.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPrNo2.Location = new System.Drawing.Point(15, 6);
            this.lblPrNo2.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPrNo2.Name = "lblPrNo2";
            this.lblPrNo2.Size = new System.Drawing.Size(148, 22);
            this.lblPrNo2.StyleSetName = "Default";
            this.lblPrNo2.TabIndex = 0;
            this.lblPrNo2.Text = "P/R No";
            this.lblPrNo2.UseMnemonic = false;
            // 
            // txtPrNo
            // 
            this.txtPrNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance14.TextVAlignAsString = "Bottom";
            this.txtPrNo.Appearance = appearance14;
            this.txtPrNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPrNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtPrNo.Location = new System.Drawing.Point(163, 5);
            this.txtPrNo.LockedField = false;
            this.txtPrNo.Margin = new System.Windows.Forms.Padding(0);
            this.txtPrNo.Name = "txtPrNo";
            this.txtPrNo.QueryIfEnterKeyPressed = true;
            this.txtPrNo.RequiredField = false;
            this.txtPrNo.Size = new System.Drawing.Size(150, 24);
            this.txtPrNo.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtPrNo.StyleSetName = "Default";
            this.txtPrNo.TabIndex = 1;
            this.txtPrNo.uniALT = null;
            this.txtPrNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPrNo.UseDynamicFormat = false;
            // 
            // lblPlantCd
            // 
            appearance15.TextHAlignAsString = "Left";
            appearance15.TextVAlignAsString = "Middle";
            this.lblPlantCd.Appearance = appearance15;
            this.lblPlantCd.AutoPopupID = null;
            this.lblPlantCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPlantCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPlantCd.Location = new System.Drawing.Point(598, 6);
            this.lblPlantCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPlantCd.Name = "lblPlantCd";
            this.lblPlantCd.Size = new System.Drawing.Size(148, 22);
            this.lblPlantCd.StyleSetName = "Default";
            this.lblPlantCd.TabIndex = 2;
            this.lblPlantCd.Text = "Plant";
            this.lblPlantCd.UseMnemonic = false;
            // 
            // popPlantCd
            // 
            this.popPlantCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPlantCd.AutoPopupCodeParameter = null;
            this.popPlantCd.AutoPopupID = null;
            this.popPlantCd.AutoPopupNameParameter = null;
            this.popPlantCd.CodeMaxLength = 10;
            this.popPlantCd.CodeName = "";
            this.popPlantCd.CodeSize = 100;
            this.popPlantCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPlantCd.CodeTextBoxName = null;
            this.popPlantCd.CodeValue = "";
            this.popPlantCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.popPlantCd.Location = new System.Drawing.Point(746, 7);
            this.popPlantCd.LockedField = false;
            this.popPlantCd.Margin = new System.Windows.Forms.Padding(0);
            this.popPlantCd.Name = "popPlantCd";
            this.popPlantCd.NameDisplay = true;
            this.popPlantCd.NameId = null;
            this.popPlantCd.NameMaxLength = 50;
            this.popPlantCd.NamePopup = false;
            this.popPlantCd.NameSize = 150;
            this.popPlantCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPlantCd.Parameter = null;
            this.popPlantCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPlantCd.PopupId = null;
            this.popPlantCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPlantCd.QueryIfEnterKeyPressed = true;
            this.popPlantCd.RequiredField = false;
            this.popPlantCd.Size = new System.Drawing.Size(271, 21);
            this.popPlantCd.TabIndex = 3;
            this.popPlantCd.uniALT = "Plant";
            this.popPlantCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPlantCd.UseDynamicFormat = false;
            this.popPlantCd.ValueTextBoxName = null;
            this.popPlantCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPlantCd_BeforePopupOpen);
            this.popPlantCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPlantCd_AfterPopupClosed);
            // 
            // lblReqDept
            // 
            appearance16.TextHAlignAsString = "Left";
            appearance16.TextVAlignAsString = "Middle";
            this.lblReqDept.Appearance = appearance16;
            this.lblReqDept.AutoPopupID = null;
            this.lblReqDept.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReqDept.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReqDept.Location = new System.Drawing.Point(15, 29);
            this.lblReqDept.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReqDept.Name = "lblReqDept";
            this.lblReqDept.Size = new System.Drawing.Size(148, 22);
            this.lblReqDept.StyleSetName = "Default";
            this.lblReqDept.TabIndex = 4;
            this.lblReqDept.Text = "P/R Department";
            this.lblReqDept.UseMnemonic = false;
            // 
            // popReqDept
            // 
            this.popReqDept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popReqDept.AutoPopupCodeParameter = null;
            this.popReqDept.AutoPopupID = null;
            this.popReqDept.AutoPopupNameParameter = null;
            this.popReqDept.CodeMaxLength = 10;
            this.popReqDept.CodeName = "";
            this.popReqDept.CodeSize = 100;
            this.popReqDept.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReqDept.CodeTextBoxName = null;
            this.popReqDept.CodeValue = "";
            this.popReqDept.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.popReqDept.Location = new System.Drawing.Point(163, 30);
            this.popReqDept.LockedField = false;
            this.popReqDept.Margin = new System.Windows.Forms.Padding(0);
            this.popReqDept.Name = "popReqDept";
            this.popReqDept.NameDisplay = true;
            this.popReqDept.NameId = null;
            this.popReqDept.NameMaxLength = 50;
            this.popReqDept.NamePopup = false;
            this.popReqDept.NameSize = 150;
            this.popReqDept.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReqDept.Parameter = null;
            this.popReqDept.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popReqDept.PopupId = "Request Dept";
            this.popReqDept.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popReqDept.QueryIfEnterKeyPressed = true;
            this.popReqDept.RequiredField = false;
            this.popReqDept.Size = new System.Drawing.Size(271, 21);
            this.popReqDept.TabIndex = 5;
            this.popReqDept.uniALT = "Request Dept";
            this.popReqDept.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popReqDept.UseDynamicFormat = false;
            this.popReqDept.ValueTextBoxName = null;
            this.popReqDept.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popReqDept_BeforePopupOpen);
            this.popReqDept.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popReqDept_AfterPopupClosed);
            // 
            // lblReqDt
            // 
            appearance17.TextHAlignAsString = "Left";
            appearance17.TextVAlignAsString = "Middle";
            this.lblReqDt.Appearance = appearance17;
            this.lblReqDt.AutoPopupID = null;
            this.lblReqDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReqDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReqDt.Location = new System.Drawing.Point(598, 29);
            this.lblReqDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReqDt.Name = "lblReqDt";
            this.lblReqDt.Size = new System.Drawing.Size(148, 22);
            this.lblReqDt.StyleSetName = "Default";
            this.lblReqDt.TabIndex = 6;
            this.lblReqDt.Text = "Request Date";
            this.lblReqDt.UseMnemonic = false;
            // 
            // dtReqDt
            // 
            this.dtReqDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance18.TextHAlignAsString = "Center";
            this.dtReqDt.Appearance = appearance18;
            this.dtReqDt.DateTime = new System.DateTime(2015, 9, 10, 0, 0, 0, 0);
            this.dtReqDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtReqDt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtReqDt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.dtReqDt.Location = new System.Drawing.Point(746, 28);
            this.dtReqDt.LockedField = false;
            this.dtReqDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtReqDt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtReqDt.Name = "dtReqDt";
            this.dtReqDt.QueryIfEnterKeyPressed = true;
            this.dtReqDt.RequiredField = false;
            this.dtReqDt.Size = new System.Drawing.Size(100, 24);
            this.dtReqDt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtReqDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtReqDt.StyleSetName = "Default";
            this.dtReqDt.TabIndex = 7;
            this.dtReqDt.uniALT = "Request Date";
            this.dtReqDt.uniValue = new System.DateTime(2015, 9, 10, 0, 0, 0, 0);
            this.dtReqDt.Value = new System.DateTime(2015, 9, 10, 0, 0, 0, 0);
            // 
            // lblRqPrsn
            // 
            appearance19.TextHAlignAsString = "Left";
            appearance19.TextVAlignAsString = "Middle";
            this.lblRqPrsn.Appearance = appearance19;
            this.lblRqPrsn.AutoPopupID = null;
            this.lblRqPrsn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRqPrsn.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRqPrsn.Location = new System.Drawing.Point(15, 52);
            this.lblRqPrsn.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRqPrsn.Name = "lblRqPrsn";
            this.lblRqPrsn.Size = new System.Drawing.Size(148, 22);
            this.lblRqPrsn.StyleSetName = "Default";
            this.lblRqPrsn.TabIndex = 8;
            this.lblRqPrsn.Text = "Requester";
            this.lblRqPrsn.UseMnemonic = false;
            // 
            // popReqPrsn
            // 
            this.popReqPrsn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popReqPrsn.AutoPopupCodeParameter = null;
            this.popReqPrsn.AutoPopupID = null;
            this.popReqPrsn.AutoPopupNameParameter = null;
            this.popReqPrsn.CodeMaxLength = 10;
            this.popReqPrsn.CodeName = "";
            this.popReqPrsn.CodeSize = 100;
            this.popReqPrsn.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReqPrsn.CodeTextBoxName = null;
            this.popReqPrsn.CodeValue = "";
            this.popReqPrsn.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.popReqPrsn.Location = new System.Drawing.Point(163, 53);
            this.popReqPrsn.LockedField = false;
            this.popReqPrsn.Margin = new System.Windows.Forms.Padding(0);
            this.popReqPrsn.Name = "popReqPrsn";
            this.popReqPrsn.NameDisplay = true;
            this.popReqPrsn.NameId = null;
            this.popReqPrsn.NameMaxLength = 50;
            this.popReqPrsn.NamePopup = false;
            this.popReqPrsn.NameSize = 150;
            this.popReqPrsn.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReqPrsn.Parameter = null;
            this.popReqPrsn.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popReqPrsn.PopupId = "";
            this.popReqPrsn.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.UserDefinedPopup;
            this.popReqPrsn.QueryIfEnterKeyPressed = true;
            this.popReqPrsn.RequiredField = false;
            this.popReqPrsn.Size = new System.Drawing.Size(271, 21);
            this.popReqPrsn.TabIndex = 9;
            this.popReqPrsn.uniALT = "Requester";
            this.popReqPrsn.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popReqPrsn.UseDynamicFormat = false;
            this.popReqPrsn.ValueTextBoxName = null;
            this.popReqPrsn.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popReqPrsn_BeforePopupOpen);
            this.popReqPrsn.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popReqPrsn_AfterPopupClosed);
            this.popReqPrsn.OnChange += new System.EventHandler(this.popReqPrsn_OnChange);
            // 
            // lblPurOrz
            // 
            appearance20.TextHAlignAsString = "Left";
            appearance20.TextVAlignAsString = "Middle";
            this.lblPurOrz.Appearance = appearance20;
            this.lblPurOrz.AutoPopupID = null;
            this.lblPurOrz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPurOrz.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPurOrz.Location = new System.Drawing.Point(15, 75);
            this.lblPurOrz.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPurOrz.Name = "lblPurOrz";
            this.lblPurOrz.Size = new System.Drawing.Size(148, 22);
            this.lblPurOrz.StyleSetName = "Default";
            this.lblPurOrz.TabIndex = 12;
            this.lblPurOrz.Text = "Purchase Organization";
            this.lblPurOrz.UseMnemonic = false;
            // 
            // popPurOrz
            // 
            this.popPurOrz.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPurOrz.AutoPopupCodeParameter = null;
            this.popPurOrz.AutoPopupID = null;
            this.popPurOrz.AutoPopupNameParameter = null;
            this.popPurOrz.CodeMaxLength = 10;
            this.popPurOrz.CodeName = "";
            this.popPurOrz.CodeSize = 100;
            this.popPurOrz.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPurOrz.CodeTextBoxName = null;
            this.popPurOrz.CodeValue = "";
            this.popPurOrz.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.popPurOrz.Location = new System.Drawing.Point(163, 76);
            this.popPurOrz.LockedField = false;
            this.popPurOrz.Margin = new System.Windows.Forms.Padding(0);
            this.popPurOrz.Name = "popPurOrz";
            this.popPurOrz.NameDisplay = true;
            this.popPurOrz.NameId = null;
            this.popPurOrz.NameMaxLength = 50;
            this.popPurOrz.NamePopup = false;
            this.popPurOrz.NameSize = 150;
            this.popPurOrz.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPurOrz.Parameter = null;
            this.popPurOrz.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPurOrz.PopupId = null;
            this.popPurOrz.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPurOrz.QueryIfEnterKeyPressed = true;
            this.popPurOrz.RequiredField = false;
            this.popPurOrz.Size = new System.Drawing.Size(271, 21);
            this.popPurOrz.TabIndex = 13;
            this.popPurOrz.uniALT = "Purchase Organization";
            this.popPurOrz.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPurOrz.UseDynamicFormat = false;
            this.popPurOrz.ValueTextBoxName = null;
            this.popPurOrz.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPurOrz_BeforePopupOpen);
            this.popPurOrz.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPurOrz_AfterPopupClosed);
            // 
            // lblPrSts
            // 
            appearance21.TextHAlignAsString = "Left";
            appearance21.TextVAlignAsString = "Middle";
            this.lblPrSts.Appearance = appearance21;
            this.lblPrSts.AutoPopupID = null;
            this.lblPrSts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrSts.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPrSts.Location = new System.Drawing.Point(598, 75);
            this.lblPrSts.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPrSts.Name = "lblPrSts";
            this.lblPrSts.Size = new System.Drawing.Size(148, 22);
            this.lblPrSts.StyleSetName = "Default";
            this.lblPrSts.TabIndex = 16;
            this.lblPrSts.Text = "P/R Status";
            this.lblPrSts.UseMnemonic = false;
            // 
            // uniTableLayoutPanel2
            // 
            this.uniTableLayoutPanel2.AutoFit = false;
            this.uniTableLayoutPanel2.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel2.AutoFitRowCount = 4;
            this.uniTableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel2.ColumnCount = 3;
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.44444F));
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTableLayoutPanel2.Controls.Add(this.txtPrSts, 0, 0);
            this.uniTableLayoutPanel2.Controls.Add(this.txtPrStsNm, 2, 0);
            this.uniTableLayoutPanel2.DefaultRowSize = 23;
            this.uniTableLayoutPanel2.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel2.Location = new System.Drawing.Point(746, 74);
            this.uniTableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel2.Name = "uniTableLayoutPanel2";
            this.uniTableLayoutPanel2.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTableLayoutPanel2.RowCount = 1;
            this.uniTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTableLayoutPanel2.Size = new System.Drawing.Size(200, 23);
            this.uniTableLayoutPanel2.SizeTD5 = 14F;
            this.uniTableLayoutPanel2.SizeTD6 = 36F;
            this.uniTableLayoutPanel2.TabIndex = 17;
            this.uniTableLayoutPanel2.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel2.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // txtPrSts
            // 
            this.txtPrSts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance22.TextVAlignAsString = "Bottom";
            this.txtPrSts.Appearance = appearance22;
            this.txtPrSts.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPrSts.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtPrSts.Location = new System.Drawing.Point(0, 0);
            this.txtPrSts.LockedField = false;
            this.txtPrSts.Margin = new System.Windows.Forms.Padding(0);
            this.txtPrSts.Name = "txtPrSts";
            this.txtPrSts.QueryIfEnterKeyPressed = true;
            this.txtPrSts.RequiredField = false;
            this.txtPrSts.Size = new System.Drawing.Size(88, 24);
            this.txtPrSts.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtPrSts.StyleSetName = "Default";
            this.txtPrSts.TabIndex = 0;
            this.txtPrSts.uniALT = null;
            this.txtPrSts.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPrSts.UseDynamicFormat = false;
            // 
            // txtPrStsNm
            // 
            this.txtPrStsNm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance23.TextVAlignAsString = "Bottom";
            this.txtPrStsNm.Appearance = appearance23;
            this.txtPrStsNm.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPrStsNm.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtPrStsNm.Location = new System.Drawing.Point(99, 0);
            this.txtPrStsNm.LockedField = false;
            this.txtPrStsNm.Margin = new System.Windows.Forms.Padding(0);
            this.txtPrStsNm.Name = "txtPrStsNm";
            this.txtPrStsNm.QueryIfEnterKeyPressed = true;
            this.txtPrStsNm.RequiredField = false;
            this.txtPrStsNm.Size = new System.Drawing.Size(100, 24);
            this.txtPrStsNm.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtPrStsNm.StyleSetName = "Default";
            this.txtPrStsNm.TabIndex = 1;
            this.txtPrStsNm.uniALT = null;
            this.txtPrStsNm.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPrStsNm.UseDynamicFormat = false;
            // 
            // lbldeliveryDt
            // 
            appearance24.TextHAlignAsString = "Left";
            appearance24.TextVAlignAsString = "Middle";
            this.lbldeliveryDt.Appearance = appearance24;
            this.lbldeliveryDt.AutoPopupID = null;
            this.lbldeliveryDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbldeliveryDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lbldeliveryDt.Location = new System.Drawing.Point(598, 52);
            this.lbldeliveryDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lbldeliveryDt.Name = "lbldeliveryDt";
            this.lbldeliveryDt.Size = new System.Drawing.Size(148, 22);
            this.lbldeliveryDt.StyleSetName = "Default";
            this.lbldeliveryDt.TabIndex = 18;
            this.lbldeliveryDt.Text = "Delivery Date";
            this.lbldeliveryDt.UseMnemonic = false;
            // 
            // dtDeliveryDt
            // 
            this.dtDeliveryDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance25.TextHAlignAsString = "Center";
            this.dtDeliveryDt.Appearance = appearance25;
            this.dtDeliveryDt.DateTime = new System.DateTime(2018, 6, 7, 0, 0, 0, 0);
            this.dtDeliveryDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtDeliveryDt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtDeliveryDt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtDeliveryDt.Location = new System.Drawing.Point(746, 51);
            this.dtDeliveryDt.LockedField = false;
            this.dtDeliveryDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtDeliveryDt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtDeliveryDt.Name = "dtDeliveryDt";
            this.dtDeliveryDt.QueryIfEnterKeyPressed = true;
            this.dtDeliveryDt.RequiredField = false;
            this.dtDeliveryDt.Size = new System.Drawing.Size(100, 24);
            this.dtDeliveryDt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtDeliveryDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtDeliveryDt.StyleSetName = "Default";
            this.dtDeliveryDt.TabIndex = 19;
            this.dtDeliveryDt.uniALT = null;
            this.dtDeliveryDt.uniValue = new System.DateTime(2018, 6, 7, 0, 0, 0, 0);
            this.dtDeliveryDt.Value = new System.DateTime(2018, 6, 7, 0, 0, 0, 0);
            // 
            // lblApproval
            // 
            appearance26.TextHAlignAsString = "Left";
            appearance26.TextVAlignAsString = "Middle";
            this.lblApproval.Appearance = appearance26;
            this.lblApproval.AutoPopupID = null;
            this.lblApproval.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblApproval.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblApproval.Location = new System.Drawing.Point(598, 98);
            this.lblApproval.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblApproval.Name = "lblApproval";
            this.lblApproval.Size = new System.Drawing.Size(148, 22);
            this.lblApproval.StyleSetName = "Default";
            this.lblApproval.TabIndex = 20;
            this.lblApproval.Text = "결재상태";
            this.lblApproval.UseMnemonic = false;
            // 
            // lblReqRsn
            // 
            appearance27.TextHAlignAsString = "Left";
            appearance27.TextVAlignAsString = "Middle";
            this.lblReqRsn.Appearance = appearance27;
            this.lblReqRsn.AutoPopupID = null;
            this.lblReqRsn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReqRsn.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReqRsn.Location = new System.Drawing.Point(15, 98);
            this.lblReqRsn.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReqRsn.Name = "lblReqRsn";
            this.lblReqRsn.Size = new System.Drawing.Size(148, 22);
            this.lblReqRsn.StyleSetName = "Default";
            this.lblReqRsn.TabIndex = 22;
            this.lblReqRsn.Text = "구매요청사유";
            this.lblReqRsn.UseMnemonic = false;
            // 
            // txtReqRsn
            // 
            this.txtReqRsn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance28.TextVAlignAsString = "Bottom";
            this.txtReqRsn.Appearance = appearance28;
            this.txtReqRsn.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtReqRsn.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.txtReqRsn.Location = new System.Drawing.Point(163, 97);
            this.txtReqRsn.LockedField = false;
            this.txtReqRsn.Margin = new System.Windows.Forms.Padding(0);
            this.txtReqRsn.Name = "txtReqRsn";
            this.txtReqRsn.QueryIfEnterKeyPressed = true;
            this.txtReqRsn.RequiredField = false;
            this.txtReqRsn.Size = new System.Drawing.Size(271, 24);
            this.txtReqRsn.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtReqRsn.StyleSetName = "Default";
            this.txtReqRsn.TabIndex = 23;
            this.txtReqRsn.uniALT = "구매요청사유";
            this.txtReqRsn.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtReqRsn.UseDynamicFormat = false;
            // 
            // lblRemark
            // 
            appearance29.TextHAlignAsString = "Left";
            appearance29.TextVAlignAsString = "Middle";
            this.lblRemark.Appearance = appearance29;
            this.lblRemark.AutoPopupID = null;
            this.lblRemark.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRemark.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRemark.Location = new System.Drawing.Point(15, 121);
            this.lblRemark.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(148, 22);
            this.lblRemark.StyleSetName = "Default";
            this.lblRemark.TabIndex = 24;
            this.lblRemark.Text = "비고";
            this.lblRemark.UseMnemonic = false;
            // 
            // txtRemark
            // 
            this.txtRemark.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance30.TextVAlignAsString = "Bottom";
            this.txtRemark.Appearance = appearance30;
            this.txtRemark.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtRemark.Location = new System.Drawing.Point(163, 120);
            this.txtRemark.LockedField = false;
            this.txtRemark.Margin = new System.Windows.Forms.Padding(0);
            this.txtRemark.MaxLength = 200;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.QueryIfEnterKeyPressed = true;
            this.txtRemark.RequiredField = false;
            this.txtRemark.Size = new System.Drawing.Size(271, 24);
            this.txtRemark.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtRemark.StyleSetName = "Default";
            this.txtRemark.TabIndex = 25;
            this.txtRemark.uniALT = "Remark";
            this.txtRemark.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtRemark.UseDynamicFormat = false;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniTBL_MainData.SetColumnSpan(this.uniGrid1, 3);
            this.uniGrid1.DirectPaste = false;
            appearance31.BackColor = System.Drawing.SystemColors.Window;
            appearance31.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance31;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance32.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance32.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance32.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance32;
            appearance33.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance33;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance34.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance34.BackColor2 = System.Drawing.SystemColors.Control;
            appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance34.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance34;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance35.BackColor = System.Drawing.SystemColors.Window;
            appearance35.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance35;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance36.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance36;
            appearance37.BorderColor = System.Drawing.Color.Silver;
            appearance37.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance37;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance38.BackColor = System.Drawing.SystemColors.Control;
            appearance38.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance38.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance38.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance38;
            appearance39.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance39;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance40.BackColor = System.Drawing.SystemColors.Window;
            appearance40.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance40;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance41.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance41;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 162);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0, 9, 0, 0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(1168, 331);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 1;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.AfterExitEditMode += new System.EventHandler(this.uniGrid1_AfterExitEditMode_1);
            this.uniGrid1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.uniGrid1_BeforePopupOpen);
            this.uniGrid1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.uniGrid1_AfterPopupClosed);
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(1180, 623);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainReference.ResumeLayout(false);
            this.uniTBL_MainBatch.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            this.uniTBL_Single.ResumeLayout(false);
            this.uniTBL_Single.PerformLayout();
            this.uniTableLayoutPanel1.ResumeLayout(false);
            this.uniTableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtApproval)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprovalNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtReqDt)).EndInit();
            this.uniTableLayoutPanel2.ResumeLayout(false);
            this.uniTableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrSts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrStsNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDeliveryDt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReqRsn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_Single;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPrNo;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popProdReqNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPrNo2;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtPrNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPlantCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPlantCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblUnitSalesGrpRef;
        private uniERP.AppFramework.UI.Controls.uniLabel lblTGSRef;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPoRef;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDvlyReqRef;
        private uniERP.AppFramework.UI.Controls.uniButton btnApproval;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReqDept;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popReqDept;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReqDt;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtReqDt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRqPrsn;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popReqPrsn;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPurOrz;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPurOrz;
        private uniERP.AppFramework.UI.Controls.uniLabel lblInfo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPrSts;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel2;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtPrSts;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtPrStsNm;
        private uniERP.AppFramework.UI.Controls.uniLabel lbldeliveryDt;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtDeliveryDt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBomRef;
        private uniERP.AppFramework.UI.Controls.uniLabel lblApproval;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel1;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtApproval;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtApprovalNm;
        private uniERP.AppFramework.UI.Controls.uniButton btnPreview;
        private uniERP.AppFramework.UI.Controls.uniButton btnPrint;
        private uniERP.AppFramework.UI.Controls.uniLabel lblEmpNo;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popEmpNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReqRsn;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtReqRsn;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRemark;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtRemark;
        private uniERP.AppFramework.UI.Controls.uniButton btnCancel;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRef5;

    }
}
