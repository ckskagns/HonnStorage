﻿namespace uniERP.App.UI.MM.M2111MA4_KO883 {
    
    
    public partial class tdsM2111M4_KO883 {
    }
}
namespace uniERP.App.UI.MM.M2111MA4_KO883.tdsM2111M4_KO883TableAdapters
{
    
    
    public partial class tdsM2111M4_KO883 {
    }
}
