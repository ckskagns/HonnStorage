﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Common.Exceptions;
using uniERP.AppFramework.DataBridge;

using uniERP.AppFramework.UI.Controls.Popup;

#endregion

namespace uniERP.App.UI.MM.M2111MA4_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①namespace</NameSpace>
        /// <Module>②module name</Module>
        /// <Class>③class name</Class>
        /// <Desc>④
        ///   This part describe the summary information about class 
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="creator" Date="created date">Make …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="SEH"  Date="2016-03-29"> 법인분리로 인해 법인에 따라 결재상신 CALL ID 달라지도록 변경</history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        // change your code
        //private wsMyBizFL.TypedDataSet cstdsTypedDataSet = new wsMyBizFL.TypedDataSet();
        #endregion

        #region ■ 1.4 Class global constants (grid)

        #endregion

        #region ■ 1.5 Class global variables (grid)

        tdsM2111M4_KO883 cqtdsM2111M4_KO883 = new tdsM2111M4_KO883();


        string selected_emp_biz_area_cd = null;

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(cqtdsM2111M4_KO883);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T03_SingleMulti);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.MaterialManagement);  // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format

        }

        protected override void Form_Load_Completed()
        {
            //ControlName.Focus();                // Set focus
            uniBase.UCommon.SetToolBarSingleAll(false);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New, true);
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            // init OperationMode is Create Mode
            base.viewDBSaveMode = enumDef.DBSaveMode.CreateMode;

        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            this.dtReqDt.Value = uniBase.UDate.GetDBServerDateTime();
            this.dtDeliveryDt.Value = uniBase.UDate.GetDBServerDateTime();

            popPlantCd.CodeValue = CommonVariable.gPlant;
            popPlantCd.CodeName = CommonVariable.gPlantNm;

            popPurOrz.CodeValue = CommonVariable.gPurOrg;
            popReqDept.CodeValue = CommonVariable.gDepart;

            if (popPurOrz.CodeValue.Length > 0)
            {
                string strPurOrz = string.Format("select PUR_ORG_NM from B_PUR_ORG where pur_org = '" + popPurOrz.CodeValue + "'");
                DataSet dsPurOrg = uniBase.UDataAccess.CommonQuerySQL(strPurOrz);
                if (dsPurOrg == null || dsPurOrg.Tables[0] == null || dsPurOrg.Tables[0].Rows.Count == 0)
                    return;
                popPurOrz.CodeName = dsPurOrg.Tables[0].Rows[0]["PUR_ORG_NM"].ToString();
            }


            if (popReqDept.CodeValue.Length > 0)
            {
                string strDept = string.Format("select DEPT_NM from B_ACCT_DEPT where ORG_CHANGE_ID = '" + CommonVariable.gChangeOrgId + "' and DEPT_CD ='" + popReqDept.CodeValue + "'");
                DataSet dsDept = uniBase.UDataAccess.CommonQuerySQL(strDept);
                if (dsDept == null || dsDept.Tables[0] == null || dsDept.Tables[0].Rows.Count == 0)
                    return;
                popReqDept.CodeName = dsDept.Tables[0].Rows[0]["DEPT_NM"].ToString();
            }

            lblInfo.Appearance.ForeColor = Color.Red;
            
            //uniBase.UCommon.SetToolBarMultiAll(false);
            //uniBase.UCommon.SetToolBarSingleAll(false);

            return;
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            // Example: Set ComboBox List (Column Name, Select, From, Where)
            //uniBase.UData.ComboMajorAdd("TaxPolicy", "B0004");
            //uniBase.UData.ComboCustomAdd("MSG_TYPE", "MINOR_CD , MINOR_NM ", "B_MINOR", "MAJOR_CD='A1001'");

            uniBase.UData.ComboMajorAdd("Change_Type", "XPR01");
            uniBase.UData.ComboMajorAdd("DEPT", "XPR02");
            uniBase.UData.ComboMajorAdd("APPROVAL", "SM003");



        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆
            base.viewTB19029.ggUserDefined6.DecPoint = 0;
            base.viewTB19029.ggUserDefined6.Integeral = 15;
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information


            tdsM2111M4_KO883.E_M2111M4_KO883_Multi_QueryDataTable uniGridTB1 = cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query;
           
            uniGrid1.SSSetEdit(uniGridTB1.plant_cdColumn.ColumnName, "Plant", 171, enumDef.FieldType.Default, enumDef.CharCase.Upper, false, enumDef.HAlign.Left, 50);
            uniGrid1.SSSetEdit(uniGridTB1.pr_noColumn.ColumnName, "Request No.", 135, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);
            uniGrid1.SSSetEdit(uniGridTB1.item_cdColumn.ColumnName, "Item", 171, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
           
            uniGrid1.SSSetEdit(uniGridTB1.item_nmColumn.ColumnName, "Item Desc", 180, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            uniGrid1.SSSetEdit(uniGridTB1.specColumn.ColumnName, "Item Spec", 180, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            uniGrid1.SSSetEdit(uniGridTB1.basic_unitColumn.ColumnName, "P/R Unit", 80, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);
            uniGrid1.SSSetEdit(uniGridTB1.flagColumn.ColumnName, "Flag", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.req_qtyColumn.ColumnName, "P/R Qty", base.viewTB19029.ggQty, enumDef.FieldType.NotNull);
            uniGrid1.SSSetEdit(uniGridTB1.tracking_noColumn.ColumnName, "Tracking No.", 150, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);

            //필요일자 싱글에 있는 값을 멀티로 옮김 (2015-11-09 수정)
            
            //this.uniGrid1.SSSetDate(uniGridTB1.dlvy_dtColumn.ColumnName, "필요일자", 150, enumDef.FieldType.Default, CommonVariable.gDateFormat, enumDef.HAlign.Center);

            //계획오더번호
            uniGrid1.SSSetEdit(uniGridTB1.mrp_ord_noColumn.ColumnName, "MRP Order No.", 150, enumDef.FieldType.Default, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);

            //용도            
            //uniGrid1.SSSetEdit(uniGridTB1.use_typeColumn.ColumnName, "Use", 80, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            //uniGrid1.SSSetEdit(uniGridTB1.use_type_nmColumn.ColumnName, "Use Desc.", 150, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);

            uniGrid1.SSSetEdit(uniGridTB1.sl_cdColumn.ColumnName, "Receipt S/L", 100, enumDef.FieldType.Nullable, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            uniGrid1.SSSetEdit(uniGridTB1.sl_nmColumn.ColumnName, "Receipt Name", 150, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);

            //Pallet
            uniGrid1.SSSetEdit(uniGridTB1.pallet_noColumn.ColumnName, "Pallet", 150, enumDef.FieldType.Default, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            uniGrid1.SSSetEdit(uniGridTB1.pallet_nmColumn.ColumnName, "Pallet Desc.", 200, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);

            //uniGrid1.SSSetEdit(uniGridTB1.remarkColumn.ColumnName, "Remark", 500, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);
            uniGrid1.SSSetFloat(uniGridTB1.sppl_dlvy_ltColumn.ColumnName, "Delivery L/T", base.viewTB19029.ggUserDefined6, enumDef.FieldType.ReadOnly);

            //추가(2015-11-04)
            uniGrid1.SSSetEdit(uniGridTB1.so_noColumn.ColumnName, "출고요청번호", 150, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);
            uniGrid1.SSSetFloat(uniGridTB1.so_seq_noColumn.ColumnName, "출고요청순번", base.viewTB19029.ggUserDefined6, enumDef.FieldType.ReadOnly);

            //hidden
            //해제 (2018-06-07)
            uniGrid1.SSSetFloat(uniGridTB1.org_req_qtyColumn.ColumnName, "Original Qty", base.viewTB19029.ggQty, enumDef.FieldType.ReadOnly);

            //자동채번
            uniGrid1.SSSetEdit(uniGridTB1.ext3_cdColumn.ColumnName, "Auto No.", 150, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);

            //add by. SEH (160310 - 싱글영역의 요청진행상태,요청진행상태명 그리드로 내림)
            //add by. CHH (180607 - 다시 싱글그리드로 올림)
            uniGrid1.SSSetEdit(uniGridTB1.pr_stsColumn.ColumnName, "요청진행상태", 110, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);
            uniGrid1.SSSetEdit(uniGridTB1.pr_sts_nmColumn.ColumnName, "요청진행상태명", 150, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Left);

            //add by, SEH (180628) 컬럼추가
            //uniGrid1.SSSetEdit(uniGridTB1.approval_rtnColumn.ColumnName, "결재상태", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetCombo(uniGridTB1.approval_rtnColumn.ColumnName, "결재상태", 110, viewDataSet.Tables["APPROVAL"], enumDef.FieldType.ReadOnly, enumDef.HAlign.Center, false, false);
            uniGrid1.SSSetEdit(uniGridTB1.doc_noColumn.ColumnName, "결재번호", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.item_nm_engColumn.ColumnName, "Maker", 110, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext1_cdColumn.ColumnName, "설계변경번호", 100, enumDef.FieldType.NotNull, enumDef.CharCase.Upper, true, enumDef.HAlign.Left);
            uniGrid1.SSSetEdit(uniGridTB1.ecn_descColumn.ColumnName, "설계변경내역", 150, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.reason_cdColumn.ColumnName, "설계변경근거", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.reason_nmColumn.ColumnName, "설계변경근거명", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ext4_cd_ko883Column.ColumnName, "비고(BOM)", 100, enumDef.FieldType.Default, enumDef.CharCase.Upper, false, enumDef.HAlign.Left, 100);
            //add by, SEH(180801) 멀티영역에있던 구매요청사유를 싱글영역으로 옮김
            //uniGrid1.SSSetEdit(uniGridTB1.ext5_cd_ko883Column.ColumnName, "구매요청사유", 110, enumDef.FieldType.Default, enumDef.CharCase.Upper, false, enumDef.HAlign.Left, 100);
            uniGrid1.SSSetCombo(uniGridTB1.ext6_cd_ko883Column.ColumnName, "Change Type(C/T)", 110, viewDataSet.Tables["Change_Type"], enumDef.FieldType.Default, enumDef.HAlign.Center, false, true);
            uniGrid1.SSSetCombo(uniGridTB1.ext7_cd_ko883Column.ColumnName, "원청부서", 110, viewDataSet.Tables["DEPT"], enumDef.FieldType.Default, enumDef.HAlign.Center, false, true); 


            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.flagInformation("status", "row_num");
            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            // Hidden Column Setting
            this.uniGrid1.SSSetColHidden(uniGridTB1.plant_cdColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.ext3_cdColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.mrp_ord_noColumn.ColumnName);
            //this.uniGrid1.SSSetColHidden(uniGridTB1.dlvy_dtColumn.ColumnName);
            
            this.uniGrid1.SSSetColHidden(uniGridTB1.so_noColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.so_seq_noColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.pr_stsColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.pr_sts_nmColumn.ColumnName);
            //this.uniGrid1.SSSetColHidden(uniGridTB1.org_req_qtyColumn.ColumnName);
            //this.uniGrid1.SSSetColHidden(uniGridTB1.use_typeColumn.ColumnName);
            //this.uniGrid1.SSSetColHidden(uniGridTB1.use_type_nmColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.pallet_noColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.pallet_nmColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.sppl_dlvy_ltColumn.ColumnName);


            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
            // TO-DO: 컨트롤을 초기화(또는 초기값)할때 할일 
            // SetDefaultVal과의 차이점은 전자는 Form_Load 시점에 콘트롤에 초기값을 세팅하는것이고
            // 후자는 특정 시점(조회후 또는 행추가후 등 특정이벤트)에서 초기값을 셋팅한다.
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            #region 싱글조회

            tdsM2111M4_KO883.E_M2111M4_KO883_Single_QueryDataTable uniTB1 = cqtdsM2111M4_KO883.E_M2111M4_KO883_Single_Query;

            uniBase.UData.addDataBinding(txtPrNo, uniTB1.pr_req_noColumn);                                   //구매의뢰번호
            uniBase.UData.addDataBinding(popReqDept, "CodeValue", uniTB1, uniTB1.req_deptColumn.ColumnName); //요청부서            
            uniBase.UData.addDataBinding(popReqDept, "CodeName", uniTB1, uniTB1.dept_nmColumn.ColumnName); //요청부서명          
            uniBase.UData.addDataBinding(popReqPrsn, "CodeValue", uniTB1, uniTB1.req_prsnColumn.ColumnName); //요청자
            uniBase.UData.addDataBinding(popReqPrsn, "CodeName", uniTB1, uniTB1.prsn_nmColumn.ColumnName); //요청자명
            uniBase.UData.addDataBinding(popPurOrz, "CodeValue", uniTB1, uniTB1.pur_orgColumn.ColumnName);   //구매조직
            uniBase.UData.addDataBinding(popPurOrz, "CodeName", uniTB1, uniTB1.pur_org_nmColumn.ColumnName);   //구매조직명
            uniBase.UData.addDataBinding(popPlantCd, "CodeValue", uniTB1, uniTB1.plant_cdColumn.ColumnName); //공장
            uniBase.UData.addDataBinding(popPlantCd, "CodeName", uniTB1, uniTB1.plant_nmColumn.ColumnName); //공장명
            uniBase.UData.addDataBinding(dtReqDt, uniTB1.req_dtColumn);                                      //요청일자
            uniBase.UData.addDataBinding(dtDeliveryDt, uniTB1.dlvy_dtColumn);                                      //필요일자
            
            uniBase.UData.addDataBinding(txtPrSts, uniTB1.pr_stsColumn);                                     //요청진행상태 
            uniBase.UData.addDataBinding(txtPrStsNm, uniTB1.pr_sts_nmColumn);                                //요청진행상태명  

            //add by, SEH (180628) 컬럼추가
            uniBase.UData.addDataBinding(txtApproval, uniTB1.approval_rtnColumn);                                     //결재상태 
            uniBase.UData.addDataBinding(txtApprovalNm, uniTB1.approval_rtn_nmColumn);                                //결재상태명  

            //add by, SEH(180801) 멀티영역에있던 구매요청사유를 싱글영역으로 옮김
            uniBase.UData.addDataBinding(txtReqRsn, uniTB1.ext5_cd_ko883Column);                                //구매요청사유  
            //add by, SEH(180813) 비고 컬럼 추가 
            uniBase.UData.addDataBinding(txtRemark, uniTB1.ext9_cd_ko883Column);                                //비고  




            #endregion


            this.InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(this.cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query);

        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)


        protected override bool OnFncQuery()
        {
            return DBQuery();
        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)
        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic
            return DBSave();
        }
        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {
            //TO-DO : code business oriented logic
            popReqDept.FieldType = enumDef.FieldType.NotNull;
            uniBase.UCommon.ChangeFieldLockAttribute(popReqDept, enumDef.FieldLockAttribute.Required);
            dtReqDt.FieldType = enumDef.FieldType.NotNull;
            uniBase.UCommon.ChangeFieldLockAttribute(dtReqDt, enumDef.FieldLockAttribute.Required);
            popReqPrsn.FieldType = enumDef.FieldType.NotNull;
            uniBase.UCommon.ChangeFieldLockAttribute(popReqPrsn, enumDef.FieldLockAttribute.Required);
            popPurOrz.FieldType = enumDef.FieldType.NotNull;
            uniBase.UCommon.ChangeFieldLockAttribute(popPurOrz, enumDef.FieldLockAttribute.Required);
            dtDeliveryDt.FieldType = enumDef.FieldType.NotNull;
            uniBase.UCommon.ChangeFieldLockAttribute(dtDeliveryDt, enumDef.FieldLockAttribute.Required);
            txtReqRsn.FieldType = enumDef.FieldType.NotNull;
            uniBase.UCommon.ChangeFieldLockAttribute(txtReqRsn, enumDef.FieldLockAttribute.Required);
            txtRemark.FieldType = enumDef.FieldType.Default;
            uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Normal);

            uniBase.UCommon.SetToolBarMultiAll(true);

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)

        protected override bool OnPreFncInsertRow()
        {
            if (popPlantCd.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("189220", MessageBoxButtons.OK);
                popPlantCd.Focus();

                return false;
            }

            return base.OnPreFncInsertRow();
        }



        protected override bool OnFncInsertRow()
        {
            uniGrid1.ActiveRow.Cells["plant_cd"].Value = popPlantCd.CodeValue.ToUpper();

            //M2111MA4에서 가지고옴 
            //uniGrid1.ActiveRow.Cells["req_dt"].Value = uniBase.UDate.GetDBServerDateTime().Date;
            //uniGrid1.ActiveRow.Cells["req_dept"].Value = CommonVariable.gDepart;
            //uniGrid1.ActiveRow.Cells["req_prsn"].Value = CommonVariable.gUsrID;
            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {

            //int i = uniGrid1.ActiveRow.Index;
            ////Modified by YangQizhong , 2008-2-27
            //uniGrid1.ActiveRow.Cells["pr_no"].Value = "";
            //uniGrid1.ActiveRow.Cells["pur_plan_dt"].Value = DBNull.Value;
            //uniGrid1.ActiveRow.Cells["pr_sts"].Value = "";
            ////uniGrid1.ActiveRow.Cells["sts_nm"].Value = DBNull.Value;
            //uniGrid1.ActiveRow.Cells["pr_type"].Value = "";
            ////uniGrid1.ActiveRow.Cells["type_nm"].Value = "";
            //uniGrid1.ActiveRow.Cells["req_dept"].Value = CommonVariable.gDepart;
            //uniGrid1.ActiveRow.Cells["req_prsn"].Value = CommonVariable.gUsrID;

            //uniGrid1.SpreadLock("tracking_no", uniGrid1.ActiveRow.Index, uniGrid1.ActiveRow.Index);
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            #region 상단 싱글영역 조회
            DataSet rtnDs1 = null;
            try
            {
                cqtdsM2111M4_KO883.E_M2111M4_KO883_Single_Query.Clear();

                using (uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetStoredProcCommand("USP_PAM_M2111M4_KO883_1"))
                //using (uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetStoredProcCommand("dbo.USP_PAM_M2111M4_KO883_TEST"))                
                {
                    uniBase.UDatabase.AddInParameter(uniCmd, "@PR_REQ_NO", SqlDbType.NVarChar, popProdReqNo.CodeValue);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@MNU_ID", SqlDbType.NVarChar, uniBase.UCommon.GetProgramID(false));

                    rtnDs1 = uniBase.UDatabase.ExecuteDataSet(uniCmd);

                    if (rtnDs1 == null || rtnDs1.Tables[0] == null || rtnDs1.Tables[0].Rows.Count == 0)
                    {
                        uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                        popEmpNo.CodeValue = string.Empty;
                        popEmpNo.CodeName = string.Empty;

                        txtRemark.Text = string.Empty;
                        return false;
                    }
                    else
                    {
                        uniBase.UData.MergeDataTable(cqtdsM2111M4_KO883.E_M2111M4_KO883_Single_Query, rtnDs1.Tables[0], false, MissingSchemaAction.Ignore);
                        txtPrNo.FieldType = enumDef.FieldType.ReadOnly;

                        popEmpNo.CodeValue = rtnDs1.Tables[0].Rows[0]["DOC_USER_ID"].ToString();
                        popEmpNo.CodeName = rtnDs1.Tables[0].Rows[0]["NAME"].ToString();

                        txtRemark.Text = rtnDs1.Tables[0].Rows[0]["EXT9_CD_KO883"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                //if (iqtdsTypedDataSet != null) iqtdsTypedDataSet.Dispose();
                //if (iqtdsICondition != null) iqtdsICondition.Dispose();
            }
            #endregion


            #region 하단 그리드 조회
            DataSet rtnDs2 = null;
            try
            {
                cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.Clear();

                using (uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetStoredProcCommand("USP_PAM_M2111M4_KO883_2"))
                //using (uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetStoredProcCommand("dbo.USP_PAM_M2111M4_KO883_TEST2"))                
                {
                    uniBase.UDatabase.AddInParameter(uniCmd, "@PR_REQ_NO", SqlDbType.NVarChar, popProdReqNo.CodeValue);
                    uniBase.UDatabase.AddInParameter(uniCmd, "@MNU_ID", SqlDbType.NVarChar, uniBase.UCommon.GetProgramID(false));

                    rtnDs2 = uniBase.UDatabase.ExecuteDataSet(uniCmd);

                    if (rtnDs2 == null || rtnDs2.Tables[0] == null || rtnDs2.Tables[0].Rows.Count == 0)
                    {
                        uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                        return false;
                    }
                    else
                    {
                        uniBase.UData.MergeDataTable(cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query, rtnDs2.Tables[0], false, MissingSchemaAction.Ignore);
                    }

                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                //if (iqtdsTypedDataSet != null) iqtdsTypedDataSet.Dispose();
                //if (iqtdsICondition != null) iqtdsICondition.Dispose();
            }
            #endregion

            //조회 후 구매의뢰번호 readonly처리
            uniBase.UCommon.ChangeFieldLockAttribute(txtPrNo, enumDef.FieldLockAttribute.Protected);
      
            //조회 후 그리드의 구매요청번호, 품목, tracking no 필드 속성 readonly 처리

                for (int i = 0; i < uniGrid1.Rows.Count; i++)
                {
                    uniGrid1.SpreadLock("pr_no", i, i);
                    uniGrid1.SpreadLock("item_cd", i, i);
                    uniGrid1.SpreadLock("tracking_no", i, i);

                    if (txtPrSts.Text != "RQ" || (txtApproval.Text == "1" || txtApproval.Text == "7" || txtApproval.Text == "9" || txtApproval.Text == "T"))
                    {
                        uniGrid1.SpreadLock("req_qty", i, i);
                        uniGrid1.SpreadLock("use_type", i, i);
                        uniGrid1.SpreadLock("sl_cd", i, i);
                        uniGrid1.SpreadLock("pallet_no", i, i);
                        uniGrid1.SpreadLock("dlvy_dt", i, i);

                        //Add by, SEH (180628)
                        uniGrid1.SpreadLock("ext1_cd", i, i);
                        uniGrid1.SpreadLock("ext4_cd_ko883", i, i);
                        uniGrid1.SpreadLock("ext5_cd_ko883", i, i);
                        uniGrid1.SpreadLock("ext6_cd_ko883", i, i);
                        uniGrid1.SpreadLock("ext7_cd_ko883", i, i);

                        uniBase.UCommon.SetToolBarMultiAll(false);


                    }
                    else
                    {
                        uniBase.UCommon.SetToolBarMultiAll(true);

                    }

                }


                if ((txtPrSts.Text != "RQ") ||(txtApproval.Text == "1" || txtApproval.Text == "7" || txtApproval.Text == "9" || txtApproval.Text == "T"))
                {
                    if ((txtApproval.Text == "1" || txtApproval.Text == "7" || txtApproval.Text == "9" || txtApproval.Text == "T"))
                    {
                        uniBase.UCommon.DisableButton(this.btnApproval, false);
                        uniBase.UCommon.DisableButton(this.btnCancel, true);
                        popEmpNo.FieldType = enumDef.FieldType.ReadOnly;
                    }
                    else
                    {
                        uniBase.UCommon.DisableButton(this.btnApproval, true);
                        uniBase.UCommon.DisableButton(this.btnCancel, false);
                        popEmpNo.FieldType = enumDef.FieldType.Default;
                    }
                    popReqDept.FieldType = enumDef.FieldType.ReadOnly;
                    dtReqDt.FieldType = enumDef.FieldType.ReadOnly;
                    popReqPrsn.FieldType = enumDef.FieldType.ReadOnly;
                    popPurOrz.FieldType = enumDef.FieldType.ReadOnly;
                    dtDeliveryDt.FieldType = enumDef.FieldType.ReadOnly;
                    txtReqRsn.FieldType = enumDef.FieldType.ReadOnly;
                    txtRemark.FieldType = enumDef.FieldType.ReadOnly;



                }
                else
                {
                    if ((txtApproval.Text == "1" || txtApproval.Text == "7" || txtApproval.Text == "9" || txtApproval.Text == "T"))
                    {
                        uniBase.UCommon.DisableButton(this.btnApproval, false);
                        uniBase.UCommon.DisableButton(this.btnCancel, true);
                        popEmpNo.FieldType = enumDef.FieldType.ReadOnly;
                    }
                    else
                    {
                        uniBase.UCommon.DisableButton(this.btnApproval, true);
                        uniBase.UCommon.DisableButton(this.btnCancel, false);
                        popEmpNo.FieldType = enumDef.FieldType.Default;
                    }

                    popReqDept.FieldType = enumDef.FieldType.NotNull;
                    dtReqDt.FieldType = enumDef.FieldType.NotNull;
                    popReqPrsn.FieldType = enumDef.FieldType.NotNull;
                    popPurOrz.FieldType = enumDef.FieldType.NotNull;
                    dtDeliveryDt.FieldType = enumDef.FieldType.NotNull;
                    txtReqRsn.FieldType = enumDef.FieldType.NotNull;
                    txtRemark.FieldType = enumDef.FieldType.Default;

                }

            /*
            //조회 후 요청진행상태가 'RQ'가 아니면 그리드 모두 ReadOnly 처리 (2015-11-09 추가)
            //if (rtnDs1.Tables[0].Rows[0]["PR_STS"].ToString().Trim() != "RQ")
            int iCnt =  Convert.ToInt32(rtnDs1.Tables[0].Compute("COUNT(PR_REQ_NO)", string.Format("PR_STS <> '{0}'", "RQ")));
            if(iCnt > 0)
            {
                //mod by. SEH(요청진행상태가 멀티영역으로 내려가면서 행별 처리로 로직 변경--> 주석)
                //for (int i = 0; i < uniGrid1.Rows.Count; i++)
                //{
                //    uniGrid1.SpreadLock("req_qty", i, i);
                //    uniGrid1.SpreadLock("use_type", i, i);
                //    uniGrid1.SpreadLock("sl_cd", i, i);
                //    uniGrid1.SpreadLock("pallet_no", i, i);
                //    uniGrid1.SpreadLock("dlvy_dt", i, i);
                //}
                popReqDept.FieldType = enumDef.FieldType.ReadOnly;
                dtReqDt.FieldType = enumDef.FieldType.ReadOnly;
                popReqPrsn.FieldType = enumDef.FieldType.ReadOnly;
                popPurOrz.FieldType = enumDef.FieldType.ReadOnly;
                dtDeliveryDt.FieldType = enumDef.FieldType.ReadOnly;

                
            }
            else
            {
                popReqDept.FieldType = enumDef.FieldType.NotNull;
                dtReqDt.FieldType = enumDef.FieldType.NotNull;
                popReqPrsn.FieldType = enumDef.FieldType.NotNull;
                popPurOrz.FieldType = enumDef.FieldType.NotNull;
                dtDeliveryDt.FieldType = enumDef.FieldType.NotNull;
                
            }
            */
            //uniBase.UCommon.SetToolBarMultiAll(true);
            //uniBase.UCommon.SetToolBarSingleAll(true);
            return true;
        }


        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //wsMyBizFL.TypedDataSet isettdsTypedDataSet = new wsMyBizFL.TypedDataSet();

            try
            {
                //wsMyBizFL.TypedDataSet.IESaveSingleDTDataTable igettdtTypedSingleTable =
                //    (wsMyBizFL.TypedDataSet.IESaveDTDataTable)this.cstdsTypedDataSet.IESaveSingleDT;

                //using (wsMyBizFL.Service iwsMyBizFL = (wsMyBizFL.Service)uniBase.UConfig.SetWebServiceProxyEnv(new wsMyBizFL.Service()))
                //{
                //    isettdsTypedDataSet.IESaveSingleDT.Merge(igettdtTypedSingleTable, false, MissingSchemaAction.Ignore);
                //    iwsMyBizFL.SaveWebMethod(CommonVariable.gStrGlobalCollection, "DELETE", isettdsTypedDataSet);
                //}
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                //if (isettdsTypedDataSet != null) isettdsTypedDataSet.Dispose();
            }

            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            string strAutoNo = string.Empty;
            DataSet rtnDs = null;
            string strTrackingNo = string.Empty;
            string sSQL = string.Empty;
            #region 주석

            //            for(int i = 0; i < uniGrid1.Rows.Count; i++)
            //            {
            //                if (Convert.ToDecimal(uniGrid1.Rows[i].Cells["req_qty"].Value) == 0)                
            //                {
            //                    uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "요청수량이 0입니다.");
            //                    return false;
            //                }

            //            }

            //            if (uniGrid1.Rows.Count == 0)
            //            {
            //                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "구매요청 품목이 존재하지 않아 저장 할 수 없습니다.");
            //                return false;
            //            }

            //            //Tracking No 마감확인
            //            DataSet rtnDs = null;
            //            string strTrackingNo = string.Empty;

            //            strTrackingNo = uniGrid1.ActiveRow.Cells["tracking_no"].Value.ToString().Trim();

            //            string sSQL = string.Format(@" 
            //            
            //            SELECT * 
            //            FROM PMS_PROJECT 
            //            WHERE PROJECT_CODE = {0}  AND STATE = '4'"

            //                , uniBase.UCommon.FilterVariable(strTrackingNo, "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true));

            //            rtnDs = uniBase.UDataAccess.CommonQuerySQL(sSQL);

            //            //마감된 Tracking No로 구매요청 할수 없습니다.
            //            if (!(rtnDs == null || rtnDs.Tables.Count == 0 || rtnDs.Tables[0].Rows.Count == 0))
            //            {
            //                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK,"마감된 Tracking No로 구매요청 할수 없습니다.");
            //                return false;
            //            }             
            #endregion 
            if (uniGrid1.Rows.Count == 0)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "구매요청 품목이 존재하지 않아 저장 할 수 없습니다.");
                return false;
            }
            if (cqtdsM2111M4_KO883.GetChanges() == null && this.txtPrSts.Text == "RQ")
            {
                /*
                string strSql = string.Format(@"
UPDATE M_PUR_REQ
SET REQ_DEPT = {0}
,   REQ_DT = {1}
,   DLVY_DT = {5}
,	REQ_PRSN = {2}
,   PUR_ORG = {4}
,   EXT5_CD_KO883 = upper({6})
WHERE ext3_cD = {3}", uniBase.UCommon.FilterVariable(popReqDept.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                     , uniBase.UCommon.FilterVariable(dtReqDt.uniValue.ToString("yyyy-MM-dd"), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                     , uniBase.UCommon.FilterVariable(popReqPrsn.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                     , uniBase.UCommon.FilterVariable(popProdReqNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                     , uniBase.UCommon.FilterVariable(popPurOrz.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                     , uniBase.UCommon.FilterVariable(dtDeliveryDt.uniValue.ToString("yyyy-MM-dd"), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                     , uniBase.UCommon.FilterVariable(txtReqRsn.Value, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                     );
                uniBase.UDataAccess.CommonQuerySQL(strSql);
                */

                string strSql = " UPDATE M_PUR_REQ" + "\r\n"
    + "   SET REQ_DEPT = @REQ_DEPT" + "\r\n"
    + ",   REQ_DT = @REQ_DT" + "\r\n"
    + ",   DLVY_DT = @DLVY_DT" + "\r\n"
    + ",   REQ_PRSN = @REQ_PRSN" + "\r\n"
    + ",   PUR_ORG = @PUR_ORG" + "\r\n"
    + ",   EXT5_CD_KO883 =@EXT5_CD_KO883" + "\r\n"
    + ",   EXT9_CD_KO883 = @EXT9_CD_KO883" + "\r\n"
    + "   WHERE ext3_CD = @ext3_CD";

                using (uniERP.AppFramework.DataBridge.uniCommand iCommand = uniBase.UDatabase.GetSqlStringCommand(strSql))
                {
                    uniBase.UDatabase.AddInParameter(iCommand, "@REQ_DEPT", SqlDbType.NVarChar, popReqDept.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iCommand, "@REQ_DT", SqlDbType.DateTime, dtReqDt.uniValue.ToString("yyyy-MM-dd"));
                    uniBase.UDatabase.AddInParameter(iCommand, "@DLVY_DT", SqlDbType.DateTime, dtDeliveryDt.uniValue.ToString("yyyy-MM-dd"));
                    uniBase.UDatabase.AddInParameter(iCommand, "@REQ_PRSN", SqlDbType.NVarChar, popReqPrsn.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iCommand, "@PUR_ORG", SqlDbType.NVarChar, popPurOrz.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(iCommand, "@EXT5_CD_KO883", SqlDbType.NVarChar, txtReqRsn.Value);
                    uniBase.UDatabase.AddInParameter(iCommand, "@EXT9_CD_KO883", SqlDbType.NVarChar, txtRemark.Text);
                    uniBase.UDatabase.AddInParameter(iCommand, "@ext3_CD", SqlDbType.NVarChar, popProdReqNo.CodeValue.Trim());

                    uniBase.UDatabase.ExecuteNonQuery(iCommand, false);
                }

            }
            else
            {

                #region 표준 구매요청등록(MULTI)(M2111M4) DBSave()
                //using (wsPM2G111FL.PM2G111FL iwsPM2G111FL = (wsPM2G111FL.PM2G111FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPM2G111FL.PM2G111FL()))
                using (wsM2111M4_KO883FL.M2111M4_KO883FL iwsPM2G111FL = (wsM2111M4_KO883FL.M2111M4_KO883FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsM2111M4_KO883FL.M2111M4_KO883FL()))                
                {
                    try
                    {
                        //wsPM2G111FL.DsMMaintPurReqMultiSvr istdsMMaintPurReqMultiSvr = new uniERP.App.UI.MM.M2111M4_KO883.wsPM2G111FL.DsMMaintPurReqMultiSvr();
                        wsPM2G111FL.DsMMaintPurReqSvr istdsMMaintPurReqSvr = new uniERP.App.UI.MM.M2111MA4_KO883.wsPM2G111FL.DsMMaintPurReqSvr();

                        wsM2111M4_KO883FL.DsMMaintPurReqMultiSvr istdsMMaintPurReqMultiSvr = new uniERP.App.UI.MM.M2111MA4_KO883.wsM2111M4_KO883FL.DsMMaintPurReqMultiSvr();
                        
                        ////////Add By, SEH (180629) 사이트컬럼 추가 
                        //////if (!istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns.Contains("EXT4_CD_KO883"))
                        //////    istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns.Add("EXT4_CD_KO883", typeof(string));
                        //////if (!istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns.Contains("EXT5_CD_KO883"))
                        //////    istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns.Add("EXT5_CD_KO883", typeof(string));
                        //////if (!istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns.Contains("EXT6_CD_KO883"))
                        //////    istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns.Add("EXT6_CD_KO883", typeof(string));
                        //////if (!istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns.Contains("EXT7_CD_KO883"))
                        //////    istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns.Add("EXT7_CD_KO883", typeof(string));



                        DataSet itdsTemp = cqtdsM2111M4_KO883.GetChanges();

                        for (int i = 0; i < itdsTemp.Tables[1].Rows.Count; i++)
                        {
                            if (Convert.ToDecimal(uniGrid1.Rows[i].Cells["req_qty"].Value) == 0)
                            {
                                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "요청수량이 0입니다.");
                                return false;
                            }


                            if (!itdsTemp.Tables[1].Rows[i]["status"].ToString().Trim().Equals("D"))
                            {
                                //Tracking No 마감확인
                                strTrackingNo = itdsTemp.Tables[1].Rows[i]["tracking_no"].ToString().Trim();
                                sSQL = string.Format(@" 
            
            SELECT * 
            FROM PMS_PROJECT(Nolock)
            WHERE PROJECT_CODE = {0}  AND STATE = '4'"

                                    , uniBase.UCommon.FilterVariable(strTrackingNo, "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true));

                                rtnDs = uniBase.UDataAccess.CommonQuerySQL(sSQL);

                                //마감된 Tracking No로 구매요청 할수 없습니다.
                                if (!(rtnDs == null || rtnDs.Tables.Count == 0 || rtnDs.Tables[0].Rows.Count == 0))
                                {
                                    uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "마감된 Tracking No로 구매요청 할수 없습니다.");
                                    return false;
                                }
                            }
                        }

                        istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Merge(itdsTemp.Tables[1], false, MissingSchemaAction.Add);

                        istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns["req_no"].Expression = itdsTemp.Tables[1].Columns["pr_no"].ColumnName;

                        for (int i = 0; i < istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Count; i++)
                        {
                            //일자를 싱글로 올림으로서 주석처리(2018-06-07)
                            //if (istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.dlvy_dtColumn.ColumnName].ToString() == string.Empty)
                            //{
                            //    //uniBase.UMessage.DisplayMessageBox("970021", MessageBoxButtons.OK);
                            //    //return false;


                            //}
                            //if (istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.req_dtColumn.ColumnName].ToString() == string.Empty)
                            //{
                            //    //uniBase.UMessage.DisplayMessageBox("970021", MessageBoxButtons.OK);
                            //    //return false;
                               
                            //}

                            if (istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.tracking_noColumn.ColumnName].ToString() == string.Empty)
                            {
                                istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.tracking_noColumn.ColumnName] = "*";
                            }
                            if (istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.plan_dtColumn.ColumnName].ToString() == string.Empty)
                            {
                                istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.plan_dtColumn.ColumnName] = uniBase.UDate.DateTimeToString(null, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD);
                            }
                            if (istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.pr_typeColumn.ColumnName].ToString() == string.Empty)
                            {
                                istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.pr_typeColumn.ColumnName] = "E";
                            }

                            //용도  --> 설꼐변경번호 관리용으로 변겨오딤에 따라 주석처리                      
                            //istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.ext1_cdColumn.ColumnName]
                            //    = cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.Rows[i][cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.use_typeColumn.ColumnName].ToString().Trim();
                            //Pallet No
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.ext2_cdColumn.ColumnName]
                                = cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.Rows[i][cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.pallet_noColumn.ColumnName].ToString().Trim();
                            //요청수량 - ext1_qty에 같이저장
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.ext1_qtyColumn.ColumnName]
                                = cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.Rows[i][cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.req_qtyColumn.ColumnName];
                            //요청단위
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.req_unitColumn.ColumnName]
                                = cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.Rows[i][cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.basic_unitColumn.ColumnName];

                            //출고요청번호(추가 2015-11-04)
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i]["so_no"]
                                = cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.Rows[i][cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.so_noColumn.ColumnName];
                            //출고요청순번(추가 2015-11-04)
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i]["so_seq_no"]
                                = cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.Rows[i][cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.so_seq_noColumn.ColumnName];


                            //계획오더번호
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.hdn_mrp_noColumn.ColumnName]
                                = cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.Rows[i][cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.mrp_ord_noColumn.ColumnName];


                            //요청상태 'RQ'
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.pr_stsColumn.ColumnName] = "RQ";


                            ////req_no 싱글에 조회된 값을 저장(ext3_cd 구매의뢰번호) - 자동채번됨
                            //istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.ext3_cdColumn.ColumnName] = popProdReqNo.CodeValue.ToString().Trim();                                               
                            //공장명 
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.plant_cdColumn.ColumnName] = popPlantCd.CodeValue.ToString().Trim();
                            //요청부서 
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqSvr.IM_PUR_REQ.req_deptColumn.ColumnName] = popReqDept.CodeValue.ToString().Trim();
                            //요청자
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.req_prsnColumn.ColumnName] = popReqPrsn.CodeValue.ToString().Trim();
                            //구매부서
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.pur_orgColumn.ColumnName] = popPurOrz.CodeValue.ToString().Trim();
                            //요청일
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.req_dtColumn.ColumnName] = dtReqDt.Value;

                            //필요일(싱글에서 멀티로 2015-11-09) 2018-06-07 주석해제
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.dlvy_dtColumn.ColumnName] = dtDeliveryDt.Value;
                            //필요일
                            //istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.dlvy_dtColumn.ColumnName]
                            //    = cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.Rows[i][cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.dlvy_dtColumn.ColumnName];

                            //add by, SEH(180801) 멀티영역에있던 구매요청사유를 싱글영역으로 옮김
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns["ext5_cd_ko883"].ColumnName] = txtReqRsn.Value;
                            //add by, SEH(180813) 싱글영역에 비고 추가
                            istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i][istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns["ext9_cd_ko883"].ColumnName] = txtRemark.Text;


                        }

                        //구매의뢰 번호 'PX'로 자동채번

                        //if (popProdReqNo.CodeValue.ToString().Trim() == null || popProdReqNo.CodeValue.ToString().Trim() == "")
                        if (txtPrNo.Text.Trim() == "")
                        {
                            DateTime today = uniBase.UDate.GetDBServerDateTime();
                            using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("dbo.usp_s_CreateAutoNo"))
                            {

                                uniBase.UDatabase.AddParameter(iuniCommand, "RETURN_VALUE", SqlDbType.Int, ParameterDirection.ReturnValue, string.Empty, DataRowVersion.Current, null);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@auto_no_type", SqlDbType.VarChar, "PX");
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@work_date", SqlDbType.VarChar, today.ToString("yyyyMMdd"));
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@cnt", SqlDbType.Int, 1);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@user_id", SqlDbType.VarChar, CommonVariable.gUsrID);

                                uniBase.UDatabase.AddOutParameter(iuniCommand, "@serial_no", SqlDbType.Decimal, 15);
                                uniBase.UDatabase.AddOutParameter(iuniCommand, "@auto_no", SqlDbType.VarChar, 18);
                                uniBase.UDatabase.AddOutParameter(iuniCommand, "@job_prefix", SqlDbType.VarChar, 2);
                                uniBase.UDatabase.AddOutParameter(iuniCommand, "@date_info", SqlDbType.VarChar, 8);
                                uniBase.UDatabase.AddOutParameter(iuniCommand, "@serial_digit", SqlDbType.Int, int.MaxValue);
                                uniBase.UDatabase.AddOutParameter(iuniCommand, "@serial_len", SqlDbType.Int, int.MaxValue);

                                uniBase.UDatabase.ExecuteNonQuery(iuniCommand);

                                for (int i = 0; i < uniGrid1.Rows.Count; i++) // ext3_cd --> SP에서 AS로 pr_req_no
                                {
                                    istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i]["ext3_cd"] = uniBase.UDatabase.GetParameterValue(iuniCommand, "@auto_no").ToString();
                                }

                                //popProdReqNo.CodeValue = uniBase.UDatabase.GetParameterValue(iuniCommand, "@auto_no").ToString();
                                //txtPrNo.Text = uniBase.UDatabase.GetParameterValue(iuniCommand, "@auto_no").ToString();

                                strAutoNo = uniBase.UDatabase.GetParameterValue(iuniCommand, "@auto_no").ToString();

                                int retval = Convert.ToInt32(uniBase.UDatabase.GetParameterValue(iuniCommand, "RETURN_VALUE"));

                                if (retval != 0)
                                {
                                    uniBase.UMessage.DisplayMessageBox(retval.ToString(), MessageBoxButtons.OK, new string[] { "" });
                                    return false;
                                }
                            }
                        }
                        else
                        {
                            //mod by. SEH(160314 주석해제 및 popProdReqNo 대신 txtPrNo 값 대입 + Status "C"조건 추가
                            for (int i = 0; i < istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows.Count; i++)
                            //for (int i = 0; i < uniGrid1.Rows.Count; i++) // ext3_cd --> SP에서 AS로 pr_req_no
                            {
                                if (istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i]["status"].ToString().Trim().Equals("C")
                                    || istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i]["status"].ToString().Trim().Equals("U"))
                                {
                                    istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i]["ext3_cd"] = txtPrNo.Value;//popProdReqNo.CodeValue.ToString().Trim();
                                }
                            }
                        }

                        for (int i = 0; i < istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows.Count; i++) // ext3_cd --> SP에서 AS로 pr_req_no
                        {
                            if ((istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i]["status"].ToString().Trim().Equals("C")) && (istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Rows[i]["ext3_cd"].ToString().Trim() == ""))
                            {
                                uniBase.UMessage.DisplayMessageBox("120705", MessageBoxButtons.OK);
                                return false;
                            }
                        }

                        istdsMMaintPurReqMultiSvr.IM_PUR_REQ.hdn_mrp_noColumn.Expression = istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns["mrp_ord_no"].ColumnName;
                        istdsMMaintPurReqMultiSvr.IM_PUR_REQ.dept_cdColumn.Expression = istdsMMaintPurReqMultiSvr.IM_PUR_REQ.Columns["req_dept"].ColumnName;


                        //if(Debugger.IsAttached)
                        //iwsPM2G111FL.Url = "http://localhost:3710/VD/Services/MM/PM2G111FL.asmx";
                        //iwsPM2G111FL.Url = "http://localhost:3710/VD/Services/MM/M2111M4_KO883FL.asmx";                        
                        iwsPM2G111FL.cMMaintPurReqMultiS_M_MAINT_PUR_REQ_MULTI_SVR(CommonVariable.gStrGlobalCollection, istdsMMaintPurReqMultiSvr);
                        //uniBase.UData.uniSaveDS(istdsMMaintPurReqMultiSvr);

                        if (!strAutoNo.Trim().Equals(""))
                        {
                            popProdReqNo.CodeValue = strAutoNo;
                            txtPrNo.Text = strAutoNo;
                        }
                        //DBQuery();
                    }
                    catch (Exception ex)
                    {
                        bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                        if (reThrow)
                            throw;
                        return false;
                    }
                }
                #endregion

                if (this.txtPrSts.Text == "RQ")
                {
                    string strSql = " UPDATE M_PUR_REQ" + "\r\n"
        + "   SET REQ_DEPT = @REQ_DEPT" + "\r\n"
        + ",   REQ_DT = @REQ_DT" + "\r\n"
        + ",   DLVY_DT = @DLVY_DT" + "\r\n"
        + ",	 REQ_PRSN = @REQ_PRSN" + "\r\n"
        + ",   PUR_ORG = @PUR_ORG" + "\r\n"
        + ",   EXT5_CD_KO883 =@EXT5_CD_KO883" + "\r\n"
        + ",   EXT9_CD_KO883 = @EXT9_CD_KO883" + "\r\n"
        + "   WHERE ext3_CD = @ext3_CD";

                    using (uniERP.AppFramework.DataBridge.uniCommand iCommand = uniBase.UDatabase.GetSqlStringCommand(strSql))
                    {
                        uniBase.UDatabase.AddInParameter(iCommand, "@REQ_DEPT", SqlDbType.NVarChar, popReqDept.CodeValue.Trim());
                        uniBase.UDatabase.AddInParameter(iCommand, "@REQ_DT", SqlDbType.DateTime, dtReqDt.uniValue.ToString("yyyy-MM-dd"));
                        uniBase.UDatabase.AddInParameter(iCommand, "@DLVY_DT", SqlDbType.DateTime, dtDeliveryDt.uniValue.ToString("yyyy-MM-dd"));
                        uniBase.UDatabase.AddInParameter(iCommand, "@REQ_PRSN", SqlDbType.NVarChar, popReqPrsn.CodeValue.Trim());
                        uniBase.UDatabase.AddInParameter(iCommand, "@PUR_ORG", SqlDbType.NVarChar, popPurOrz.CodeValue.Trim());
                        uniBase.UDatabase.AddInParameter(iCommand, "@EXT5_CD_KO883", SqlDbType.NVarChar, txtReqRsn.Value);
                        uniBase.UDatabase.AddInParameter(iCommand, "@EXT9_CD_KO883", SqlDbType.NVarChar, txtRemark.Value);
                        uniBase.UDatabase.AddInParameter(iCommand, "@ext3_CD", SqlDbType.NVarChar, popProdReqNo.CodeValue.Trim());

                        uniBase.UDatabase.ExecuteNonQuery(iCommand, false);
                    }

                }
                

            }
            return true;
        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group



        #endregion

        #region ■ 5.2 Grid   control event implementation group


        #region ▶ Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        /// <summary>
        /// 기존의 Context메뉴를 보여주기 위해 fpSpread의 MouseDown이벤트와 Click이벤트에서 처리하던 일련의 코드들은
        /// UltraGrid에서는 MouseDown이벤트에서 처리합니다.
        /// fpSpread의 Click이벤트는 UltraGrid의 
        /// AfterCellActivate | AfterRowActivate | AfterSelectChange 이벤트로 변경 하실 수 있습니다.
        /// AfterCellActivate   : isSearch=No (에디터모드)에서 CellSelect모드에서 한 Cell을 클릭했을때 발생하는 이벤트입니다.
        /// AfterRowActivate    : isSearch=Yes (조회전용모드)에서 RowSelect모드에서 한 Row를 클릭했을때 발생하는 이벤트입니다.
        /// AfterSelectChange   : 셀또는 Row를 하나 이상 선택시 발생하는 이벤트입니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
            Debug.WriteLine("AfterSelectChange Event Fired");

            // Check the type to find out whether rows, columns or cells were selected.
            // 그리드가 읽기 전용 일경우는 e.Type은 UltraGridRow이며
            // 그렇지 않을 경우는 e.Type은 UltraGridCell을 반환합니다.
            if (typeof(UltraGridGroupByRow) == e.Type)
            {
                // The activeRow can be a group-by row 
                // Item type is a group-by-row so use Rows property off the Selected to access those items. 
                if (this.uniGrid1.Selected.Rows.Count == 0)
                    Debug.WriteLine("No group-by rows selected.");
                else
                {
                    Debug.WriteLine(this.uniGrid1.Selected.Rows.Count + " group-by rows selected.");
                    Debug.WriteLine("Group by row activated. Description : " + uniGrid1.ActiveRow.Description);
                }
            }
            else if (typeof(UltraGridRow) == e.Type)
            {
                // Item type is a row so use Rows property off the Selected to access those items. 
                if (this.uniGrid1.Selected.Rows.Count == 0)
                    Debug.WriteLine("No rows selected.");
                else
                {
                    Debug.WriteLine(this.uniGrid1.Selected.Rows.Count + " rows selected.");
                    Debug.WriteLine(uniGrid1.ActiveRow.Index.ToString());
                    Debug.WriteLine(uniGrid1.ActiveRow.ListIndex.ToString());
                    // 참고 : 특정컬럼을 기준으로 그룹화 되었을 경우
                    // ActiveRow.Index와 ActiveRow.ListIndex는 서로 다른 값을 반환합니다.
                    // uniGrid1.ActiveRow = uniGrid1.Rows.GetRowWithListIndex(5);
                }
            }
            else if (typeof(UltraGridColumn) == e.Type)
            {
                // Item type is a column so use Columns property off the Selected to access those items. 
                if (this.uniGrid1.Selected.Columns.Count == 0)
                    Debug.WriteLine("Columns are being unselected.");
                else
                    Debug.WriteLine(this.uniGrid1.Selected.Columns.Count + " columns are being selected.");
            }
            else if (typeof(UltraGridCell) == e.Type)
            {
                // Item type is a cell so use Cells property off the Selected to access those items. 
                if (this.uniGrid1.Selected.Cells.Count == 0)
                    Debug.WriteLine("Columns are being unselected.");
                else
                {
                    Debug.WriteLine(this.uniGrid1.Selected.Cells.Count + " cells are being selected.");
                    Debug.WriteLine("Index of the new active row is  " + this.uniGrid1.ActiveCell.Row.Index.ToString());
                    Debug.WriteLine("Key of the new active col is  " + this.uniGrid1.ActiveCell.Column.Key.ToString());
                }
            }
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
            Debug.WriteLine("AfterCellActivate Event Fired");
            Debug.WriteLine("Index of the new active row is  " + uniGrid1.ActiveCell.Row.Index.ToString());
            Debug.WriteLine("Key of the new active col is  " + uniGrid1.ActiveCell.Column.Key.ToString());
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
            Debug.WriteLine("AfterRowActivate Event Fired");
            Debug.WriteLine("Index of the new active row is  " + uniGrid1.ActiveRow.Index.ToString());
        }
        #endregion ▶ Click >>> AfterSelectChange

        #region ▶ DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
            Debug.WriteLine("DoubleClickCell Event Fired");
            Debug.WriteLine("Index of the new active row is  " + e.Cell.Row.Index.ToString());
            Debug.WriteLine("Key of the new active col is  " + e.Cell.Column.Key);
        }
        #endregion ▶ DblClick >>> DoubleClickCell

        #region ▶ MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
                return;

            UltraGrid grid = (UltraGrid)sender;
            UIElement element = grid.DisplayLayout.UIElement.ElementFromPoint(new Point(e.X, e.Y));
            UltraGridCell cell = element.GetContext(typeof(UltraGridCell)) as UltraGridCell;

            if (cell != null)
            {
                Debug.WriteLine("MouseDown Event Fired");
                Debug.WriteLine("Index of the right mouse click row is  " + cell.Row.Index.ToString());
                Debug.WriteLine("Key of the right mouse click col is  " + cell.Column.Key);

                // 컨텍스트 메뉴를 보여주기 위한 코드 작성 시작
                //SetPopUpMenuItemInf("1101111111")
                // 컨텍스트 메뉴를 보여주기 위한 코드 작성 끝
            }
        }
        #endregion ▶ MouseDown >>> MouseDown

        #region ▶ ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
            Debug.WriteLine("Before Cell Row is  " + uniGrid1.ActiveCell.Row.Index.ToString());
            Debug.WriteLine("Before Cell Col is  " + uniGrid1.ActiveCell.Column.Key.ToString());

            // 새로운 Cell로 이동하기전에 기존 Cell에서 처리할 작업들 수행 코드 시작

            // Validation 체크해서 새로운 Cell로 이동하는 것을 취소
            // e.Cancel = true;

            // 새로운 Cell로 이동하기전에 기존 Cell에서 처리할 작업들 수행 코드 종료



            // 새로운 Cell에 대한 작업은 AfterCellActivate 이벤트에서 처리합니다.
        }
        #endregion ▶ ScriptLeaveCell >>> BeforeCellDeactivate

        #region ▶ ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
            Debug.WriteLine("ClickCellButton Event Fired");
            Debug.WriteLine("Index of the new active row is  " + e.Cell.Row.Index.ToString());
            Debug.WriteLine("Key of the new active col is  " + e.Cell.Column.Key);

            // 버튼클릭 시 수행 할 코드 작성 시작
            //switch (e.Cell.Column.Key)
            //{
            //    case "C_AcctPopUp":
            //        OpenPopUp(e.Cell.Row.Cells["AAA"].Value);
            //        break;
            //    case "C_deptPopup":
            //        OpenPopUp(e.Cell.Row.Cells["BBB"].Value);
            //        break;
            //    case "C_DocCurPopup":
            //        OpenPopUp(e.Cell.Row.Cells["CCC"].Value);
            //        break;
            //    default:
            //}
            // 버튼클릭 시 수행 할 코드 작성 끝
        }
        #endregion ▶ ButtonClicked >>> ClickCellButton

        #region ▶ ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
            if (null != e.Cell.Column.ValueList)
            {
                int itemIndex = e.Cell.Column.ValueList.SelectedItemIndex;
                Debug.WriteLine("Selected Item Index = " + itemIndex);
                Debug.WriteLine("Selected Item Value = " + e.Cell.Column.ValueList.GetValue(itemIndex).ToString());
                Debug.WriteLine("Selected Item Text = " + e.Cell.Column.ValueList.GetText(itemIndex).ToString());
                Debug.WriteLine("Index of the new active row is  " + e.Cell.Row.Index.ToString());
                Debug.WriteLine("Key of the new active col is  " + e.Cell.Column.Key);

                //switch (e.Cell.Column.Key)
                //{
                //    case "AAA":
                //        break;
                //    case "BBB":
                //        break;
                //    case "CCC":
                //        break;
                //    default:
                //        break;
                //}
            }
        }
        #endregion ▶ ComboSelChange >>> CellListSelect

        #region ▶ Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeExitEditMode(object sender, Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs e)
        {
            // If the user is canceling the modifications (for example by hitting Escape  
            // key, then just return because the cell will revert to its original value 
            // in this case and not commit the user‘s input. 
            if (e.CancellingEditOperation)
                return;

            switch (uniGrid1.ActiveCell.Column.Key)
            {
                case "AAA":
                    break;
                case "BBB":
                    break;
                case "CCC":
                    break;
                default:
                    break;
            }
        }

        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {

        }
        #endregion ▶ Change >>> CellChange


        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors
            //CommonPopup cp = new CommonUtil.CommonPopup(PopupType.AutoNumbering);

            //string[] arrRet = cp.showModalDialog(InputParam1);

            #endregion

            #region ▶▶▶ 10.1.2.2 Setting Returned Data

            //if (iWhere) 
            //{
            //    txtMinor.value = arrRet[0];
            //    txtMinorNm.value = arrRet[1];
            //}
            //else
            //{
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingCd].value = arrRet[0];
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingNm].value = arrRet[1];

            //    if (arrRet[2].Length > 0) 
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = arrRet[2];
            //    else
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = "18";

            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.PrefixCd].value = arrRet[0];

            //}

            #endregion

            //CommonVariable.lgBlnFlgChgValue = true;  // 사용자 액션 발생 알림
        }

        #endregion



        #endregion


        private void popEmpNo_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            /*
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup";
            e.PopupPassData.PopupWinTitle = "Employee PopUp";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;

            //e.PopupPassData.Data = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName, "", "1", "", txtInternalCd.Text, "", "" };   //Modified by Gao Tianxing, 2009-2-4
            e.PopupPassData.Data = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName, "", "1", "" };
            */
            /*
            e.PopupPassData.PopupWinTitle = "사원정보";
            e.PopupPassData.ConditionCaption = "사원정보";

            e.PopupPassData.SQLFromStatements = "HAA010T(NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = this.popEmpNo.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "(retire_dt is null or retire_dt > '" + uniBase.UDate.GetDBServerDateTime().ToString("yyyy-MM-dd") + "')";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];

            e.PopupPassData.GridCellCode[0] = "emp_no";
            e.PopupPassData.GridCellCode[1] = "name";
            e.PopupPassData.GridCellCode[2] = "dept_nm";


            e.PopupPassData.GridCellCaption[0] = "사번";
            e.PopupPassData.GridCellCaption[1] = "이름";
            e.PopupPassData.GridCellCaption[2] = "부서";


            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
            */
            string[] param_array = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName };
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup_KO883";
            e.PopupPassData.PopupWinTitle = "Name/Employee No. Query Popup";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;
            e.PopupPassData.Data = param_array;

            e.PopupPassData.UserParameters = new string[5];
            e.PopupPassData.UserParameters[0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[1] = "''";
            e.PopupPassData.UserParameters[2] = uniBase.UCommon.FilterVariable(this.popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[3] = uniBase.UCommon.FilterVariable(this.popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[4] = " ";



        }


        private void popEmpNo_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popEmpNo.CodeValue = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
            popEmpNo.CodeName = iDataSet.Tables[0].Rows[0]["name"].ToString();


        }


        private void popEmpNo_OnChange(object sender, EventArgs e)
        {
            DataSet rtnDs = new DataSet();
            string sSQL = string.Format(@"

Declare @PARAM Nvarchar(13)
Set @PARAM = {0}
Select EMP_NO, NAME From HAA010T(Nolock)
WHERE (HAA010T.EMP_NO like  @PARAM +'%' or HAA010T.NAME LIKE '%' + @PARAM + '%')    "

                , uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));

            rtnDs = uniBase.UDataAccess.CommonQuerySQL(sSQL);

            if (rtnDs == null || rtnDs.Tables.Count == 0 || rtnDs.Tables[0].Rows.Count == 0)
            {
                popEmpNo.CodeValue = "";
                popEmpNo.CodeName = "";
            }
            else
            {
                if (rtnDs.Tables[0].Rows.Count == 1)
                {
                    popEmpNo.CodeValue = rtnDs.Tables[0].Rows[0]["EMP_NO"].ToString().Trim();
                    popEmpNo.CodeName = rtnDs.Tables[0].Rows[0]["NAME"].ToString().Trim();
                }
                else
                {
                    if (popEmpNo.CodeValue.Trim() == "")
                    {
                        popEmpNo.CodeValue = "";
                        popEmpNo.CodeName = "";
                    }
                    else
                    {
                        this.popEmpNo.uniButton_Click(null, null);
                    }
                }
            }
        }


        private void popProdReqNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            string[] sParam = new string[2];

            sParam[0] = txtPrNo.Text;
            sParam[1] = popReqPrsn.CodeName.ToString().Trim();

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.M2111P1_KO883";
            e.PopupPassData.PopupWinTitle = "구매의뢰번호";
            e.PopupPassData.PopupWinWidth = 871;
            e.PopupPassData.PopupWinHeight = 680;

            e.PopupPassData.Data = sParam;

        }

        private void popProdReqNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            if (iDataSet.Tables[0].Rows[0]["pr_req_no"].ToString() != "" || iDataSet.Tables[0].Rows[0]["pr_req_no"].ToString() != null)
            {
                popProdReqNo.CodeValue = iDataSet.Tables[0].Rows[0]["pr_req_no"].ToString();
            }
        }

        private void popReqDept_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "P/R Dept.";
            e.PopupPassData.ConditionCaption = "P/R Dept.";

            e.PopupPassData.SQLFromStatements = "B_ACCT_DEPT(NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = this.popReqDept.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "ORG_CHANGE_ID= " + uniBase.UCommon.FilterVariable(CommonVariable.gChangeOrgId, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "dept_cd";
            e.PopupPassData.GridCellCode[1] = "dept_nm";

            e.PopupPassData.GridCellCaption[0] = "P/R Dept.";
            e.PopupPassData.GridCellCaption[1] = "P/R Dept. Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popReqDept_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            this.popReqDept.CodeValue = iDataSet.Tables[0].Rows[0]["DEPT_CD"].ToString();
            this.popReqDept.CodeName = iDataSet.Tables[0].Rows[0]["DEPT_NM"].ToString();
        }

        private void popPlantCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            string[] param_array = new string[] { popPlantCd.CodeValue, popPlantCd.CodeName };
            e.PopupPassData.PopupWinTitle = "Plant";
            e.PopupPassData.ConditionCaption = "Plant";

            e.PopupPassData.SQLFromStatements = "B_Plant(NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = this.popPlantCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "Plant_CD";
            e.PopupPassData.GridCellCode[1] = "Plant_NM";

            e.PopupPassData.GridCellCaption[0] = "Plant";
            e.PopupPassData.GridCellCaption[1] = "Plant Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popPlantCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            this.popPlantCd.CodeValue = iDataSet.Tables[0].Rows[0]["Plant_CD"].ToString();
            this.popPlantCd.CodeName = iDataSet.Tables[0].Rows[0]["Plant_NM"].ToString();
        }

        private void popReqPrsn_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            string[] param_array = new string[] { popReqPrsn.CodeValue, popReqPrsn.CodeName };
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup_KO883";
            e.PopupPassData.PopupWinTitle = "Name/Employee No. Query Popup";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;
            e.PopupPassData.Data = param_array;

            e.PopupPassData.UserParameters = new string[5];
            e.PopupPassData.UserParameters[0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[1] = "''";
            e.PopupPassData.UserParameters[2] = uniBase.UCommon.FilterVariable(this.popReqPrsn.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[3] = uniBase.UCommon.FilterVariable(this.popReqPrsn.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[4] = " ";

        }

        private void popReqPrsn_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popReqPrsn.CodeValue = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
            popReqPrsn.CodeName = iDataSet.Tables[0].Rows[0]["name"].ToString();
            selected_emp_biz_area_cd = iDataSet.Tables[0].Rows[0]["biz_area_cd"].ToString();
        }

        private void popPurOrz_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Purchase Organization";
            e.PopupPassData.ConditionCaption = "Purchase Organization";

            e.PopupPassData.SQLFromStatements = "B_Pur_Org(nolock)";
            e.PopupPassData.SQLWhereInputCodeValue = this.popPurOrz.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "usage_flg = 'Y'";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "PUR_ORG";
            e.PopupPassData.GridCellCode[1] = "PUR_ORG_NM";

            e.PopupPassData.GridCellCaption[0] = "Purchase Organization";
            e.PopupPassData.GridCellCaption[1] = "Purchase Organization Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popPurOrz_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            this.popPurOrz.CodeValue = iDataSet.Tables[0].Rows[0]["PUR_ORG"].ToString();
            this.popPurOrz.CodeName = iDataSet.Tables[0].Rows[0]["PUR_ORG_NM"].ToString();
        }

        private void uniGrid1_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            int selectedRowIndex = uniGrid1.ActiveRow.Index;
            string columnName = uniGrid1.ActiveCell.Column.Key;

            string icodeValue = uniGrid1.ActiveCell.Text;
            string ipopupWinTitle = string.Empty;
            string iconditionCaption = string.Empty;
            string iSQLFromStatements = string.Empty;
            string iSQLWhereStatements = string.Empty;
            string iGridCellCode1 = string.Empty;
            string iGridCellCode2 = string.Empty;
            string iGridCellCode3 = string.Empty;

            string iGridCellCode4 = string.Empty;

            string iGridCellCaption1 = string.Empty;
            string iGridCellCaption2 = string.Empty;
            string iGridCellCaption3 = string.Empty;

            string iGridCellCaption4 = string.Empty;


            switch (columnName)
            {
                case "item_cd":
                    //if (uniGrid1.Rows[selectedRowIndex].Cells["ITEM_CD"].Value.ToString() == "")
                    //{
                    //    uniBase.UMessage.DisplayMessageBox("17a003", MessageBoxButtons.OK, popPlantCd.uniALT);
                    //    return;
                    //}

                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.B1B11PA3";
                    e.PopupPassData.PopupWinTitle = "Item by Plant Popup";
                    e.PopupPassData.PopupWinWidth = 871;
                    e.PopupPassData.PopupWinHeight = 680;

                    DataSet ds = new DataSet();
                    DataTable dt = new DataTable();

                    dt.Columns.Add("PlantCd");
                    dt.Columns.Add("ItemCd");
                    dt.Columns.Add("Param3");
                    dt.Columns.Add("Param4");
                    dt.Columns.Add("Param5");
                    dt.Columns.Add("Param6");

                    DataRow dr = dt.NewRow();
                    if (uniGrid1.Rows[selectedRowIndex].Cells["plant_cd"].Value.ToString().Length > 0)
                    {
                        dr["PlantCd"] = uniGrid1.Rows[selectedRowIndex].Cells["plant_cd"].Value.ToString();
                    }
                    else
                    {
                        dr["PlantCd"] = "";
                    }
                    if (uniGrid1.Rows[selectedRowIndex].Cells["item_cd"].Value.ToString().Length > 0)
                    {
                        dr["ItemCd"] = uniGrid1.Rows[selectedRowIndex].Cells["item_cd"].Value.ToString();
                    }
                    else
                    {
                        dr["ItemCd"] = "";
                    }

                    dr["Param3"] = "!";
                    dr["Param4"] = "30!P";
                    dr["Param5"] = "";
                    dr["Param6"] = "";

                    dt.Rows.Add(dr);
                    ds.Tables.Add(dt);

                    e.PopupPassData.Data = ds;
                    break;

                case "tracking_no":
                    ipopupWinTitle = "Tracking No.";
                    iconditionCaption = "Tracking No.";
                    iSQLFromStatements = "s_so_tracking(nolock) a left join pms_project(nolock) b on a.tracking_no = b.project_code left join b_item (nolock) c on a.item_cd = c.item_cd";
                    iSQLWhereStatements = " ";
                    iGridCellCode1 = "a.Tracking_No";
                    iGridCellCode2 = "c.Item_nm";
                    iGridCellCode3 = "a.item_cd";
                    iGridCellCode4 = "b.project_nm";

                    iGridCellCaption1 = "Tracking No.";
                    iGridCellCaption2 = "Item Desc.";
                    iGridCellCaption3 = "Item";
                    iGridCellCaption4 = "Project Desc.";

                    e.PopupPassData.PopupWinWidth = 800;
                    e.PopupPassData.PopupWinHeight = 600;


                    break;

                case "sl_cd":
                    ipopupWinTitle = "Receipt S/L";
                    iconditionCaption = "Receipt S/L";
                    iSQLFromStatements = "B_STORAGE_LOCATION (nolock)";
                    iSQLWhereStatements = " plant_cd = " + uniBase.UCommon.FilterVariable(popPlantCd.CodeValue.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

                    iGridCellCode1 = "SL_CD";
                    iGridCellCode2 = "SL_NM";
                    iGridCellCaption1 = "Receipt S/L";
                    iGridCellCaption2 = "Receipt S/L Name";
                    break;

                case "use_type": //ips에서 데이터 이관
                    ipopupWinTitle = "Use.";
                    iconditionCaption = "Use";
                    iSQLFromStatements = "B_MINOR(nolock)";
                    iSQLWhereStatements = "major_cd = 'ZZ02'";
                    iGridCellCode1 = "MINOR_CD";
                    iGridCellCode2 = "MINOR_NM";
                    iGridCellCaption1 = "MINOR_CD";
                    iGridCellCaption2 = "MINOR_NM";
                    break;

                case "pallet_no": //ips에서 데이터 일부 이관
                    ipopupWinTitle = "Pallet No.";
                    iconditionCaption = "Pallet No.";
                    iSQLFromStatements = "B_MINOR(nolock)";
                    iSQLWhereStatements = "major_cd = 'ZP001'";
                    iGridCellCode1 = "MINOR_CD";
                    iGridCellCode2 = "MINOR_NM";
                    iGridCellCaption1 = "MINOR_CD";
                    iGridCellCaption2 = "MINOR_NM";
                    break;
                //Add by, SEH (180628) 설계변경번호 팝업
                case "ext1_cd": 
                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.P1410PA1";
                    e.PopupPassData.PopupWinTitle = "설계변경번호 Popup";
                    e.PopupPassData.PopupWinWidth = 800;
                    e.PopupPassData.PopupWinHeight = 600;
                    e.PopupPassData.Data = uniGrid1.ActiveRow.Cells["ext1_cd"].Value.ToString().Trim();
                    break;
            }

            if (columnName.Trim().Equals("tracking_no"))
            {
                e.PopupPassData.PopupWinTitle = ipopupWinTitle;
                e.PopupPassData.ConditionCaption = iconditionCaption;

                e.PopupPassData.SQLFromStatements = iSQLFromStatements;
                e.PopupPassData.SQLWhereStatements = iSQLWhereStatements;

                e.PopupPassData.SQLWhereInputCodeValue = icodeValue;
                e.PopupPassData.SQLWhereInputNameValue = "";

                e.PopupPassData.DistinctOrNot = true;

                e.PopupPassData.GridCellCode = new String[4];
                e.PopupPassData.GridCellCaption = new String[4];
                e.PopupPassData.GridCellType = new enumDef.GridCellType[4];
                e.PopupPassData.GridCellLength = new Int32[4];

                e.PopupPassData.GridCellCode[0] = iGridCellCode1;
                e.PopupPassData.GridCellCode[1] = iGridCellCode2;
                e.PopupPassData.GridCellCode[2] = iGridCellCode3;
                e.PopupPassData.GridCellCode[3] = iGridCellCode4;

                e.PopupPassData.GridCellCaption[0] = iGridCellCaption1;
                e.PopupPassData.GridCellCaption[1] = iGridCellCaption2;
                e.PopupPassData.GridCellCaption[2] = iGridCellCaption3;
                e.PopupPassData.GridCellCaption[3] = iGridCellCaption4;

                e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
                e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
                e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;

                e.PopupPassData.GridCellLength[0] = 100;
                e.PopupPassData.GridCellLength[1] = 150;
                e.PopupPassData.GridCellLength[2] = 200;
                e.PopupPassData.GridCellLength[3] = 200;
            }
            else
            {
                e.PopupPassData.PopupWinTitle = ipopupWinTitle;
                e.PopupPassData.ConditionCaption = iconditionCaption;

                e.PopupPassData.SQLFromStatements = iSQLFromStatements;
                e.PopupPassData.SQLWhereStatements = iSQLWhereStatements;

                e.PopupPassData.SQLWhereInputCodeValue = icodeValue;
                e.PopupPassData.SQLWhereInputNameValue = "";

                e.PopupPassData.DistinctOrNot = true;

                e.PopupPassData.GridCellCode = new String[2];
                e.PopupPassData.GridCellCaption = new String[2];
                e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
                e.PopupPassData.GridCellLength = new Int32[2];

                e.PopupPassData.GridCellCode[0] = iGridCellCode1;
                e.PopupPassData.GridCellCode[1] = iGridCellCode2;

                e.PopupPassData.GridCellCaption[0] = iGridCellCaption1;
                e.PopupPassData.GridCellCaption[1] = iGridCellCaption2;

                e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            }
        }

        private void uniGrid1_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            int selectedRowIndex = uniGrid1.ActiveRow.Index;
            string columnName = uniGrid1.ActiveCell.Column.Key;
            string columnNameForName = string.Empty;
            string iGridCellCode1 = string.Empty;
            string iGridCellCode2 = string.Empty;
            string iGridCellCode3 = string.Empty;
            string iGridCellCode4 = string.Empty;


            switch (columnName)
            {
                case "plant_cd":

                    iGridCellCode1 = "plant_cd";
                    break;
                case "item_cd":
                    columnNameForName = "item_nm";
                    iGridCellCode1 = "item_cd";
                    iGridCellCode2 = "item_nm";
                    iGridCellCode3 = "spec";
                    
                    
                    break;
                case "use_type":
                    columnNameForName = "use_type_nm";
                    iGridCellCode1 = "minor_cd";
                    iGridCellCode2 = "minor_nm";
                    break;
                case "pallet_no":
                    columnNameForName = "pallet_nm";
                    iGridCellCode1 = "minor_cd";
                    iGridCellCode2 = "minor_nm";
                    break;
                case "req_unit":
                    columnNameForName = "req_unit";
                    iGridCellCode1 = "req_unit";
                    break;
                case "sl_cd":
                    columnNameForName = "sl_nm";
                    iGridCellCode1 = "sl_cd";
                    iGridCellCode2 = "sl_nm";
                    break;
                case "tracking_no":
                    columnNameForName = "tracking_no";
                    iGridCellCode1 = "tracking_no";
                    break;
                //Add by, SEH (180628) 설계변경번호 팝업
                case "ext1_cd":
                    columnNameForName = "ecn_desc";
                    iGridCellCode1 = "ext1_cd";
                    iGridCellCode2 = "ecn_desc";
                    iGridCellCode3 = "reason_cd";
                    iGridCellCode4 = "reason_nm";


                    /*
                    if (e.ResultData.Data == null)
                        return;

                    DataSet iqtDataSet = (DataSet)e.ResultData.Data;
                    uniGrid1.Rows[uniGrid1.ActiveRow.Index].Cells[cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.ext1_cdColumn.ColumnName].Value = iqtDataSet.Tables[0].Rows[0]["ecn_no"].ToString();
                    uniGrid1.Rows[uniGrid1.ActiveRow.Index].Cells[cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.ecn_descColumn.ColumnName].Value = iqtDataSet.Tables[0].Rows[0]["ecn_desc"].ToString();
                    uniGrid1.Rows[uniGrid1.ActiveRow.Index].Cells[cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.reason_cdColumn.ColumnName].Value = iqtDataSet.Tables[0].Rows[0]["reason_cd"].ToString();
                    uniGrid1.Rows[uniGrid1.ActiveRow.Index].Cells[cqtdsM2111M4_KO883.E_M2111M4_KO883_Multi_Query.reason_nmColumn.ColumnName].Value = iqtDataSet.Tables[0].Rows[0]["issuedby"].ToString();
                     */
                     break; 

                default:
                    break;
            }

            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            //uniGrid1.ActiveRow.Cells[columnName].Value = iDataSet.Tables[0].Rows[0][iGridCellCode1].ToString();

            //if(columnName.Equals("item_cd"))
            //{
            //    Check_TrackingFiled(iDataSet.Tables[0].Rows[0]["item_cd"].ToString(), uniGrid1.ActiveRow.Cells["plant_cd"].ToString());
            //}

            //Modified by YangQizhong , 2008-3-20
            if (iGridCellCode1 != "req_unit" && iGridCellCode1 != "ext1_cd")
            {
                uniBase.UGrid.SetGridValue(uniGrid1, columnName, uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0][iGridCellCode1].ToString());
                
            }
            else if (iGridCellCode1 == "req_unit")
            {
                uniBase.UGrid.SetGridValue(uniGrid1, columnName, uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["unit"].ToString());
            }
            else
            {
                uniBase.UGrid.SetGridValue(uniGrid1, columnName, uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["ecn_no"].ToString());
            }

            if (iGridCellCode2 != string.Empty)
            {
                uniBase.UGrid.SetGridValue(uniGrid1, columnNameForName, uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0][iGridCellCode2].ToString()); //iDataSet.Tables[0].Rows[0][iGridCellCode2].ToString();
            }

            //품목 spec & 설계변경번호 EXT1_CD
            if (iGridCellCode3 != string.Empty)
            {
                uniBase.UGrid.SetGridValue(uniGrid1, iGridCellCode3, uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0][iGridCellCode3].ToString()); //iDataSet.Tables[0].Rows[0][iGridCellCode2].ToString();
            }

            //설계변경번호 EXT1_CD
            if (iGridCellCode4 != string.Empty)
            {
                uniBase.UGrid.SetGridValue(uniGrid1, iGridCellCode4, uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["issuedby"].ToString()); //iDataSet.Tables[0].Rows[0][iGridCellCode2].ToString();
            }

            uniGrid1_AfterExitEditMode_1(sender, e);
          
        }

        //부품영업참조 
        private void lblUnitSalesGrpRef_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            //조회한 후 실행 불가 ("신규에서만 참조 가능합니다." 메세지출력)
            if (this.viewDBSaveMode != enumDef.DBSaveMode.CreateMode)
            {
                // 조회를 먼저 하십시오.
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "신규에서만 참조 가능합니다.");
                e.Cancel = true;
                return;
            }


            //상단필수값 입력확인
            //공장필수
            if (popPlantCd.CodeValue == null || popPlantCd.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "공장을 입력하세요.");
                e.Cancel = true;
                return;
            }

            //요청부서필수
            else if (popReqDept.CodeValue == null || popReqDept.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "요청부서를 입력하세요.");
                e.Cancel = true;
                return;
            }

            //요청자필수
            else if (popReqPrsn.CodeValue == null || popReqPrsn.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "요청자를 입력하세요.");
                e.Cancel = true;
                return;
            }

            //구매조직필수
            else if (popPurOrz.CodeValue == null || popPurOrz.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "구매조직을 입력하세요.");
                e.Cancel = true;
                return;
            }

            //요청일자 필수
            else if (dtReqDt.Value == null)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "요청일자를 입력하세요.");
                e.Cancel = true;
                return;
            }

            //행추가 확인
            else if (uniGrid1.Rows.Count <= 0)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "행추가 후 작업을 진행하세요");
                e.Cancel = true;
                return;
            }

            //필요일자 필수
            //(2018-06-07) 싱글그리드로 올림으로서 주석처리
            //else if (uniGrid1.ActiveRow.Cells["dlvy_dt"].Value.ToString() == null || uniGrid1.ActiveRow.Cells["dlvy_dt"].Value.ToString() == "")
            //{
            //    uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "필요일자를 입력하세요.");
            //    e.Cancel = true;
            //    return;
            //}

            //품목필수
            else if (uniGrid1.ActiveRow.Cells["item_cd"].Value.ToString() == null || uniGrid1.ActiveRow.Cells["item_cd"].Value.ToString() == "")
            {
                uniBase.UMessage.DisplayMessageBox("173133", MessageBoxButtons.OK, "Item");
                popProdReqNo.Focus();
                e.Cancel = true;
                return;
            }

            else
            {
                string strPlantCd = popPlantCd.CodeValue.ToString().Trim();
                string strItemCd = uniGrid1.ActiveRow.Cells["item_cd"].Value.ToString().Trim();
                string strTrackingNo = uniGrid1.ActiveRow.Cells["tracking_no"].Value.ToString().Trim();
                string strNeedQty = uniGrid1.ActiveRow.Cells["req_qty"].Value.ToString().Trim();
                string strPlantNm = popPlantCd.CodeName.ToString().Trim();
                string strItemNm = uniGrid1.ActiveRow.Cells["item_nm"].Value.ToString().Trim();



                //Tracking No 필수
                if (strTrackingNo == null || strTrackingNo == "")
                {
                    uniBase.UMessage.DisplayMessageBox("173133", MessageBoxButtons.OK, "Tracking No.");
                    popProdReqNo.Focus();
                    e.Cancel = true;
                    return;
                }

                //수량필수
                else if (strNeedQty == "0" || strNeedQty == "0.00")
                {
                    uniBase.UMessage.DisplayMessageBox("173133", MessageBoxButtons.OK, "요청수량");
                    popProdReqNo.Focus();
                    e.Cancel = true;
                    return;
                }

                e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.M2111R1_KO883";
                e.PopupPassData.PopupWinTitle = "부품영업참조";
                e.PopupPassData.PopupWinWidth = 760;
                e.PopupPassData.PopupWinHeight = 420;

                string[] arrParam = new string[6];
                arrParam[0] = strPlantCd;
                arrParam[1] = strItemCd;
                arrParam[2] = strTrackingNo;
                arrParam[3] = strNeedQty;
                arrParam[4] = strPlantNm;
                arrParam[5] = strItemNm;

                e.PopupPassData.Data = arrParam;
            }

        }

        //부품영업참조에서 선택된 row 메인그리드에 행추가 
        private void lblUnitSalesGrpRef_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            //if (e.ResultData.Data == null)
            //{
            //    this.txtIvNo1.Focus();
            //    return;
            //}

            DataSet iDataSet = new DataSet();
            iDataSet = (DataSet)e.ResultData.Data;

            int i = 0;

            if (iDataSet == null || iDataSet.Tables.Count == 0 || iDataSet.Tables[i].Rows.Count == 0)
            {
                uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                //return false; 
            }
            else if (iDataSet.Tables[0].Rows.Count >= 1)
            {
                //OnPreFncInsertRow(); //행추가  
                for (int h = 0; h < iDataSet.Tables[i].Rows.Count; h++)
                {
                    OnPreFncInsertRow();

                    uniGrid1.ActiveRow.Cells["plant_cd"].Value = iDataSet.Tables[0].Rows[h]["PLANT_CD"].ToString(); //공장명                    
                    uniGrid1.ActiveRow.Cells["item_cd"].Value = iDataSet.Tables[0].Rows[h]["CHILD_ITEM_CD"].ToString();   //품목코드
                    uniGrid1.ActiveRow.Cells["item_nm"].Value = iDataSet.Tables[0].Rows[h]["ITEM_NM"].ToString();   //품목명
                    uniGrid1.ActiveRow.Cells["spec"].Value = iDataSet.Tables[0].Rows[h]["SPEC"].ToString();         //규격
                    uniGrid1.ActiveRow.Cells["req_qty"].Value = iDataSet.Tables[0].Rows[h]["CHILD_ITEM_QTY"];        //필요수량?? 요청수량??
                    uniGrid1.ActiveRow.Cells["basic_unit"].Value = iDataSet.Tables[0].Rows[h]["BASIC_UNIT"].ToString(); //기본단위   
                    uniGrid1.ActiveRow.Cells["tracking_no"].Value = iDataSet.Tables[0].Rows[h]["TRACKING_NO"].ToString();
                    uniGrid1.ActiveRow.Cells["dlvy_dt"].Value = uniGrid1.Rows[0].Cells["dlvy_dt"].Value; //필요일자 첫번째 로우로 세팅 
                }
            } i++;
        }


        //출고요청참조
        private void lblDvlyReqRef_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (this.viewDBSaveMode != enumDef.DBSaveMode.CreateMode)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "신규에서만 참조 가능합니다.");
                e.Cancel = true;
                return;
            }

            if (popPlantCd.CodeValue == null || popPlantCd.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("173133", MessageBoxButtons.OK, popPlantCd.uniALT);
                e.Cancel = true;
                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.M2111R2_KO883";
            e.PopupPassData.PopupWinTitle = "출고요청참조";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 450;

            string[] arrParam = new string[6];
            arrParam[0] = popPlantCd.CodeValue;
            arrParam[1] = popPlantCd.CodeName;
            arrParam[2] = popReqDept.CodeValue;
            arrParam[3] = popReqDept.CodeName;
            arrParam[4] = popReqPrsn.CodeValue;
            arrParam[5] = popReqPrsn.CodeName;

            e.PopupPassData.Data = arrParam;
        }

        //참조에서 선택된 row 메인그리드에 행추가 
        private void lblDvlyReqRef_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            //if (e.ResultData.Data == null)
            //{
            //    this.txtIvNo1.Focus();
            //    return;
            //}

            DataSet iDataSet = new DataSet();
            iDataSet = (DataSet)e.ResultData.Data;

            int i = 0;

            if (iDataSet == null || iDataSet.Tables.Count == 0 || iDataSet.Tables[i].Rows.Count == 0)
            {
                uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                //return false; 
            }
            else if (iDataSet.Tables[0].Rows.Count >= 1)
            {
                //기존행이있을때 뒤로 붙이기
                //int j = uniGrid1.Rows.Count - 1; 
                //uniGrid1.setFocusCell(0, j);

                //OnPreFncInsertRow(); //행추가  
                for (int h = 0; i < iDataSet.Tables[0].Rows.Count; h++)
                {
                    OnPreFncInsertRow();

                    uniGrid1.ActiveRow.Cells["item_cd"].Value = iDataSet.Tables[0].Rows[h]["item_cd"].ToString();
                    uniGrid1.ActiveRow.Cells["item_nm"].Value = iDataSet.Tables[0].Rows[h]["item_nm"].ToString();
                    uniGrid1.ActiveRow.Cells["spec"].Value = iDataSet.Tables[0].Rows[h]["spec"].ToString();
                    uniGrid1.ActiveRow.Cells["basic_unit"].Value = iDataSet.Tables[0].Rows[h]["basic_unit"].ToString();
                    uniGrid1.ActiveRow.Cells["req_qty"].Value = iDataSet.Tables[0].Rows[h]["iss_req_qty"].ToString();
                    uniGrid1.ActiveRow.Cells["pr_no"].Value = iDataSet.Tables[0].Rows[h]["iss_req_no"].ToString();
                    uniGrid1.ActiveRow.Cells["tracking_no"].Value = iDataSet.Tables[0].Rows[h]["tracking_no"].ToString();
                    uniGrid1.ActiveRow.Cells["pallet_no"].Value = iDataSet.Tables[0].Rows[h]["pallet_no"].ToString();
                    uniGrid1.ActiveRow.Cells["remark"].Value = iDataSet.Tables[0].Rows[h]["remark"].ToString();
                    i++;
                }
            }
        }

        private void lblBomRef_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            if (this.viewDBSaveMode != enumDef.DBSaveMode.CreateMode)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "신규에서만 참조 가능합니다.");
                e.Cancel = true;
                return;
            }

            if (popPlantCd.CodeValue == null || popPlantCd.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("173133", MessageBoxButtons.OK, popPlantCd.uniALT);
                e.Cancel = true;
                return;
            }

            //string strPrntItemCd = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.item_cdColumn.ColumnName].Value.ToString();
            //string strPrntItemNm = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.item_nmColumn.ColumnName].Value.ToString();
            //string strTrackingNo = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.tracking_noColumn.ColumnName].Value.ToString();
            //string strWcCd = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.wc_cdColumn.ColumnName].Value.ToString();
            //string strRcptSlCd = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.sl_cdColumn.ColumnName].Value.ToString();
            //string strRcptSlNm = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.sl_nmColumn.ColumnName].Value.ToString();

            string[] arrParam = new string[8];
            arrParam[0] = popPlantCd.CodeValue.Trim();
            arrParam[1] = popPlantCd.CodeName.Trim();
            arrParam[2] = "";
            arrParam[3] = "";
            arrParam[4] = "";
            arrParam[5] = "1";//bom유형  

            arrParam[6] = "";//출고창고                 
            arrParam[7] = "";//출고창고명    

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.P4311R3_KO883";
            e.PopupPassData.PopupWinTitle = "BOM Copy";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 600;

            e.PopupPassData.Data = arrParam;
        }

        private void lblBomRef_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {

            DataSet iDataSet = new DataSet();
            iDataSet = (DataSet)e.ResultData.Data;

            int i = 0;

            if (iDataSet == null || iDataSet.Tables.Count == 0 || iDataSet.Tables[i].Rows.Count == 0)
            {
                uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                //return false; 
            }
            else if (iDataSet.Tables[0].Rows.Count >= 1)
            {
                for (int h = 0; i < iDataSet.Tables[0].Rows.Count; h++)
                {
                    OnPreFncInsertRow();

                    uniGrid1.ActiveRow.Cells["item_cd"].Value = iDataSet.Tables[0].Rows[h]["child_item_cd"].ToString();
                    uniGrid1.ActiveRow.Cells["item_nm"].Value = iDataSet.Tables[0].Rows[h]["item_nm"].ToString();
                    uniGrid1.ActiveRow.Cells["spec"].Value = iDataSet.Tables[0].Rows[h]["spec"].ToString();
                    uniGrid1.ActiveRow.Cells["basic_unit"].Value = iDataSet.Tables[0].Rows[h]["basic_unit"].ToString();
                    uniGrid1.ActiveRow.Cells["req_qty"].Value = iDataSet.Tables[0].Rows[h]["child_item_qty"].ToString();
                    uniGrid1.ActiveRow.Cells["tracking_no"].Value = iDataSet.Tables[0].Rows[h]["project_code"].ToString();
                    uniGrid1.ActiveRow.Cells["ext1_cd"].Value = iDataSet.Tables[0].Rows[h]["ecn_no"].ToString();
                    uniGrid1.ActiveRow.Cells["ecn_desc"].Value = iDataSet.Tables[0].Rows[h]["ecn_desc"].ToString();
                    uniGrid1.ActiveRow.Cells["reason_cd"].Value = iDataSet.Tables[0].Rows[h]["reason_cd"].ToString();
                    uniGrid1.ActiveRow.Cells["reason_nm"].Value = iDataSet.Tables[0].Rows[h]["reason_desc"].ToString();
                    uniGrid1.ActiveRow.Cells["ext4_cd_ko883"].Value = iDataSet.Tables[0].Rows[h]["remark"].ToString();
                    uniGrid1.ActiveRow.Cells["sl_cd"].Value = iDataSet.Tables[0].Rows[h]["sl_cd"].ToString();
                    uniGrid1.ActiveRow.Cells["sl_nm"].Value = iDataSet.Tables[0].Rows[h]["sl_nm"].ToString();

                    i++;
                }
            }
            
        }

        private void uniGrid1_AfterExitEditMode_1(object sender, EventArgs e)
        {
            if (uniGrid1.ActiveRow == null || uniGrid1.ActiveCell == null)
            {
                return;
            }

            string columnName = uniGrid1.ActiveCell.Column.Key;
            if(columnName.ToUpper().Equals("ITEM_CD"))
            {
                Check_TrackingFiled(uniGrid1.ActiveRow.Cells["item_cd"].Value.ToString(), uniGrid1.ActiveRow.Cells["plant_cd"].Value.ToString());
            }
            // 2011-08-23 modify by kim woo hyun 공장이나 품목 변경시만 호출
            switch (columnName.ToUpper())
            {
                case "ITEM_CD":
                   
                case "PLANT_CD":
                    if (uniGrid1.ActiveRow.Cells["plant_cd"].Value.ToString() != "")
                    {
                        if (uniGrid1.ActiveRow.Cells["item_cd"].Value.ToString() != "")
                        {
                            ChangePurUnit(uniGrid1.ActiveRow.Cells["plant_cd"].Value.ToString(), uniGrid1.ActiveRow.Cells["item_cd"].Value.ToString());
                        }
                    }
                    break;
                //Add by, SEH (180628)
                case "EXT1_CD":

                    if (uniGrid1.ActiveRow.Cells["ext1_cd"].Value.ToString().Length == 0)
                        return;
                    StringBuilder istrBuilder = new StringBuilder();
                    istrBuilder.Append("SELECT ECN_NO, ECN_DESC, REASON_CD, dbo.ufn_getcodename('P1402', REASON_CD ) REASON_NM FROM P_ECN_MASTER ");
                    istrBuilder.AppendFormat("WHERE ECN_NO = '{0}'", uniGrid1.ActiveRow.Cells["ext1_cd"].Value.ToString());

                    DataSet iqttdsECNNo = null;
                    try
                    {
                        iqttdsECNNo = uniBase.UDataAccess.CommonQuerySQL(istrBuilder.ToString());
                        if (iqttdsECNNo == null || iqttdsECNNo.Tables.Count == 0 || iqttdsECNNo.Tables[0].Rows.Count == 0)
                            return;
                    }
                    catch (Exception ex)
                    {
                        bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                        if (reThrow)
                            throw;
                        return;
                    }

                    uniGrid1.ActiveRow.Cells["ecn_desc"].Value = iqttdsECNNo.Tables[0].Rows[0]["ECN_DESC"].ToString();
                    uniGrid1.ActiveRow.Cells["reason_cd"].Value = iqttdsECNNo.Tables[0].Rows[0]["REASON_CD"].ToString();
                    uniGrid1.ActiveRow.Cells["reason_nm"].Value = iqttdsECNNo.Tables[0].Rows[0]["REASON_NM"].ToString();

                    break;

                case "TRACKING_NO":

                    if (uniGrid1.ActiveRow.Cells["TRACKING_NO"].Value.ToString().Length == 0)
                        return;
                    StringBuilder istrBuilder2 = new StringBuilder();
                    istrBuilder2.Append("select distinct tracking_no   from s_so_tracking(nolock) ");
                    istrBuilder2.AppendFormat("WHERE TRACKING_NO = '{0}'", uniGrid1.ActiveRow.Cells["TRACKING_NO"].Value.ToString());

                    DataSet iqttdsECNNo2 = null;
                    try
                    {
                        iqttdsECNNo2 = uniBase.UDataAccess.CommonQuerySQL(istrBuilder2.ToString());
                        if (iqttdsECNNo2 == null || iqttdsECNNo2.Tables.Count == 0 || iqttdsECNNo2.Tables[0].Rows.Count == 0)
                        {
                            uniGrid1.ActiveRow.Cells["tracking_no"].Value = string.Empty;
                            uniGrid1.BeforePopupOpenEvent();
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                        if (reThrow)
                            throw;
                        return;
                    }

                    uniGrid1.ActiveRow.Cells["TRACKING_NO"].Value = iqttdsECNNo2.Tables[0].Rows[0]["TRACKING_NO"].ToString();

                    break;

                default:
                    break;
            }
        }

        private void ChangePurUnit(string plant_cd, string item_cd)
        {
            StringBuilder sbSQL = new StringBuilder();
            DataSet ds = null;
            sbSQL.Remove(0, sbSQL.Length);
            sbSQL.Append(" Select b.item_nm, b.spec, a.order_unit_pur,isnull(X.RECV_INSPEC_FLG,'N') as flag from b_item_by_plant a inner join b_item b on a.item_cd = b.item_cd INNER JOIN B_ITEM_BY_PLANT X(NOLOCK) ON A.ITEM_CD = X.ITEM_CD  where a.plant_cd= '" + plant_cd + "' " + " and a.item_cd ='" + item_cd + "'");
            ds = uniBase.UDataAccess.CommonQuerySQL(sbSQL.ToString());

            // 2011-08-22 modify by kim woo hyun ds 내용이 없는경우도 있음
            if (ds.Tables[0].Rows.Count < 1 || ds.Tables[0].Rows[0][0] == System.DBNull.Value
                || (ds.Tables[0].Rows.Count > 0 && ds.Tables[0].Rows[0][0].ToString() == ""))
            {
            }
            else
            {
                //uniGrid1.ActiveRow.Cells["pur_unit"].Value = ds.Tables[0].Rows[0]["order_unit_pur"].ToString();
                uniGrid1.ActiveRow.Cells["item_nm"].Value = ds.Tables[0].Rows[0]["item_nm"].ToString();
                uniGrid1.ActiveRow.Cells["spec"].Value = ds.Tables[0].Rows[0]["spec"].ToString();
                uniGrid1.ActiveRow.Cells["basic_unit"].Value = ds.Tables[0].Rows[0]["order_unit_pur"].ToString();
                uniGrid1.ActiveRow.Cells["flag"].Value = ds.Tables[0].Rows[0]["flag"].ToString();
            }

        }

        private void uniButton1_Click(object sender, EventArgs e)
        {
            if (this.viewDBSaveMode == enumDef.DBSaveMode.CreateMode)
            {
                // 조회를 먼저 하십시오.
                uniBase.UMessage.DisplayMessageBox("900002", MessageBoxButtons.OK);
                return;
            }

            if (txtPrNo.Text.Trim().Length < 1)
            {
                // %1 발주일반정보  데이터가 존재하지 않습니다.
                uniBase.UMessage.DisplayMessageBox("173100", MessageBoxButtons.OK);
                txtPrNo.Focus();
                return;
            }

            if (uniGrid1.Rows.Count == 0)
            {
                // 승인할 DATA가 없습니다.
                uniBase.UMessage.DisplayMessageBox("187738", MessageBoxButtons.OK);
                return;
            }

            if (popEmpNo.CodeValue.ToString().Trim() == "" || popEmpNo.CodeValue.ToString().Trim() == null)
            {//사번을 확인하십시요
                uniBase.UMessage.DisplayMessageBox("800478", MessageBoxButtons.OK);
                return;
            }

            DataSet ds = uniBase.UDataAccess.CommonQuerySQL(string.Format(@"
                            select top 1 emp_no from HAA010T (nolock)
                            where emp_no = {0}"
                       , uniBase.UCommon.FilterVariable(popEmpNo.CodeValue.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));

            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
            {//사번을 확인하십시요
                uniBase.UMessage.DisplayMessageBox("800478", MessageBoxButtons.OK);
                return;
            }


            if (uniBase.UMessage.DisplayMessageBox("900018", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                return;
            }

            uniBase.UProcess.DisplayProgressBar();

            try
            {

                uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_IF_APPROVAL");

                uniBase.UDatabase.AddInParameter(iuniCommand, "@doc_no", SqlDbType.NVarChar, txtPrNo.Text.Trim());//popGlNo.CodeValue.ToString().Trim());
                uniBase.UDatabase.AddInParameter(iuniCommand, "@system_code", SqlDbType.NVarChar, "SCM");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@ap_form", SqlDbType.NVarChar, "M2111M4_KO883");//"A5101M1_KO883");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@ref_no", SqlDbType.NVarChar, txtPrNo.Text.Trim());//popGlNo.CodeValue.ToString().Trim());
                uniBase.UDatabase.AddInParameter(iuniCommand, "@doc_user_id", SqlDbType.NVarChar, popEmpNo.CodeValue.ToString()); //"20110301"); //
                uniBase.UDatabase.AddInParameter(iuniCommand, "@user_id", SqlDbType.NVarChar, popEmpNo.CodeValue.ToString()); //"20110301"); //

                uniBase.UDatabase.AddOutParameter(iuniCommand, "@msg_cd", SqlDbType.NVarChar, 6);
                uniBase.UDatabase.AddOutParameter(iuniCommand, "@msg_text", SqlDbType.NVarChar, 200);

                uniBase.UDatabase.AddReturnParameter(iuniCommand, "RETURN_VALUE", SqlDbType.Int, 4);

                uniBase.UDatabase.ExecuteNonQuery(iuniCommand);

                int iretVal = (int)uniBase.UDatabase.GetParameterValue(iuniCommand, "RETURN_VALUE");

                if (iretVal != 1)
                {
                    string istrMsgCd = uniBase.UDatabase.GetParameterValue(iuniCommand, "@msg_cd").ToString();
                    string istrMsgText = uniBase.UDatabase.GetParameterValue(iuniCommand, "@msg_text").ToString();
                    uniBase.UMessage.DisplayMessageBox(istrMsgCd, MessageBoxButtons.OK, istrMsgText);
                    this.Presenter.ProgressBarController.HideProgressBar();
                    return;
                }

                // --결재창 OPEN
                uniERP.AppFramework.UI.Controls.Popup.PopupRunningInfo popupRunninginfo = new uniERP.AppFramework.UI.Controls.Popup.PopupRunningInfo();

                string callPopupID = "uniERP.App.UI.Popup.SMES";

                popupRunninginfo.ParentData.CalledPopupID = callPopupID;
                popupRunninginfo.ParentData.PopupWinTitle = "전자결재";
                
                //popupRunninginfo.ParentData.Data = popProdReqNo.CodeValue.ToString().Trim();  // 팝업 데이타 전달
                popupRunninginfo.ParentData.Data = txtPrNo.Text.Trim();  // 팝업 데이타 전달
                popupRunninginfo.ParentView = this;
                popupRunninginfo.ReturnPopup = (uniERP.AppFramework.UI.Controls.uniControls.IOpenPopup)this.btnApproval;
                popupRunninginfo.ParentColumnID = "";

                popupRunninginfo.ParentData.PopupWinWidth = 1500;
                popupRunninginfo.ParentData.PopupWinHeight = 1500;

                 ControlManager.PopupLoad(callPopupID, popupRunninginfo, this.Presenter.WorkItem);

                //


                /*******
                //mod by. SEH 160329 (법인분리로 인해 법인에 따라 CALL ID 달라지도록 변경)
                if (CommonVariable.gLicensedCompany.ToUpper() == "KO883")
                {
                    strUrl = string.Format("http://{0}/{1}/GroupWare/gw_form_new.asp?ext3_cd={2}&req_dt={3}", CommonVariable.gAPServer, CommonVariable.gRootVirtualDirectory, sDocumentNo, sReqDt);
                    //dialogWidth=100px; dialogHeight=100px; center: Yes; help: No; resizable: YES; status: No
                }
                else
                {
                    strUrl = string.Format("http://{0}/{1}/GroupWare/gw_form_new_tgs.asp?ext3_cd={2}&req_dt={3}", CommonVariable.gAPServer, CommonVariable.gRootVirtualDirectory, sDocumentNo, sReqDt);
                }
                //mod by. SEH 160329 (법인분리로 인해 법인에 따라 CALL ID 달라지도록 변경)

                ProcessStartInfo proc = new ProcessStartInfo();
                proc.FileName = "iexplore.exe";
                proc.Arguments = strUrl;
                Process.Start(proc);

                //기존 방식
                //내부 외부 아이피 
                //string sPath = string.Format("http://{0}/{1}/", CommonVariable.gAPServer, CommonVariable.gRootVirtualDirectory);
                //string sDocumentNo = txtPrNo.Text.Trim().ToUpper();
                //string sReqDt = dtReqDt.uniValue.ToString(CommonVariable.CDT_YYYY_MM_DD).Trim();


                //using (ApprovalForm frm = new ApprovalForm(sPath, sDocumentNo, sReqDt))
                //{
                //    frm.ShowDialog(); 
                //}
                *****/
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                this.Presenter.ProgressBarController.HideProgressBar();
                return;
            }

            this.Presenter.ProgressBarController.HideProgressBar();
            //결재상신 I/F 테이블의 승인상태값을 'T'로 변경
            DataSet dsData = new DataSet();
            string strUPIF = string.Format("UPDATE ERP_IF_APPROVAL SET APPROVAL_RTN = UPPER('T') WHERE DOC_NO = '{0}' AND SYSTEM_CODE ='SCM' AND MNU_ID = '{1}' AND AP_ITEM = 'M2'", txtPrNo.Text, uniBase.UCommon.GetProgramID(false));
            dsData = this.uniBase.UDataAccess.CommonQuerySQL(strUPIF);

            OnPostFncSave();


        }

        private void lblTGSRef_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (this.viewDBSaveMode != enumDef.DBSaveMode.CreateMode)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "신규에서만 참조 가능합니다.");
                e.Cancel = true;
                return;
            }

            if (popPlantCd.CodeValue == null || popPlantCd.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("173133", MessageBoxButtons.OK, popPlantCd.uniALT);
                e.Cancel = true;
                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.M2111R3_KO883";
            e.PopupPassData.PopupWinTitle = "TGS참조";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 450;

            string[] arrParam = new string[2];
            arrParam[0] = popPlantCd.CodeValue;
            arrParam[1] = popPlantCd.CodeName;

            e.PopupPassData.Data = arrParam;
        }

        private void lblTGSRef_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            iDataSet = (DataSet)e.ResultData.Data;

            int i = 0;

            if (iDataSet == null || iDataSet.Tables.Count == 0 || iDataSet.Tables[i].Rows.Count == 0)
            {
                uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                //return false; 
            }
            else if (iDataSet.Tables[0].Rows.Count >= 1)
            {
                //기존행이있을때 뒤로 붙이기
                //int j = uniGrid1.Rows.Count - 1; 
                //uniGrid1.setFocusCell(0, j);

                //OnPreFncInsertRow(); //행추가  
                for (int h = 0; i < iDataSet.Tables[0].Rows.Count; h++)
                {
                    OnPreFncInsertRow();

                    uniGrid1.ActiveRow.Cells["item_cd"].Value = iDataSet.Tables[0].Rows[h]["item_cd"].ToString();
                    uniGrid1.ActiveRow.Cells["item_nm"].Value = iDataSet.Tables[0].Rows[h]["item_nm"].ToString();
                    uniGrid1.ActiveRow.Cells["spec"].Value = iDataSet.Tables[0].Rows[h]["spec"].ToString();
                    uniGrid1.ActiveRow.Cells["basic_unit"].Value = iDataSet.Tables[0].Rows[h]["basic_unit"].ToString();
                    uniGrid1.ActiveRow.Cells["req_qty"].Value = iDataSet.Tables[0].Rows[h]["req_qty"].ToString();
                    uniGrid1.ActiveRow.Cells["tracking_no"].Value = iDataSet.Tables[0].Rows[h]["tracking_no"].ToString();
                    uniGrid1.ActiveRow.Cells["so_no"].Value = iDataSet.Tables[0].Rows[h]["dlvy_req_no"].ToString();
                    uniGrid1.ActiveRow.Cells["so_seq_no"].Value = iDataSet.Tables[0].Rows[h]["seq_no"].ToString();

                    i++;
                }
            }
        }

        private void lblPoRef_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (this.viewDBSaveMode != enumDef.DBSaveMode.CreateMode)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "신규에서만 참조 가능합니다.");
                e.Cancel = true;
                return;
            }

            if (popPlantCd.CodeValue == null || popPlantCd.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("173133", MessageBoxButtons.OK, popPlantCd.uniALT);
                e.Cancel = true;
                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.M2111R4_KO883";
            e.PopupPassData.PopupWinTitle = "선발주참조";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 450;

            string[] arrParam = new string[2];
            arrParam[0] = popPlantCd.CodeValue;
            arrParam[1] = popPlantCd.CodeName;

            e.PopupPassData.Data = arrParam;
        }

        private void lblPoRef_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            iDataSet = (DataSet)e.ResultData.Data;

            int i = 0;

            if (iDataSet == null || iDataSet.Tables.Count == 0 || iDataSet.Tables[i].Rows.Count == 0)
            {
                uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                //return false; 
            }
            else if (iDataSet.Tables[0].Rows.Count >= 1)
            {
                //기존행이있을때 뒤로 붙이기
                //int j = uniGrid1.Rows.Count - 1; 
                //uniGrid1.setFocusCell(0, j);

                //OnPreFncInsertRow(); //행추가  
                for (int h = 0; i < iDataSet.Tables[0].Rows.Count; h++)
                {
                    OnPreFncInsertRow();

                    uniGrid1.ActiveRow.Cells["item_cd"].Value = iDataSet.Tables[0].Rows[h]["item_cd"].ToString();
                    uniGrid1.ActiveRow.Cells["item_nm"].Value = iDataSet.Tables[0].Rows[h]["item_nm"].ToString();
                    uniGrid1.ActiveRow.Cells["spec"].Value = iDataSet.Tables[0].Rows[h]["spec"].ToString();
                    uniGrid1.ActiveRow.Cells["basic_unit"].Value = iDataSet.Tables[0].Rows[h]["basic_unit"].ToString();
                    uniGrid1.ActiveRow.Cells["req_qty"].Value = iDataSet.Tables[0].Rows[h]["pre_qty"].ToString();
                    uniGrid1.ActiveRow.Cells["tracking_no"].Value = iDataSet.Tables[0].Rows[h]["tracking_no"].ToString();
                    uniGrid1.ActiveRow.Cells["so_no"].Value = iDataSet.Tables[0].Rows[h]["pre_po_no"].ToString();

                    i++;
                }
            }
        }

        private void popReqPrsn_OnChange(object sender, EventArgs e)
        {
            DataSet rtnDs = new DataSet();
            string sSQL = string.Format(@"

Declare @PARAM Nvarchar(13)
Set @PARAM = {0}
Select EMP_NO, NAME From HAA010T(Nolock)
WHERE (HAA010T.EMP_NO like  @PARAM +'%' or HAA010T.NAME LIKE '%' + @PARAM + '%')    "

                , uniBase.UCommon.FilterVariable(popReqPrsn.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));

            rtnDs = uniBase.UDataAccess.CommonQuerySQL(sSQL);

            if (rtnDs == null || rtnDs.Tables.Count == 0 || rtnDs.Tables[0].Rows.Count == 0)
            {
                popReqPrsn.CodeValue = "";
                popReqPrsn.CodeName = "";
            }
            else
            {
                if (rtnDs.Tables[0].Rows.Count == 1)
                {
                    popReqPrsn.CodeValue = rtnDs.Tables[0].Rows[0]["EMP_NO"].ToString().Trim();
                    popReqPrsn.CodeName = rtnDs.Tables[0].Rows[0]["NAME"].ToString().Trim();
                }
                else
                {
                    if (popReqPrsn.CodeValue.Trim() == "")
                    {
                        popReqPrsn.CodeValue = "";
                        popReqPrsn.CodeName = "";
                    }
                    else
                    {
                        PopupRunningInfo popupRunningInfo = new PopupRunningInfo();

                        string[] param_array = new string[] { popReqPrsn.CodeValue, popReqPrsn.CodeName };
                        popupRunningInfo.ParentData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup_KO883";
                        popupRunningInfo.ParentData.PopupWinTitle = "Name/Employee No. Query Popup";
                        popupRunningInfo.ParentData.PopupWinWidth = 800;
                        popupRunningInfo.ParentData.PopupWinHeight = 700;
                        popupRunningInfo.ParentData.Data = param_array;

                        popupRunningInfo.ParentData.UserParameters = new string[5];
                        popupRunningInfo.ParentData.UserParameters[0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                        popupRunningInfo.ParentData.UserParameters[1] = "''";
                        popupRunningInfo.ParentData.UserParameters[2] = uniBase.UCommon.FilterVariable(this.popReqPrsn.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                        popupRunningInfo.ParentData.UserParameters[3] = uniBase.UCommon.FilterVariable(this.popReqPrsn.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                        popupRunningInfo.ParentData.UserParameters[4] = " ";

                        ControlManager.PopupLoad("uniERP.App.UI.Popup.EmpPopup_KO883", popupRunningInfo, this.Presenter.WorkItem);


                        DataSet iDataSet = new DataSet();

                        if (popupRunningInfo.PopupResult.Data == null)
                            return;

                        iDataSet = (DataSet)popupRunningInfo.PopupResult.Data;

                        popReqPrsn.CodeValue = iDataSet.Tables[0].Rows[0]["EMP_NO"].ToString().Trim();
                        popReqPrsn.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString().Trim();
                    }
                }
            }
        }



        #region ▶ 7. User-defined method part

        private void Check_TrackingFiled(string item_cd, string plant_cd)
        {
            DataSet Dsdata = new DataSet();
            string sSQL = string.Format(@"

Select tracking_flg
from b_item_by_plant (nolock) 
where item_cd = {0}
and plant_cd = {1}"

                , uniBase.UCommon.FilterVariable(item_cd.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                , uniBase.UCommon.FilterVariable(plant_cd.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));

            Dsdata = uniBase.UDataAccess.CommonQuerySQL(sSQL);

            if (Dsdata == null || Dsdata.Tables.Count == 0 || Dsdata.Tables[0].Rows.Count == 0 || Dsdata.Tables[0].Rows[0]["tracking_flg"].ToString().Equals("N"))
            {
                uniGrid1.SpreadLock("tracking_no", uniGrid1.ActiveRow.Index, uniGrid1.ActiveRow.Index);
                uniGrid1.ActiveRow.Cells["tracking_no"].Value = "*";
            }
            else if(Dsdata.Tables[0].Rows[0]["tracking_flg"].ToString().Equals("Y"))
            {
                uniGrid1.SSSetRequired("tracking_no", uniGrid1.ActiveRow.Index, uniGrid1.ActiveRow.Index);
                uniGrid1.ActiveRow.Cells["tracking_no"].Value = "";
            }


        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            PrintEasyBaseDocument(enumDef.EasyBaseActionType.View);   //TO-DO : code business oriented logic
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintEasyBaseDocument(enumDef.EasyBaseActionType.Print);   //TO-DO : code business oriented logic
        }


        #region ■ 7.1 User-defined function group

        private void PrintEasyBaseDocument(enumDef.EasyBaseActionType pEasyBaseActionType)
        {
            StringBuilder isbURL = new StringBuilder();

            string istrEasyBaseID;

            if (!uniBase.UCommon.CheckRequiredFields(enumDef.PanelType.Condition))                      //TO-DO : check fields
                return;

            //TO-DO : Batch , SP or DLL Call
            this.Presenter.ProgressBarController.DisplayProgressBar();
            try
            {
                if (!SetPrintConditionValue(isbURL, out istrEasyBaseID))                                    //TO-DO : set EasyBase file name and parameters
                    return;

                switch (pEasyBaseActionType)                                                                 //TO-DO : EasyBase Start
                {
                    case enumDef.EasyBaseActionType.View:
                        if (string.IsNullOrEmpty(istrEasyBaseID as string) == false)
                        {
                            uniBase.UEasyBase.PreviewEBRDocument(istrEasyBaseID, isbURL.ToString());
                        }
                        break;
                    case enumDef.EasyBaseActionType.Print:
                        if (string.IsNullOrEmpty(istrEasyBaseID as string) == false)
                        {
                            uniBase.UEasyBase.PrintEBRDocument(istrEasyBaseID, isbURL.ToString());
                        }
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                this.Presenter.ProgressBarController.HideProgressBar();
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
            this.Presenter.ProgressBarController.HideProgressBar();
        }
        private bool SetPrintConditionValue(StringBuilder psbURL, out string pstrEasyBaseID)
        {
            pstrEasyBaseID = string.Empty;

            string cstrEasyBaseID = "";
            if (string.IsNullOrEmpty(txtPrNo.Text))
                psbURL.Append("EXT3_CD|").Append(CommonVariable.Percent4EBR);
            else
                psbURL.Append("EXT3_CD|" + uniBase.UCommon.FilterVariable(txtPrNo.Text, "''", enumDef.FilterVarType.NoBraceButReplSingleWithDoubleQuotation, true));

            cstrEasyBaseID = "M2111M4_KO883";
            pstrEasyBaseID = uniBase.UEasyBase.AskEBDocumentName(cstrEasyBaseID, enumDef.EasyBaseDocType.EBR.ToString());

            return true;
        }

        #endregion

        private void btnCancel_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {


            //if (uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.YesNo, "PORTAL에 임시저장중인 문서가 있습니다. PORTAL 임시저장 문서를 삭제후 처리하세요. 상신취소하시겠습니까?") == DialogResult.No)
            //    return;

            if (e.ResultData.Data.ToString().Contains("22"))
            {

            }
            else if (e.ResultData.Data.ToString().ToUpper().Contains("11"))
            {
                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, "인증 오류로 인하여 상신취소가 불가능합니다.");
                return;
            }
            else if (e.ResultData.Data.ToString().Contains("21"))
            {
                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, "파라미터 오류로 인하여 상신취소가 불가능합니다.");
                return;
            }
            else if (e.ResultData.Data.ToString().Contains("23"))
            {
                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, "데이터 처리 오류로 인하여 상신취소가 불가능합니다.");
                return;
            }
            else if (e.ResultData.Data.ToString().Contains("24"))
            {
                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, "데이터 중복 오류로 인하여 상신취소가 불가능합니다.");
                return;
            }
            else if (e.ResultData.Data.ToString().Contains("99"))
            {
                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, "시스템 오류로 인하여 상신취소가 불가능합니다.");
                return;
            }

            try
            {
                StringBuilder sbUpdate = new StringBuilder();
                sbUpdate.Remove(0, sbUpdate.Length);

                sbUpdate.AppendFormat(@"
UPDATE ERP_IF_APPROVAL 
SET APPROVAL_RTN = 'F'
, UPDT_USER_ID = '{1}'
, UPDT_DT = getdate() 
WHERE DOC_NO = '{0}' 
AND SYSTEM_CODE ='SCM' AND MNU_ID = '{2}' AND AP_ITEM = 'M2'"
, txtPrNo.Text.ToString().Trim(), CommonVariable.gUsrID, uniBase.UCommon.GetProgramID(false));


                if (sbUpdate.ToString() != "")
                {
                    uniCommand uniCmd = uniBase.UDatabase.GetSqlStringCommand(sbUpdate.ToString());
                    uniBase.UDatabase.ExecuteNonQuery(uniCmd);
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }

            if (e.ResultData.Data.ToString().Contains("22"))
            {
                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, "해당 결재문서가 그룹웨어에 미존재하여 상신취소하였습니다.");
            }
            else
            {
                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, "정상적으로 상신취소하였습니다.");
            }
            DBQuery();

        }

        private void btnCancel_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {

            if (this.viewDBSaveMode == enumDef.DBSaveMode.CreateMode)
            {
                // 조회를 먼저 하십시오.
                uniBase.UMessage.DisplayMessageBox("900002", MessageBoxButtons.OK);
                e.Cancel = true;
                return;
            }


            if (uniGrid1.Rows.Count == 0)
            {
                // 취소할 DATA가 없습니다.
                uniBase.UMessage.DisplayMessageBox("155130", MessageBoxButtons.OK);
                e.Cancel = true;
                return;
            }

            if (uniBase.UMessage.DisplayMessageBox("900018", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                e.Cancel = true;
                return;
            }

            string strSQL = string.Format(@"
SELECT APPROVAL_RTN
FROM ERP_IF_APPROVAL (NOLOCK) 
WHERE DOC_NO = '{0}'  
AND SYSTEM_CODE ='SCM' AND MNU_ID = '{2}' AND AP_ITEM = 'M2'"
, txtPrNo.Text.ToString().Trim(), CommonVariable.gUsrID, uniBase.UCommon.GetProgramID(false));

            DataSet ds = uniBase.UDataAccess.CommonQuerySQL(strSQL);

            if (ds.Tables[0].Rows.Count == 0 || ds.Tables[0].Rows[0][0].ToString() != "T")
            {
                uniBase.UMessage.DisplayMessageBox("W70001", MessageBoxButtons.OK, "임시 저장상태에만 상신취소 가능합니다");
                e.Cancel = true;
                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.SMES";
            e.PopupPassData.PopupWinTitle = "전자결재";
            e.PopupPassData.PopupWinWidth = 1500;
            e.PopupPassData.PopupWinHeight = 1500;

            e.PopupPassData.Data = txtPrNo.Text.ToString().Trim() + "|B";
        }
        #endregion

        # region lblRef5_AfterPopupClosed
        private void lblRef5_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            iDataSet = (DataSet)e.ResultData.Data;

            int i = 0;

            if (iDataSet == null || iDataSet.Tables.Count == 0 || iDataSet.Tables[i].Rows.Count == 0)
            {
                uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                //return false; 
            }
            else if (iDataSet.Tables[0].Rows.Count >= 1)
            {
                for (int h = 0; i < iDataSet.Tables[0].Rows.Count; h++)
                {
                    OnPreFncInsertRow();

                    uniGrid1.ActiveRow.Cells["item_cd"].Value = iDataSet.Tables[0].Rows[h]["item_cd"].ToString();
                    uniGrid1.ActiveRow.Cells["item_nm"].Value = iDataSet.Tables[0].Rows[h]["item_nm"].ToString();
                    uniGrid1.ActiveRow.Cells["spec"].Value = iDataSet.Tables[0].Rows[h]["spec"].ToString();
                    uniGrid1.ActiveRow.Cells["basic_unit"].Value = iDataSet.Tables[0].Rows[h]["basic_unit"].ToString();
                    uniGrid1.ActiveRow.Cells["req_qty"].Value = iDataSet.Tables[0].Rows[h]["so_qty"].ToString();
                    uniGrid1.ActiveRow.Cells["tracking_no"].Value = iDataSet.Tables[0].Rows[h]["tracking_no"].ToString();


                    ////2019-11-26
                    DataSet dsTemp = new DataSet();
                    dsTemp = uniBase.UDataAccess.CommonQueryRs("a.major_sl_cd, b.sl_nm ", "b_item_by_plant a (nolock) inner join b_storage_location b (nolock) on a.major_sl_cd = b.sl_cd ", "a.plant_cd= " +
                     "'" + popPlantCd.CodeValue.ToUpper() + "' and a.item_cd = '" + uniGrid1.ActiveRow.Cells["item_cd"].Value + "'");
                    if (dsTemp == null || dsTemp.Tables[0].Rows.Count == 0)
                    {
                        uniGrid1.ActiveRow.Cells["sl_cd"].Value = "";
                        uniGrid1.ActiveRow.Cells["sl_nm"].Value = "";
                        return;
                    }
                    else
                    {
                        uniGrid1.ActiveRow.Cells["sl_cd"].Value = dsTemp.Tables[0].Rows[0]["major_sl_cd"].ToString();
                        uniGrid1.ActiveRow.Cells["sl_nm"].Value = dsTemp.Tables[0].Rows[0]["sl_nm"].ToString();
                    }


                    uniGrid1.ActiveRow.Cells["ext6_cd_ko883"].Value = "AD";


                    i++;
                }
            }

        }
        # endregion

        # region lblRef5_BeforePopupOpen
        private void lblRef5_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {

            if (this.viewDBSaveMode != enumDef.DBSaveMode.CreateMode)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "신규에서만 참조 가능합니다.");
                e.Cancel = true;
                return;
            }

            if (popPlantCd.CodeValue == null || popPlantCd.CodeValue == "")
            {
                uniBase.UMessage.DisplayMessageBox("173133", MessageBoxButtons.OK, popPlantCd.uniALT);
                e.Cancel = true;
                return;
            }

            //string strPrntItemCd = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.item_cdColumn.ColumnName].Value.ToString();
            //string strPrntItemNm = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.item_nmColumn.ColumnName].Value.ToString();
            //string strTrackingNo = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.tracking_noColumn.ColumnName].Value.ToString();
            //string strWcCd = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.wc_cdColumn.ColumnName].Value.ToString();
            //string strRcptSlCd = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.sl_cdColumn.ColumnName].Value.ToString();
            //string strRcptSlNm = uniGrid1.ActiveRow.Cells[cstdsP4311MA1_KO883.E_CHILD_ITEM_HDR.sl_nmColumn.ColumnName].Value.ToString();

            string[] arrParam = new string[8];
            arrParam[0] = popPlantCd.CodeValue.Trim();
            //arrParam[1] = popPlantCd.CodeName.Trim();
            arrParam[1] = "";
            arrParam[2] = "";
            arrParam[3] = "";
            arrParam[4] = "";
            arrParam[5] = "1";//bom유형  

            arrParam[6] = "";//출고창고                 
            arrParam[7] = "";//출고창고명    

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.P4600PA1_KO883"; // KTW 20191210 P4600PA1_KO883" -> P4600PA1_KO883"
            e.PopupPassData.PopupWinTitle = "Inventory Status Info.";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 600;

            e.PopupPassData.Data = arrParam;        
        
        
        }
        # endregion
    }
}