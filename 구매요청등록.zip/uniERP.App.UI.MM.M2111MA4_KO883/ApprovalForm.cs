﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using uniERP.AppFramework.UI.Module;

namespace uniERP.App.UI.MM.M2111MA4_KO883
{

    public partial class ApprovalForm : Form
    {
        private string sUrl = null;
        private string sPgType = null;
        private string sUserId = null;
        private string sFormCode = null;
        private string sXmlContent = null;
        private string strPostData = null;
        private bool IsLoaded = false;
        UProcessClass UProcess = null;

        public ApprovalForm()
        {
            InitializeComponent();
        }

        public ApprovalForm(string sPath, string sParamDocumentID, string sParamReqDt)
        {
            InitializeComponent();

            sUrl = string.Format(sPath + "GroupWare/gw_form_new.asp?ext3_cd=" + sParamDocumentID + "&req_dt=" + sParamReqDt + "dialogWidth=1200px; dialogHeight=900px; center: Yes; help: No; resizable: YES; status: No");
        }


        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            webBrowser1.Navigating += new WebBrowserNavigatingEventHandler(webBrowser1_Navigating);
            webBrowser1.Navigated += new WebBrowserNavigatedEventHandler(webBrowser1_Navigated);

            string strHeader = "Content-Type: application/x-www-form-urlencoded";
            //byte[] postData = Encoding.Default.GetBytes(strPostData);


            webBrowser1.Navigate(sUrl, null, null, strHeader);

        }

        private void webBrowser1_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            if (IsLoaded == false) UProcess.DisplayProgressBar();
        }
        private void webBrowser1_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            UProcess.HideProgressBar();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            //UProcess.HideProgressBar();
        }

        private void Window_Unload(object sender, HtmlElementEventArgs e)
        {
            if (IsLoaded == true && webBrowser1.Document == null) this.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
