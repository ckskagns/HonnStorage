﻿using System;
using System.Collections.Generic;
using System.Text;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Interface;
using uniERP.AppFramework.UI.Common;

namespace uniERP.App.UI.SD.S3111MA1
{
    public class ModulePresenter : Presenter<IViewBase>
    {
    }
}
