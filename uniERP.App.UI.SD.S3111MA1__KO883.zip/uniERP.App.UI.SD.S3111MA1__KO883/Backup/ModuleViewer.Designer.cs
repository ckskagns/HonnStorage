﻿using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;
using uniERP.AppFramework.UI.Module;

namespace uniERP.App.UI.SD.S3111MA1_KO883
{
   public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }
    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem2 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem3 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem4 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance37 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance38 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance39 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance40 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance41 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance42 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance43 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance44 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance45 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance62 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance63 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance64 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance65 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance66 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab1 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab2 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            this.ultraTabPageControl1 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.tbl1 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblSoNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblSo_Type = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblSo_dt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCust_po_dt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblSold_to_party = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblShip_to_party = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPayer = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDeal_Type = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPay_terms = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblVat_Inc_Flag = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblVat_Type = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblVat_amt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblVat_rate = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lbl_Payterms_txt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblRemark = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCfm_flag = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPrice_flag = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblReq_dlvy_dt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCust_po_no = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblSales_Grp = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblBill_to_party = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblTo_Biz_Grp = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblTrans_Meth = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPay_dur = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDoc_cur = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblXchg_rate = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPay_type = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblNet_Amt_Loc = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtSoNo = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.dtSo_dt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.dtCust_po_dt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.txt_Payterms_txt = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.popPay_type = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popTrans_Meth = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popTo_Biz_Grp = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popBill_to_party = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popSales_Grp = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.txtCust_po_no = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.dtReq_dlvy_dt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.rdoPrice_flag = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.rdoCfm_flag = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.popSo_Type = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popSold_to_party = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popShip_to_party = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popPayer = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popDeal_Type = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popPay_terms = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popVat_Inc_Flag = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popVat_Type = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.numXchg_rate = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.numVat_amt = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.numNet_Amt_Loc = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.txtRemark = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.tbl3 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblPerc = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.numVat_rate = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.tbl4 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.numPay_dur = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.lbldays = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.pnlNetAmt = new uniERP.AppFramework.UI.Controls.uniPanel(this.components);
            this.numDoc_cur = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.popDoc_cur = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblCurr = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popCurr = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTextBox_Name = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTextBox_Code = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.numExt2Amt = new uniERP.AppFramework.UI.Controls.uniNumeric(this.components);
            this.uniLabel1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.ultraTabPageControl2 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.tbl2 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblIncoTerms = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblContract_dt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblship_dt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblShip_dt_txt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblLoading_port_Cd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDischge_port_Cd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPack_cond = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblManufacturer = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblBeneficiary = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblValid_dt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblOrigin = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popIncoTerms = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popBeneficiary = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popManufacturer = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popPack_cond = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popDischge_port_Cd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popLoading_port_Cd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.dtContract_dt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.dtValid_dt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.dtship_dt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.popOrigin = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.txtShip_dt_txt = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.popSending_Bank = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.txtDischge_city = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.popInspect_meth = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popAgent = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblSending_Bank = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDischge_city = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblInspect_meth = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblAgent = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.popConSo_no = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblConSo_no = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblSORef = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblProjectReference = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnDNCancel = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnDNCheck = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnCancel = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnConfirm = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.lblSalesOrderDetail = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.tab1 = new uniERP.AppFramework.UI.Controls.uniTabControl(this.components);
            this.ultraTabSharedControlsPage1 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.ultraTabPageControl1.SuspendLayout();
            this.tbl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtSo_dt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtCust_po_dt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Payterms_txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCust_po_no)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtReq_dlvy_dt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoPrice_flag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoCfm_flag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXchg_rate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVat_amt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNet_Amt_Loc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).BeginInit();
            this.tbl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numVat_rate)).BeginInit();
            this.tbl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPay_dur)).BeginInit();
            this.pnlNetAmt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDoc_cur)).BeginInit();
            this.popCurr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numExt2Amt)).BeginInit();
            this.ultraTabPageControl2.SuspendLayout();
            this.tbl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtContract_dt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtValid_dt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtship_dt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShip_dt_txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDischge_city)).BeginInit();
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainCondition.SuspendLayout();
            this.uniTBL_MainReference.SuspendLayout();
            this.uniTBL_MainBatch.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab1)).BeginInit();
            this.tab1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ultraTabPageControl1
            // 
            this.ultraTabPageControl1.Controls.Add(this.tbl1);
            this.ultraTabPageControl1.Location = new System.Drawing.Point(1, 25);
            this.ultraTabPageControl1.Name = "ultraTabPageControl1";
            this.ultraTabPageControl1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ultraTabPageControl1.Size = new System.Drawing.Size(973, 600);
            // 
            // tbl1
            // 
            this.tbl1.AutoFit = false;
            this.tbl1.AutoFitColumnCount = 4;
            this.tbl1.AutoFitRowCount = 4;
            this.tbl1.BackColor = System.Drawing.Color.Transparent;
            this.tbl1.ColumnCount = 4;
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tbl1.Controls.Add(this.lblSoNo, 0, 0);
            this.tbl1.Controls.Add(this.lblSo_Type, 0, 1);
            this.tbl1.Controls.Add(this.lblSo_dt, 0, 2);
            this.tbl1.Controls.Add(this.lblCust_po_dt, 0, 3);
            this.tbl1.Controls.Add(this.lblSold_to_party, 0, 4);
            this.tbl1.Controls.Add(this.lblShip_to_party, 0, 5);
            this.tbl1.Controls.Add(this.lblPayer, 0, 6);
            this.tbl1.Controls.Add(this.lblDeal_Type, 0, 7);
            this.tbl1.Controls.Add(this.lblPay_terms, 0, 8);
            this.tbl1.Controls.Add(this.lblVat_Inc_Flag, 0, 9);
            this.tbl1.Controls.Add(this.lblVat_Type, 0, 10);
            this.tbl1.Controls.Add(this.lblVat_amt, 0, 12);
            this.tbl1.Controls.Add(this.lblVat_rate, 0, 11);
            this.tbl1.Controls.Add(this.lbl_Payterms_txt, 0, 13);
            this.tbl1.Controls.Add(this.lblRemark, 0, 14);
            this.tbl1.Controls.Add(this.lblCfm_flag, 2, 0);
            this.tbl1.Controls.Add(this.lblPrice_flag, 2, 1);
            this.tbl1.Controls.Add(this.lblReq_dlvy_dt, 2, 2);
            this.tbl1.Controls.Add(this.lblCust_po_no, 2, 3);
            this.tbl1.Controls.Add(this.lblSales_Grp, 2, 4);
            this.tbl1.Controls.Add(this.lblBill_to_party, 2, 5);
            this.tbl1.Controls.Add(this.lblTo_Biz_Grp, 2, 6);
            this.tbl1.Controls.Add(this.lblTrans_Meth, 2, 7);
            this.tbl1.Controls.Add(this.lblPay_dur, 2, 8);
            this.tbl1.Controls.Add(this.lblDoc_cur, 2, 9);
            this.tbl1.Controls.Add(this.lblXchg_rate, 2, 10);
            this.tbl1.Controls.Add(this.lblPay_type, 2, 11);
            this.tbl1.Controls.Add(this.lblNet_Amt_Loc, 2, 12);
            this.tbl1.Controls.Add(this.txtSoNo, 1, 0);
            this.tbl1.Controls.Add(this.dtSo_dt, 1, 2);
            this.tbl1.Controls.Add(this.dtCust_po_dt, 1, 3);
            this.tbl1.Controls.Add(this.txt_Payterms_txt, 1, 13);
            this.tbl1.Controls.Add(this.popPay_type, 3, 11);
            this.tbl1.Controls.Add(this.popTrans_Meth, 3, 7);
            this.tbl1.Controls.Add(this.popTo_Biz_Grp, 3, 6);
            this.tbl1.Controls.Add(this.popBill_to_party, 3, 5);
            this.tbl1.Controls.Add(this.popSales_Grp, 3, 4);
            this.tbl1.Controls.Add(this.txtCust_po_no, 3, 3);
            this.tbl1.Controls.Add(this.dtReq_dlvy_dt, 3, 2);
            this.tbl1.Controls.Add(this.rdoPrice_flag, 3, 1);
            this.tbl1.Controls.Add(this.rdoCfm_flag, 3, 0);
            this.tbl1.Controls.Add(this.popSo_Type, 1, 1);
            this.tbl1.Controls.Add(this.popSold_to_party, 1, 4);
            this.tbl1.Controls.Add(this.popShip_to_party, 1, 5);
            this.tbl1.Controls.Add(this.popPayer, 1, 6);
            this.tbl1.Controls.Add(this.popDeal_Type, 1, 7);
            this.tbl1.Controls.Add(this.popPay_terms, 1, 8);
            this.tbl1.Controls.Add(this.popVat_Inc_Flag, 1, 9);
            this.tbl1.Controls.Add(this.popVat_Type, 1, 10);
            this.tbl1.Controls.Add(this.numXchg_rate, 3, 10);
            this.tbl1.Controls.Add(this.numVat_amt, 1, 12);
            this.tbl1.Controls.Add(this.numNet_Amt_Loc, 3, 12);
            this.tbl1.Controls.Add(this.txtRemark, 1, 14);
            this.tbl1.Controls.Add(this.tbl3, 1, 11);
            this.tbl1.Controls.Add(this.tbl4, 3, 8);
            this.tbl1.Controls.Add(this.pnlNetAmt, 3, 9);
            this.tbl1.Controls.Add(this.lblCurr, 2, 13);
            this.tbl1.Controls.Add(this.popCurr, 3, 13);
            this.tbl1.Controls.Add(this.numExt2Amt, 3, 14);
            this.tbl1.Controls.Add(this.uniLabel1, 2, 14);
            this.tbl1.DefaultRowSize = 23;
            this.tbl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl1.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.tbl1.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.tbl1.HEIGHT_TYPE_01 = 9F;
            this.tbl1.HEIGHT_TYPE_01_CONDITION = 40F;
            this.tbl1.HEIGHT_TYPE_02 = 9F;
            this.tbl1.HEIGHT_TYPE_02_DATA = 0F;
            this.tbl1.HEIGHT_TYPE_03 = 9F;
            this.tbl1.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.tbl1.HEIGHT_TYPE_04 = 3F;
            this.tbl1.Location = new System.Drawing.Point(4, 5);
            this.tbl1.Margin = new System.Windows.Forms.Padding(0);
            this.tbl1.Name = "tbl1";
            this.tbl1.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.tbl1.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.tbl1.RowCount = 16;
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl1.Size = new System.Drawing.Size(965, 590);
            this.tbl1.SizeTD5 = 14F;
            this.tbl1.SizeTD6 = 36F;
            this.tbl1.TabIndex = 0;
            this.tbl1.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.tbl1.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblSoNo
            // 
            appearance1.TextHAlignAsString = "Left";
            appearance1.TextVAlignAsString = "Middle";
            this.lblSoNo.Appearance = appearance1;
            this.lblSoNo.AutoPopupID = null;
            this.lblSoNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSoNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSoNo.Location = new System.Drawing.Point(15, 6);
            this.lblSoNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSoNo.Name = "lblSoNo";
            this.lblSoNo.Size = new System.Drawing.Size(120, 22);
            this.lblSoNo.StyleSetName = "Default";
            this.lblSoNo.TabIndex = 0;
            this.lblSoNo.Text = "S/O No.";
            this.lblSoNo.UseMnemonic = false;
            // 
            // lblSo_Type
            // 
            appearance2.TextHAlignAsString = "Left";
            appearance2.TextVAlignAsString = "Middle";
            this.lblSo_Type.Appearance = appearance2;
            this.lblSo_Type.AutoPopupID = null;
            this.lblSo_Type.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSo_Type.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSo_Type.Location = new System.Drawing.Point(15, 29);
            this.lblSo_Type.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSo_Type.Name = "lblSo_Type";
            this.lblSo_Type.Size = new System.Drawing.Size(120, 22);
            this.lblSo_Type.StyleSetName = "Default";
            this.lblSo_Type.TabIndex = 1;
            this.lblSo_Type.Text = "S/O Type";
            this.lblSo_Type.UseMnemonic = false;
            // 
            // lblSo_dt
            // 
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.lblSo_dt.Appearance = appearance3;
            this.lblSo_dt.AutoPopupID = null;
            this.lblSo_dt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSo_dt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSo_dt.Location = new System.Drawing.Point(15, 52);
            this.lblSo_dt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSo_dt.Name = "lblSo_dt";
            this.lblSo_dt.Size = new System.Drawing.Size(120, 22);
            this.lblSo_dt.StyleSetName = "Default";
            this.lblSo_dt.TabIndex = 2;
            this.lblSo_dt.Text = "S/O Date";
            this.lblSo_dt.UseMnemonic = false;
            // 
            // lblCust_po_dt
            // 
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.lblCust_po_dt.Appearance = appearance4;
            this.lblCust_po_dt.AutoPopupID = null;
            this.lblCust_po_dt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCust_po_dt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCust_po_dt.Location = new System.Drawing.Point(15, 75);
            this.lblCust_po_dt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCust_po_dt.Name = "lblCust_po_dt";
            this.lblCust_po_dt.Size = new System.Drawing.Size(120, 22);
            this.lblCust_po_dt.StyleSetName = "Default";
            this.lblCust_po_dt.TabIndex = 3;
            this.lblCust_po_dt.Text = "Cust. P/O Date";
            this.lblCust_po_dt.UseMnemonic = false;
            // 
            // lblSold_to_party
            // 
            appearance5.TextHAlignAsString = "Left";
            appearance5.TextVAlignAsString = "Middle";
            this.lblSold_to_party.Appearance = appearance5;
            this.lblSold_to_party.AutoPopupID = null;
            this.lblSold_to_party.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSold_to_party.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSold_to_party.Location = new System.Drawing.Point(15, 98);
            this.lblSold_to_party.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSold_to_party.Name = "lblSold_to_party";
            this.lblSold_to_party.Size = new System.Drawing.Size(120, 22);
            this.lblSold_to_party.StyleSetName = "Default";
            this.lblSold_to_party.TabIndex = 4;
            this.lblSold_to_party.Text = "Sold to Party";
            this.lblSold_to_party.UseMnemonic = false;
            // 
            // lblShip_to_party
            // 
            appearance6.TextHAlignAsString = "Left";
            appearance6.TextVAlignAsString = "Middle";
            this.lblShip_to_party.Appearance = appearance6;
            this.lblShip_to_party.AutoPopupID = null;
            this.lblShip_to_party.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblShip_to_party.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblShip_to_party.Location = new System.Drawing.Point(15, 121);
            this.lblShip_to_party.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblShip_to_party.Name = "lblShip_to_party";
            this.lblShip_to_party.Size = new System.Drawing.Size(120, 22);
            this.lblShip_to_party.StyleSetName = "Default";
            this.lblShip_to_party.TabIndex = 5;
            this.lblShip_to_party.Text = "Ship to Party";
            this.lblShip_to_party.UseMnemonic = false;
            // 
            // lblPayer
            // 
            appearance7.TextHAlignAsString = "Left";
            appearance7.TextVAlignAsString = "Middle";
            this.lblPayer.Appearance = appearance7;
            this.lblPayer.AutoPopupID = null;
            this.lblPayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPayer.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPayer.Location = new System.Drawing.Point(15, 144);
            this.lblPayer.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPayer.Name = "lblPayer";
            this.lblPayer.Size = new System.Drawing.Size(120, 22);
            this.lblPayer.StyleSetName = "Default";
            this.lblPayer.TabIndex = 6;
            this.lblPayer.Text = "Payer";
            this.lblPayer.UseMnemonic = false;
            // 
            // lblDeal_Type
            // 
            appearance8.TextHAlignAsString = "Left";
            appearance8.TextVAlignAsString = "Middle";
            this.lblDeal_Type.Appearance = appearance8;
            this.lblDeal_Type.AutoPopupID = null;
            this.lblDeal_Type.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDeal_Type.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDeal_Type.Location = new System.Drawing.Point(15, 167);
            this.lblDeal_Type.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDeal_Type.Name = "lblDeal_Type";
            this.lblDeal_Type.Size = new System.Drawing.Size(120, 22);
            this.lblDeal_Type.StyleSetName = "Default";
            this.lblDeal_Type.TabIndex = 7;
            this.lblDeal_Type.Text = "Sales Type";
            this.lblDeal_Type.UseMnemonic = false;
            // 
            // lblPay_terms
            // 
            appearance9.TextHAlignAsString = "Left";
            appearance9.TextVAlignAsString = "Middle";
            this.lblPay_terms.Appearance = appearance9;
            this.lblPay_terms.AutoPopupID = null;
            this.lblPay_terms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPay_terms.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPay_terms.Location = new System.Drawing.Point(15, 190);
            this.lblPay_terms.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPay_terms.Name = "lblPay_terms";
            this.lblPay_terms.Size = new System.Drawing.Size(120, 22);
            this.lblPay_terms.StyleSetName = "Default";
            this.lblPay_terms.TabIndex = 8;
            this.lblPay_terms.Text = "Pay Method";
            this.lblPay_terms.UseMnemonic = false;
            // 
            // lblVat_Inc_Flag
            // 
            appearance10.TextHAlignAsString = "Left";
            appearance10.TextVAlignAsString = "Middle";
            this.lblVat_Inc_Flag.Appearance = appearance10;
            this.lblVat_Inc_Flag.AutoPopupID = null;
            this.lblVat_Inc_Flag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVat_Inc_Flag.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblVat_Inc_Flag.Location = new System.Drawing.Point(15, 213);
            this.lblVat_Inc_Flag.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblVat_Inc_Flag.Name = "lblVat_Inc_Flag";
            this.lblVat_Inc_Flag.Size = new System.Drawing.Size(120, 22);
            this.lblVat_Inc_Flag.StyleSetName = "Default";
            this.lblVat_Inc_Flag.TabIndex = 9;
            this.lblVat_Inc_Flag.Text = "VAT inclusion ID";
            this.lblVat_Inc_Flag.UseMnemonic = false;
            // 
            // lblVat_Type
            // 
            appearance11.TextHAlignAsString = "Left";
            appearance11.TextVAlignAsString = "Middle";
            this.lblVat_Type.Appearance = appearance11;
            this.lblVat_Type.AutoPopupID = null;
            this.lblVat_Type.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVat_Type.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblVat_Type.Location = new System.Drawing.Point(15, 236);
            this.lblVat_Type.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblVat_Type.Name = "lblVat_Type";
            this.lblVat_Type.Size = new System.Drawing.Size(120, 22);
            this.lblVat_Type.StyleSetName = "Default";
            this.lblVat_Type.TabIndex = 10;
            this.lblVat_Type.Text = "VAT Type";
            this.lblVat_Type.UseMnemonic = false;
            // 
            // lblVat_amt
            // 
            appearance12.TextHAlignAsString = "Left";
            appearance12.TextVAlignAsString = "Middle";
            this.lblVat_amt.Appearance = appearance12;
            this.lblVat_amt.AutoPopupID = null;
            this.lblVat_amt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVat_amt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblVat_amt.Location = new System.Drawing.Point(15, 282);
            this.lblVat_amt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblVat_amt.Name = "lblVat_amt";
            this.lblVat_amt.Size = new System.Drawing.Size(120, 22);
            this.lblVat_amt.StyleSetName = "Default";
            this.lblVat_amt.TabIndex = 11;
            this.lblVat_amt.Text = "VAT Amt.";
            this.lblVat_amt.UseMnemonic = false;
            // 
            // lblVat_rate
            // 
            appearance13.TextHAlignAsString = "Left";
            appearance13.TextVAlignAsString = "Middle";
            this.lblVat_rate.Appearance = appearance13;
            this.lblVat_rate.AutoPopupID = null;
            this.lblVat_rate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVat_rate.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblVat_rate.Location = new System.Drawing.Point(15, 259);
            this.lblVat_rate.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblVat_rate.Name = "lblVat_rate";
            this.lblVat_rate.Size = new System.Drawing.Size(120, 22);
            this.lblVat_rate.StyleSetName = "Default";
            this.lblVat_rate.TabIndex = 12;
            this.lblVat_rate.Text = "VAT Rate";
            this.lblVat_rate.UseMnemonic = false;
            // 
            // lbl_Payterms_txt
            // 
            appearance14.TextHAlignAsString = "Left";
            appearance14.TextVAlignAsString = "Middle";
            this.lbl_Payterms_txt.Appearance = appearance14;
            this.lbl_Payterms_txt.AutoPopupID = null;
            this.lbl_Payterms_txt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_Payterms_txt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lbl_Payterms_txt.Location = new System.Drawing.Point(15, 305);
            this.lbl_Payterms_txt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lbl_Payterms_txt.Name = "lbl_Payterms_txt";
            this.lbl_Payterms_txt.Size = new System.Drawing.Size(120, 22);
            this.lbl_Payterms_txt.StyleSetName = "Default";
            this.lbl_Payterms_txt.TabIndex = 13;
            this.lbl_Payterms_txt.Text = "Payment Ref.";
            this.lbl_Payterms_txt.UseMnemonic = false;
            // 
            // lblRemark
            // 
            appearance15.TextHAlignAsString = "Left";
            appearance15.TextVAlignAsString = "Middle";
            this.lblRemark.Appearance = appearance15;
            this.lblRemark.AutoPopupID = null;
            this.lblRemark.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRemark.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRemark.Location = new System.Drawing.Point(15, 328);
            this.lblRemark.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(120, 22);
            this.lblRemark.StyleSetName = "Default";
            this.lblRemark.TabIndex = 14;
            this.lblRemark.Text = "Remarks";
            this.lblRemark.UseMnemonic = false;
            // 
            // lblCfm_flag
            // 
            appearance16.TextHAlignAsString = "Left";
            appearance16.TextVAlignAsString = "Middle";
            this.lblCfm_flag.Appearance = appearance16;
            this.lblCfm_flag.AutoPopupID = null;
            this.lblCfm_flag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCfm_flag.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCfm_flag.Location = new System.Drawing.Point(497, 6);
            this.lblCfm_flag.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCfm_flag.Name = "lblCfm_flag";
            this.lblCfm_flag.Size = new System.Drawing.Size(120, 22);
            this.lblCfm_flag.StyleSetName = "Default";
            this.lblCfm_flag.TabIndex = 15;
            this.lblCfm_flag.Text = "S/O Confirm";
            this.lblCfm_flag.UseMnemonic = false;
            // 
            // lblPrice_flag
            // 
            appearance17.TextHAlignAsString = "Left";
            appearance17.TextVAlignAsString = "Middle";
            this.lblPrice_flag.Appearance = appearance17;
            this.lblPrice_flag.AutoPopupID = null;
            this.lblPrice_flag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrice_flag.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPrice_flag.Location = new System.Drawing.Point(497, 29);
            this.lblPrice_flag.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPrice_flag.Name = "lblPrice_flag";
            this.lblPrice_flag.Size = new System.Drawing.Size(120, 22);
            this.lblPrice_flag.StyleSetName = "Default";
            this.lblPrice_flag.TabIndex = 16;
            this.lblPrice_flag.Text = "Price Type";
            this.lblPrice_flag.UseMnemonic = false;
            // 
            // lblReq_dlvy_dt
            // 
            appearance18.TextHAlignAsString = "Left";
            appearance18.TextVAlignAsString = "Middle";
            this.lblReq_dlvy_dt.Appearance = appearance18;
            this.lblReq_dlvy_dt.AutoPopupID = null;
            this.lblReq_dlvy_dt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReq_dlvy_dt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReq_dlvy_dt.Location = new System.Drawing.Point(497, 52);
            this.lblReq_dlvy_dt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReq_dlvy_dt.Name = "lblReq_dlvy_dt";
            this.lblReq_dlvy_dt.Size = new System.Drawing.Size(120, 22);
            this.lblReq_dlvy_dt.StyleSetName = "Default";
            this.lblReq_dlvy_dt.TabIndex = 17;
            this.lblReq_dlvy_dt.Text = "Delivery Date";
            this.lblReq_dlvy_dt.UseMnemonic = false;
            // 
            // lblCust_po_no
            // 
            appearance19.TextHAlignAsString = "Left";
            appearance19.TextVAlignAsString = "Middle";
            this.lblCust_po_no.Appearance = appearance19;
            this.lblCust_po_no.AutoPopupID = null;
            this.lblCust_po_no.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCust_po_no.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCust_po_no.Location = new System.Drawing.Point(497, 75);
            this.lblCust_po_no.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCust_po_no.Name = "lblCust_po_no";
            this.lblCust_po_no.Size = new System.Drawing.Size(120, 22);
            this.lblCust_po_no.StyleSetName = "Default";
            this.lblCust_po_no.TabIndex = 18;
            this.lblCust_po_no.Text = "Customer P/O No.";
            this.lblCust_po_no.UseMnemonic = false;
            // 
            // lblSales_Grp
            // 
            appearance20.TextHAlignAsString = "Left";
            appearance20.TextVAlignAsString = "Middle";
            this.lblSales_Grp.Appearance = appearance20;
            this.lblSales_Grp.AutoPopupID = null;
            this.lblSales_Grp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSales_Grp.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSales_Grp.Location = new System.Drawing.Point(497, 98);
            this.lblSales_Grp.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSales_Grp.Name = "lblSales_Grp";
            this.lblSales_Grp.Size = new System.Drawing.Size(120, 22);
            this.lblSales_Grp.StyleSetName = "Default";
            this.lblSales_Grp.TabIndex = 19;
            this.lblSales_Grp.Text = "Sales Group";
            this.lblSales_Grp.UseMnemonic = false;
            // 
            // lblBill_to_party
            // 
            appearance21.TextHAlignAsString = "Left";
            appearance21.TextVAlignAsString = "Middle";
            this.lblBill_to_party.Appearance = appearance21;
            this.lblBill_to_party.AutoPopupID = null;
            this.lblBill_to_party.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBill_to_party.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBill_to_party.Location = new System.Drawing.Point(497, 121);
            this.lblBill_to_party.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblBill_to_party.Name = "lblBill_to_party";
            this.lblBill_to_party.Size = new System.Drawing.Size(120, 22);
            this.lblBill_to_party.StyleSetName = "Default";
            this.lblBill_to_party.TabIndex = 20;
            this.lblBill_to_party.Text = "Tax Recipient";
            this.lblBill_to_party.UseMnemonic = false;
            // 
            // lblTo_Biz_Grp
            // 
            appearance22.TextHAlignAsString = "Left";
            appearance22.TextVAlignAsString = "Middle";
            this.lblTo_Biz_Grp.Appearance = appearance22;
            this.lblTo_Biz_Grp.AutoPopupID = null;
            this.lblTo_Biz_Grp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTo_Biz_Grp.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblTo_Biz_Grp.Location = new System.Drawing.Point(497, 144);
            this.lblTo_Biz_Grp.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblTo_Biz_Grp.Name = "lblTo_Biz_Grp";
            this.lblTo_Biz_Grp.Size = new System.Drawing.Size(120, 22);
            this.lblTo_Biz_Grp.StyleSetName = "Default";
            this.lblTo_Biz_Grp.TabIndex = 21;
            this.lblTo_Biz_Grp.Text = "Collection Group";
            this.lblTo_Biz_Grp.UseMnemonic = false;
            // 
            // lblTrans_Meth
            // 
            appearance23.TextHAlignAsString = "Left";
            appearance23.TextVAlignAsString = "Middle";
            this.lblTrans_Meth.Appearance = appearance23;
            this.lblTrans_Meth.AutoPopupID = null;
            this.lblTrans_Meth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTrans_Meth.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblTrans_Meth.Location = new System.Drawing.Point(497, 167);
            this.lblTrans_Meth.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblTrans_Meth.Name = "lblTrans_Meth";
            this.lblTrans_Meth.Size = new System.Drawing.Size(120, 22);
            this.lblTrans_Meth.StyleSetName = "Default";
            this.lblTrans_Meth.TabIndex = 22;
            this.lblTrans_Meth.Text = "Transport Meth.";
            this.lblTrans_Meth.UseMnemonic = false;
            // 
            // lblPay_dur
            // 
            appearance24.TextHAlignAsString = "Left";
            appearance24.TextVAlignAsString = "Middle";
            this.lblPay_dur.Appearance = appearance24;
            this.lblPay_dur.AutoPopupID = null;
            this.lblPay_dur.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPay_dur.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPay_dur.Location = new System.Drawing.Point(497, 190);
            this.lblPay_dur.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPay_dur.Name = "lblPay_dur";
            this.lblPay_dur.Size = new System.Drawing.Size(120, 22);
            this.lblPay_dur.StyleSetName = "Default";
            this.lblPay_dur.TabIndex = 23;
            this.lblPay_dur.Text = "Payment Net Days";
            this.lblPay_dur.UseMnemonic = false;
            // 
            // lblDoc_cur
            // 
            appearance25.TextHAlignAsString = "Left";
            appearance25.TextVAlignAsString = "Middle";
            this.lblDoc_cur.Appearance = appearance25;
            this.lblDoc_cur.AutoPopupID = null;
            this.lblDoc_cur.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDoc_cur.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDoc_cur.Location = new System.Drawing.Point(497, 213);
            this.lblDoc_cur.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDoc_cur.Name = "lblDoc_cur";
            this.lblDoc_cur.Size = new System.Drawing.Size(120, 22);
            this.lblDoc_cur.StyleSetName = "Default";
            this.lblDoc_cur.TabIndex = 24;
            this.lblDoc_cur.Text = "Net Amt.";
            this.lblDoc_cur.UseMnemonic = false;
            // 
            // lblXchg_rate
            // 
            appearance26.TextHAlignAsString = "Left";
            appearance26.TextVAlignAsString = "Middle";
            this.lblXchg_rate.Appearance = appearance26;
            this.lblXchg_rate.AutoPopupID = null;
            this.lblXchg_rate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblXchg_rate.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblXchg_rate.Location = new System.Drawing.Point(497, 236);
            this.lblXchg_rate.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblXchg_rate.Name = "lblXchg_rate";
            this.lblXchg_rate.Size = new System.Drawing.Size(120, 22);
            this.lblXchg_rate.StyleSetName = "Default";
            this.lblXchg_rate.TabIndex = 25;
            this.lblXchg_rate.Text = "Exchange Rate";
            this.lblXchg_rate.UseMnemonic = false;
            // 
            // lblPay_type
            // 
            appearance27.TextHAlignAsString = "Left";
            appearance27.TextVAlignAsString = "Middle";
            this.lblPay_type.Appearance = appearance27;
            this.lblPay_type.AutoPopupID = null;
            this.lblPay_type.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPay_type.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPay_type.Location = new System.Drawing.Point(497, 259);
            this.lblPay_type.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPay_type.Name = "lblPay_type";
            this.lblPay_type.Size = new System.Drawing.Size(120, 22);
            this.lblPay_type.StyleSetName = "Default";
            this.lblPay_type.TabIndex = 26;
            this.lblPay_type.Text = "Receipt Type";
            this.lblPay_type.UseMnemonic = false;
            // 
            // lblNet_Amt_Loc
            // 
            appearance28.TextHAlignAsString = "Left";
            appearance28.TextVAlignAsString = "Middle";
            this.lblNet_Amt_Loc.Appearance = appearance28;
            this.lblNet_Amt_Loc.AutoPopupID = null;
            this.lblNet_Amt_Loc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNet_Amt_Loc.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblNet_Amt_Loc.Location = new System.Drawing.Point(497, 282);
            this.lblNet_Amt_Loc.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblNet_Amt_Loc.Name = "lblNet_Amt_Loc";
            this.lblNet_Amt_Loc.Size = new System.Drawing.Size(120, 22);
            this.lblNet_Amt_Loc.StyleSetName = "Default";
            this.lblNet_Amt_Loc.TabIndex = 27;
            this.lblNet_Amt_Loc.Text = "S/O Amt. (Local)";
            this.lblNet_Amt_Loc.UseMnemonic = false;
            // 
            // txtSoNo
            // 
            this.txtSoNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance29.TextVAlignAsString = "Bottom";
            this.txtSoNo.Appearance = appearance29;
            this.txtSoNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSoNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtSoNo.Location = new System.Drawing.Point(135, 6);
            this.txtSoNo.LockedField = false;
            this.txtSoNo.Margin = new System.Windows.Forms.Padding(0);
            this.txtSoNo.MaxLength = 18;
            this.txtSoNo.Name = "txtSoNo";
            this.txtSoNo.QueryIfEnterKeyPressed = true;
            this.txtSoNo.RequiredField = false;
            this.txtSoNo.Size = new System.Drawing.Size(150, 22);
            this.txtSoNo.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtSoNo.StyleSetName = "Default";
            this.txtSoNo.TabIndex = 0;
            this.txtSoNo.uniALT = "S/O No.";
            this.txtSoNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSoNo.UseDynamicFormat = false;
            // 
            // dtSo_dt
            // 
            this.dtSo_dt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance30.TextHAlignAsString = "Center";
            this.dtSo_dt.Appearance = appearance30;
            this.dtSo_dt.DateTime = new System.DateTime(2007, 8, 21, 0, 0, 0, 0);
            this.dtSo_dt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtSo_dt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtSo_dt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.dtSo_dt.Location = new System.Drawing.Point(135, 52);
            this.dtSo_dt.LockedField = false;
            this.dtSo_dt.Margin = new System.Windows.Forms.Padding(0);
            this.dtSo_dt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtSo_dt.Name = "dtSo_dt";
            this.dtSo_dt.QueryIfEnterKeyPressed = true;
            this.dtSo_dt.RequiredField = false;
            this.dtSo_dt.Size = new System.Drawing.Size(100, 22);
            this.dtSo_dt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtSo_dt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtSo_dt.StyleSetName = "Default";
            this.dtSo_dt.TabIndex = 4;
            this.dtSo_dt.uniALT = "S/O Date";
            this.dtSo_dt.uniValue = new System.DateTime(2007, 8, 21, 0, 0, 0, 0);
            this.dtSo_dt.Value = new System.DateTime(2007, 8, 21, 0, 0, 0, 0);
            this.dtSo_dt.ValueChanged += new System.EventHandler(this.dtSo_dt_ValueChanged);
            // 
            // dtCust_po_dt
            // 
            this.dtCust_po_dt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance31.TextHAlignAsString = "Center";
            this.dtCust_po_dt.Appearance = appearance31;
            this.dtCust_po_dt.DateTime = new System.DateTime(2007, 8, 21, 0, 0, 0, 0);
            this.dtCust_po_dt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtCust_po_dt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtCust_po_dt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtCust_po_dt.Location = new System.Drawing.Point(135, 75);
            this.dtCust_po_dt.LockedField = false;
            this.dtCust_po_dt.Margin = new System.Windows.Forms.Padding(0);
            this.dtCust_po_dt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtCust_po_dt.Name = "dtCust_po_dt";
            this.dtCust_po_dt.QueryIfEnterKeyPressed = true;
            this.dtCust_po_dt.RequiredField = false;
            this.dtCust_po_dt.Size = new System.Drawing.Size(100, 22);
            this.dtCust_po_dt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtCust_po_dt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtCust_po_dt.StyleSetName = "Default";
            this.dtCust_po_dt.TabIndex = 6;
            this.dtCust_po_dt.uniALT = "Cust. P/O Date";
            this.dtCust_po_dt.uniValue = new System.DateTime(2007, 8, 21, 0, 0, 0, 0);
            this.dtCust_po_dt.Value = new System.DateTime(2007, 8, 21, 0, 0, 0, 0);
            // 
            // txt_Payterms_txt
            // 
            this.txt_Payterms_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance32.TextVAlignAsString = "Bottom";
            this.txt_Payterms_txt.Appearance = appearance32;
            this.txt_Payterms_txt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.txt_Payterms_txt.Location = new System.Drawing.Point(135, 305);
            this.txt_Payterms_txt.LockedField = false;
            this.txt_Payterms_txt.Margin = new System.Windows.Forms.Padding(0);
            this.txt_Payterms_txt.MaxLength = 120;
            this.txt_Payterms_txt.Name = "txt_Payterms_txt";
            this.txt_Payterms_txt.QueryIfEnterKeyPressed = true;
            this.txt_Payterms_txt.RequiredField = false;
            this.txt_Payterms_txt.Size = new System.Drawing.Size(347, 22);
            this.txt_Payterms_txt.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txt_Payterms_txt.StyleSetName = "Default";
            this.txt_Payterms_txt.TabIndex = 26;
            this.txt_Payterms_txt.uniALT = "Payment Ref.";
            this.txt_Payterms_txt.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txt_Payterms_txt.UseDynamicFormat = false;
            // 
            // popPay_type
            // 
            this.popPay_type.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPay_type.AutoPopupCodeParameter = null;
            this.popPay_type.AutoPopupID = null;
            this.popPay_type.AutoPopupNameParameter = null;
            this.popPay_type.CodeMaxLength = 5;
            this.popPay_type.CodeName = "";
            this.popPay_type.CodeSize = 100;
            this.popPay_type.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPay_type.CodeTextBoxName = null;
            this.popPay_type.CodeValue = "";
            this.popPay_type.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popPay_type.Location = new System.Drawing.Point(617, 260);
            this.popPay_type.LockedField = false;
            this.popPay_type.Margin = new System.Windows.Forms.Padding(0);
            this.popPay_type.Name = "popPay_type";
            this.popPay_type.NameDisplay = true;
            this.popPay_type.NameId = null;
            this.popPay_type.NameMaxLength = 20;
            this.popPay_type.NamePopup = false;
            this.popPay_type.NameSize = 150;
            this.popPay_type.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPay_type.Parameter = null;
            this.popPay_type.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPay_type.PopupId = null;
            this.popPay_type.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPay_type.QueryIfEnterKeyPressed = true;
            this.popPay_type.RequiredField = false;
            this.popPay_type.Size = new System.Drawing.Size(271, 21);
            this.popPay_type.TabIndex = 23;
            this.popPay_type.uniALT = "Receipt Type";
            this.popPay_type.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPay_type.UseDynamicFormat = false;
            this.popPay_type.ValueTextBoxName = null;
            this.popPay_type.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPay_type_BeforePopupOpen);
            this.popPay_type.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPay_type_AfterPopupClosed);
            // 
            // popTrans_Meth
            // 
            this.popTrans_Meth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popTrans_Meth.AutoPopupCodeParameter = null;
            this.popTrans_Meth.AutoPopupID = null;
            this.popTrans_Meth.AutoPopupNameParameter = null;
            this.popTrans_Meth.CodeMaxLength = 5;
            this.popTrans_Meth.CodeName = "";
            this.popTrans_Meth.CodeSize = 100;
            this.popTrans_Meth.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popTrans_Meth.CodeTextBoxName = null;
            this.popTrans_Meth.CodeValue = "";
            this.popTrans_Meth.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popTrans_Meth.Location = new System.Drawing.Point(617, 168);
            this.popTrans_Meth.LockedField = false;
            this.popTrans_Meth.Margin = new System.Windows.Forms.Padding(0);
            this.popTrans_Meth.Name = "popTrans_Meth";
            this.popTrans_Meth.NameDisplay = true;
            this.popTrans_Meth.NameId = null;
            this.popTrans_Meth.NameMaxLength = 20;
            this.popTrans_Meth.NamePopup = false;
            this.popTrans_Meth.NameSize = 150;
            this.popTrans_Meth.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popTrans_Meth.Parameter = null;
            this.popTrans_Meth.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popTrans_Meth.PopupId = null;
            this.popTrans_Meth.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popTrans_Meth.QueryIfEnterKeyPressed = true;
            this.popTrans_Meth.RequiredField = false;
            this.popTrans_Meth.Size = new System.Drawing.Size(271, 21);
            this.popTrans_Meth.TabIndex = 15;
            this.popTrans_Meth.uniALT = "Transport Meth.";
            this.popTrans_Meth.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popTrans_Meth.UseDynamicFormat = false;
            this.popTrans_Meth.ValueTextBoxName = null;
            this.popTrans_Meth.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popTrans_Meth_BeforePopupOpen);
            this.popTrans_Meth.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popTrans_Meth_AfterPopupClosed);
            // 
            // popTo_Biz_Grp
            // 
            this.popTo_Biz_Grp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popTo_Biz_Grp.AutoPopupCodeParameter = null;
            this.popTo_Biz_Grp.AutoPopupID = null;
            this.popTo_Biz_Grp.AutoPopupNameParameter = null;
            this.popTo_Biz_Grp.CodeMaxLength = 4;
            this.popTo_Biz_Grp.CodeName = "";
            this.popTo_Biz_Grp.CodeSize = 100;
            this.popTo_Biz_Grp.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popTo_Biz_Grp.CodeTextBoxName = null;
            this.popTo_Biz_Grp.CodeValue = "";
            this.popTo_Biz_Grp.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popTo_Biz_Grp.Location = new System.Drawing.Point(617, 145);
            this.popTo_Biz_Grp.LockedField = false;
            this.popTo_Biz_Grp.Margin = new System.Windows.Forms.Padding(0);
            this.popTo_Biz_Grp.Name = "popTo_Biz_Grp";
            this.popTo_Biz_Grp.NameDisplay = true;
            this.popTo_Biz_Grp.NameId = null;
            this.popTo_Biz_Grp.NameMaxLength = 50;
            this.popTo_Biz_Grp.NamePopup = false;
            this.popTo_Biz_Grp.NameSize = 150;
            this.popTo_Biz_Grp.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popTo_Biz_Grp.Parameter = null;
            this.popTo_Biz_Grp.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popTo_Biz_Grp.PopupId = null;
            this.popTo_Biz_Grp.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popTo_Biz_Grp.QueryIfEnterKeyPressed = true;
            this.popTo_Biz_Grp.RequiredField = false;
            this.popTo_Biz_Grp.Size = new System.Drawing.Size(271, 21);
            this.popTo_Biz_Grp.TabIndex = 13;
            this.popTo_Biz_Grp.uniALT = "Collection Group";
            this.popTo_Biz_Grp.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popTo_Biz_Grp.UseDynamicFormat = false;
            this.popTo_Biz_Grp.ValueTextBoxName = null;
            this.popTo_Biz_Grp.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popTo_Biz_Grp_BeforePopupOpen);
            this.popTo_Biz_Grp.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popTo_Biz_Grp_AfterPopupClosed);
            // 
            // popBill_to_party
            // 
            this.popBill_to_party.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popBill_to_party.AutoPopupCodeParameter = null;
            this.popBill_to_party.AutoPopupID = null;
            this.popBill_to_party.AutoPopupNameParameter = null;
            this.popBill_to_party.CodeMaxLength = 10;
            this.popBill_to_party.CodeName = "";
            this.popBill_to_party.CodeSize = 100;
            this.popBill_to_party.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBill_to_party.CodeTextBoxName = null;
            this.popBill_to_party.CodeValue = "";
            this.popBill_to_party.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popBill_to_party.Location = new System.Drawing.Point(617, 122);
            this.popBill_to_party.LockedField = false;
            this.popBill_to_party.Margin = new System.Windows.Forms.Padding(0);
            this.popBill_to_party.Name = "popBill_to_party";
            this.popBill_to_party.NameDisplay = true;
            this.popBill_to_party.NameId = null;
            this.popBill_to_party.NameMaxLength = 50;
            this.popBill_to_party.NamePopup = false;
            this.popBill_to_party.NameSize = 150;
            this.popBill_to_party.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBill_to_party.Parameter = null;
            this.popBill_to_party.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popBill_to_party.PopupId = null;
            this.popBill_to_party.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popBill_to_party.QueryIfEnterKeyPressed = true;
            this.popBill_to_party.RequiredField = false;
            this.popBill_to_party.Size = new System.Drawing.Size(271, 21);
            this.popBill_to_party.TabIndex = 11;
            this.popBill_to_party.uniALT = "Tax Recipient";
            this.popBill_to_party.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popBill_to_party.UseDynamicFormat = false;
            this.popBill_to_party.ValueTextBoxName = null;
            this.popBill_to_party.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popBill_to_party_BeforePopupOpen);
            this.popBill_to_party.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popBill_to_party_AfterPopupClosed);
            // 
            // popSales_Grp
            // 
            this.popSales_Grp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSales_Grp.AutoPopupCodeParameter = null;
            this.popSales_Grp.AutoPopupID = null;
            this.popSales_Grp.AutoPopupNameParameter = null;
            this.popSales_Grp.CodeMaxLength = 4;
            this.popSales_Grp.CodeName = "";
            this.popSales_Grp.CodeSize = 100;
            this.popSales_Grp.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSales_Grp.CodeTextBoxName = null;
            this.popSales_Grp.CodeValue = "";
            this.popSales_Grp.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.popSales_Grp.Location = new System.Drawing.Point(617, 99);
            this.popSales_Grp.LockedField = false;
            this.popSales_Grp.Margin = new System.Windows.Forms.Padding(0);
            this.popSales_Grp.Name = "popSales_Grp";
            this.popSales_Grp.NameDisplay = true;
            this.popSales_Grp.NameId = null;
            this.popSales_Grp.NameMaxLength = 50;
            this.popSales_Grp.NamePopup = false;
            this.popSales_Grp.NameSize = 150;
            this.popSales_Grp.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSales_Grp.Parameter = null;
            this.popSales_Grp.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSales_Grp.PopupId = null;
            this.popSales_Grp.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSales_Grp.QueryIfEnterKeyPressed = true;
            this.popSales_Grp.RequiredField = false;
            this.popSales_Grp.Size = new System.Drawing.Size(271, 21);
            this.popSales_Grp.TabIndex = 9;
            this.popSales_Grp.uniALT = "Sales Group";
            this.popSales_Grp.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popSales_Grp.UseDynamicFormat = false;
            this.popSales_Grp.ValueTextBoxName = null;
            this.popSales_Grp.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSales_Grp_BeforePopupOpen);
            this.popSales_Grp.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSales_Grp_AfterPopupClosed);
            // 
            // txtCust_po_no
            // 
            this.txtCust_po_no.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance33.TextVAlignAsString = "Bottom";
            this.txtCust_po_no.Appearance = appearance33;
            this.txtCust_po_no.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCust_po_no.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.txtCust_po_no.Location = new System.Drawing.Point(617, 75);
            this.txtCust_po_no.LockedField = false;
            this.txtCust_po_no.Margin = new System.Windows.Forms.Padding(0);
            this.txtCust_po_no.MaxLength = 20;
            this.txtCust_po_no.Name = "txtCust_po_no";
            this.txtCust_po_no.QueryIfEnterKeyPressed = true;
            this.txtCust_po_no.RequiredField = false;
            this.txtCust_po_no.Size = new System.Drawing.Size(150, 22);
            this.txtCust_po_no.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtCust_po_no.StyleSetName = "Default";
            this.txtCust_po_no.TabIndex = 7;
            this.txtCust_po_no.uniALT = "Customer P/O No.";
            this.txtCust_po_no.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCust_po_no.UseDynamicFormat = false;
            // 
            // dtReq_dlvy_dt
            // 
            this.dtReq_dlvy_dt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance34.TextHAlignAsString = "Center";
            this.dtReq_dlvy_dt.Appearance = appearance34;
            this.dtReq_dlvy_dt.DateTime = new System.DateTime(2007, 8, 21, 0, 0, 0, 0);
            this.dtReq_dlvy_dt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtReq_dlvy_dt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtReq_dlvy_dt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtReq_dlvy_dt.Location = new System.Drawing.Point(617, 52);
            this.dtReq_dlvy_dt.LockedField = false;
            this.dtReq_dlvy_dt.Margin = new System.Windows.Forms.Padding(0);
            this.dtReq_dlvy_dt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtReq_dlvy_dt.Name = "dtReq_dlvy_dt";
            this.dtReq_dlvy_dt.QueryIfEnterKeyPressed = true;
            this.dtReq_dlvy_dt.RequiredField = false;
            this.dtReq_dlvy_dt.Size = new System.Drawing.Size(100, 22);
            this.dtReq_dlvy_dt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtReq_dlvy_dt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtReq_dlvy_dt.StyleSetName = "Default";
            this.dtReq_dlvy_dt.TabIndex = 5;
            this.dtReq_dlvy_dt.uniALT = "Delivery Date";
            this.dtReq_dlvy_dt.uniValue = new System.DateTime(2007, 8, 21, 0, 0, 0, 0);
            this.dtReq_dlvy_dt.Value = new System.DateTime(2007, 8, 21, 0, 0, 0, 0);
            // 
            // rdoPrice_flag
            // 
            appearance35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.rdoPrice_flag.Appearance = appearance35;
            this.rdoPrice_flag.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.rdoPrice_flag.CheckedIndex = 0;
            this.rdoPrice_flag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rdoPrice_flag.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            valueListItem1.DataValue = "Y";
            valueListItem1.DisplayText = "Actual";
            valueListItem1.Tag = "24";
            valueListItem2.DataValue = "N";
            valueListItem2.DisplayText = "Provisional";
            valueListItem2.Tag = "24";
            this.rdoPrice_flag.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1,
            valueListItem2});
            this.rdoPrice_flag.ItemSpacingHorizontal = 30;
            this.rdoPrice_flag.ItemSpacingVertical = 10;
            this.rdoPrice_flag.Location = new System.Drawing.Point(617, 28);
            this.rdoPrice_flag.LockedField = false;
            this.rdoPrice_flag.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.rdoPrice_flag.Name = "rdoPrice_flag";
            this.rdoPrice_flag.RequiredField = false;
            this.rdoPrice_flag.Size = new System.Drawing.Size(345, 23);
            this.rdoPrice_flag.StyleSetName = "Lock";
            this.rdoPrice_flag.TabIndex = 3;
            this.rdoPrice_flag.TabStop = false;
            this.rdoPrice_flag.Text = "Actual";
            this.rdoPrice_flag.uniALT = "Price Type";
            // 
            // rdoCfm_flag
            // 
            appearance36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.rdoCfm_flag.Appearance = appearance36;
            this.rdoCfm_flag.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.rdoCfm_flag.CheckedIndex = 1;
            this.rdoCfm_flag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rdoCfm_flag.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            valueListItem3.DataValue = "Y";
            valueListItem3.DisplayText = "Release";
            valueListItem3.Tag = "24";
            valueListItem4.DataValue = "N";
            valueListItem4.DisplayText = "Pending";
            valueListItem4.Tag = "24";
            this.rdoCfm_flag.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem3,
            valueListItem4});
            this.rdoCfm_flag.ItemSpacingHorizontal = 30;
            this.rdoCfm_flag.ItemSpacingVertical = 10;
            this.rdoCfm_flag.Location = new System.Drawing.Point(617, 5);
            this.rdoCfm_flag.LockedField = false;
            this.rdoCfm_flag.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.rdoCfm_flag.Name = "rdoCfm_flag";
            this.rdoCfm_flag.RequiredField = false;
            this.rdoCfm_flag.Size = new System.Drawing.Size(345, 23);
            this.rdoCfm_flag.StyleSetName = "Lock";
            this.rdoCfm_flag.TabIndex = 1;
            this.rdoCfm_flag.TabStop = false;
            this.rdoCfm_flag.Text = "Pending";
            this.rdoCfm_flag.uniALT = "S/O Confirm";
            // 
            // popSo_Type
            // 
            this.popSo_Type.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSo_Type.AutoPopupCodeParameter = null;
            this.popSo_Type.AutoPopupID = null;
            this.popSo_Type.AutoPopupNameParameter = null;
            this.popSo_Type.CodeMaxLength = 4;
            this.popSo_Type.CodeName = "";
            this.popSo_Type.CodeSize = 100;
            this.popSo_Type.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSo_Type.CodeTextBoxName = null;
            this.popSo_Type.CodeValue = "";
            this.popSo_Type.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.popSo_Type.Location = new System.Drawing.Point(135, 30);
            this.popSo_Type.LockedField = false;
            this.popSo_Type.Margin = new System.Windows.Forms.Padding(0);
            this.popSo_Type.Name = "popSo_Type";
            this.popSo_Type.NameDisplay = true;
            this.popSo_Type.NameId = null;
            this.popSo_Type.NameMaxLength = 50;
            this.popSo_Type.NamePopup = false;
            this.popSo_Type.NameSize = 150;
            this.popSo_Type.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSo_Type.Parameter = null;
            this.popSo_Type.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSo_Type.PopupId = null;
            this.popSo_Type.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSo_Type.QueryIfEnterKeyPressed = true;
            this.popSo_Type.RequiredField = false;
            this.popSo_Type.Size = new System.Drawing.Size(271, 21);
            this.popSo_Type.TabIndex = 2;
            this.popSo_Type.uniALT = "S/O Type";
            this.popSo_Type.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popSo_Type.UseDynamicFormat = false;
            this.popSo_Type.ValueTextBoxName = null;
            this.popSo_Type.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSo_Type_BeforePopupOpen);
            this.popSo_Type.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popSo_Type_OnExitEditCode);
            this.popSo_Type.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSo_Type_AfterPopupClosed);
            // 
            // popSold_to_party
            // 
            this.popSold_to_party.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSold_to_party.AutoPopupCodeParameter = null;
            this.popSold_to_party.AutoPopupID = null;
            this.popSold_to_party.AutoPopupNameParameter = null;
            this.popSold_to_party.CodeMaxLength = 10;
            this.popSold_to_party.CodeName = "";
            this.popSold_to_party.CodeSize = 100;
            this.popSold_to_party.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSold_to_party.CodeTextBoxName = null;
            this.popSold_to_party.CodeValue = "";
            this.popSold_to_party.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.popSold_to_party.Location = new System.Drawing.Point(135, 99);
            this.popSold_to_party.LockedField = false;
            this.popSold_to_party.Margin = new System.Windows.Forms.Padding(0);
            this.popSold_to_party.Name = "popSold_to_party";
            this.popSold_to_party.NameDisplay = true;
            this.popSold_to_party.NameId = null;
            this.popSold_to_party.NameMaxLength = 50;
            this.popSold_to_party.NamePopup = false;
            this.popSold_to_party.NameSize = 150;
            this.popSold_to_party.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSold_to_party.Parameter = null;
            this.popSold_to_party.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSold_to_party.PopupId = null;
            this.popSold_to_party.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSold_to_party.QueryIfEnterKeyPressed = true;
            this.popSold_to_party.RequiredField = false;
            this.popSold_to_party.Size = new System.Drawing.Size(271, 21);
            this.popSold_to_party.TabIndex = 8;
            this.popSold_to_party.uniALT = "Sold to Party";
            this.popSold_to_party.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popSold_to_party.UseDynamicFormat = false;
            this.popSold_to_party.ValueTextBoxName = null;
            this.popSold_to_party.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSold_to_party_BeforePopupOpen);
            this.popSold_to_party.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popSold_to_party_OnExitEditCode);
            this.popSold_to_party.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSold_to_party_AfterPopupClosed);
            // 
            // popShip_to_party
            // 
            this.popShip_to_party.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popShip_to_party.AutoPopupCodeParameter = null;
            this.popShip_to_party.AutoPopupID = null;
            this.popShip_to_party.AutoPopupNameParameter = null;
            this.popShip_to_party.CodeMaxLength = 10;
            this.popShip_to_party.CodeName = "";
            this.popShip_to_party.CodeSize = 100;
            this.popShip_to_party.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popShip_to_party.CodeTextBoxName = null;
            this.popShip_to_party.CodeValue = "";
            this.popShip_to_party.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Primary;
            this.popShip_to_party.Location = new System.Drawing.Point(135, 122);
            this.popShip_to_party.LockedField = false;
            this.popShip_to_party.Margin = new System.Windows.Forms.Padding(0);
            this.popShip_to_party.Name = "popShip_to_party";
            this.popShip_to_party.NameDisplay = true;
            this.popShip_to_party.NameId = null;
            this.popShip_to_party.NameMaxLength = 50;
            this.popShip_to_party.NamePopup = false;
            this.popShip_to_party.NameSize = 150;
            this.popShip_to_party.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popShip_to_party.Parameter = null;
            this.popShip_to_party.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popShip_to_party.PopupId = null;
            this.popShip_to_party.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popShip_to_party.QueryIfEnterKeyPressed = true;
            this.popShip_to_party.RequiredField = false;
            this.popShip_to_party.Size = new System.Drawing.Size(271, 21);
            this.popShip_to_party.TabIndex = 10;
            this.popShip_to_party.uniALT = "Ship to Party";
            this.popShip_to_party.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popShip_to_party.UseDynamicFormat = false;
            this.popShip_to_party.ValueTextBoxName = null;
            this.popShip_to_party.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popShip_to_party_BeforePopupOpen);
            this.popShip_to_party.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popShip_to_party_AfterPopupClosed);
            // 
            // popPayer
            // 
            this.popPayer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPayer.AutoPopupCodeParameter = null;
            this.popPayer.AutoPopupID = null;
            this.popPayer.AutoPopupNameParameter = null;
            this.popPayer.CodeMaxLength = 10;
            this.popPayer.CodeName = "";
            this.popPayer.CodeSize = 100;
            this.popPayer.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPayer.CodeTextBoxName = null;
            this.popPayer.CodeValue = "";
            this.popPayer.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popPayer.Location = new System.Drawing.Point(135, 145);
            this.popPayer.LockedField = false;
            this.popPayer.Margin = new System.Windows.Forms.Padding(0);
            this.popPayer.Name = "popPayer";
            this.popPayer.NameDisplay = true;
            this.popPayer.NameId = null;
            this.popPayer.NameMaxLength = 50;
            this.popPayer.NamePopup = false;
            this.popPayer.NameSize = 150;
            this.popPayer.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPayer.Parameter = null;
            this.popPayer.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPayer.PopupId = null;
            this.popPayer.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPayer.QueryIfEnterKeyPressed = true;
            this.popPayer.RequiredField = false;
            this.popPayer.Size = new System.Drawing.Size(271, 21);
            this.popPayer.TabIndex = 12;
            this.popPayer.uniALT = "Payer";
            this.popPayer.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPayer.UseDynamicFormat = false;
            this.popPayer.ValueTextBoxName = null;
            this.popPayer.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPayer_BeforePopupOpen);
            this.popPayer.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPayer_AfterPopupClosed);
            // 
            // popDeal_Type
            // 
            this.popDeal_Type.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popDeal_Type.AutoPopupCodeParameter = null;
            this.popDeal_Type.AutoPopupID = null;
            this.popDeal_Type.AutoPopupNameParameter = null;
            this.popDeal_Type.CodeMaxLength = 5;
            this.popDeal_Type.CodeName = "";
            this.popDeal_Type.CodeSize = 100;
            this.popDeal_Type.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDeal_Type.CodeTextBoxName = null;
            this.popDeal_Type.CodeValue = "";
            this.popDeal_Type.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popDeal_Type.Location = new System.Drawing.Point(135, 168);
            this.popDeal_Type.LockedField = false;
            this.popDeal_Type.Margin = new System.Windows.Forms.Padding(0);
            this.popDeal_Type.Name = "popDeal_Type";
            this.popDeal_Type.NameDisplay = true;
            this.popDeal_Type.NameId = null;
            this.popDeal_Type.NameMaxLength = 20;
            this.popDeal_Type.NamePopup = false;
            this.popDeal_Type.NameSize = 150;
            this.popDeal_Type.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDeal_Type.Parameter = null;
            this.popDeal_Type.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popDeal_Type.PopupId = null;
            this.popDeal_Type.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popDeal_Type.QueryIfEnterKeyPressed = true;
            this.popDeal_Type.RequiredField = false;
            this.popDeal_Type.Size = new System.Drawing.Size(271, 21);
            this.popDeal_Type.TabIndex = 14;
            this.popDeal_Type.uniALT = "Sales Type";
            this.popDeal_Type.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popDeal_Type.UseDynamicFormat = false;
            this.popDeal_Type.ValueTextBoxName = null;
            this.popDeal_Type.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDeal_Type_BeforePopupOpen);
            this.popDeal_Type.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDeal_Type_AfterPopupClosed);
            // 
            // popPay_terms
            // 
            this.popPay_terms.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPay_terms.AutoPopupCodeParameter = null;
            this.popPay_terms.AutoPopupID = null;
            this.popPay_terms.AutoPopupNameParameter = null;
            this.popPay_terms.CodeMaxLength = 5;
            this.popPay_terms.CodeName = "";
            this.popPay_terms.CodeSize = 100;
            this.popPay_terms.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPay_terms.CodeTextBoxName = null;
            this.popPay_terms.CodeValue = "";
            this.popPay_terms.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popPay_terms.Location = new System.Drawing.Point(135, 191);
            this.popPay_terms.LockedField = false;
            this.popPay_terms.Margin = new System.Windows.Forms.Padding(0);
            this.popPay_terms.Name = "popPay_terms";
            this.popPay_terms.NameDisplay = true;
            this.popPay_terms.NameId = null;
            this.popPay_terms.NameMaxLength = 20;
            this.popPay_terms.NamePopup = false;
            this.popPay_terms.NameSize = 150;
            this.popPay_terms.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPay_terms.Parameter = null;
            this.popPay_terms.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPay_terms.PopupId = null;
            this.popPay_terms.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPay_terms.QueryIfEnterKeyPressed = true;
            this.popPay_terms.RequiredField = false;
            this.popPay_terms.Size = new System.Drawing.Size(271, 21);
            this.popPay_terms.TabIndex = 16;
            this.popPay_terms.uniALT = "Pay Method";
            this.popPay_terms.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPay_terms.UseDynamicFormat = false;
            this.popPay_terms.ValueTextBoxName = null;
            this.popPay_terms.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPay_terms_BeforePopupOpen);
            this.popPay_terms.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPay_terms_AfterPopupClosed);
            // 
            // popVat_Inc_Flag
            // 
            this.popVat_Inc_Flag.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popVat_Inc_Flag.AutoPopupCodeParameter = null;
            this.popVat_Inc_Flag.AutoPopupID = null;
            this.popVat_Inc_Flag.AutoPopupNameParameter = null;
            this.popVat_Inc_Flag.CodeMaxLength = 4;
            this.popVat_Inc_Flag.CodeName = "";
            this.popVat_Inc_Flag.CodeSize = 100;
            this.popVat_Inc_Flag.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popVat_Inc_Flag.CodeTextBoxName = null;
            this.popVat_Inc_Flag.CodeValue = "";
            this.popVat_Inc_Flag.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popVat_Inc_Flag.Location = new System.Drawing.Point(135, 214);
            this.popVat_Inc_Flag.LockedField = false;
            this.popVat_Inc_Flag.Margin = new System.Windows.Forms.Padding(0);
            this.popVat_Inc_Flag.Name = "popVat_Inc_Flag";
            this.popVat_Inc_Flag.NameDisplay = true;
            this.popVat_Inc_Flag.NameId = null;
            this.popVat_Inc_Flag.NameMaxLength = 20;
            this.popVat_Inc_Flag.NamePopup = false;
            this.popVat_Inc_Flag.NameSize = 150;
            this.popVat_Inc_Flag.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popVat_Inc_Flag.Parameter = null;
            this.popVat_Inc_Flag.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popVat_Inc_Flag.PopupId = null;
            this.popVat_Inc_Flag.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popVat_Inc_Flag.QueryIfEnterKeyPressed = true;
            this.popVat_Inc_Flag.RequiredField = false;
            this.popVat_Inc_Flag.Size = new System.Drawing.Size(271, 21);
            this.popVat_Inc_Flag.TabIndex = 18;
            this.popVat_Inc_Flag.uniALT = "VAT inclusion ID";
            this.popVat_Inc_Flag.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popVat_Inc_Flag.UseDynamicFormat = false;
            this.popVat_Inc_Flag.ValueTextBoxName = null;
            this.popVat_Inc_Flag.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popVat_Inc_Flag_BeforePopupOpen);
            this.popVat_Inc_Flag.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popVat_Inc_Flag_AfterPopupClosed);
            // 
            // popVat_Type
            // 
            this.popVat_Type.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popVat_Type.AutoPopupCodeParameter = null;
            this.popVat_Type.AutoPopupID = null;
            this.popVat_Type.AutoPopupNameParameter = null;
            this.popVat_Type.CodeMaxLength = 4;
            this.popVat_Type.CodeName = "";
            this.popVat_Type.CodeSize = 100;
            this.popVat_Type.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popVat_Type.CodeTextBoxName = null;
            this.popVat_Type.CodeValue = "";
            this.popVat_Type.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popVat_Type.Location = new System.Drawing.Point(135, 237);
            this.popVat_Type.LockedField = false;
            this.popVat_Type.Margin = new System.Windows.Forms.Padding(0);
            this.popVat_Type.Name = "popVat_Type";
            this.popVat_Type.NameDisplay = true;
            this.popVat_Type.NameId = null;
            this.popVat_Type.NameMaxLength = 20;
            this.popVat_Type.NamePopup = false;
            this.popVat_Type.NameSize = 150;
            this.popVat_Type.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popVat_Type.Parameter = null;
            this.popVat_Type.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popVat_Type.PopupId = null;
            this.popVat_Type.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popVat_Type.QueryIfEnterKeyPressed = true;
            this.popVat_Type.RequiredField = false;
            this.popVat_Type.Size = new System.Drawing.Size(271, 21);
            this.popVat_Type.TabIndex = 20;
            this.popVat_Type.uniALT = "VAT Type";
            this.popVat_Type.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popVat_Type.UseDynamicFormat = false;
            this.popVat_Type.ValueTextBoxName = null;
            this.popVat_Type.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popVat_Type_BeforePopupOpen);
            this.popVat_Type.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popVat_Type_OnExitEditCode);
            this.popVat_Type.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popVat_Type_AfterPopupClosed);
            // 
            // numXchg_rate
            // 
            this.numXchg_rate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numXchg_rate.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.numXchg_rate.Location = new System.Drawing.Point(617, 236);
            this.numXchg_rate.LockedField = false;
            this.numXchg_rate.Margin = new System.Windows.Forms.Padding(0);
            this.numXchg_rate.Name = "numXchg_rate";
            this.numXchg_rate.Nullable = true;
            this.numXchg_rate.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numXchg_rate.QueryIfEnterKeyPressed = true;
            this.numXchg_rate.RequiredField = false;
            this.numXchg_rate.Size = new System.Drawing.Size(140, 22);
            this.numXchg_rate.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numXchg_rate.StyleSetName = "Default";
            this.numXchg_rate.TabIndex = 21;
            this.numXchg_rate.uniALT = "Exchange Rate";
            this.numXchg_rate.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.ExchangeRate;
            this.numXchg_rate.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numXchg_rate.Value = null;
            // 
            // numVat_amt
            // 
            this.numVat_amt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numVat_amt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.numVat_amt.Location = new System.Drawing.Point(135, 282);
            this.numVat_amt.LockedField = false;
            this.numVat_amt.Margin = new System.Windows.Forms.Padding(0);
            this.numVat_amt.MaxValue = 1E+21;
            this.numVat_amt.MinValue = -1E+21;
            this.numVat_amt.Name = "numVat_amt";
            this.numVat_amt.Nullable = true;
            this.numVat_amt.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numVat_amt.QueryIfEnterKeyPressed = true;
            this.numVat_amt.RequiredField = false;
            this.numVat_amt.Size = new System.Drawing.Size(140, 22);
            this.numVat_amt.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numVat_amt.StyleSetName = "Default";
            this.numVat_amt.TabIndex = 24;
            this.numVat_amt.uniALT = "VAT amt.";
            this.numVat_amt.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.AmtOfMoney;
            this.numVat_amt.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numVat_amt.Value = null;
            // 
            // numNet_Amt_Loc
            // 
            this.numNet_Amt_Loc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numNet_Amt_Loc.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.numNet_Amt_Loc.Location = new System.Drawing.Point(617, 282);
            this.numNet_Amt_Loc.LockedField = false;
            this.numNet_Amt_Loc.Margin = new System.Windows.Forms.Padding(0);
            this.numNet_Amt_Loc.MaxValue = 1E+21;
            this.numNet_Amt_Loc.MinValue = -1E+21;
            this.numNet_Amt_Loc.Name = "numNet_Amt_Loc";
            this.numNet_Amt_Loc.Nullable = true;
            this.numNet_Amt_Loc.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numNet_Amt_Loc.QueryIfEnterKeyPressed = true;
            this.numNet_Amt_Loc.RequiredField = false;
            this.numNet_Amt_Loc.Size = new System.Drawing.Size(140, 22);
            this.numNet_Amt_Loc.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numNet_Amt_Loc.StyleSetName = "Default";
            this.numNet_Amt_Loc.TabIndex = 25;
            this.numNet_Amt_Loc.uniALT = "S/O Amt.(Local)";
            this.numNet_Amt_Loc.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.AmtOfMoney;
            this.numNet_Amt_Loc.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numNet_Amt_Loc.Value = null;
            // 
            // txtRemark
            // 
            this.txtRemark.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance37.TextVAlignAsString = "Bottom";
            this.txtRemark.Appearance = appearance37;
            this.txtRemark.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.txtRemark.Location = new System.Drawing.Point(135, 328);
            this.txtRemark.LockedField = false;
            this.txtRemark.Margin = new System.Windows.Forms.Padding(0);
            this.txtRemark.MaxLength = 80;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.QueryIfEnterKeyPressed = true;
            this.txtRemark.RequiredField = false;
            this.txtRemark.Size = new System.Drawing.Size(347, 22);
            this.txtRemark.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtRemark.StyleSetName = "Default";
            this.txtRemark.TabIndex = 27;
            this.txtRemark.uniALT = "Remarks";
            this.txtRemark.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtRemark.UseDynamicFormat = false;
            // 
            // tbl3
            // 
            this.tbl3.AutoFit = false;
            this.tbl3.AutoFitColumnCount = 4;
            this.tbl3.AutoFitRowCount = 4;
            this.tbl3.BackColor = System.Drawing.Color.Transparent;
            this.tbl3.ColumnCount = 2;
            this.tbl3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tbl3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl3.Controls.Add(this.lblPerc, 1, 0);
            this.tbl3.Controls.Add(this.numVat_rate, 0, 0);
            this.tbl3.DefaultRowSize = 23;
            this.tbl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl3.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.tbl3.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.tbl3.HEIGHT_TYPE_01 = 6F;
            this.tbl3.HEIGHT_TYPE_01_CONDITION = 38F;
            this.tbl3.HEIGHT_TYPE_02 = 9F;
            this.tbl3.HEIGHT_TYPE_02_DATA = 0F;
            this.tbl3.HEIGHT_TYPE_03 = 3F;
            this.tbl3.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.tbl3.HEIGHT_TYPE_04 = 1F;
            this.tbl3.Location = new System.Drawing.Point(135, 258);
            this.tbl3.Margin = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.tbl3.Name = "tbl3";
            this.tbl3.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.tbl3.RowCount = 1;
            this.tbl3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl3.Size = new System.Drawing.Size(346, 23);
            this.tbl3.SizeTD5 = 14F;
            this.tbl3.SizeTD6 = 36F;
            this.tbl3.TabIndex = 22;
            this.tbl3.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.tbl3.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblPerc
            // 
            appearance38.TextHAlignAsString = "Left";
            appearance38.TextVAlignAsString = "Middle";
            this.lblPerc.Appearance = appearance38;
            this.lblPerc.AutoPopupID = null;
            this.lblPerc.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Default_NoStyle;
            this.lblPerc.Location = new System.Drawing.Point(143, 0);
            this.lblPerc.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.lblPerc.Name = "lblPerc";
            this.lblPerc.Size = new System.Drawing.Size(193, 22);
            this.lblPerc.StyleSetName = "uniLabel_NoStyle";
            this.lblPerc.TabIndex = 2;
            this.lblPerc.Text = "%";
            this.lblPerc.UseMnemonic = false;
            // 
            // numVat_rate
            // 
            this.numVat_rate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numVat_rate.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.numVat_rate.Location = new System.Drawing.Point(0, 1);
            this.numVat_rate.LockedField = false;
            this.numVat_rate.Margin = new System.Windows.Forms.Padding(0);
            this.numVat_rate.Name = "numVat_rate";
            this.numVat_rate.Nullable = true;
            this.numVat_rate.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numVat_rate.QueryIfEnterKeyPressed = true;
            this.numVat_rate.RequiredField = false;
            this.numVat_rate.Size = new System.Drawing.Size(140, 22);
            this.numVat_rate.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numVat_rate.StyleSetName = "Default";
            this.numVat_rate.TabIndex = 0;
            this.numVat_rate.uniALT = "Vat Rate";
            this.numVat_rate.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.ExchangeRate;
            this.numVat_rate.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numVat_rate.Value = null;
            // 
            // tbl4
            // 
            this.tbl4.AutoFit = false;
            this.tbl4.AutoFitColumnCount = 4;
            this.tbl4.AutoFitRowCount = 4;
            this.tbl4.BackColor = System.Drawing.Color.Transparent;
            this.tbl4.ColumnCount = 2;
            this.tbl4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tbl4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl4.Controls.Add(this.numPay_dur, 0, 0);
            this.tbl4.Controls.Add(this.lbldays, 1, 0);
            this.tbl4.DefaultRowSize = 23;
            this.tbl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl4.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.tbl4.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.tbl4.HEIGHT_TYPE_01 = 6F;
            this.tbl4.HEIGHT_TYPE_01_CONDITION = 38F;
            this.tbl4.HEIGHT_TYPE_02 = 9F;
            this.tbl4.HEIGHT_TYPE_02_DATA = 0F;
            this.tbl4.HEIGHT_TYPE_03 = 3F;
            this.tbl4.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.tbl4.HEIGHT_TYPE_04 = 1F;
            this.tbl4.Location = new System.Drawing.Point(617, 189);
            this.tbl4.Margin = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.tbl4.Name = "tbl4";
            this.tbl4.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.tbl4.RowCount = 1;
            this.tbl4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl4.Size = new System.Drawing.Size(347, 23);
            this.tbl4.SizeTD5 = 14F;
            this.tbl4.SizeTD6 = 36F;
            this.tbl4.TabIndex = 17;
            this.tbl4.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.tbl4.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // numPay_dur
            // 
            this.numPay_dur.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numPay_dur.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.numPay_dur.Location = new System.Drawing.Point(0, 1);
            this.numPay_dur.LockedField = false;
            this.numPay_dur.Margin = new System.Windows.Forms.Padding(0);
            this.numPay_dur.MaxValue = 999;
            this.numPay_dur.MinValue = 0;
            this.numPay_dur.Name = "numPay_dur";
            this.numPay_dur.Nullable = true;
            this.numPay_dur.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numPay_dur.QueryIfEnterKeyPressed = true;
            this.numPay_dur.RequiredField = false;
            this.numPay_dur.Size = new System.Drawing.Size(140, 22);
            this.numPay_dur.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numPay_dur.StyleSetName = "Default";
            this.numPay_dur.TabIndex = 0;
            this.numPay_dur.uniALT = "Payment Net Days";
            this.numPay_dur.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.UserDefined6;
            this.numPay_dur.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numPay_dur.Value = null;
            // 
            // lbldays
            // 
            appearance39.TextHAlignAsString = "Left";
            appearance39.TextVAlignAsString = "Middle";
            this.lbldays.Appearance = appearance39;
            this.lbldays.AutoPopupID = null;
            this.lbldays.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Default_NoStyle;
            this.lbldays.Location = new System.Drawing.Point(143, 0);
            this.lbldays.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.lbldays.Name = "lbldays";
            this.lbldays.Size = new System.Drawing.Size(85, 22);
            this.lbldays.StyleSetName = "uniLabel_NoStyle";
            this.lbldays.TabIndex = 1;
            this.lbldays.Text = "Days";
            this.lbldays.UseMnemonic = false;
            // 
            // pnlNetAmt
            // 
            this.pnlNetAmt.BackColor = System.Drawing.Color.Transparent;
            this.pnlNetAmt.Controls.Add(this.numDoc_cur);
            this.pnlNetAmt.Controls.Add(this.popDoc_cur);
            this.pnlNetAmt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlNetAmt.Location = new System.Drawing.Point(617, 212);
            this.pnlNetAmt.Margin = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.pnlNetAmt.Name = "pnlNetAmt";
            this.pnlNetAmt.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.pnlNetAmt.Size = new System.Drawing.Size(347, 23);
            this.pnlNetAmt.TabIndex = 28;
            // 
            // numDoc_cur
            // 
            this.numDoc_cur.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numDoc_cur.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.numDoc_cur.Location = new System.Drawing.Point(121, 1);
            this.numDoc_cur.LockedField = false;
            this.numDoc_cur.Margin = new System.Windows.Forms.Padding(0);
            this.numDoc_cur.MaxValue = 1E+21;
            this.numDoc_cur.MinValue = -1E+21;
            this.numDoc_cur.Name = "numDoc_cur";
            this.numDoc_cur.Nullable = true;
            this.numDoc_cur.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numDoc_cur.QueryIfEnterKeyPressed = true;
            this.numDoc_cur.RequiredField = false;
            this.numDoc_cur.Size = new System.Drawing.Size(140, 22);
            this.numDoc_cur.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.FPDS140;
            this.numDoc_cur.StyleSetName = "Default";
            this.numDoc_cur.TabIndex = 1;
            this.numDoc_cur.uniALT = "Net Amt.";
            this.numDoc_cur.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.AmtOfMoney;
            this.numDoc_cur.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numDoc_cur.Value = null;
            // 
            // popDoc_cur
            // 
            this.popDoc_cur.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popDoc_cur.AutoPopupCodeParameter = null;
            this.popDoc_cur.AutoPopupID = null;
            this.popDoc_cur.AutoPopupNameParameter = null;
            this.popDoc_cur.CodeMaxLength = 3;
            this.popDoc_cur.CodeName = "";
            this.popDoc_cur.CodeSize = 100;
            this.popDoc_cur.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDoc_cur.CodeTextBoxName = null;
            this.popDoc_cur.CodeValue = "";
            this.popDoc_cur.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popDoc_cur.Location = new System.Drawing.Point(0, 1);
            this.popDoc_cur.LockedField = false;
            this.popDoc_cur.Margin = new System.Windows.Forms.Padding(0);
            this.popDoc_cur.Name = "popDoc_cur";
            this.popDoc_cur.NameDisplay = false;
            this.popDoc_cur.NameId = null;
            this.popDoc_cur.NameMaxLength = 50;
            this.popDoc_cur.NamePopup = false;
            this.popDoc_cur.NameSize = 100;
            this.popDoc_cur.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDoc_cur.Parameter = null;
            this.popDoc_cur.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popDoc_cur.PopupId = null;
            this.popDoc_cur.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popDoc_cur.QueryIfEnterKeyPressed = true;
            this.popDoc_cur.RequiredField = false;
            this.popDoc_cur.Size = new System.Drawing.Size(121, 21);
            this.popDoc_cur.TabIndex = 0;
            this.popDoc_cur.uniALT = "Net Amt.";
            this.popDoc_cur.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popDoc_cur.UseDynamicFormat = false;
            this.popDoc_cur.ValueTextBoxName = null;
            this.popDoc_cur.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDoc_cur_BeforePopupOpen);
            this.popDoc_cur.OnExitEditCode += new uniERP.AppFramework.UI.Controls.Popup.OnExitEditCodeEventHandler(this.popDoc_cur_OnExitEditCode);
            this.popDoc_cur.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDoc_cur_AfterPopupClosed);
            // 
            // lblCurr
            // 
            appearance40.TextHAlignAsString = "Left";
            appearance40.TextVAlignAsString = "Middle";
            this.lblCurr.Appearance = appearance40;
            this.lblCurr.AutoPopupID = null;
            this.lblCurr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCurr.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCurr.Location = new System.Drawing.Point(497, 305);
            this.lblCurr.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCurr.Name = "lblCurr";
            this.lblCurr.Size = new System.Drawing.Size(120, 22);
            this.lblCurr.StyleSetName = "Default";
            this.lblCurr.TabIndex = 29;
            this.lblCurr.Text = "PIT통화";
            this.lblCurr.UseMnemonic = false;
            // 
            // popCurr
            // 
            this.popCurr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popCurr.AutoPopupCodeParameter = null;
            this.popCurr.AutoPopupID = null;
            this.popCurr.AutoPopupNameParameter = null;
            this.popCurr.CodeMaxLength = 3;
            this.popCurr.CodeName = "";
            this.popCurr.CodeSize = 150;
            this.popCurr.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCurr.CodeTextBoxName = null;
            this.popCurr.CodeValue = "";
            this.popCurr.Controls.Add(this.uniTextBox_Name);
            this.popCurr.Controls.Add(this.uniTextBox_Code);
            this.popCurr.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popCurr.Location = new System.Drawing.Point(617, 306);
            this.popCurr.LockedField = false;
            this.popCurr.Margin = new System.Windows.Forms.Padding(0);
            this.popCurr.Name = "popCurr";
            this.popCurr.NameDisplay = false;
            this.popCurr.NameId = null;
            this.popCurr.NameMaxLength = 50;
            this.popCurr.NamePopup = false;
            this.popCurr.NameSize = 150;
            this.popCurr.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCurr.Parameter = null;
            this.popCurr.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popCurr.PopupId = null;
            this.popCurr.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popCurr.QueryIfEnterKeyPressed = true;
            this.popCurr.RequiredField = false;
            this.popCurr.Size = new System.Drawing.Size(321, 21);
            this.popCurr.TabIndex = 30;
            this.popCurr.uniALT = "Currency";
            this.popCurr.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popCurr.UseDynamicFormat = false;
            this.popCurr.ValueTextBoxName = null;
            this.popCurr.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popCurr_BeforePopupOpen);
            this.popCurr.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popCurr_AfterPopupClosed);
            // 
            // uniTextBox_Name
            // 
            this.uniTextBox_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.Appearance = appearance41;
            this.uniTextBox_Name.AutoSize = false;
            this.uniTextBox_Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Name.Location = new System.Drawing.Point(171, 0);
            this.uniTextBox_Name.LockedField = false;
            this.uniTextBox_Name.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Name.MaxLength = 50;
            this.uniTextBox_Name.Name = "uniTextBox_Name";
            this.uniTextBox_Name.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Name.ReadOnly = true;
            this.uniTextBox_Name.RequiredField = false;
            this.uniTextBox_Name.Size = new System.Drawing.Size(148, 21);
            this.uniTextBox_Name.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Name.StyleSetName = "Lock";
            this.uniTextBox_Name.TabIndex = 0;
            this.uniTextBox_Name.TabStop = false;
            this.uniTextBox_Name.uniALT = null;
            this.uniTextBox_Name.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.uniTextBox_Name.UseDynamicFormat = false;
            this.uniTextBox_Name.Visible = false;
            this.uniTextBox_Name.WordWrap = false;
            // 
            // uniTextBox_Code
            // 
            this.uniTextBox_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.Appearance = appearance42;
            this.uniTextBox_Code.AutoSize = false;
            this.uniTextBox_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox_Code.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Code.Location = new System.Drawing.Point(0, 0);
            this.uniTextBox_Code.LockedField = false;
            this.uniTextBox_Code.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Code.MaxLength = 3;
            this.uniTextBox_Code.Name = "uniTextBox_Code";
            this.uniTextBox_Code.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Code.RequiredField = false;
            this.uniTextBox_Code.Size = new System.Drawing.Size(150, 21);
            this.uniTextBox_Code.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Code.StyleSetName = "Default";
            this.uniTextBox_Code.TabIndex = 0;
            this.uniTextBox_Code.uniALT = null;
            this.uniTextBox_Code.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox_Code.UseDynamicFormat = false;
            this.uniTextBox_Code.WordWrap = false;
            // 
            // numExt2Amt
            // 
            this.numExt2Amt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numExt2Amt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.numExt2Amt.Location = new System.Drawing.Point(617, 328);
            this.numExt2Amt.LockedField = false;
            this.numExt2Amt.Margin = new System.Windows.Forms.Padding(0);
            this.numExt2Amt.Name = "numExt2Amt";
            this.numExt2Amt.Nullable = true;
            this.numExt2Amt.NumericType = Infragistics.Win.UltraWinEditors.NumericType.Double;
            this.numExt2Amt.QueryIfEnterKeyPressed = true;
            this.numExt2Amt.RequiredField = false;
            this.numExt2Amt.Size = new System.Drawing.Size(100, 22);
            this.numExt2Amt.Style = uniERP.AppFramework.UI.Controls.DoubleSingle_Style.Default;
            this.numExt2Amt.StyleSetName = "Default";
            this.numExt2Amt.TabIndex = 47;
            this.numExt2Amt.uniALT = null;
            this.numExt2Amt.uniNumericType = uniERP.AppFramework.UI.Variables.enumDef.NumericType.UserDefinedB;
            this.numExt2Amt.uniValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numExt2Amt.Value = null;
            // 
            // uniLabel1
            // 
            appearance43.TextHAlignAsString = "Left";
            appearance43.TextVAlignAsString = "Middle";
            this.uniLabel1.Appearance = appearance43;
            this.uniLabel1.AutoPopupID = null;
            this.uniLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniLabel1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.uniLabel1.Location = new System.Drawing.Point(497, 328);
            this.uniLabel1.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.uniLabel1.Name = "uniLabel1";
            this.uniLabel1.Size = new System.Drawing.Size(120, 22);
            this.uniLabel1.StyleSetName = "Default";
            this.uniLabel1.TabIndex = 48;
            this.uniLabel1.Text = "PIT금액";
            this.uniLabel1.UseMnemonic = false;
            // 
            // ultraTabPageControl2
            // 
            this.ultraTabPageControl2.Controls.Add(this.tbl2);
            this.ultraTabPageControl2.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl2.Name = "ultraTabPageControl2";
            this.ultraTabPageControl2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ultraTabPageControl2.Size = new System.Drawing.Size(973, 600);
            // 
            // tbl2
            // 
            this.tbl2.AutoFit = false;
            this.tbl2.AutoFitColumnCount = 4;
            this.tbl2.AutoFitRowCount = 4;
            this.tbl2.BackColor = System.Drawing.Color.Transparent;
            this.tbl2.ColumnCount = 4;
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tbl2.Controls.Add(this.lblIncoTerms, 0, 0);
            this.tbl2.Controls.Add(this.lblContract_dt, 0, 1);
            this.tbl2.Controls.Add(this.lblship_dt, 0, 2);
            this.tbl2.Controls.Add(this.lblShip_dt_txt, 0, 3);
            this.tbl2.Controls.Add(this.lblLoading_port_Cd, 0, 4);
            this.tbl2.Controls.Add(this.lblDischge_port_Cd, 0, 5);
            this.tbl2.Controls.Add(this.lblPack_cond, 0, 6);
            this.tbl2.Controls.Add(this.lblManufacturer, 0, 7);
            this.tbl2.Controls.Add(this.lblBeneficiary, 2, 0);
            this.tbl2.Controls.Add(this.lblValid_dt, 2, 1);
            this.tbl2.Controls.Add(this.lblOrigin, 2, 2);
            this.tbl2.Controls.Add(this.popIncoTerms, 1, 0);
            this.tbl2.Controls.Add(this.popBeneficiary, 3, 0);
            this.tbl2.Controls.Add(this.popManufacturer, 1, 7);
            this.tbl2.Controls.Add(this.popPack_cond, 1, 6);
            this.tbl2.Controls.Add(this.popDischge_port_Cd, 1, 5);
            this.tbl2.Controls.Add(this.popLoading_port_Cd, 1, 4);
            this.tbl2.Controls.Add(this.dtContract_dt, 1, 1);
            this.tbl2.Controls.Add(this.dtValid_dt, 3, 1);
            this.tbl2.Controls.Add(this.dtship_dt, 1, 2);
            this.tbl2.Controls.Add(this.popOrigin, 3, 2);
            this.tbl2.Controls.Add(this.txtShip_dt_txt, 1, 3);
            this.tbl2.Controls.Add(this.popSending_Bank, 3, 3);
            this.tbl2.Controls.Add(this.txtDischge_city, 3, 4);
            this.tbl2.Controls.Add(this.popInspect_meth, 3, 5);
            this.tbl2.Controls.Add(this.popAgent, 3, 6);
            this.tbl2.Controls.Add(this.lblSending_Bank, 2, 3);
            this.tbl2.Controls.Add(this.lblDischge_city, 2, 4);
            this.tbl2.Controls.Add(this.lblInspect_meth, 2, 5);
            this.tbl2.Controls.Add(this.lblAgent, 2, 6);
            this.tbl2.DefaultRowSize = 23;
            this.tbl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl2.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.tbl2.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.tbl2.HEIGHT_TYPE_01 = 9F;
            this.tbl2.HEIGHT_TYPE_01_CONDITION = 40F;
            this.tbl2.HEIGHT_TYPE_02 = 9F;
            this.tbl2.HEIGHT_TYPE_02_DATA = 0F;
            this.tbl2.HEIGHT_TYPE_03 = 9F;
            this.tbl2.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.tbl2.HEIGHT_TYPE_04 = 3F;
            this.tbl2.Location = new System.Drawing.Point(4, 5);
            this.tbl2.Margin = new System.Windows.Forms.Padding(0);
            this.tbl2.Name = "tbl2";
            this.tbl2.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.tbl2.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.tbl2.RowCount = 9;
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl2.Size = new System.Drawing.Size(965, 590);
            this.tbl2.SizeTD5 = 14F;
            this.tbl2.SizeTD6 = 36F;
            this.tbl2.TabIndex = 0;
            this.tbl2.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.tbl2.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblIncoTerms
            // 
            appearance44.TextHAlignAsString = "Left";
            appearance44.TextVAlignAsString = "Middle";
            this.lblIncoTerms.Appearance = appearance44;
            this.lblIncoTerms.AutoPopupID = null;
            this.lblIncoTerms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIncoTerms.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblIncoTerms.Location = new System.Drawing.Point(15, 6);
            this.lblIncoTerms.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblIncoTerms.Name = "lblIncoTerms";
            this.lblIncoTerms.Size = new System.Drawing.Size(120, 22);
            this.lblIncoTerms.StyleSetName = "Default";
            this.lblIncoTerms.TabIndex = 0;
            this.lblIncoTerms.Text = "Incoterms";
            this.lblIncoTerms.UseMnemonic = false;
            // 
            // lblContract_dt
            // 
            appearance45.TextHAlignAsString = "Left";
            appearance45.TextVAlignAsString = "Middle";
            this.lblContract_dt.Appearance = appearance45;
            this.lblContract_dt.AutoPopupID = null;
            this.lblContract_dt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblContract_dt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblContract_dt.Location = new System.Drawing.Point(15, 29);
            this.lblContract_dt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblContract_dt.Name = "lblContract_dt";
            this.lblContract_dt.Size = new System.Drawing.Size(120, 22);
            this.lblContract_dt.StyleSetName = "Default";
            this.lblContract_dt.TabIndex = 1;
            this.lblContract_dt.Text = "Contract Date";
            this.lblContract_dt.UseMnemonic = false;
            // 
            // lblship_dt
            // 
            appearance46.TextHAlignAsString = "Left";
            appearance46.TextVAlignAsString = "Middle";
            this.lblship_dt.Appearance = appearance46;
            this.lblship_dt.AutoPopupID = null;
            this.lblship_dt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblship_dt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblship_dt.Location = new System.Drawing.Point(15, 52);
            this.lblship_dt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblship_dt.Name = "lblship_dt";
            this.lblship_dt.Size = new System.Drawing.Size(120, 22);
            this.lblship_dt.StyleSetName = "Default";
            this.lblship_dt.TabIndex = 2;
            this.lblship_dt.Text = "Shipping Date";
            this.lblship_dt.UseMnemonic = false;
            // 
            // lblShip_dt_txt
            // 
            appearance47.TextHAlignAsString = "Left";
            appearance47.TextVAlignAsString = "Middle";
            this.lblShip_dt_txt.Appearance = appearance47;
            this.lblShip_dt_txt.AutoPopupID = null;
            this.lblShip_dt_txt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblShip_dt_txt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblShip_dt_txt.Location = new System.Drawing.Point(15, 75);
            this.lblShip_dt_txt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblShip_dt_txt.Name = "lblShip_dt_txt";
            this.lblShip_dt_txt.Size = new System.Drawing.Size(120, 22);
            this.lblShip_dt_txt.StyleSetName = "Default";
            this.lblShip_dt_txt.TabIndex = 3;
            this.lblShip_dt_txt.Text = "Shipment Date Ref.";
            this.lblShip_dt_txt.UseMnemonic = false;
            // 
            // lblLoading_port_Cd
            // 
            appearance48.TextHAlignAsString = "Left";
            appearance48.TextVAlignAsString = "Middle";
            this.lblLoading_port_Cd.Appearance = appearance48;
            this.lblLoading_port_Cd.AutoPopupID = null;
            this.lblLoading_port_Cd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLoading_port_Cd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblLoading_port_Cd.Location = new System.Drawing.Point(15, 98);
            this.lblLoading_port_Cd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblLoading_port_Cd.Name = "lblLoading_port_Cd";
            this.lblLoading_port_Cd.Size = new System.Drawing.Size(120, 22);
            this.lblLoading_port_Cd.StyleSetName = "Default";
            this.lblLoading_port_Cd.TabIndex = 4;
            this.lblLoading_port_Cd.Text = "Loading Port";
            this.lblLoading_port_Cd.UseMnemonic = false;
            // 
            // lblDischge_port_Cd
            // 
            appearance49.TextHAlignAsString = "Left";
            appearance49.TextVAlignAsString = "Middle";
            this.lblDischge_port_Cd.Appearance = appearance49;
            this.lblDischge_port_Cd.AutoPopupID = null;
            this.lblDischge_port_Cd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDischge_port_Cd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDischge_port_Cd.Location = new System.Drawing.Point(15, 121);
            this.lblDischge_port_Cd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDischge_port_Cd.Name = "lblDischge_port_Cd";
            this.lblDischge_port_Cd.Size = new System.Drawing.Size(120, 22);
            this.lblDischge_port_Cd.StyleSetName = "Default";
            this.lblDischge_port_Cd.TabIndex = 5;
            this.lblDischge_port_Cd.Text = "Arrival Port";
            this.lblDischge_port_Cd.UseMnemonic = false;
            // 
            // lblPack_cond
            // 
            appearance50.TextHAlignAsString = "Left";
            appearance50.TextVAlignAsString = "Middle";
            this.lblPack_cond.Appearance = appearance50;
            this.lblPack_cond.AutoPopupID = null;
            this.lblPack_cond.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPack_cond.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPack_cond.Location = new System.Drawing.Point(15, 144);
            this.lblPack_cond.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPack_cond.Name = "lblPack_cond";
            this.lblPack_cond.Size = new System.Drawing.Size(120, 22);
            this.lblPack_cond.StyleSetName = "Default";
            this.lblPack_cond.TabIndex = 6;
            this.lblPack_cond.Text = "Packing Cond.";
            this.lblPack_cond.UseMnemonic = false;
            // 
            // lblManufacturer
            // 
            appearance51.TextHAlignAsString = "Left";
            appearance51.TextVAlignAsString = "Middle";
            this.lblManufacturer.Appearance = appearance51;
            this.lblManufacturer.AutoPopupID = null;
            this.lblManufacturer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblManufacturer.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblManufacturer.Location = new System.Drawing.Point(15, 167);
            this.lblManufacturer.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblManufacturer.Name = "lblManufacturer";
            this.lblManufacturer.Size = new System.Drawing.Size(120, 22);
            this.lblManufacturer.StyleSetName = "Default";
            this.lblManufacturer.TabIndex = 7;
            this.lblManufacturer.Text = "Manufacturer";
            this.lblManufacturer.UseMnemonic = false;
            // 
            // lblBeneficiary
            // 
            appearance52.TextHAlignAsString = "Left";
            appearance52.TextVAlignAsString = "Middle";
            this.lblBeneficiary.Appearance = appearance52;
            this.lblBeneficiary.AutoPopupID = null;
            this.lblBeneficiary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBeneficiary.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBeneficiary.Location = new System.Drawing.Point(497, 6);
            this.lblBeneficiary.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblBeneficiary.Name = "lblBeneficiary";
            this.lblBeneficiary.Size = new System.Drawing.Size(120, 22);
            this.lblBeneficiary.StyleSetName = "Default";
            this.lblBeneficiary.TabIndex = 8;
            this.lblBeneficiary.Text = "Exporter";
            this.lblBeneficiary.UseMnemonic = false;
            // 
            // lblValid_dt
            // 
            appearance53.TextHAlignAsString = "Left";
            appearance53.TextVAlignAsString = "Middle";
            this.lblValid_dt.Appearance = appearance53;
            this.lblValid_dt.AutoPopupID = null;
            this.lblValid_dt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblValid_dt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblValid_dt.Location = new System.Drawing.Point(497, 29);
            this.lblValid_dt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblValid_dt.Name = "lblValid_dt";
            this.lblValid_dt.Size = new System.Drawing.Size(120, 22);
            this.lblValid_dt.StyleSetName = "Default";
            this.lblValid_dt.TabIndex = 9;
            this.lblValid_dt.Text = "Effective Date";
            this.lblValid_dt.UseMnemonic = false;
            // 
            // lblOrigin
            // 
            appearance54.TextHAlignAsString = "Left";
            appearance54.TextVAlignAsString = "Middle";
            this.lblOrigin.Appearance = appearance54;
            this.lblOrigin.AutoPopupID = null;
            this.lblOrigin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOrigin.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblOrigin.Location = new System.Drawing.Point(497, 52);
            this.lblOrigin.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblOrigin.Name = "lblOrigin";
            this.lblOrigin.Size = new System.Drawing.Size(120, 22);
            this.lblOrigin.StyleSetName = "Default";
            this.lblOrigin.TabIndex = 10;
            this.lblOrigin.Text = "Origin";
            this.lblOrigin.UseMnemonic = false;
            // 
            // popIncoTerms
            // 
            this.popIncoTerms.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popIncoTerms.AutoPopupCodeParameter = null;
            this.popIncoTerms.AutoPopupID = null;
            this.popIncoTerms.AutoPopupNameParameter = null;
            this.popIncoTerms.CodeMaxLength = 5;
            this.popIncoTerms.CodeName = "";
            this.popIncoTerms.CodeSize = 100;
            this.popIncoTerms.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popIncoTerms.CodeTextBoxName = null;
            this.popIncoTerms.CodeValue = "";
            this.popIncoTerms.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popIncoTerms.Location = new System.Drawing.Point(135, 7);
            this.popIncoTerms.LockedField = false;
            this.popIncoTerms.Margin = new System.Windows.Forms.Padding(0);
            this.popIncoTerms.Name = "popIncoTerms";
            this.popIncoTerms.NameDisplay = true;
            this.popIncoTerms.NameId = null;
            this.popIncoTerms.NameMaxLength = 20;
            this.popIncoTerms.NamePopup = false;
            this.popIncoTerms.NameSize = 150;
            this.popIncoTerms.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popIncoTerms.Parameter = null;
            this.popIncoTerms.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popIncoTerms.PopupId = null;
            this.popIncoTerms.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popIncoTerms.QueryIfEnterKeyPressed = true;
            this.popIncoTerms.RequiredField = false;
            this.popIncoTerms.Size = new System.Drawing.Size(271, 21);
            this.popIncoTerms.TabIndex = 0;
            this.popIncoTerms.uniALT = "Incoterms";
            this.popIncoTerms.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popIncoTerms.UseDynamicFormat = false;
            this.popIncoTerms.ValueTextBoxName = null;
            this.popIncoTerms.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popIncoTerms_BeforePopupOpen);
            this.popIncoTerms.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popIncoTerms_AfterPopupClosed);
            // 
            // popBeneficiary
            // 
            this.popBeneficiary.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popBeneficiary.AutoPopupCodeParameter = null;
            this.popBeneficiary.AutoPopupID = null;
            this.popBeneficiary.AutoPopupNameParameter = null;
            this.popBeneficiary.CodeMaxLength = 10;
            this.popBeneficiary.CodeName = "";
            this.popBeneficiary.CodeSize = 100;
            this.popBeneficiary.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBeneficiary.CodeTextBoxName = null;
            this.popBeneficiary.CodeValue = "";
            this.popBeneficiary.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popBeneficiary.Location = new System.Drawing.Point(617, 7);
            this.popBeneficiary.LockedField = false;
            this.popBeneficiary.Margin = new System.Windows.Forms.Padding(0);
            this.popBeneficiary.Name = "popBeneficiary";
            this.popBeneficiary.NameDisplay = true;
            this.popBeneficiary.NameId = null;
            this.popBeneficiary.NameMaxLength = 20;
            this.popBeneficiary.NamePopup = false;
            this.popBeneficiary.NameSize = 150;
            this.popBeneficiary.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBeneficiary.Parameter = null;
            this.popBeneficiary.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popBeneficiary.PopupId = null;
            this.popBeneficiary.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popBeneficiary.QueryIfEnterKeyPressed = true;
            this.popBeneficiary.RequiredField = false;
            this.popBeneficiary.Size = new System.Drawing.Size(271, 21);
            this.popBeneficiary.TabIndex = 1;
            this.popBeneficiary.uniALT = "Exporter";
            this.popBeneficiary.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popBeneficiary.UseDynamicFormat = false;
            this.popBeneficiary.ValueTextBoxName = null;
            this.popBeneficiary.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popBeneficiary_BeforePopupOpen);
            this.popBeneficiary.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popBeneficiary_AfterPopupClosed);
            // 
            // popManufacturer
            // 
            this.popManufacturer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popManufacturer.AutoPopupCodeParameter = null;
            this.popManufacturer.AutoPopupID = null;
            this.popManufacturer.AutoPopupNameParameter = null;
            this.popManufacturer.CodeMaxLength = 10;
            this.popManufacturer.CodeName = "";
            this.popManufacturer.CodeSize = 100;
            this.popManufacturer.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popManufacturer.CodeTextBoxName = null;
            this.popManufacturer.CodeValue = "";
            this.popManufacturer.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popManufacturer.Location = new System.Drawing.Point(135, 168);
            this.popManufacturer.LockedField = false;
            this.popManufacturer.Margin = new System.Windows.Forms.Padding(0);
            this.popManufacturer.Name = "popManufacturer";
            this.popManufacturer.NameDisplay = true;
            this.popManufacturer.NameId = null;
            this.popManufacturer.NameMaxLength = 50;
            this.popManufacturer.NamePopup = false;
            this.popManufacturer.NameSize = 150;
            this.popManufacturer.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popManufacturer.Parameter = null;
            this.popManufacturer.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popManufacturer.PopupId = null;
            this.popManufacturer.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popManufacturer.QueryIfEnterKeyPressed = true;
            this.popManufacturer.RequiredField = false;
            this.popManufacturer.Size = new System.Drawing.Size(271, 21);
            this.popManufacturer.TabIndex = 13;
            this.popManufacturer.uniALT = "Manufacturer";
            this.popManufacturer.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popManufacturer.UseDynamicFormat = false;
            this.popManufacturer.ValueTextBoxName = null;
            this.popManufacturer.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popManufacturer_BeforePopupOpen);
            this.popManufacturer.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popManufacturer_AfterPopupClosed);
            // 
            // popPack_cond
            // 
            this.popPack_cond.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPack_cond.AutoPopupCodeParameter = null;
            this.popPack_cond.AutoPopupID = null;
            this.popPack_cond.AutoPopupNameParameter = null;
            this.popPack_cond.CodeMaxLength = 5;
            this.popPack_cond.CodeName = "";
            this.popPack_cond.CodeSize = 100;
            this.popPack_cond.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPack_cond.CodeTextBoxName = null;
            this.popPack_cond.CodeValue = "";
            this.popPack_cond.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popPack_cond.Location = new System.Drawing.Point(135, 145);
            this.popPack_cond.LockedField = false;
            this.popPack_cond.Margin = new System.Windows.Forms.Padding(0);
            this.popPack_cond.Name = "popPack_cond";
            this.popPack_cond.NameDisplay = true;
            this.popPack_cond.NameId = null;
            this.popPack_cond.NameMaxLength = 50;
            this.popPack_cond.NamePopup = false;
            this.popPack_cond.NameSize = 150;
            this.popPack_cond.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPack_cond.Parameter = null;
            this.popPack_cond.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPack_cond.PopupId = null;
            this.popPack_cond.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPack_cond.QueryIfEnterKeyPressed = true;
            this.popPack_cond.RequiredField = false;
            this.popPack_cond.Size = new System.Drawing.Size(271, 21);
            this.popPack_cond.TabIndex = 11;
            this.popPack_cond.uniALT = "Packing Cond.";
            this.popPack_cond.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPack_cond.UseDynamicFormat = false;
            this.popPack_cond.ValueTextBoxName = null;
            this.popPack_cond.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPack_cond_BeforePopupOpen);
            this.popPack_cond.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPack_cond_AfterPopupClosed);
            // 
            // popDischge_port_Cd
            // 
            this.popDischge_port_Cd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popDischge_port_Cd.AutoPopupCodeParameter = null;
            this.popDischge_port_Cd.AutoPopupID = null;
            this.popDischge_port_Cd.AutoPopupNameParameter = null;
            this.popDischge_port_Cd.CodeMaxLength = 5;
            this.popDischge_port_Cd.CodeName = "";
            this.popDischge_port_Cd.CodeSize = 100;
            this.popDischge_port_Cd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDischge_port_Cd.CodeTextBoxName = null;
            this.popDischge_port_Cd.CodeValue = "";
            this.popDischge_port_Cd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popDischge_port_Cd.Location = new System.Drawing.Point(135, 122);
            this.popDischge_port_Cd.LockedField = false;
            this.popDischge_port_Cd.Margin = new System.Windows.Forms.Padding(0);
            this.popDischge_port_Cd.Name = "popDischge_port_Cd";
            this.popDischge_port_Cd.NameDisplay = true;
            this.popDischge_port_Cd.NameId = null;
            this.popDischge_port_Cd.NameMaxLength = 50;
            this.popDischge_port_Cd.NamePopup = false;
            this.popDischge_port_Cd.NameSize = 150;
            this.popDischge_port_Cd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDischge_port_Cd.Parameter = null;
            this.popDischge_port_Cd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popDischge_port_Cd.PopupId = null;
            this.popDischge_port_Cd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popDischge_port_Cd.QueryIfEnterKeyPressed = true;
            this.popDischge_port_Cd.RequiredField = false;
            this.popDischge_port_Cd.Size = new System.Drawing.Size(271, 21);
            this.popDischge_port_Cd.TabIndex = 9;
            this.popDischge_port_Cd.uniALT = "Arrival Port";
            this.popDischge_port_Cd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popDischge_port_Cd.UseDynamicFormat = false;
            this.popDischge_port_Cd.ValueTextBoxName = null;
            this.popDischge_port_Cd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDischge_port_Cd_BeforePopupOpen);
            this.popDischge_port_Cd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDischge_port_Cd_AfterPopupClosed);
            // 
            // popLoading_port_Cd
            // 
            this.popLoading_port_Cd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popLoading_port_Cd.AutoPopupCodeParameter = null;
            this.popLoading_port_Cd.AutoPopupID = null;
            this.popLoading_port_Cd.AutoPopupNameParameter = null;
            this.popLoading_port_Cd.CodeMaxLength = 5;
            this.popLoading_port_Cd.CodeName = "";
            this.popLoading_port_Cd.CodeSize = 100;
            this.popLoading_port_Cd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popLoading_port_Cd.CodeTextBoxName = null;
            this.popLoading_port_Cd.CodeValue = "";
            this.popLoading_port_Cd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popLoading_port_Cd.Location = new System.Drawing.Point(135, 99);
            this.popLoading_port_Cd.LockedField = false;
            this.popLoading_port_Cd.Margin = new System.Windows.Forms.Padding(0);
            this.popLoading_port_Cd.Name = "popLoading_port_Cd";
            this.popLoading_port_Cd.NameDisplay = true;
            this.popLoading_port_Cd.NameId = null;
            this.popLoading_port_Cd.NameMaxLength = 50;
            this.popLoading_port_Cd.NamePopup = false;
            this.popLoading_port_Cd.NameSize = 150;
            this.popLoading_port_Cd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popLoading_port_Cd.Parameter = null;
            this.popLoading_port_Cd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popLoading_port_Cd.PopupId = null;
            this.popLoading_port_Cd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popLoading_port_Cd.QueryIfEnterKeyPressed = true;
            this.popLoading_port_Cd.RequiredField = false;
            this.popLoading_port_Cd.Size = new System.Drawing.Size(271, 21);
            this.popLoading_port_Cd.TabIndex = 7;
            this.popLoading_port_Cd.uniALT = "Loading Port";
            this.popLoading_port_Cd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popLoading_port_Cd.UseDynamicFormat = false;
            this.popLoading_port_Cd.ValueTextBoxName = null;
            this.popLoading_port_Cd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popLoading_port_Cd_BeforePopupOpen);
            this.popLoading_port_Cd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popLoading_port_Cd_AfterPopupClosed);
            // 
            // dtContract_dt
            // 
            this.dtContract_dt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance55.TextHAlignAsString = "Center";
            this.dtContract_dt.Appearance = appearance55;
            this.dtContract_dt.DateTime = new System.DateTime(2007, 8, 22, 0, 0, 0, 0);
            this.dtContract_dt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtContract_dt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtContract_dt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtContract_dt.Location = new System.Drawing.Point(135, 29);
            this.dtContract_dt.LockedField = false;
            this.dtContract_dt.Margin = new System.Windows.Forms.Padding(0);
            this.dtContract_dt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtContract_dt.Name = "dtContract_dt";
            this.dtContract_dt.QueryIfEnterKeyPressed = true;
            this.dtContract_dt.RequiredField = false;
            this.dtContract_dt.Size = new System.Drawing.Size(100, 22);
            this.dtContract_dt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtContract_dt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtContract_dt.StyleSetName = "Default";
            this.dtContract_dt.TabIndex = 2;
            this.dtContract_dt.uniALT = "Contract Date";
            this.dtContract_dt.uniValue = new System.DateTime(2007, 8, 22, 0, 0, 0, 0);
            this.dtContract_dt.Value = new System.DateTime(2007, 8, 22, 0, 0, 0, 0);
            // 
            // dtValid_dt
            // 
            this.dtValid_dt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance56.TextHAlignAsString = "Center";
            this.dtValid_dt.Appearance = appearance56;
            this.dtValid_dt.DateTime = new System.DateTime(2007, 8, 22, 0, 0, 0, 0);
            this.dtValid_dt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtValid_dt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtValid_dt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtValid_dt.Location = new System.Drawing.Point(617, 29);
            this.dtValid_dt.LockedField = false;
            this.dtValid_dt.Margin = new System.Windows.Forms.Padding(0);
            this.dtValid_dt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtValid_dt.Name = "dtValid_dt";
            this.dtValid_dt.QueryIfEnterKeyPressed = true;
            this.dtValid_dt.RequiredField = false;
            this.dtValid_dt.Size = new System.Drawing.Size(100, 22);
            this.dtValid_dt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtValid_dt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtValid_dt.StyleSetName = "Default";
            this.dtValid_dt.TabIndex = 3;
            this.dtValid_dt.uniALT = "Effective Date";
            this.dtValid_dt.uniValue = new System.DateTime(2007, 8, 22, 0, 0, 0, 0);
            this.dtValid_dt.Value = new System.DateTime(2007, 8, 22, 0, 0, 0, 0);
            // 
            // dtship_dt
            // 
            this.dtship_dt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance57.TextHAlignAsString = "Center";
            this.dtship_dt.Appearance = appearance57;
            this.dtship_dt.DateTime = new System.DateTime(2007, 8, 22, 0, 0, 0, 0);
            this.dtship_dt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtship_dt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtship_dt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtship_dt.Location = new System.Drawing.Point(135, 52);
            this.dtship_dt.LockedField = false;
            this.dtship_dt.Margin = new System.Windows.Forms.Padding(0);
            this.dtship_dt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtship_dt.Name = "dtship_dt";
            this.dtship_dt.QueryIfEnterKeyPressed = true;
            this.dtship_dt.RequiredField = false;
            this.dtship_dt.Size = new System.Drawing.Size(100, 22);
            this.dtship_dt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtship_dt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtship_dt.StyleSetName = "Default";
            this.dtship_dt.TabIndex = 4;
            this.dtship_dt.uniALT = "Shipping Date";
            this.dtship_dt.uniValue = new System.DateTime(2007, 8, 22, 0, 0, 0, 0);
            this.dtship_dt.Value = new System.DateTime(2007, 8, 22, 0, 0, 0, 0);
            // 
            // popOrigin
            // 
            this.popOrigin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popOrigin.AutoPopupCodeParameter = null;
            this.popOrigin.AutoPopupID = null;
            this.popOrigin.AutoPopupNameParameter = null;
            this.popOrigin.CodeMaxLength = 10;
            this.popOrigin.CodeName = "";
            this.popOrigin.CodeSize = 100;
            this.popOrigin.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popOrigin.CodeTextBoxName = null;
            this.popOrigin.CodeValue = "";
            this.popOrigin.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popOrigin.Location = new System.Drawing.Point(617, 53);
            this.popOrigin.LockedField = false;
            this.popOrigin.Margin = new System.Windows.Forms.Padding(0);
            this.popOrigin.Name = "popOrigin";
            this.popOrigin.NameDisplay = true;
            this.popOrigin.NameId = null;
            this.popOrigin.NameMaxLength = 50;
            this.popOrigin.NamePopup = false;
            this.popOrigin.NameSize = 150;
            this.popOrigin.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popOrigin.Parameter = null;
            this.popOrigin.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popOrigin.PopupId = null;
            this.popOrigin.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popOrigin.QueryIfEnterKeyPressed = true;
            this.popOrigin.RequiredField = false;
            this.popOrigin.Size = new System.Drawing.Size(271, 21);
            this.popOrigin.TabIndex = 5;
            this.popOrigin.uniALT = "Origin";
            this.popOrigin.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popOrigin.UseDynamicFormat = false;
            this.popOrigin.ValueTextBoxName = null;
            this.popOrigin.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popOrigin_BeforePopupOpen);
            this.popOrigin.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popOrigin_AfterPopupClosed);
            // 
            // txtShip_dt_txt
            // 
            this.txtShip_dt_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance58.TextVAlignAsString = "Bottom";
            this.txtShip_dt_txt.Appearance = appearance58;
            this.txtShip_dt_txt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtShip_dt_txt.Location = new System.Drawing.Point(135, 75);
            this.txtShip_dt_txt.LockedField = false;
            this.txtShip_dt_txt.Margin = new System.Windows.Forms.Padding(0);
            this.txtShip_dt_txt.MaxLength = 80;
            this.txtShip_dt_txt.Name = "txtShip_dt_txt";
            this.txtShip_dt_txt.QueryIfEnterKeyPressed = true;
            this.txtShip_dt_txt.RequiredField = false;
            this.txtShip_dt_txt.Size = new System.Drawing.Size(347, 22);
            this.txtShip_dt_txt.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtShip_dt_txt.StyleSetName = "Default";
            this.txtShip_dt_txt.TabIndex = 6;
            this.txtShip_dt_txt.uniALT = "Shipment Date Ref.";
            this.txtShip_dt_txt.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtShip_dt_txt.UseDynamicFormat = false;
            // 
            // popSending_Bank
            // 
            this.popSending_Bank.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSending_Bank.AutoPopupCodeParameter = null;
            this.popSending_Bank.AutoPopupID = null;
            this.popSending_Bank.AutoPopupNameParameter = null;
            this.popSending_Bank.CodeMaxLength = 10;
            this.popSending_Bank.CodeName = "";
            this.popSending_Bank.CodeSize = 100;
            this.popSending_Bank.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSending_Bank.CodeTextBoxName = null;
            this.popSending_Bank.CodeValue = "";
            this.popSending_Bank.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popSending_Bank.Location = new System.Drawing.Point(617, 76);
            this.popSending_Bank.LockedField = false;
            this.popSending_Bank.Margin = new System.Windows.Forms.Padding(0);
            this.popSending_Bank.Name = "popSending_Bank";
            this.popSending_Bank.NameDisplay = true;
            this.popSending_Bank.NameId = null;
            this.popSending_Bank.NameMaxLength = 30;
            this.popSending_Bank.NamePopup = false;
            this.popSending_Bank.NameSize = 150;
            this.popSending_Bank.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSending_Bank.Parameter = null;
            this.popSending_Bank.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSending_Bank.PopupId = null;
            this.popSending_Bank.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSending_Bank.QueryIfEnterKeyPressed = true;
            this.popSending_Bank.RequiredField = false;
            this.popSending_Bank.Size = new System.Drawing.Size(271, 21);
            this.popSending_Bank.TabIndex = 8;
            this.popSending_Bank.uniALT = "Rem. Bank";
            this.popSending_Bank.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popSending_Bank.UseDynamicFormat = false;
            this.popSending_Bank.ValueTextBoxName = null;
            this.popSending_Bank.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSending_Bank_BeforePopupOpen);
            this.popSending_Bank.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSending_Bank_AfterPopupClosed);
            // 
            // txtDischge_city
            // 
            this.txtDischge_city.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance59.TextVAlignAsString = "Bottom";
            this.txtDischge_city.Appearance = appearance59;
            this.txtDischge_city.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDischge_city.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.txtDischge_city.Location = new System.Drawing.Point(617, 98);
            this.txtDischge_city.LockedField = false;
            this.txtDischge_city.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.txtDischge_city.MaxLength = 30;
            this.txtDischge_city.Name = "txtDischge_city";
            this.txtDischge_city.QueryIfEnterKeyPressed = true;
            this.txtDischge_city.RequiredField = false;
            this.txtDischge_city.Size = new System.Drawing.Size(345, 22);
            this.txtDischge_city.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtDischge_city.StyleSetName = "Default";
            this.txtDischge_city.TabIndex = 16;
            this.txtDischge_city.uniALT = "Arrival City";
            this.txtDischge_city.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDischge_city.UseDynamicFormat = false;
            // 
            // popInspect_meth
            // 
            this.popInspect_meth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popInspect_meth.AutoPopupCodeParameter = null;
            this.popInspect_meth.AutoPopupID = null;
            this.popInspect_meth.AutoPopupNameParameter = null;
            this.popInspect_meth.CodeMaxLength = 4;
            this.popInspect_meth.CodeName = "";
            this.popInspect_meth.CodeSize = 100;
            this.popInspect_meth.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popInspect_meth.CodeTextBoxName = null;
            this.popInspect_meth.CodeValue = "";
            this.popInspect_meth.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popInspect_meth.Location = new System.Drawing.Point(617, 122);
            this.popInspect_meth.LockedField = false;
            this.popInspect_meth.Margin = new System.Windows.Forms.Padding(0);
            this.popInspect_meth.Name = "popInspect_meth";
            this.popInspect_meth.NameDisplay = true;
            this.popInspect_meth.NameId = null;
            this.popInspect_meth.NameMaxLength = 20;
            this.popInspect_meth.NamePopup = false;
            this.popInspect_meth.NameSize = 150;
            this.popInspect_meth.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popInspect_meth.Parameter = null;
            this.popInspect_meth.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popInspect_meth.PopupId = null;
            this.popInspect_meth.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popInspect_meth.QueryIfEnterKeyPressed = true;
            this.popInspect_meth.RequiredField = false;
            this.popInspect_meth.Size = new System.Drawing.Size(271, 21);
            this.popInspect_meth.TabIndex = 12;
            this.popInspect_meth.uniALT = "Insp. Method";
            this.popInspect_meth.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popInspect_meth.UseDynamicFormat = false;
            this.popInspect_meth.ValueTextBoxName = null;
            this.popInspect_meth.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popInspect_meth_BeforePopupOpen);
            this.popInspect_meth.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popInspect_meth_AfterPopupClosed);
            // 
            // popAgent
            // 
            this.popAgent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popAgent.AutoPopupCodeParameter = null;
            this.popAgent.AutoPopupID = null;
            this.popAgent.AutoPopupNameParameter = null;
            this.popAgent.CodeMaxLength = 10;
            this.popAgent.CodeName = "";
            this.popAgent.CodeSize = 100;
            this.popAgent.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popAgent.CodeTextBoxName = null;
            this.popAgent.CodeValue = "";
            this.popAgent.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popAgent.Location = new System.Drawing.Point(617, 145);
            this.popAgent.LockedField = false;
            this.popAgent.Margin = new System.Windows.Forms.Padding(0);
            this.popAgent.Name = "popAgent";
            this.popAgent.NameDisplay = true;
            this.popAgent.NameId = null;
            this.popAgent.NameMaxLength = 50;
            this.popAgent.NamePopup = false;
            this.popAgent.NameSize = 150;
            this.popAgent.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popAgent.Parameter = null;
            this.popAgent.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popAgent.PopupId = null;
            this.popAgent.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popAgent.QueryIfEnterKeyPressed = true;
            this.popAgent.RequiredField = false;
            this.popAgent.Size = new System.Drawing.Size(271, 21);
            this.popAgent.TabIndex = 14;
            this.popAgent.uniALT = "Agent";
            this.popAgent.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popAgent.UseDynamicFormat = false;
            this.popAgent.ValueTextBoxName = null;
            this.popAgent.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popAgent_BeforePopupOpen);
            this.popAgent.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popAgent_AfterPopupClosed);
            // 
            // lblSending_Bank
            // 
            appearance60.TextHAlignAsString = "Left";
            appearance60.TextVAlignAsString = "Middle";
            this.lblSending_Bank.Appearance = appearance60;
            this.lblSending_Bank.AutoPopupID = null;
            this.lblSending_Bank.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSending_Bank.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSending_Bank.Location = new System.Drawing.Point(497, 75);
            this.lblSending_Bank.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSending_Bank.Name = "lblSending_Bank";
            this.lblSending_Bank.Size = new System.Drawing.Size(120, 22);
            this.lblSending_Bank.StyleSetName = "Default";
            this.lblSending_Bank.TabIndex = 12;
            this.lblSending_Bank.Text = "Rem. Bank";
            this.lblSending_Bank.UseMnemonic = false;
            // 
            // lblDischge_city
            // 
            appearance61.TextHAlignAsString = "Left";
            appearance61.TextVAlignAsString = "Middle";
            this.lblDischge_city.Appearance = appearance61;
            this.lblDischge_city.AutoPopupID = null;
            this.lblDischge_city.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDischge_city.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDischge_city.Location = new System.Drawing.Point(497, 98);
            this.lblDischge_city.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDischge_city.Name = "lblDischge_city";
            this.lblDischge_city.Size = new System.Drawing.Size(120, 22);
            this.lblDischge_city.StyleSetName = "Default";
            this.lblDischge_city.TabIndex = 13;
            this.lblDischge_city.Text = "Arrival City";
            this.lblDischge_city.UseMnemonic = false;
            // 
            // lblInspect_meth
            // 
            appearance62.TextHAlignAsString = "Left";
            appearance62.TextVAlignAsString = "Middle";
            this.lblInspect_meth.Appearance = appearance62;
            this.lblInspect_meth.AutoPopupID = null;
            this.lblInspect_meth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInspect_meth.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblInspect_meth.Location = new System.Drawing.Point(497, 121);
            this.lblInspect_meth.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblInspect_meth.Name = "lblInspect_meth";
            this.lblInspect_meth.Size = new System.Drawing.Size(120, 22);
            this.lblInspect_meth.StyleSetName = "Default";
            this.lblInspect_meth.TabIndex = 14;
            this.lblInspect_meth.Text = "Insp. Method";
            this.lblInspect_meth.UseMnemonic = false;
            // 
            // lblAgent
            // 
            appearance63.TextHAlignAsString = "Left";
            appearance63.TextVAlignAsString = "Middle";
            this.lblAgent.Appearance = appearance63;
            this.lblAgent.AutoPopupID = null;
            this.lblAgent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAgent.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblAgent.Location = new System.Drawing.Point(497, 144);
            this.lblAgent.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblAgent.Name = "lblAgent";
            this.lblAgent.Size = new System.Drawing.Size(120, 22);
            this.lblAgent.StyleSetName = "Default";
            this.lblAgent.TabIndex = 15;
            this.lblAgent.Text = "Agent";
            this.lblAgent.UseMnemonic = false;
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.DefaultRowSize = 25;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(979, 740);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.popConSo_no, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblConSo_no, 0, 0);
            this.uniTBL_MainCondition.DefaultRowSize = 25;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 1;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(979, 38);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // popConSo_no
            // 
            this.popConSo_no.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popConSo_no.AutoPopupCodeParameter = null;
            this.popConSo_no.AutoPopupID = null;
            this.popConSo_no.AutoPopupNameParameter = null;
            this.popConSo_no.CodeMaxLength = 18;
            this.popConSo_no.CodeName = "";
            this.popConSo_no.CodeSize = 150;
            this.popConSo_no.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popConSo_no.CodeTextBoxName = null;
            this.popConSo_no.CodeValue = "";
            this.popConSo_no.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popConSo_no.Location = new System.Drawing.Point(137, 7);
            this.popConSo_no.LockedField = false;
            this.popConSo_no.Margin = new System.Windows.Forms.Padding(0);
            this.popConSo_no.Name = "popConSo_no";
            this.popConSo_no.NameDisplay = false;
            this.popConSo_no.NameId = null;
            this.popConSo_no.NameMaxLength = 50;
            this.popConSo_no.NamePopup = false;
            this.popConSo_no.NameSize = 100;
            this.popConSo_no.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popConSo_no.Parameter = null;
            this.popConSo_no.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popConSo_no.PopupId = null;
            this.popConSo_no.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popConSo_no.QueryIfEnterKeyPressed = true;
            this.popConSo_no.RequiredField = false;
            this.popConSo_no.Size = new System.Drawing.Size(171, 21);
            this.popConSo_no.TabIndex = 0;
            this.popConSo_no.uniALT = "S/O No.";
            this.popConSo_no.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popConSo_no.UseDynamicFormat = false;
            this.popConSo_no.ValueTextBoxName = null;
            this.popConSo_no.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popConSo_no_BeforePopupOpen);
            this.popConSo_no.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popConSo_no_AfterPopupClosed);
            // 
            // lblConSo_no
            // 
            appearance64.TextHAlignAsString = "Left";
            appearance64.TextVAlignAsString = "Middle";
            this.lblConSo_no.Appearance = appearance64;
            this.lblConSo_no.AutoPopupID = null;
            this.lblConSo_no.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblConSo_no.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblConSo_no.Location = new System.Drawing.Point(15, 6);
            this.lblConSo_no.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblConSo_no.Name = "lblConSo_no";
            this.lblConSo_no.Size = new System.Drawing.Size(122, 22);
            this.lblConSo_no.StyleSetName = "Default";
            this.lblConSo_no.TabIndex = 1;
            this.lblConSo_no.Text = "S/O No.";
            this.lblConSo_no.UseMnemonic = false;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.Controls.Add(this.lblSORef, 1, 0);
            this.uniTBL_MainReference.Controls.Add(this.lblProjectReference, 2, 0);
            this.uniTBL_MainReference.DefaultRowSize = 25;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(979, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 0;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblSORef
            // 
            appearance65.TextHAlignAsString = "Left";
            appearance65.TextVAlignAsString = "Middle";
            this.lblSORef.Appearance = appearance65;
            this.lblSORef.AutoPopupID = null;
            this.lblSORef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSORef.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblSORef.Location = new System.Drawing.Point(779, 3);
            this.lblSORef.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblSORef.Name = "lblSORef";
            this.lblSORef.Size = new System.Drawing.Size(100, 15);
            this.lblSORef.StyleSetName = "uniLabel_Reference";
            this.lblSORef.TabIndex = 3;
            this.lblSORef.Text = "S/O Ref.";
            this.lblSORef.UseMnemonic = false;
            this.lblSORef.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblSORef_BeforePopupOpen);
            this.lblSORef.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblSORef_AfterPopupClosed);
            // 
            // lblProjectReference
            // 
            appearance66.TextHAlignAsString = "Left";
            appearance66.TextVAlignAsString = "Middle";
            this.lblProjectReference.Appearance = appearance66;
            this.lblProjectReference.AutoPopupID = null;
            this.lblProjectReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProjectReference.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblProjectReference.Location = new System.Drawing.Point(879, 3);
            this.lblProjectReference.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblProjectReference.Name = "lblProjectReference";
            this.lblProjectReference.Size = new System.Drawing.Size(100, 15);
            this.lblProjectReference.StyleSetName = "uniLabel_Reference";
            this.lblProjectReference.TabIndex = 2;
            this.lblProjectReference.Text = "Project Reference";
            this.lblProjectReference.UseMnemonic = false;
            this.lblProjectReference.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblProjectReference_BeforePopupOpen);
            this.lblProjectReference.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblProjectReference_AfterPopupClosed);
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 6;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTBL_MainBatch.Controls.Add(this.btnDNCancel, 0, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnDNCheck, 0, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnCancel, 3, 0);
            this.uniTBL_MainBatch.Controls.Add(this.btnConfirm, 2, 0);
            this.uniTBL_MainBatch.Controls.Add(this.lblSalesOrderDetail, 5, 0);
            this.uniTBL_MainBatch.DefaultRowSize = 25;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 711);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(979, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnDNCancel
            // 
            this.btnDNCancel.AutoPopupID = null;
            this.btnDNCancel.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnDNCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDNCancel.Location = new System.Drawing.Point(100, 1);
            this.btnDNCancel.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnDNCancel.Name = "btnDNCancel";
            this.btnDNCancel.PopupID = null;
            this.btnDNCancel.Size = new System.Drawing.Size(97, 24);
            this.btnDNCancel.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnDNCancel.TabIndex = 4;
            this.btnDNCancel.Text = "Shipment Cancel";
            this.btnDNCancel.UserDefinedText = null;
            this.btnDNCancel.Click += new System.EventHandler(this.btnDNCheck_Click);
            // 
            // btnDNCheck
            // 
            this.btnDNCheck.AutoPopupID = null;
            this.btnDNCheck.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnDNCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDNCheck.Location = new System.Drawing.Point(0, 1);
            this.btnDNCheck.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnDNCheck.Name = "btnDNCheck";
            this.btnDNCheck.PopupID = null;
            this.btnDNCheck.Size = new System.Drawing.Size(97, 24);
            this.btnDNCheck.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnDNCheck.TabIndex = 0;
            this.btnDNCheck.Text = "Shipment Req.";
            this.btnDNCheck.UserDefinedText = null;
            this.btnDNCheck.Click += new System.EventHandler(this.btnDNCheck_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.AutoPopupID = null;
            this.btnCancel.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCancel.Location = new System.Drawing.Point(300, 1);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.PopupID = null;
            this.btnCancel.Size = new System.Drawing.Size(97, 24);
            this.btnCancel.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UserDefinedText = null;
            this.btnCancel.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.AutoPopupID = null;
            this.btnConfirm.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnConfirm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnConfirm.Location = new System.Drawing.Point(200, 1);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.PopupID = null;
            this.btnConfirm.Size = new System.Drawing.Size(97, 24);
            this.btnConfirm.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnConfirm.TabIndex = 3;
            this.btnConfirm.Text = "Release";
            this.btnConfirm.UserDefinedText = null;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // lblSalesOrderDetail
            // 
            appearance67.TextHAlignAsString = "Left";
            appearance67.TextVAlignAsString = "Middle";
            this.lblSalesOrderDetail.Appearance = appearance67;
            this.lblSalesOrderDetail.AutoPopupID = null;
            this.lblSalesOrderDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSalesOrderDetail.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Jump;
            this.lblSalesOrderDetail.Location = new System.Drawing.Point(859, 3);
            this.lblSalesOrderDetail.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblSalesOrderDetail.Name = "lblSalesOrderDetail";
            this.lblSalesOrderDetail.Size = new System.Drawing.Size(120, 22);
            this.lblSalesOrderDetail.StyleSetName = "uniLabel_Jump";
            this.lblSalesOrderDetail.TabIndex = 2;
            this.lblSalesOrderDetail.Text = "(E) Sales Order Detail";
            this.lblSalesOrderDetail.UseMnemonic = false;
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.tab1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 25;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 40F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 74);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(979, 634);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 2;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // tab1
            // 
            this.tab1.Controls.Add(this.ultraTabSharedControlsPage1);
            this.tab1.Controls.Add(this.ultraTabPageControl1);
            this.tab1.Controls.Add(this.ultraTabPageControl2);
            this.tab1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab1.Location = new System.Drawing.Point(1, 3);
            this.tab1.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.tab1.Name = "tab1";
            this.tab1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tab1.ReferenceTable = null;
            this.tab1.SharedControlsPage = this.ultraTabSharedControlsPage1;
            this.tab1.Size = new System.Drawing.Size(977, 628);
            this.tab1.TabIndex = 0;
            this.tab1.TabMode = uniERP.AppFramework.UI.Variables.enumDef.TabMode.All;
            this.tab1.TabPadding = new System.Drawing.Size(19, 2);
            ultraTab1.TabPage = this.ultraTabPageControl1;
            ultraTab1.Text = "S/O General";
            ultraTab2.TabPage = this.ultraTabPageControl2;
            ultraTab2.Text = "Trade Info.";
            this.tab1.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab1,
            ultraTab2});
            this.tab1.SelectedTabChanging += new Infragistics.Win.UltraWinTabControl.SelectedTabChangingEventHandler(this.tab1_SelectedTabChanging);
            // 
            // ultraTabSharedControlsPage1
            // 
            this.ultraTabSharedControlsPage1.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage1.Name = "ultraTabSharedControlsPage1";
            this.ultraTabSharedControlsPage1.Size = new System.Drawing.Size(973, 600);
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(990, 760);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.ultraTabPageControl1.ResumeLayout(false);
            this.tbl1.ResumeLayout(false);
            this.tbl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtSo_dt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtCust_po_dt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Payterms_txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCust_po_no)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtReq_dlvy_dt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoPrice_flag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoCfm_flag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXchg_rate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVat_amt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNet_Amt_Loc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).EndInit();
            this.tbl3.ResumeLayout(false);
            this.tbl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numVat_rate)).EndInit();
            this.tbl4.ResumeLayout(false);
            this.tbl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPay_dur)).EndInit();
            this.pnlNetAmt.ResumeLayout(false);
            this.pnlNetAmt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDoc_cur)).EndInit();
            this.popCurr.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numExt2Amt)).EndInit();
            this.ultraTabPageControl2.ResumeLayout(false);
            this.tbl2.ResumeLayout(false);
            this.tbl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtContract_dt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtValid_dt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtship_dt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShip_dt_txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDischge_city)).EndInit();
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainReference.ResumeLayout(false);
            this.uniTBL_MainBatch.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tab1)).EndInit();
            this.tab1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTabControl tab1;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl1;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel tbl1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl2;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSoNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSo_Type;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSo_dt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCust_po_dt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSold_to_party;
        private uniERP.AppFramework.UI.Controls.uniLabel lblShip_to_party;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPayer;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDeal_Type;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPay_terms;
        private uniERP.AppFramework.UI.Controls.uniLabel lblVat_Inc_Flag;
        private uniERP.AppFramework.UI.Controls.uniLabel lblVat_Type;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popConSo_no;
        private uniERP.AppFramework.UI.Controls.uniLabel lblConSo_no;
        private uniERP.AppFramework.UI.Controls.uniLabel lblVat_amt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblVat_rate;
        private uniERP.AppFramework.UI.Controls.uniLabel lbl_Payterms_txt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRemark;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCfm_flag;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPrice_flag;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReq_dlvy_dt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCust_po_no;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSales_Grp;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBill_to_party;
        private uniERP.AppFramework.UI.Controls.uniLabel lblTo_Biz_Grp;
        private uniERP.AppFramework.UI.Controls.uniLabel lblTrans_Meth;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPay_dur;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDoc_cur;
        private uniERP.AppFramework.UI.Controls.uniLabel lblXchg_rate;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPay_type;
        private uniERP.AppFramework.UI.Controls.uniLabel lblNet_Amt_Loc;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtSoNo;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtSo_dt;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtCust_po_dt;
        private uniERP.AppFramework.UI.Controls.uniTextBox txt_Payterms_txt;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtRemark;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPay_type;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popTrans_Meth;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popTo_Biz_Grp;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popBill_to_party;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSales_Grp;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtCust_po_no;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtReq_dlvy_dt;
        private uniERP.AppFramework.UI.Controls.uniRadioButton rdoPrice_flag;
        private uniERP.AppFramework.UI.Controls.uniRadioButton rdoCfm_flag;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSo_Type;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSold_to_party;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popShip_to_party;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPayer;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popDeal_Type;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPay_terms;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popVat_Inc_Flag;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popVat_Type;
        private uniERP.AppFramework.UI.Controls.uniButton btnDNCheck;
        private uniERP.AppFramework.UI.Controls.uniButton btnCancel;
        private uniERP.AppFramework.UI.Controls.uniNumeric numPay_dur;
        private uniERP.AppFramework.UI.Controls.uniNumeric numXchg_rate;
        private uniERP.AppFramework.UI.Controls.uniNumeric numVat_amt;
        private uniERP.AppFramework.UI.Controls.uniNumeric numNet_Amt_Loc;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel tbl2;
        private uniERP.AppFramework.UI.Controls.uniLabel lblIncoTerms;
        private uniERP.AppFramework.UI.Controls.uniLabel lblContract_dt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblship_dt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblShip_dt_txt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblLoading_port_Cd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDischge_port_Cd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPack_cond;
        private uniERP.AppFramework.UI.Controls.uniLabel lblManufacturer;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBeneficiary;
        private uniERP.AppFramework.UI.Controls.uniLabel lblValid_dt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblOrigin;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSending_Bank;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDischge_city;
        private uniERP.AppFramework.UI.Controls.uniLabel lblInspect_meth;
        private uniERP.AppFramework.UI.Controls.uniLabel lblAgent;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popIncoTerms;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popBeneficiary;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popManufacturer;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPack_cond;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popDischge_port_Cd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popLoading_port_Cd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSending_Bank;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popInspect_meth;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popAgent;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtContract_dt;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtValid_dt;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtship_dt;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popOrigin;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtShip_dt_txt;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel tbl3;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel tbl4;
        private uniERP.AppFramework.UI.Controls.uniLabel lbldays;
        private uniERP.AppFramework.UI.Controls.uniLabel lblProjectReference;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSalesOrderDetail;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSORef;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtDischge_city;
        private uniERP.AppFramework.UI.Controls.uniButton btnConfirm;
        private uniERP.AppFramework.UI.Controls.uniButton btnDNCancel;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPerc;
        private uniERP.AppFramework.UI.Controls.uniNumeric numVat_rate;
        private uniERP.AppFramework.UI.Controls.uniPanel pnlNetAmt;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popDoc_cur;
        private uniERP.AppFramework.UI.Controls.uniNumeric numDoc_cur;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCurr;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popCurr;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Name;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Code;
        private uniERP.AppFramework.UI.Controls.uniNumeric numExt2Amt;
        private uniERP.AppFramework.UI.Controls.uniLabel uniLabel1;

    }
}
