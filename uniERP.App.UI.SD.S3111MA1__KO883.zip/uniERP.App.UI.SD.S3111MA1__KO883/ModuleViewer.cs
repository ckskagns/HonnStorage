﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Common.Exceptions;
#endregion

namespace uniERP.App.UI.SD.S3111MA1__KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <NameSpace>①namespace</NameSpace>
        /// <Module>②module name</Module>
        /// <Class>③class name</Class>
        /// <Desc>④
        ///   This part describe the summary information about class 
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="creator" Date="created date">Make …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        private wsPS3G102FL.DsSLookupSoHdrSvr cqtdsSLookupSoHdrSvr = new wsPS3G102FL.DsSLookupSoHdrSvr();

        string cstrProjectCd = string.Empty;
        string cstrReq_dlvy_dt = string.Empty;
        string cstrRadioFlag = string.Empty;
        string cstrRadioType = string.Empty;
        string cstrRetItemFlag = string.Empty;
        string cstrHRdoConfirm = string.Empty;
        string cstrHRdioType = string.Empty;
        string gSelframeFlg = string.Empty;
        string cstrSoTypeExportFlag = string.Empty;
        string cstrSoTypeRetItemFlag = String.Empty;
        string cstrDlvyLt = String.Empty;
        string cstrSoTypeCiFlag = String.Empty;
        string cstrMaintNo = String.Empty;
        string cstrSoSts = String.Empty;
        string cstrRdoDnReq = String.Empty;        
        string cstrPrevRadioFlag = String.Empty;
        string cstrPrevRadioType = String.Empty;
        string cstrHSONo = String.Empty;
        string cstrSoNo = String.Empty;
        string cstrCur = String.Empty;
        string cstrelbillflag = string.Empty;

        #endregion

        #region ■ 1.4 Class global constants (grid)

        #endregion

        #region ■ 1.5 Class global variables (grid)

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(cqtdsSLookupSoHdrSvr);
            uniBase.UCommon.SetViewType( enumDef.ViewType.T01_Single| enumDef.ViewType.T91_TAB);
            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.Common);  // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                          // Load custoqm numeric format
        }

        protected override void Form_Load_Completed()
        {
                      
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {

        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            uniBase.UCommon.SetToolBarAll(false);
            uniBase.UCommon.SetToolBarCommonAll(true);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New, true);

            DateTime dbTime = uniBase.UDate.GetDBServerDateTime();

            cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].req_dlvy_dt = dbTime;
            cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].cust_po_dt = dbTime;
            cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].so_dt = dbTime;
            cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].contract_dt = dbTime;
            cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].valid_dt = dbTime;
            dtContract_dt.Value = dbTime;

            cqtdsSLookupSoHdrSvr.AcceptChanges();           

            //radio button
            rdoCfm_flag.CheckedIndex = 1;
            rdoPrice_flag.CheckedIndex = 0;
            cstrRadioFlag = rdoCfm_flag.CheckedItem.DataValue.ToString().Trim();
            cstrRadioType = rdoPrice_flag.CheckedItem.DataValue.ToString().Trim();

           
            uniBase.UCommon.DisableButton(btnCancel, false);
            uniBase.UCommon.DisableButton(btnDNCheck, false);
            uniBase.UCommon.DisableButton(btnDNCancel, false);
            uniBase.UCommon.DisableButton(btnConfirm, false);
            
            //lock xRate
            uniBase.UCommon.ChangeFieldLockAttribute(numXchg_rate, enumDef.FieldLockAttribute.Protected);
            numXchg_rate.FieldType = enumDef.FieldType.ReadOnly;

            // set default value
            popBeneficiary.CodeValue = CommonVariable.gCompany;
            popBeneficiary.CodeName = CommonVariable.gCompanyNm;

            cstrProjectCd = string.Empty;
            cstrReq_dlvy_dt = string.Empty;
            cstrRadioFlag = string.Empty;
            cstrRadioType = string.Empty;
            cstrHRdoConfirm = string.Empty;
            //
            
            //
            cstrHRdioType = string.Empty;
            gSelframeFlg = string.Empty;

            cstrSoTypeExportFlag = string.Empty;
            cstrSoTypeRetItemFlag = String.Empty;
            cstrDlvyLt = String.Empty;
            cstrSoTypeCiFlag = String.Empty;
            cstrMaintNo = String.Empty;
            cstrSoSts = String.Empty;
            cstrRdoDnReq = String.Empty;
            cstrPrevRadioFlag = String.Empty;
            cstrPrevRadioType = String.Empty;
            cstrHSONo = String.Empty;

            return;
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            // Example: Set ComboBox List (Column Name, Select, From, Where)
            //uniBase.UData.ComboMajorAdd("TaxPolicy", "B0004");
            //uniBase.UData.ComboCustomAdd("MSG_TYPE", "MINOR_CD , MINOR_NM ", "B_MINOR", "MAJOR_CD='A1001'");

        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {
            #region User Define Numeric Format Data Setting  ☆
            base.viewTB19029.ggUserDefined6.DecPoint = 0;
            base.viewTB19029.ggUserDefined6.Integeral = 20;

            base.viewTB19029.ggUserDefinedB.DecPoint = 2;
            
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            #endregion

            #region ■■ 3.1.2 Formatting grid information

            //uniGrid1.InitializeGrid(enumIsOutlookGroupBy.No, enumDef.IsSearch.No);            

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            // Hidden Column Setting
            
            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
            // TO-DO: 컨트롤을 초기화(또는 초기값)할때 할일 
            // SetDefaultVal과의 차이점은 전자는 Form_Load 시점에 콘트롤에 초기값을 세팅하는것이고
            // 후자는 특정 시점(조회후 또는 행추가후 등 특정이벤트)에서 초기값을 셋팅한다.
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {

            wsPS3G102FL.DsSLookupSoHdrSvr.ES_SO_HDRDataTable uniTB = cqtdsSLookupSoHdrSvr.ES_SO_HDR;
            //tb1
            uniBase.UData.addDataBinding(txtSoNo, uniTB.so_noColumn);
            //radio
            uniBase.UData.addDataBinding(popSo_Type, "CodeValue", uniTB.so_typeColumn);
            uniBase.UData.addDataBinding(popSo_Type, "CodeName", uniTB.so_type_nmColumn);

            //datetime -- tangwei modified
            uniBase.UData.addDataBinding(dtSo_dt, uniTB.so_dtColumn);
            uniBase.UData.addDataBinding(dtReq_dlvy_dt, uniTB.req_dlvy_dtColumn);
            uniBase.UData.addDataBinding(dtCust_po_dt, uniTB.cust_po_dtColumn);

            uniBase.UData.addDataBinding(txtCust_po_no, uniTB.cust_po_noColumn);
            uniBase.UData.addDataBinding(popSold_to_party, "CodeValue", uniTB.sold_to_partyColumn);
            uniBase.UData.addDataBinding(popSold_to_party, "CodeName", uniTB.sold_to_party_nmColumn);
            uniBase.UData.addDataBinding(popSales_Grp, "CodeValue", uniTB.sales_grpColumn);
            uniBase.UData.addDataBinding(popSales_Grp, "CodeName", uniTB.sales_grp_nmColumn);
            uniBase.UData.addDataBinding(popShip_to_party, "CodeValue", uniTB.ship_to_partyColumn);
            uniBase.UData.addDataBinding(popShip_to_party, "CodeName", uniTB.ship_to_party_nmColumn);
            uniBase.UData.addDataBinding(popBill_to_party, "CodeValue", uniTB.bill_to_partyColumn);
            uniBase.UData.addDataBinding(popBill_to_party, "CodeName", uniTB.bill_to_party_nmColumn);
            uniBase.UData.addDataBinding(popPayer, "CodeValue", uniTB.payerColumn);
            uniBase.UData.addDataBinding(popPayer, "CodeName", uniTB.payer_nmColumn);
            uniBase.UData.addDataBinding(popTo_Biz_Grp, "CodeValue", uniTB.to_biz_grpColumn);
            uniBase.UData.addDataBinding(popTo_Biz_Grp, "CodeName", uniTB.to_biz_grp_nmColumn);
            uniBase.UData.addDataBinding(popDeal_Type, "CodeValue", uniTB.deal_typeColumn);
            uniBase.UData.addDataBinding(popDeal_Type, "CodeName", uniTB.deal_type_nmColumn);
            uniBase.UData.addDataBinding(popTrans_Meth, "CodeValue", uniTB.trans_methColumn);
            uniBase.UData.addDataBinding(popTrans_Meth, "CodeName", uniTB.trans_meth_nmColumn);
            uniBase.UData.addDataBinding(popPay_terms, "CodeValue", uniTB.pay_methColumn);
            uniBase.UData.addDataBinding(popPay_terms, "CodeName", uniTB.pay_meth_nmColumn);
            uniBase.UData.addDataBinding(numPay_dur, uniTB.pay_durColumn);
            uniBase.UData.addDataBinding(popVat_Inc_Flag, "CodeValue", uniTB.vat_inc_flagColumn);
            uniBase.UData.addDataBinding(popVat_Inc_Flag, "CodeName", uniTB.vat_inc_flag_nmColumn);
            uniBase.UData.addDataBinding(popDoc_cur, "CodeValue", uniTB.curColumn);
            uniBase.UData.addDataBinding(numDoc_cur, uniTB.net_amtColumn);
            uniBase.UData.addDataBinding(popVat_Type, "CodeValue", uniTB.vat_typeColumn);
            uniBase.UData.addDataBinding(popVat_Type, "CodeName", uniTB.vat_type_nmColumn);
            uniBase.UData.addDataBinding(numXchg_rate, uniTB.xchg_rateColumn);
            uniBase.UData.addDataBinding(numVat_rate, uniTB.vat_rateColumn);

            uniBase.UData.addDataBinding(popPay_type, "CodeValue", uniTB.pay_typeColumn);
            uniBase.UData.addDataBinding(popPay_type, "CodeName", uniTB.pay_type_nmColumn);
            uniBase.UData.addDataBinding(numVat_amt, uniTB.vat_amtColumn);
            uniBase.UData.addDataBinding(numNet_Amt_Loc, uniTB.net_amt_locColumn);
            uniBase.UData.addDataBinding(txt_Payterms_txt, uniTB.pay_terms_txtColumn);
            uniBase.UData.addDataBinding(txtRemark, uniTB.remarkColumn);

            ////tab2
            uniBase.UData.addDataBinding(popIncoTerms, "CodeValue", uniTB.incotermsColumn);
            uniBase.UData.addDataBinding(popIncoTerms, "CodeName", uniTB.incoterms_nmColumn);
            uniBase.UData.addDataBinding(popBeneficiary, "CodeValue", uniTB.beneficiaryColumn);
            uniBase.UData.addDataBinding(popBeneficiary, "CodeName", uniTB.beneficiary_nmColumn);

            //datetime
            uniBase.UData.addDataBinding(dtContract_dt, uniTB.contract_dtColumn);
            uniBase.UData.addDataBinding(dtValid_dt, uniTB.valid_dtColumn);
            ////todo: 取消注  ba bug
            uniBase.UData.addDataBinding(dtship_dt, uniTB.ship_dtColumn);

            uniBase.UData.addDataBinding(popOrigin, "CodeValue", uniTB.origin_cdColumn);
            uniBase.UData.addDataBinding(popOrigin, "CodeName", uniTB.origin_nmColumn);
            uniBase.UData.addDataBinding(txtShip_dt_txt, uniTB.ship_dt_txtColumn);
            uniBase.UData.addDataBinding(popLoading_port_Cd, "CodeValue", uniTB.loading_port_cdColumn);
            uniBase.UData.addDataBinding(popLoading_port_Cd, "CodeName", uniTB.loading_port_nmColumn);
            uniBase.UData.addDataBinding(popSending_Bank, "CodeValue", uniTB.bank_cdColumn);
            uniBase.UData.addDataBinding(popSending_Bank, "CodeName", uniTB.bank_nmColumn);
            uniBase.UData.addDataBinding(popDischge_port_Cd, "CodeValue", uniTB.dischge_port_cdColumn);
            uniBase.UData.addDataBinding(popDischge_port_Cd, "CodeName", uniTB.dischge_port_nmColumn);
            uniBase.UData.addDataBinding(txtDischge_city, uniTB.dischge_cityColumn);
            uniBase.UData.addDataBinding(popPack_cond, "CodeValue", uniTB.pack_condColumn);
            uniBase.UData.addDataBinding(popPack_cond, "CodeName", uniTB.pack_cond_nmColumn);
            uniBase.UData.addDataBinding(popInspect_meth, "CodeValue", uniTB.inspect_methColumn);
            uniBase.UData.addDataBinding(popInspect_meth, "CodeName", uniTB.inspect_meth_nmColumn);
            uniBase.UData.addDataBinding(popManufacturer, "CodeValue", uniTB.manufacturerColumn);
            uniBase.UData.addDataBinding(popManufacturer, "CodeName", uniTB.manufacturer_nmColumn);
            uniBase.UData.addDataBinding(popAgent, "CodeValue", uniTB.agentColumn);
            uniBase.UData.addDataBinding(popAgent, "CodeName", uniTB.agent_nmColumn);

            //add to --tangwei
            //dtReq_dlvy_dt.uni_AddOperation(1);
            //dtCust_po_dt.uni_AddOperation(1);
            //dtContract_dt.uni_AddOperation(1);
            //dtValid_dt.uni_AddOperation(1);
            dtship_dt.uni_AddOperation(1);
            dtContract_dt.uni_AddOperation(1);


            popCurr.uni_AddOperation(1);
            numExt2Amt.uni_AddOperation(1);

        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)
        //tang wei added for Query
        protected override bool OnPreFncQuery()
        {
            return base.OnPreFncQuery();
            //return true;
        }      

        protected override bool OnFncQuery()
        {
            uniBase.UCommon.DisableButton(btnCancel, false);
            uniBase.UCommon.DisableButton(btnDNCheck, false);
            uniBase.UCommon.DisableButton(btnDNCancel, false);
            uniBase.UCommon.DisableButton(btnConfirm, false);

            LockFieldInit("L");
            UnLockColor_CfmNo();
            return DBQuery();
        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave) 
      
        //tang wei added for Query
        protected override bool OnPreFncSave()
        {
            //tangwei added
            if (cstrSoTypeExportFlag.ToUpper() == "Y" || cstrSoTypeCiFlag.ToUpper() == "Y")
            {
                SoTypeExpRequiredChg();
            }
            else
            {
                SoTypeExpDefaultChg();
            }
            
            return base.OnPreFncSave();
            //return true;
        }
        //tangwei modified
        protected override bool OnFncSave()
        {
            if (!uniBase.UCommon.CheckRequiredField(popSo_Type, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(popSold_to_party , enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(popSales_Grp, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(popShip_to_party, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(popDeal_Type, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(popPay_terms, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(popDoc_cur, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(popIncoTerms, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(popBeneficiary, enumDef.PanelType.Data))
                return false;           
            if (!uniBase.UCommon.CheckRequiredField(txt_Payterms_txt, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(txtRemark, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(txtShip_dt_txt, enumDef.PanelType.Data))
                return false;
            if (!uniBase.UCommon.CheckRequiredField(txtDischge_city, enumDef.PanelType.Data))
                return false;

            if ((cstrRetItemFlag.ToUpper() != cstrSoTypeRetItemFlag.ToUpper())
                && !checkSoDtlExist())
            {
                uniBase.UMessage.DisplayMessageBox("203244",MessageBoxButtons.OK,"");
                return false;
            }

            //2017-05-15 EJW
            if (base.viewDBSaveMode != enumDef.DBSaveMode.CreateMode)
            {
                if (!chkMultiCompany())
                {
                    uniBase.UMessage.DisplayMessageBox("20M010", MessageBoxButtons.OK, ""); //저장/삭제/확정/취소 할 수 없습니다. 멀티컴퍼니 모듈의 메뉴를 이용하세요.
                    return false;
                }
            }

            return DBSave();
        }
        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic
            # region Set controls
            uniBase.UCommon.ChangeFieldLockAttribute(this.txtSoNo, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popSo_Type, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.dtSo_dt, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.dtCust_po_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popSold_to_party, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popShip_to_party, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popPayer, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popDeal_Type, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popPay_terms, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popVat_Inc_Flag, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popVat_Type, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.txt_Payterms_txt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.txtRemark, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.dtReq_dlvy_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.txtCust_po_no, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popSales_Grp, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popBill_to_party, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popTo_Biz_Grp, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popTrans_Meth, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.numPay_dur, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popDoc_cur, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popPay_type, enumDef.FieldLockAttribute.Normal);

            txtSoNo.FieldType = enumDef.FieldType.NotNull;
            popSo_Type.FieldType = enumDef.FieldType.NotNull;
            dtSo_dt.FieldType = enumDef.FieldType.NotNull;
            dtCust_po_dt.FieldType = enumDef.FieldType.Nullable;
            popSold_to_party.FieldType = enumDef.FieldType.NotNull;
            popShip_to_party.FieldType = enumDef.FieldType.NotNull;
            popPayer.FieldType = enumDef.FieldType.Default;
            popDeal_Type.FieldType = enumDef.FieldType.NotNull;
            popPay_terms.FieldType = enumDef.FieldType.NotNull;
            popVat_Inc_Flag.FieldType = enumDef.FieldType.Default;
            popVat_Type.FieldType = enumDef.FieldType.Default;
            txt_Payterms_txt.FieldType = enumDef.FieldType.Default;
            txtRemark.FieldType = enumDef.FieldType.Default;
            dtReq_dlvy_dt.FieldType = enumDef.FieldType.Default;
            txtCust_po_no.FieldType = enumDef.FieldType.Default;
            popSales_Grp.FieldType = enumDef.FieldType.NotNull;
            popBill_to_party.FieldType = enumDef.FieldType.Default;
            popTo_Biz_Grp.FieldType = enumDef.FieldType.Default;
            popTrans_Meth.FieldType = enumDef.FieldType.Default;
            popTo_Biz_Grp.FieldType = enumDef.FieldType.Default;
            numPay_dur.FieldType = enumDef.FieldType.Default;
            popDoc_cur.FieldType = enumDef.FieldType.NotNull;
            popPay_type.FieldType = enumDef.FieldType.Nullable;
            # endregion

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            
            //2017-05-15 EJW
            if (!chkMultiCompany())
            {
                uniBase.UMessage.DisplayMessageBox("20M010", MessageBoxButtons.OK, ""); //저장/삭제/확정/취소 할 수 없습니다. 멀티컴퍼니 모듈의 메뉴를 이용하세요.
                return false;
            }

            return DBDelete();
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)
        //tangwei modified
        protected override bool OnFncCopy()
        {
            LockFieldInit("N");
            UnLockColor_CfmNo();
            
            uniBase.UCommon.SetToolBarAll(false);
            uniBase.UCommon.SetToolBarCommonAll(true);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New, true);

            numDoc_cur.Value = "";
            numVat_amt.Value = "";
            numNet_Amt_Loc.Value = "";
            txtSoNo.Text = "";

            cstrRadioFlag = "N";
            rdoCfm_flag.CheckedIndex = 1;
            rdoPrice_flag.CheckedIndex = 0;

            uniBase.UCommon.ChangeFieldLockAttribute(this.txtSoNo, enumDef.FieldLockAttribute.Normal); //2017-11-23 EJW
            txtSoNo.FieldType = enumDef.FieldType.Primary; //2017-11-23 EJW            

            CurrencyOnChange();
            if (cstrSoTypeExportFlag.ToUpper() == "Y" || cstrSoTypeCiFlag.ToUpper() == "Y")
            {
                SoTypeExpRequiredChg();
            }
            else
            {
                SoTypeExpDefaultChg();
            }

            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)
        //tang wei modified
        private bool DBQuery()
        {
            wsPS3G102FL.PS3G102FL iwsPS3G102FL = (wsPS3G102FL.PS3G102FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPS3G102FL.PS3G102FL());
            wsPS3G102FL.DsSLookupSoHdrSvr iqtdsSLookupSoHdrSvr = null;
            string ipvCommandSent;
            string I1_s_so_hdr;
            ipvCommandSent = "QUERY";
            I1_s_so_hdr = popConSo_no.CodeValue.Trim();
           

            try
            {   
                iqtdsSLookupSoHdrSvr = iwsPS3G102FL.cLookupSoHdrSvr_S_LOOKUP_SO_HDR_SVR(
                    CommonVariable.gStrGlobalCollection, ipvCommandSent, I1_s_so_hdr);
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);               

                if (reThrow)
                    throw;

                return false;
            }
            cqtdsSLookupSoHdrSvr.Clear();
            uniBase.UData.MergeDataSet(cqtdsSLookupSoHdrSvr, iqtdsSLookupSoHdrSvr, false, MissingSchemaAction.Ignore);

            if (I1_s_so_hdr.Length < 1)
            {
                cstrSoNo = cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].so_no.ToString();
            }
            else
            {
                cstrSoNo = I1_s_so_hdr;
            }

            cstrCur = cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].cur;

            cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].pay_terms_txt = cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["pay_terms_txt"] 
                == System.DBNull.Value ?"":cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].pay_terms_txt.Trim();

            # region for datetime controls

            //dtCust_po_dt
            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["cust_po_dt"] == System.DBNull.Value
                || cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].cust_po_dt.Date >= Convert.ToDateTime(CommonVariable.gMaximumDate).Date
                || cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].cust_po_dt.Date <= Convert.ToDateTime(CommonVariable.gMinimumDate).Date)
            {
                this.dtCust_po_dt.Value = null;
            }

            //dtReq_dlvy_dt
            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["req_dlvy_dt"] == System.DBNull.Value
                || cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].req_dlvy_dt.Date >= Convert.ToDateTime(CommonVariable.gMaximumDate).Date
                || cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].req_dlvy_dt.Date <= Convert.ToDateTime(CommonVariable.gMinimumDate).Date)
            {
                this.dtReq_dlvy_dt.Value = null;
            }
            //dtship_dt
            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["ship_dt"] == System.DBNull.Value
                || cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].ship_dt.Date >= Convert.ToDateTime(CommonVariable.gMaximumDate).Date
                || cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].ship_dt.Date <= Convert.ToDateTime(CommonVariable.gMinimumDate).Date)
            {
                this.dtship_dt.Value = null;
            }


            # endregion

            # region for global variables
            cstrMaintNo = cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["maint_no"] == System.DBNull.Value ?"":
                cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].maint_no.ToString();
            cstrSoSts = cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["so_sts"] == System.DBNull.Value ? "" :
                cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].so_sts.ToString();
            //cstrSoTypeRetItemFlag = cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["ret_item_flag"] == System.DBNull.Value ? "" :
            //    cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].ret_item_flag.ToString();
            cstrSoTypeExportFlag = cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["export_flag"] == System.DBNull.Value ? "" :
                cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].export_flag.ToString();
            cstrSoTypeCiFlag = cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["ci_flag"] == System.DBNull.Value ? "" :
                cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].ci_flag.ToString();
            //
            cstrelbillflag = cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["rel_bill_flag"] == System.DBNull.Value ? "" :
                 cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].rel_bill_flag.ToString();
            //

            cstrRetItemFlag = cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["ret_item_flag"] == System.DBNull.Value ? "" :
                cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].ret_item_flag.ToString();


            popCurr.CodeValue = cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].ext1_cd.ToString();
            numExt2Amt.Value = cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].ext1_amt;


            # endregion

            # region radiobox & button
            uniBase.UCommon.ChangeFieldLockAttribute(rdoCfm_flag,enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(rdoPrice_flag,enumDef.FieldLockAttribute.Normal);
            rdoCfm_flag.FieldType = enumDef.FieldType.Default;
            rdoPrice_flag.FieldType = enumDef.FieldType.Default;

            cstrHRdoConfirm = "Y";
            cstrRdoDnReq = "N";
            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["cfm_flag"].ToString() == "Y")
            {
                rdoCfm_flag.CheckedIndex = 0;
                if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["auto_dn_flag"].ToString() == "N")
                {
                    uniBase.UCommon.DisableButton(btnDNCancel, false);
                    uniBase.UCommon.DisableButton(btnDNCheck, false);
                }
                else if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["auto_dn_flag"].ToString() == "Y")
                {
                    if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["dn_req_flag"].ToString() == "N" 
                        && cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["so_sts"].ToString() == "2")
                    {
                        cstrRdoDnReq = "N";
                        uniBase.UCommon.DisableButton(btnDNCheck, true);
                        uniBase.UCommon.DisableButton(btnDNCancel, false);

                    }
                    else if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["dn_req_flag"].ToString() == "N" 
                        && cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["so_sts"].ToString() == "1")
                    {
                        uniBase.UCommon.DisableButton(btnDNCancel, false);
                    }
                    else if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["dn_req_flag"].ToString() == "Y" 
                        && cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["so_sts"].ToString() == "1")
                    {
                        cstrRdoDnReq = "Y";
                        uniBase.UCommon.DisableButton(btnDNCancel, true);
                        uniBase.UCommon.DisableButton(btnDNCheck, false); //2016-11-16 EJW
                    }
                }
                cstrHRdoConfirm = "N";
                uniBase.UCommon.DisableButton(btnCancel, true);
            }
            else if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["cfm_flag"].ToString() == "N")
            {
                rdoCfm_flag.CheckedIndex = 1;
                uniBase.UCommon.DisableButton(btnDNCancel, false);
                uniBase.UCommon.DisableButton(btnDNCheck, false);
            }

            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["price_flag"].ToString() == "Y")
            {
                rdoPrice_flag.CheckedIndex = 0;
                cstrHRdioType = rdoPrice_flag.Value.ToString();
            }
            else
            {
                rdoPrice_flag.CheckedIndex = 1;
                cstrHRdioType = rdoPrice_flag.Value.ToString();
            }


            uniBase.UCommon.ChangeFieldLockAttribute(rdoCfm_flag,enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(rdoPrice_flag,enumDef.FieldLockAttribute.Protected);
            rdoCfm_flag.FieldType = enumDef.FieldType.ReadOnly;
            rdoPrice_flag.FieldType = enumDef.FieldType.ReadOnly;
            # endregion
            
            # region DB Query OK
            uniBase.UCommon.ChangeFieldLockAttribute(this.txtSoNo, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popSo_Type, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popSales_Grp, enumDef.FieldLockAttribute.Required);

            this.txtSoNo.FieldType = enumDef.FieldType.ReadOnly;
            this.popSo_Type.FieldType = enumDef.FieldType.NotNull;
            this.popSales_Grp.FieldType = enumDef.FieldType.NotNull;

            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["net_amt"] != System.DBNull.Value
                && cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].net_amt > 0)
            {
                uniBase.UCommon.ChangeFieldLockAttribute(this.popSold_to_party, enumDef.FieldLockAttribute.Protected);
                this.popSold_to_party.FieldType = enumDef.FieldType.ReadOnly;
            }
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(this.popSold_to_party, enumDef.FieldLockAttribute.Required);
                this.popSold_to_party.FieldType = enumDef.FieldType.NotNull;
            }

            uniBase.UCommon.ChangeFieldLockAttribute(this.popShip_to_party, enumDef.FieldLockAttribute.Required);
            this.popShip_to_party.FieldType = enumDef.FieldType.NotNull;


            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["cfm_flag"].ToString() == "Y")
            {
                LockField();
                LockColor_CfmYes();
                //clsClickCfmYes = true;

                uniBase.UCommon.SetToolBarAll(false);
                uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Query| enumDef.ToolBitCommon.ViewExit, true);
                uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New | enumDef.ToolBitSingle.Copy, true);
            }
            else
            {
                if (ChkSoByInf())
                {
                    LockField("INF", true);
                }
                else
                {
                    LockField("INF", false);
                }
                CurrencyOnChangeLock();

                uniBase.UCommon.SetToolBarAll(false);
                uniBase.UCommon.SetToolBarCommonAll(true);
                uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New | enumDef.ToolBitSingle.Delete | enumDef.ToolBitSingle.Copy, true);
            }
            cstrPrevRadioFlag = this.rdoCfm_flag.Value.ToString();
            cstrPrevRadioType = this.rdoPrice_flag.Value.ToString();
            SetbtnConfirmButton();
            SubSoTypeExp(cqtdsSLookupSoHdrSvr);
            //CurrencyOnChangeLock();

            # endregion

            return true;
        }

        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            string ipvCommandSent = "DELETE";
            string I2_b_sales_grp = "";
            string I3_to_grp_b_sales_grp = "";
            string I4_b_bank = "";
            string I5_sold_to_party = "";
            string I6_bill_to_party = "";
            string I7_ship_to_party = "";
            string I8_s_so_type_config = "";
            string I9_payer_to_party = "";
            string strprojectCode = "";

            wsPS3G101FL.DsSMaintSoHdrSvr idelDsSMaintSoHdrSvr = new uniERP.App.UI.SD.S3111MA1__KO883.wsPS3G101FL.DsSMaintSoHdrSvr();

            idelDsSMaintSoHdrSvr.IS_SO_HDR.Merge(cqtdsSLookupSoHdrSvr.ES_SO_HDR, false, MissingSchemaAction.Ignore);           

            try
            {
                using (wsPS3G101FL.PS3G101FL iwsPS3G101FL = (wsPS3G101FL.PS3G101FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPS3G101FL.PS3G101FL()))
                {
                    iwsPS3G101FL.ccSSoHdrSvr_S_MAINT_SO_HDR_SVR(CommonVariable.gStrGlobalCollection, idelDsSMaintSoHdrSvr, ipvCommandSent, I2_b_sales_grp, I3_to_grp_b_sales_grp, I4_b_bank, I5_sold_to_party, I6_bill_to_party, I7_ship_to_party, I8_s_so_type_config, I9_payer_to_party, strprojectCode);
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);

                if (ex.ToString().Contains("203255"))
                {
                    DBQuery();
                }
                if (reThrow)
                    throw;
                return false;
            }
            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)
        //tang wei modified
        private bool DBSave()
        {
            string istrRetVal = "";
            wsPS3G101FL.DsSMaintSoHdrSvr isettDsSMaintSoHdrSvr = new wsPS3G101FL.DsSMaintSoHdrSvr();
            wsPS3G101FL.DsSMaintSoHdrSvr.IS_SO_HDRRow iSoHdrRow = isettDsSMaintSoHdrSvr.IS_SO_HDR.NewIS_SO_HDRRow();

            # region for isettDsSMaintSoHdrSvr
            iSoHdrRow.so_no = txtSoNo.Text.Trim();
            iSoHdrRow.so_dt = Convert.ToDateTime(dtSo_dt.Value);
            //iSoHdrRow.req_dlvy_dt = Convert.ToDateTime(dtReq_dlvy_dt.Value);
            if (dtReq_dlvy_dt.Value != null)
            {
                iSoHdrRow.req_dlvy_dt = Convert.ToDateTime(dtReq_dlvy_dt.Value);
            }
            else
            {
                iSoHdrRow.req_dlvy_dt = Convert.ToDateTime(CommonVariable.gMinimumDate);
            }
            iSoHdrRow.cfm_flag = rdoCfm_flag.CheckedItem.DataValue.ToString();
            iSoHdrRow.price_flag = rdoPrice_flag.CheckedItem.DataValue.ToString();
            iSoHdrRow.cur = popDoc_cur.CodeValue.Trim().ToUpper();
            iSoHdrRow.cust_po_no = txtCust_po_no.Text.Trim().ToUpper();
            if (dtCust_po_dt.Value != null)
            {
                iSoHdrRow.cust_po_dt = Convert.ToDateTime(dtCust_po_dt.Value);
            }
            else
            {
                iSoHdrRow.cust_po_dt = Convert.ToDateTime(CommonVariable.gMinimumDate);
            }
            iSoHdrRow.deal_type = popDeal_Type.CodeValue.Trim().ToUpper();
            iSoHdrRow.pay_meth = popPay_terms.CodeValue.Trim().ToUpper();
            iSoHdrRow.pay_dur = numPay_dur.Value.ToString() == "" ? 0 : numPay_dur.uniValue;
            iSoHdrRow.trans_meth = popTrans_Meth.CodeValue.Trim().ToUpper();
            iSoHdrRow.vat_inc_flag = popVat_Inc_Flag.CodeValue.Trim().ToUpper();
            iSoHdrRow.vat_type = popVat_Type.CodeValue.Trim().ToUpper();
            iSoHdrRow.vat_rate = numVat_rate.Value.ToString() == "" ? 0 :numVat_rate.uniValue;
            iSoHdrRow.origin_cd = popOrigin.CodeValue.Trim().ToUpper();
            if (dtValid_dt.Value != null)
            {
                iSoHdrRow.valid_dt = Convert.ToDateTime(dtValid_dt.Value); 
            }
            else
            {
                iSoHdrRow.valid_dt = Convert.ToDateTime(CommonVariable.gMinimumDate);
            }
            if (dtContract_dt.Value != null)
            {
                iSoHdrRow.contract_dt = dtContract_dt.uniValue;
            }
            else
            {
                iSoHdrRow.contract_dt = Convert.ToDateTime(CommonVariable.gMinimumDate);
            }            
            if (dtship_dt.Value != null)
            {
                iSoHdrRow.ship_dt = Convert.ToDateTime(dtship_dt.Value); 
            }
            else
            {
                iSoHdrRow.ship_dt = Convert.ToDateTime(CommonVariable.gMinimumDate);
            }
            iSoHdrRow.pack_cond = popPack_cond.CodeValue.Trim().ToUpper();
            iSoHdrRow.inspect_meth = popInspect_meth.CodeValue.Trim().ToUpper();
            iSoHdrRow.incoterms = popIncoTerms.CodeValue.Trim().ToUpper();
            iSoHdrRow.dischge_city = txtDischge_city.Text.Trim();
            iSoHdrRow.dischge_port_cd = popDischge_port_Cd.CodeValue.Trim().ToUpper();
            iSoHdrRow.loading_port_cd = popLoading_port_Cd.CodeValue.Trim().ToUpper();

            if (popBeneficiary.CodeValue.ToString().Trim() == "")
            {
                iSoHdrRow.beneficiary = CommonVariable.gCompany;
            }
            else
            {
                iSoHdrRow.beneficiary = popBeneficiary.CodeValue.Trim().ToUpper();
            }
            
            iSoHdrRow.manufacturer = popManufacturer.CodeValue.Trim().ToUpper();
            iSoHdrRow.agent = popAgent.CodeValue.Trim().ToUpper();
            iSoHdrRow.remark = txtRemark.Text.Trim();
            iSoHdrRow.pay_type = popPay_type.CodeValue.Trim().ToUpper();
            iSoHdrRow.pay_terms_txt = txt_Payterms_txt.Text.Trim();
            iSoHdrRow.dn_parcel_flag = "";
            iSoHdrRow.xchg_rate = numXchg_rate.Value.ToString() == "" ? 0 : numXchg_rate.uniValue;
            iSoHdrRow.to_biz_area = "";
            iSoHdrRow.maint_no = cstrMaintNo;
            iSoHdrRow.ext1_qty = 0;
            iSoHdrRow.ext2_qty = 0;
            iSoHdrRow.ext3_qty = 0;
            iSoHdrRow.ext1_amt = numExt2Amt.uniValue;
            iSoHdrRow.ext2_amt = 0;
            iSoHdrRow.ext3_amt = 0;
            iSoHdrRow.ext1_cd = popCurr.CodeValue;
           // iSoHdrRow.ext1_cd = "";
           // iSoHdrRow.ext1_cd = "";
            iSoHdrRow.pre_doc_no = cstrHSONo;
            iSoHdrRow.sto_flag = "N";
            iSoHdrRow.ship_dt_txt = txtShip_dt_txt.Text.Trim();


            # endregion

            isettDsSMaintSoHdrSvr.IS_SO_HDR.AddIS_SO_HDRRow(iSoHdrRow);

            isettDsSMaintSoHdrSvr.AcceptChanges();

            string ipvCommandSent, I2_b_sales_grp, I3_to_grp_b_sales_grp, I4_b_bank, I5_sold_to_party, I6_bill_to_party,
                        I7_ship_to_party, I8_s_so_type_config, I9_payer_to_party, strProjectCode;

            if (base.viewDBSaveMode == enumDef.DBSaveMode.CreateMode)
                ipvCommandSent = "CREATE";
            else
                ipvCommandSent = "UPDATE";

            I2_b_sales_grp = popSales_Grp.CodeValue.Trim();

            //if (popTo_Biz_Grp.CodeValue.Trim().Length > 0)
            //{
                I3_to_grp_b_sales_grp = popTo_Biz_Grp.CodeValue.Trim();
            //}
            //else
            //{
            //    I3_to_grp_b_sales_grp = CommonVariable.gSalesGrp;
            //}
            I4_b_bank = popSending_Bank.CodeValue.Trim();
            I5_sold_to_party = popSold_to_party.CodeValue.Trim();
            I6_bill_to_party = popBill_to_party.CodeValue.Trim();
            I7_ship_to_party = popShip_to_party.CodeValue.Trim();
            I8_s_so_type_config = popSo_Type.CodeValue.Trim();
            I9_payer_to_party = popPayer.CodeValue.Trim();
            strProjectCode = cstrProjectCd;
            
            try
            {
                using (wsPS3G101FL.PS3G101FL iwsPS3G101FL = (wsPS3G101FL.PS3G101FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPS3G101FL.PS3G101FL()))
                {
                    istrRetVal = 
                    iwsPS3G101FL.ccSSoHdrSvr_S_MAINT_SO_HDR_SVR(CommonVariable.gStrGlobalCollection, isettDsSMaintSoHdrSvr,
                        ipvCommandSent, I2_b_sales_grp, I3_to_grp_b_sales_grp, I4_b_bank, I5_sold_to_party, I6_bill_to_party,
                        I7_ship_to_party, I8_s_so_type_config, I9_payer_to_party, strProjectCode);
                }

            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);

                if (ex.ToString().Contains("203255"))
                {
                    DBQuery();
                }
                if (reThrow)
                    throw;
                return false;
            }

            if (istrRetVal.Length < 1)
            {
                popConSo_no.CodeValue = cstrSoNo;
                txtSoNo.Text = cstrSoNo;
            }
            else
            {
                popConSo_no.CodeValue = istrRetVal;
                txtSoNo.Text = istrRetVal;
            }
            return true;
        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group



        #endregion

        #region ■ 5.2 Grid   control event implementation group


        #region ▶ Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        /// <summary>
        /// 기존의 Context메뉴를 보여주기 위해 fpSpread의 MouseDown이벤트와 Click이벤트에서 처리하던 일련의 코드들은
        /// UltraGrid에서는 MouseDown이벤트에서 처리합니다.
        /// fpSpread의 Click이벤트는 UltraGrid의 
        /// AfterCellActivate | AfterRowActivate | AfterSelectChange 이벤트로 변경 하실 수 있습니다.
        /// AfterCellActivate   : isSearch=No (에디터모드)에서 CellSelect모드에서 한 Cell을 클릭했을때 발생하는 이벤트입니다.
        /// AfterRowActivate    : isSearch=Yes (조회전용모드)에서 RowSelect모드에서 한 Row를 클릭했을때 발생하는 이벤트입니다.
        /// AfterSelectChange   : 셀또는 Row를 하나 이상 선택시 발생하는 이벤트입니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>



        #endregion ▶ Click >>> AfterSelectChange

        #region ▶ DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
            Debug.WriteLine("DoubleClickCell Event Fired");
            Debug.WriteLine("Index of the new active row is  " + e.Cell.Row.Index.ToString());
            Debug.WriteLine("Key of the new active col is  " + e.Cell.Column.Key);
        }
        #endregion ▶ DblClick >>> DoubleClickCell

        #region ▶ MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
                return;

            UltraGrid grid = (UltraGrid)sender;
            UIElement element = grid.DisplayLayout.UIElement.ElementFromPoint(new Point(e.X, e.Y));
            UltraGridCell cell = element.GetContext(typeof(UltraGridCell)) as UltraGridCell;

            if (cell != null)
            {
                Debug.WriteLine("MouseDown Event Fired");
                Debug.WriteLine("Index of the right mouse click row is  " + cell.Row.Index.ToString());
                Debug.WriteLine("Key of the right mouse click col is  " + cell.Column.Key);

                // 컨텍스트 메뉴를 보여주기 위한 코드 작성 시작
                //SetPopUpMenuItemInf("1101111111")
                // 컨텍스트 메뉴를 보여주기 위한 코드 작성 끝
            }
        }
        #endregion ▶ MouseDown >>> MouseDown

        #region ▶ ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        #endregion ▶ ScriptLeaveCell >>> BeforeCellDeactivate

        #region ▶ ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
            Debug.WriteLine("ClickCellButton Event Fired");
            Debug.WriteLine("Index of the new active row is  " + e.Cell.Row.Index.ToString());
            Debug.WriteLine("Key of the new active col is  " + e.Cell.Column.Key);

            // 버튼클릭 시 수행 할 코드 작성 시작
            //switch (e.Cell.Column.Key)
            //{
            //    case "C_AcctPopUp":
            //        OpenPopUp(e.Cell.Row.Cells["AAA"].Value);
            //        break;
            //    case "C_deptPopup":
            //        OpenPopUp(e.Cell.Row.Cells["BBB"].Value);
            //        break;
            //    case "C_DocCurPopup":
            //        OpenPopUp(e.Cell.Row.Cells["CCC"].Value);
            //        break;
            //    default:
            //}
            // 버튼클릭 시 수행 할 코드 작성 끝
        }
        #endregion ▶ ButtonClicked >>> ClickCellButton

        #region ▶ ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
            if (null != e.Cell.Column.ValueList)
            {
                int itemIndex = e.Cell.Column.ValueList.SelectedItemIndex;
                Debug.WriteLine("Selected Item Index = " + itemIndex);
                Debug.WriteLine("Selected Item Value = " + e.Cell.Column.ValueList.GetValue(itemIndex).ToString());
                Debug.WriteLine("Selected Item Text = " + e.Cell.Column.ValueList.GetText(itemIndex).ToString());
                Debug.WriteLine("Index of the new active row is  " + e.Cell.Row.Index.ToString());
                Debug.WriteLine("Key of the new active col is  " + e.Cell.Column.Key);

                //switch (e.Cell.Column.Key)
                //{
                //    case "AAA":
                //        break;
                //    case "BBB":
                //        break;
                //    case "CCC":
                //        break;
                //    default:
                //        break;
                //}
            }
        }
        #endregion ▶ ComboSelChange >>> CellListSelect

        #region ▶ Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {

        }
        #endregion ▶ Change >>> CellChange


        #endregion

        #region ■ 5.3 TAB    control event implementation group
        private void tab1_SelectedTabChanging(object sender, Infragistics.Win.UltraWinTabControl.SelectedTabChangingEventArgs e)
        {
            switch (tab1.SelframeFlg(e.Tab.Index))
            {
                case enumDef.TABPosition.TAB1:
                    e.Cancel = ClickTab1();
                    break;
                case enumDef.TABPosition.TAB2:                    
                    e.Cancel = ClickTab2();
                    break;
                default:
                    break;
            }
        }
        //tangwei modified
        private bool ClickTab1()
        {
            //bool CancelClickEvent = false;
            //DialogResult iDialogResult = DialogResult.None;
            //// To-Do : Your check business logic
            //bool gridcheck = false;
            ////gridcheck = this.uniGrid2.SSCheckChange();
            //if (gridcheck == true)
            //{
            //    iDialogResult = uniBase.UMessage.DisplayMessageBox("900013", MessageBoxButtons.YesNo);

            //    if (iDialogResult == DialogResult.No)
            //    {
            //        CancelClickEvent = true;
            //    }
            //}
            //// TO-DO: Your business logic
            return false;
        }
        //tangwei modified
        private bool ClickTab2()
        {
            if (SoTypeExportCheck() == 2)
            {
                uniBase.UMessage.DisplayMessageBox("202515", MessageBoxButtons.OK, "");
                popSo_Type.Focus();
                return true;
            }
            else if (SoTypeExportCheck() == 3)
            {                
                //MessageBox.Show("Sales Order Type  " + popSo_Type.CodeName.Trim() + "the export/clearance of" +
                //  cstrSoTypeExportFlag + "/" + cstrSoTypeCiFlag + "  is " + "In case of export or clearance, you can move to trade Info.");
                string[] strMsg = { popSo_Type.CodeName.Trim(), cstrSoTypeExportFlag, cstrSoTypeCiFlag };
                uniBase.UMessage.DisplayMessageBox("202516", MessageBoxButtons.OK, strMsg);
                popSo_Type.Focus();
                return true;
            }

            if (dtValid_dt.Value == null)
            {
                dtValid_dt.Value = dtReq_dlvy_dt.Value;
                
            }            

            //bool CancelClickEvent = false;
            //DialogResult iDialogResult = DialogResult.None;
            //// To-Do : Your check business logic
            //bool gridcheck = false;
            ////gridcheck = this.uniGrid2.SSCheckChange();
            //if (gridcheck == true)
            //{
            //    iDialogResult = uniBase.UMessage.DisplayMessageBox("900013", MessageBoxButtons.YesNo);

            //    if (iDialogResult == DialogResult.No)
            //    {
            //        CancelClickEvent = true;
            //    }
            //}
            // TO-DO: Your business logic
            return false;
        }
        #endregion

        #endregion

        #region ▶ 6. Popup method partz

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors
            //CommonPopup cp = new CommonUtil.CommonPopup(PopupType.AutoNumbering);

            //string[] arrRet = cp.showModalDialog(InputParam1);

            #endregion

            #region ▶▶▶ 10.1.2.2 Setting Returned Data

            //if (iWhere) 
            //{
            //    txtMinor.value = arrRet[0];
            //    txtMinorNm.value = arrRet[1];
            //}
            //else
            //{
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingCd].value = arrRet[0];
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingNm].value = arrRet[1];

            //    if (arrRet[2].Length > 0) 
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = arrRet[2];
            //    else
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = "18";

            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.PrefixCd].value = arrRet[0];

            //}

            #endregion

            //CommonVariable.lgBlnFlgChgValue = true;  // 사용자 액션 발생 알림
        }

        #endregion

        # region popSo_Type_BeforePopupOpen | OpenRequried Case 0
        private void popSo_Type_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "S/O Type";
            e.PopupPassData.ConditionCaption = "S/O Type";

            e.PopupPassData.SQLFromStatements = "S_SO_TYPE_CONFIG";
            e.PopupPassData.SQLWhereStatements = "USAGE_FLAG = " + uniBase.UCommon.FilterVariable("Y", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + "  and SO_MGMT_FLAG <> " + uniBase.UCommon.FilterVariable("N", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + "  and STO_FLAG = " + uniBase.UCommon.FilterVariable("N", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popSo_Type.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[6];
            e.PopupPassData.GridCellCaption = new String[6];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[6];
            e.PopupPassData.GridCellLength = new int[6];

            e.PopupPassData.GridCellCode[0] = "SO_TYPE";
            e.PopupPassData.GridCellCode[1] = "SO_TYPE_NM";
            e.PopupPassData.GridCellCode[2] = "EXPORT_FLAG";
            e.PopupPassData.GridCellCode[3] = "RET_ITEM_FLAG";
            e.PopupPassData.GridCellCode[4] = "AUTO_DN_FLAG";
            e.PopupPassData.GridCellCode[5] = "CI_FLAG";

            e.PopupPassData.GridCellCaption[0] = "S/O Type";
            e.PopupPassData.GridCellCaption[1] = "S/O Type Description";
            e.PopupPassData.GridCellCaption[2] = "Export";
            e.PopupPassData.GridCellCaption[3] = "Return";
            e.PopupPassData.GridCellCaption[4] = "Auto D/N Creating";
            e.PopupPassData.GridCellCaption[5] = "Cust./Clear.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[4] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[5] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popSo_Type_AfterPopupClosed | OpenRequried Case 0 | tangwei modified
        private void popSo_Type_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popSo_Type.CodeValue = iDataSet.Tables[0].Rows[0]["SO_TYPE"].ToString();
            popSo_Type.CodeName = iDataSet.Tables[0].Rows[0]["SO_TYPE_NM"].ToString();
            cstrSoTypeExportFlag = iDataSet.Tables[0].Rows[0]["export_flag"].ToString();
            cstrSoTypeRetItemFlag = iDataSet.Tables[0].Rows[0]["ret_item_flag"].ToString();
            cstrSoTypeCiFlag = iDataSet.Tables[0].Rows[0]["ci_flag"].ToString();
            dtContract_dt.Value = uniBase.UDate.GetDBServerDateTime();
            SubSoTypeExp(iDataSet);
            popSo_Type.Focus();

        }
        # endregion

        # region SubSoTypeExp | tangwei added
        private void SubSoTypeExp(DataSet pDs)
        {
            DataSet ids = new DataSet();

            string[] istrSqlID = new string[1];
            string[][] istrValue = new string[1][];
            string istrSoType = "";

            istrValue[0] = new string[1];

            istrSqlID[0] = "S1911RA101";

            if (pDs.Tables[0].Rows[0]["so_type"] != System.DBNull.Value &&
                pDs.Tables[0].Rows[0]["so_type"].ToString().Length > 0)
            {
                istrSoType = pDs.Tables[0].Rows[0]["so_type"].ToString();
            }

            istrValue[0][0] = uniBase.UCommon.FilterVariable(istrSoType, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);

            try
            {
                ids = uniBase.UDataAccess.DBAgentQryRS(istrSqlID, istrValue);

                if (ids == null || ids.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("201600", MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
            }

            popSo_Type.CodeName = ids.Tables[0].Rows[0]["so_type_nm"] == System.DBNull.Value ? "" :
            ids.Tables[0].Rows[0]["so_type_nm"].ToString();

            cstrSoTypeExportFlag = ids.Tables[0].Rows[0]["export_flag"] == System.DBNull.Value ? "" :
            ids.Tables[0].Rows[0]["export_flag"].ToString();

            cstrSoTypeRetItemFlag = ids.Tables[0].Rows[0]["ret_item_flag"] == System.DBNull.Value ? "" :
            ids.Tables[0].Rows[0]["ret_item_flag"].ToString();

            cstrDlvyLt = ids.Tables[0].Rows[0]["dlvy_lt"] == System.DBNull.Value ? "" :
            ids.Tables[0].Rows[0]["dlvy_lt"].ToString();

            cstrSoTypeCiFlag = ids.Tables[0].Rows[0]["ci_flag"] == System.DBNull.Value ? "" :
            ids.Tables[0].Rows[0]["ci_flag"].ToString();


            fncSoTypeExpChange();
        }

        # endregion

        # region popSold_to_party_BeforePopupOpen | OpenBp Case 0
        private void popSold_to_party_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Sold to Party";
            e.PopupPassData.ConditionCaption = "Sold to Party";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER";
            e.PopupPassData.SQLWhereStatements = "BP_TYPE in (" + uniBase.UCommon.FilterVariable("C", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ," + uniBase.UCommon.FilterVariable("CS", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + ") AND usage_flag = " + uniBase.UCommon.FilterVariable("Y", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popSold_to_party.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "BP_CD";
            e.PopupPassData.GridCellCode[1] = "BP_NM";
            e.PopupPassData.GridCellCode[2] = "BP_RGST_NO";

            e.PopupPassData.GridCellCaption[0] = "Sold to Party";
            e.PopupPassData.GridCellCaption[1] = "Corp. Registration No.";
            e.PopupPassData.GridCellCaption[2] = "Sold to Party Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popSold_to_party_AfterPopupClosed | SetBp Case 0 | tangwei modified
        private void popSold_to_party_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popSold_to_party.CodeValue = iDataSet.Tables[0].Rows[0]["BP_CD"].ToString();
            popSold_to_party.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
            SubLookUp();
            popSold_to_party.Focus();
        }
        # endregion

        # region SubLookUp |  tangwei added
        private void SubLookUp()
        {
            if (popSold_to_party.CodeValue.Trim().Length < 1)
            {
                uniBase.UMessage.DisplayMessageBox("203150", MessageBoxButtons.OK, "");
                return;
            }

            string istrBizPartner = popSold_to_party.CodeValue.Trim();

            wsPB5CS41FL.DsBLookupBizPartnerSvr iqtdsDsBLookupBizPartnerSvr = new uniERP.App.UI.SD.S3111MA1__KO883.wsPB5CS41FL.DsBLookupBizPartnerSvr();        
            wsPB5GS45FL.DsBListDefaultBpFtnSvr iqtdsDsBListDefaultBpFtnSvr = new uniERP.App.UI.SD.S3111MA1__KO883.wsPB5GS45FL.DsBListDefaultBpFtnSvr();

            wsPB5CS41FL.PB5CS41FL iwsPB5CS41FL = (wsPB5CS41FL.PB5CS41FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPB5CS41FL.PB5CS41FL());
            wsPB5GS45FL.PB5GS45FL iwsPB5GS45FL = (wsPB5GS45FL.PB5GS45FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPB5GS45FL.PB5GS45FL());


            try
            {
                iqtdsDsBLookupBizPartnerSvr = iwsPB5CS41FL.cLookupBizPartnerSvr_B_LOOKUP_BIZ_PARTNER_SVR(
                    CommonVariable.gStrGlobalCollection, "QUERY", istrBizPartner, "");
                iqtdsDsBListDefaultBpFtnSvr = iwsPB5GS45FL.cBListDftBpFtnSvr_B_LIST_DEFAULT_BP_FTN_SVR(
                    CommonVariable.gStrGlobalCollection, istrBizPartner);
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }

            //txtSoNo.Value = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["prj_cd"] == System.DBNull.Value ? 0 :
            //iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].bp
            popSold_to_party.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["bp_cd"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_cd"].ToString();
            popSold_to_party.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["bp_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            popDeal_Type.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["deal_type"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].deal_type.ToString();
            popDeal_Type.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["deal_type_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].deal_type_nm.ToString();
            popPay_terms.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["pay_meth"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].pay_meth.ToString();
            popPay_terms.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["pay_meth_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].pay_meth_nm.ToString();
            numPay_dur.Value = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["pay_dur"] == System.DBNull.Value ? 0 :
               iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].pay_dur;
            popVat_Type.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["vat_type"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].vat_type.ToString();
            popVat_Type.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["vat_type_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].vat_type_nm.ToString();
            numVat_rate.Value = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["vat_rate"] == System.DBNull.Value ? 0 :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].vat_rate;
            popTrans_Meth.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["trans_meth"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].trans_meth.ToString();
            popTrans_Meth.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["trans_meth_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].trans_meth_nm.ToString();
            if (iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["currency"] != System.DBNull.Value &&
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["currency"].ToString() != "")
            {
                popDoc_cur.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].currency;
            }

            // 2014-01-28 대금결제참조-> 거래처정보의 결제조건
            txt_Payterms_txt.Text = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["pay_terms_txt"] == System.DBNull.Value ? "" :
                    iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].pay_terms_txt.ToString();


            //PB5CS41
            popTo_Biz_Grp.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["to_grp"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].to_grp;
            popTo_Biz_Grp.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["b_to_grp_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].b_to_grp_nm;

            //PB5CS41
            popSales_Grp.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["biz_grp"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].biz_grp;
            popSales_Grp.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.Rows[0]["b_sales_grp_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].b_sales_grp_nm;

            //PB5GS45
            //SSH
            popShip_to_party.CodeValue = iqtdsDsBListDefaultBpFtnSvr.E1_B_BIZ_PARTNER[0]["bp_cd"] == System.DBNull.Value ? "" :
                iqtdsDsBListDefaultBpFtnSvr.E1_B_BIZ_PARTNER[0].bp_cd;
            popShip_to_party.CodeName = iqtdsDsBListDefaultBpFtnSvr.E1_B_BIZ_PARTNER[0]["bp_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBListDefaultBpFtnSvr.E1_B_BIZ_PARTNER[0].bp_nm;

            //PB5GS45
            //SBI
            popBill_to_party.CodeValue = iqtdsDsBListDefaultBpFtnSvr.E2_B_BIZ_PARTNER[0]["bp_cd"] == System.DBNull.Value ? "" :
                iqtdsDsBListDefaultBpFtnSvr.E2_B_BIZ_PARTNER[0].bp_cd;
            popBill_to_party.CodeName = iqtdsDsBListDefaultBpFtnSvr.E2_B_BIZ_PARTNER[0]["bp_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBListDefaultBpFtnSvr.E2_B_BIZ_PARTNER[0].bp_nm;

            //PB5GS45
            //SPA
            popPayer.CodeValue = iqtdsDsBListDefaultBpFtnSvr.E3_B_BIZ_PARTNER[0]["bp_cd"] == System.DBNull.Value ? "" :
                iqtdsDsBListDefaultBpFtnSvr.E3_B_BIZ_PARTNER[0].bp_cd;
            popPayer.CodeName = iqtdsDsBListDefaultBpFtnSvr.E3_B_BIZ_PARTNER[0]["bp_nm"] == System.DBNull.Value ? "" :
                iqtdsDsBListDefaultBpFtnSvr.E3_B_BIZ_PARTNER[0].bp_nm;

            //PB5GS45
            popVat_Inc_Flag.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["vat_inc_flag"] == System.DBNull.Value ? "" :
                iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].vat_inc_flag;
            popVat_Inc_Flag.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["vat_inc_flag_nm"] == System.DBNull.Value ? "" :
               iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].vat_inc_flag_nm;

            if (cstrSoTypeExportFlag.ToUpper() == "Y" || cstrSoTypeCiFlag.ToUpper() == "Y")
            {
                popIncoTerms.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["incoterms"] == System.DBNull.Value ? "" :
                   iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].INCOTERMS;
                popIncoTerms.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["incoterms_nm"] == System.DBNull.Value ? "" :
                   iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0].INCOTERMS_NM;
            }

            if (popSales_Grp.CodeValue.Trim() == "" && CommonVariable.gSalesGrp.Trim() != "")
            {
                DataSet iDs = uniBase.UDataAccess.CommonQueryRs("sales_grp, sales_grp_nm", "b_sales_grp (nolock)", "sales_grp = " + uniBase.UCommon.FilterVariable(CommonVariable.gSalesGrp, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));

                if (iDs != null && iDs.Tables[0].Rows.Count > 0)
                {
                    popSales_Grp.CodeValue = iDs.Tables[0].Rows[0][0].ToString();
                    popSales_Grp.CodeName = iDs.Tables[0].Rows[0][1].ToString();
                }
            }

            CurrencyOnChange();
            SetVatType();

            uniBase.UCommon.SetToolBarAll(false);
            uniBase.UCommon.SetToolBarCommonAll(true);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New, true);

        }
        # endregion

        # region popShip_to_party_BeforePopupOpen | tangwei modified
        //OpenOption --case 0
        private void popShip_to_party_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            //added
            if (popSold_to_party.CodeValue.Trim().Length < 1)
            {
                uniBase.UMessage.DisplayMessageBox("203150",MessageBoxButtons.OK,"");
                this.popSold_to_party.Focus();
                e.Cancel = true;
                return;
            }
          
            e.PopupPassData.PopupWinTitle = "Ship to Party";
            e.PopupPassData.ConditionCaption = "Ship to Party";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER_FTN PARTNER_FTN(nolock) ,B_BIZ_PARTNER PARTNER (nolock)";
            e.PopupPassData.SQLWhereStatements = "PARTNER_FTN.USAGE_FLAG='Y'  AND PARTNER_FTN.PARTNER_FTN='SSH' AND PARTNER.BP_CD=PARTNER_FTN.PARTNER_BP_CD AND PARTNER.BP_TYPE <= 'CS'  AND PARTNER_FTN.BP_CD= '" + popSold_to_party.CodeValue.Trim() + "' ";
            e.PopupPassData.SQLWhereInputCodeValue = popShip_to_party.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[5];
            e.PopupPassData.GridCellCaption = new String[5];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[5];
            e.PopupPassData.GridCellLength = new int[5];

            e.PopupPassData.GridCellCode[0] = "PARTNER_FTN.PARTNER_BP_CD";
            e.PopupPassData.GridCellCode[1] = "PARTNER.BP_NM";
            e.PopupPassData.GridCellCode[2] = "PARTNER_FTN.BP_CD";
            e.PopupPassData.GridCellCode[3] = "PARTNER.BP_RGST_NO";
            e.PopupPassData.GridCellCode[4] = "PARTNER_FTN.PARTNER_FTN";

            e.PopupPassData.GridCellCaption[0] = "Sold to Party";
            e.PopupPassData.GridCellCaption[1] = "Sold to Party Name";
            e.PopupPassData.GridCellCaption[2] = "Business Partner";
            e.PopupPassData.GridCellCaption[3] = "Corp. Registration No.";
            e.PopupPassData.GridCellCaption[4] = "Business Partner Type";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[4] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popShip_to_party_AfterPopupClosed
        //SetOption -- case 0
        private void popShip_to_party_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popShip_to_party.CodeValue = iDataSet.Tables[0].Rows[0]["PARTNER_BP_CD"].ToString();
            popShip_to_party.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
            popShip_to_party.Focus();
        }
        # endregion

        # region popPayer_BeforePopupOpen
        private void popPayer_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popSold_to_party.CodeValue.Trim() == string.Empty)
            {
                uniBase.UMessage.DisplayMessageBox("203150", MessageBoxButtons.OK);
                popSold_to_party.Focus();
                return;
            }

            e.PopupPassData.PopupWinTitle = "Payer";
            e.PopupPassData.ConditionCaption = "Payer";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER_FTN PARTNER_FTN (nolock) ,B_BIZ_PARTNER PARTNER (nolock) ";
            e.PopupPassData.SQLWhereStatements = "PARTNER_FTN.USAGE_FLAG=" + uniBase.UCommon.FilterVariable("Y", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + "  AND PARTNER_FTN.PARTNER_FTN=" + uniBase.UCommon.FilterVariable("SPA", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                " AND PARTNER.BP_CD=PARTNER_FTN.PARTNER_BP_CD AND PARTNER.BP_TYPE <= " + uniBase.UCommon.FilterVariable("CS", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " AND PARTNER_FTN.BP_CD=" + uniBase.UCommon.FilterVariable(popSold_to_party.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";
            e.PopupPassData.SQLWhereInputCodeValue = popPayer.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[5];
            e.PopupPassData.GridCellCaption = new String[5];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[5];
            e.PopupPassData.GridCellLength = new int[5];

            e.PopupPassData.GridCellCode[0] = "PARTNER_FTN.PARTNER_BP_CD";
            e.PopupPassData.GridCellCode[1] = "PARTNER.BP_NM";
            e.PopupPassData.GridCellCode[2] = "PARTNER_FTN.BP_CD";
            e.PopupPassData.GridCellCode[3] = "PARTNER.BP_RGST_NO";
            e.PopupPassData.GridCellCode[4] = "PARTNER_FTN.PARTNER_FTN";

            e.PopupPassData.GridCellCaption[0] = "Payer";
            e.PopupPassData.GridCellCaption[1] = "Payer Name";
            e.PopupPassData.GridCellCaption[2] = "Business Partner";
            e.PopupPassData.GridCellCaption[3] = "Corp. Registration No.";
            e.PopupPassData.GridCellCaption[4] = "Business Partner Type";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[4] = enumDef.GridCellType.Edit;

        }
        # endregion

        # region popPayer_AfterPopupClosed
        private void popPayer_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPayer.CodeValue = iDataSet.Tables[0].Rows[0]["PARTNER_BP_CD"].ToString();
            popPayer.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
            popPayer.Focus();
        }
        # endregion

        # region popDeal_Type_BeforePopupOpen
        private void popDeal_Type_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Sales Type";
            e.PopupPassData.ConditionCaption = "Sales Type";

            e.PopupPassData.SQLFromStatements = "B_MINOR";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("S0001", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popDeal_Type.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Sales Type";
            e.PopupPassData.GridCellCaption[1] = "Sales Type Desc.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popDeal_Type_AfterPopupClosed
        private void popDeal_Type_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popDeal_Type.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popDeal_Type.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popDeal_Type.Focus();
        }
        # endregion

        #region popPay_terms_BeforePopupOpen
        private void popPay_terms_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Pay Method";
            e.PopupPassData.ConditionCaption = "Pay Method";

            e.PopupPassData.SQLFromStatements = "B_MINOR";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("B9004", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popPay_terms.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Pay Method";
            e.PopupPassData.GridCellCaption[1] = "Pay Method Desc.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

        }
        # endregion

        # region popPay_terms_AfterPopupClosed
        private void popPay_terms_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPay_terms.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popPay_terms.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popPay_terms.Focus();
        }
        # endregion

        # region popVat_Inc_Flag_BeforePopupOpen
        private void popVat_Inc_Flag_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "VAT inclusion ID";
            e.PopupPassData.ConditionCaption = "VAT inclusion ID";

            e.PopupPassData.SQLFromStatements = "B_MINOR";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("S4035", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popVat_Inc_Flag.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "VAT inclusion ID";
            e.PopupPassData.GridCellCaption[1] = "VAT inclusion ID Description";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popVat_Inc_Flag_AfterPopupClosed
        private void popVat_Inc_Flag_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popVat_Inc_Flag.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popVat_Inc_Flag.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popVat_Inc_Flag.Focus();
        }
        # endregion

        # region popVat_Type_BeforePopupOpen
        private void popVat_Type_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "VAT Type";
            e.PopupPassData.ConditionCaption = "VAT Type";

            e.PopupPassData.SQLFromStatements = "B_MINOR Minor (nolock) ,B_CONFIGURATION Config (nolock) ";
            e.PopupPassData.SQLWhereStatements = "Minor.MAJOR_CD=" + uniBase.UCommon.FilterVariable("B9001", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " And Config.MAJOR_CD = Minor.MAJOR_CD  And Config.MINOR_CD = Minor.MINOR_CD  And Config.SEQ_NO = 1 ";

            e.PopupPassData.SQLWhereInputCodeValue = popVat_Type.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "Minor.MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "Minor.MINOR_NM";
            e.PopupPassData.GridCellCode[2] = "Config.REFERENCE";

            e.PopupPassData.GridCellCaption[0] = "VAT Type";
            e.PopupPassData.GridCellCaption[1] = "VAT Type Description";
            e.PopupPassData.GridCellCaption[2] = "VAT Rate";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }
        # endregion

        #region popVat_Type_AfterPopupClosed
        private void popVat_Type_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popVat_Type.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popVat_Type.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            numVat_rate.Value = iDataSet.Tables[0].Rows[0]["REFERENCE"].ToString();
            popVat_Type.Focus();
        }
        # endregion

        #region popSales_Grp_BeforePopupOpen
        private void popSales_Grp_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Sales Group";
            e.PopupPassData.ConditionCaption = "Sales Group";

            e.PopupPassData.SQLFromStatements = "B_SALES_GRP";
            e.PopupPassData.SQLWhereStatements = "USAGE_FLAG=" + uniBase.UCommon.FilterVariable("Y", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popSales_Grp.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "SALES_GRP";
            e.PopupPassData.GridCellCode[1] = "SALES_GRP_NM";

            e.PopupPassData.GridCellCaption[0] = "Sales Group";
            e.PopupPassData.GridCellCaption[1] = "Sales Group Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popSales_Grp_AfterPopupClosed
        private void popSales_Grp_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popSales_Grp.CodeValue = iDataSet.Tables[0].Rows[0]["SALES_GRP"].ToString();
            popSales_Grp.CodeName = iDataSet.Tables[0].Rows[0]["SALES_GRP_NM"].ToString();
            popSales_Grp.Focus();
        }
        # endregion

        # region popBill_to_party_BeforePopupOpen
        private void popBill_to_party_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {//OpenOption 1
            if (popSold_to_party.CodeValue.Trim() == string.Empty)
            {
                uniBase.UMessage.DisplayMessageBox("203150", MessageBoxButtons.OK);                
                e.Cancel = true;
                popSold_to_party.Focus();
                return;
            }

            e.PopupPassData.PopupWinTitle = "Tax Recipient";
            e.PopupPassData.ConditionCaption = "Tax Recipient";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER_FTN PARTNER_FTN (nolock) ,B_BIZ_PARTNER PARTNER (nolock) ";
            e.PopupPassData.SQLWhereStatements = "PARTNER_FTN.USAGE_FLAG=" + uniBase.UCommon.FilterVariable("Y", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + "  AND PARTNER_FTN.PARTNER_FTN=" + uniBase.UCommon.FilterVariable("SBI", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " AND PARTNER.BP_CD=PARTNER_FTN.PARTNER_BP_CD AND PARTNER.BP_TYPE <= " + uniBase.UCommon.FilterVariable("CS", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " AND PARTNER_FTN.BP_CD= " + uniBase.UCommon.FilterVariable(popSold_to_party.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";
            e.PopupPassData.SQLWhereInputCodeValue = popBill_to_party.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[5];
            e.PopupPassData.GridCellCaption = new String[5];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[5];
            e.PopupPassData.GridCellLength = new int[5];

            e.PopupPassData.GridCellCode[0] = "PARTNER_FTN.PARTNER_BP_CD";
            e.PopupPassData.GridCellCode[1] = "PARTNER.BP_NM";
            e.PopupPassData.GridCellCode[2] = "PARTNER_FTN.BP_CD";
            e.PopupPassData.GridCellCode[3] = "PARTNER.BP_RGST_NO";
            e.PopupPassData.GridCellCode[4] = "PARTNER_FTN.PARTNER_FTN";


            e.PopupPassData.GridCellCaption[0] = "Tax Recipient";
            e.PopupPassData.GridCellCaption[1] = "Issuer Name";
            e.PopupPassData.GridCellCaption[2] = "Business Partner";
            e.PopupPassData.GridCellCaption[3] = "Corp. Registration No.";
            e.PopupPassData.GridCellCaption[4] = "Business Partner Type";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[4] = enumDef.GridCellType.Edit;

        }
        # endregion

        # region popBill_to_party_AfterPopupClosed
        private void popBill_to_party_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popBill_to_party.CodeValue = iDataSet.Tables[0].Rows[0]["PARTNER_BP_CD"].ToString();
            popBill_to_party.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
            popBill_to_party.Focus();
        }
        # endregion

        # region popTo_Biz_Grp_BeforePopupOpen
        private void popTo_Biz_Grp_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Collection Group";
            e.PopupPassData.ConditionCaption = "Collection Group";

            e.PopupPassData.SQLFromStatements = "B_SALES_GRP";
            e.PopupPassData.SQLWhereStatements = "USAGE_FLAG=" + uniBase.UCommon.FilterVariable("Y", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popTo_Biz_Grp.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "SALES_GRP";
            e.PopupPassData.GridCellCode[1] = "SALES_GRP_NM";

            e.PopupPassData.GridCellCaption[0] = "Collection Group";
            e.PopupPassData.GridCellCaption[1] = "Collection Group Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popTo_Biz_Grp_AfterPopupClosed
        private void popTo_Biz_Grp_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popTo_Biz_Grp.CodeValue = iDataSet.Tables[0].Rows[0]["SALES_GRP"].ToString();
            popTo_Biz_Grp.CodeName = iDataSet.Tables[0].Rows[0]["SALES_GRP_NM"].ToString();
            popTo_Biz_Grp.Focus();
        }
        # endregion

        # region popTrans_Meth_BeforePopupOpen
        private void popTrans_Meth_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Transport Meth.";
            e.PopupPassData.ConditionCaption = "Transport Meth.";

            e.PopupPassData.SQLFromStatements = "B_MINOR";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("B9009", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popTrans_Meth.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Transport Meth.";
            e.PopupPassData.GridCellCaption[1] = "Transport Meth. Desc.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popTrans_Meth_AfterPopupClosed
        private void popTrans_Meth_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popTrans_Meth.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popTrans_Meth.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popTrans_Meth.Focus();
        }
        # endregion

        # region popDoc_cur_BeforePopupOpen
        private void popDoc_cur_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Currency";
            e.PopupPassData.ConditionCaption = "Currency";

            e.PopupPassData.SQLFromStatements = "B_CURRENCY";
            e.PopupPassData.SQLWhereStatements = "";

            e.PopupPassData.SQLWhereInputCodeValue = popDoc_cur.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "CURRENCY";
            e.PopupPassData.GridCellCode[1] = "CURRENCY_DESC";

            e.PopupPassData.GridCellCaption[0] = "Currency";
            e.PopupPassData.GridCellCaption[1] = "Cur. Desc.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popDoc_cur_AfterPopupClosed
        private void popDoc_cur_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popDoc_cur.CodeValue = iDataSet.Tables[0].Rows[0]["CURRENCY"].ToString();
            popDoc_cur.Focus();
        }
        # endregion

        # region popPay_type_BeforePopupOpen
        private void popPay_type_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popPay_terms.CodeValue.Trim() == string.Empty)
            {
                uniBase.UMessage.DisplayMessageBox("205152", MessageBoxButtons.OK);
                popPay_terms.Focus();
                e.Cancel = true;
                return;
            }
            e.PopupPassData.PopupWinTitle = "Receipt Type";
            e.PopupPassData.ConditionCaption = "Receipt Type";

            e.PopupPassData.SQLFromStatements = "B_MINOR (nolock) ,B_CONFIGURATION (nolock) , (Select REFERENCE From B_CONFIGURATION Where MAJOR_CD = " + uniBase.UCommon.FilterVariable("B9004", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " And MINOR_CD=" + uniBase.UCommon.FilterVariable(popPay_terms.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " And SEQ_NO>=2) C ";
            e.PopupPassData.SQLWhereStatements = "B_MINOR.MINOR_CD = C.REFERENCE And B_CONFIGURATION.MINOR_CD = B_MINOR.MINOR_CD And B_MINOR.MAJOR_CD = " + uniBase.UCommon.FilterVariable("A1006", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " AND B_CONFIGURATION.REFERENCE IN(" + uniBase.UCommon.FilterVariable("RP", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + "," + uniBase.UCommon.FilterVariable("R", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " )";

            e.PopupPassData.SQLWhereInputCodeValue = popPay_type.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "B_MINOR.MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "B_MINOR.MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Receipt Type";
            e.PopupPassData.GridCellCaption[1] = "Receipt Type Description";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popPay_type_AfterPopupClosed
        private void popPay_type_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPay_type.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popPay_type.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popPay_type.Focus();
        }
        # endregion

        # region popIncoTerms_BeforePopupOpen
        private void popIncoTerms_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Incoterms";
            e.PopupPassData.ConditionCaption = "Incoterms";

            e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("B9006", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popIncoTerms.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Incoterms";
            e.PopupPassData.GridCellCaption[1] = "Incoterms Description";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        #region popIncoTerms_AfterPopupClosed
        private void popIncoTerms_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popIncoTerms.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popIncoTerms.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popIncoTerms.Focus();
        }
        # endregion

        # region popLoading_port_Cd_BeforePopupOpen
        private void popLoading_port_Cd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Loading Port";
            e.PopupPassData.ConditionCaption = "Loading Port";

            e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("B9092", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popLoading_port_Cd.CodeValue.Trim();//popIncoTerms.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Loading Port";
            e.PopupPassData.GridCellCaption[1] = "Loading Port Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popLoading_port_Cd_AfterPopupClosed
        private void popLoading_port_Cd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popLoading_port_Cd.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popLoading_port_Cd.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popLoading_port_Cd.Focus();
        }
        # endregion

        # region popDischge_port_Cd_BeforePopupOpen
        private void popDischge_port_Cd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Arrival Port";
            e.PopupPassData.ConditionCaption = "Arrival Port";

            e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("B9092", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popDischge_port_Cd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Arrival Port";
            e.PopupPassData.GridCellCaption[1] = "Arrival Port Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popDischge_port_Cd_AfterPopupClosed
        private void popDischge_port_Cd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popDischge_port_Cd.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popDischge_port_Cd.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popDischge_port_Cd.Focus();
        }
        # endregion

        # region popPack_cond_BeforePopupOpen
        private void popPack_cond_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Packing Cond.";
            e.PopupPassData.ConditionCaption = "Packing Cond.";

            e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("B9007", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popPack_cond.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Packing Cond.";
            e.PopupPassData.GridCellCaption[1] = "Packing Cond. Desc.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popPack_cond_AfterPopupClosed
        private void popPack_cond_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPack_cond.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popPack_cond.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popPack_cond.Focus();
        }
        # endregion

        # region popManufacturer_BeforePopupOpen
        private void popManufacturer_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Manufacturer";
            e.PopupPassData.ConditionCaption = "Manufacturer";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER (nolock)";
            e.PopupPassData.SQLWhereStatements = "BP_TYPE in (" + uniBase.UCommon.FilterVariable("C", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ," + uniBase.UCommon.FilterVariable("CS", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + ") AND usage_flag = " + uniBase.UCommon.FilterVariable("Y", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popManufacturer.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "BP_CD";
            e.PopupPassData.GridCellCode[1] = "BP_NM";
            e.PopupPassData.GridCellCode[2] = "BP_RGST_NO";

            e.PopupPassData.GridCellCaption[0] = "Manufacturer";
            e.PopupPassData.GridCellCaption[1] = "Manufacturer Name";
            e.PopupPassData.GridCellCaption[2] = "Corp. Registration No.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popManufacturer_AfterPopupClosed
        private void popManufacturer_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {

            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popManufacturer.CodeValue = iDataSet.Tables[0].Rows[0]["BP_CD"].ToString();
            popManufacturer.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
            popManufacturer.Focus();
        }
        # endregion

        # region popBeneficiary_BeforePopupOpen
        private void popBeneficiary_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Exporter";
            e.PopupPassData.ConditionCaption = "Exporter";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER (nolock)";
            e.PopupPassData.SQLWhereStatements = "BP_TYPE in (" + uniBase.UCommon.FilterVariable("C", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ," + uniBase.UCommon.FilterVariable("CS", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + ") AND usage_flag = " + uniBase.UCommon.FilterVariable("Y", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popBeneficiary.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "BP_CD";
            e.PopupPassData.GridCellCode[1] = "BP_NM";
            e.PopupPassData.GridCellCode[2] = "BP_RGST_NO";

            e.PopupPassData.GridCellCaption[0] = "Exporter";
            e.PopupPassData.GridCellCaption[1] = "Exporter Name";
            e.PopupPassData.GridCellCaption[2] = "Corp. Registration No.";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popBeneficiary_AfterPopupClosed
        private void popBeneficiary_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popBeneficiary.CodeValue = iDataSet.Tables[0].Rows[0]["BP_CD"].ToString();
            popBeneficiary.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
            popBeneficiary.Focus();
        }
        # endregion

        #region popOrigin_BeforePopupOpen
        private void popOrigin_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Origin";
            e.PopupPassData.ConditionCaption = "Origin";

            e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("B9094", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popOrigin.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "Origin";
            e.PopupPassData.GridCellCaption[1] = "Origin Name";


            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

        }
        # endregion

        # region popOrigin_AfterPopupClosed
        private void popOrigin_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popOrigin.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popOrigin.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popOrigin.Focus();
        }
        # endregion

        # region popSending_Bank_BeforePopupOpen
        private void popSending_Bank_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Rem. Bank";
            e.PopupPassData.ConditionCaption = "Rem. Bank";

            e.PopupPassData.SQLFromStatements = "B_BANK (nolock)";
            e.PopupPassData.SQLWhereStatements = "";

            e.PopupPassData.SQLWhereInputCodeValue = popSending_Bank.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "BANK_CD";
            e.PopupPassData.GridCellCode[1] = "BANK_FULL_NM";
            e.PopupPassData.GridCellCode[2] = "BANK_NM";

            e.PopupPassData.GridCellCaption[0] = "Rem. Bank";
            e.PopupPassData.GridCellCaption[1] = "Rem. Bank Full Name";
            e.PopupPassData.GridCellCaption[2] = "Rem. Bank  Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }
        # endregion

        # region popSending_Bank_AfterPopupClosed
        private void popSending_Bank_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popSending_Bank.CodeValue = iDataSet.Tables[0].Rows[0]["BANK_CD"].ToString();
            popSending_Bank.CodeName = iDataSet.Tables[0].Rows[0]["BANK_FULL_NM"].ToString();
            popSending_Bank.Focus();
        }
        # endregion

        # region popInspect_meth_BeforePopupOpen
        private void popInspect_meth_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Insp. Method";
            e.PopupPassData.ConditionCaption = "Insp. Method";

            e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD=" + uniBase.UCommon.FilterVariable("B9008", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popInspect_meth.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";


            e.PopupPassData.GridCellCaption[0] = "Insp. Method";
            e.PopupPassData.GridCellCaption[1] = "Insp. Method Desc";


            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

        }
        # endregion

        # region popInspect_meth_AfterPopupClosed
        private void popInspect_meth_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popInspect_meth.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popInspect_meth.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
            popInspect_meth.Focus();
        }
        # endregion

        # region popAgent_BeforePopupOpen
        private void popAgent_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Agent";
            e.PopupPassData.ConditionCaption = "Agent";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER (nolock)";
            e.PopupPassData.SQLWhereStatements = "BP_TYPE in (" + uniBase.UCommon.FilterVariable("C", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ," + uniBase.UCommon.FilterVariable("CS", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + ") AND usage_flag = " + uniBase.UCommon.FilterVariable("Y", "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " ";

            e.PopupPassData.SQLWhereInputCodeValue = popAgent.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";

            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[3];
            e.PopupPassData.GridCellCaption = new String[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "BP_CD";
            e.PopupPassData.GridCellCode[1] = "BP_NM";
            e.PopupPassData.GridCellCode[2] = "BP_RGST_NO";


            e.PopupPassData.GridCellCaption[0] = "Agent";
            e.PopupPassData.GridCellCaption[1] = "Agent Name";
            e.PopupPassData.GridCellCaption[2] = "Corp. Registration No.";


            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
        }
        # endregion

        #region popAgent_AfterPopupClosed
        private void popAgent_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popAgent.CodeValue = iDataSet.Tables[0].Rows[0]["BP_CD"].ToString();
            popAgent.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
            popAgent.Focus();
        }
        # endregion

        # region lblSORef_BeforePopupOpen | tangwei modified
        private void lblSORef_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (viewDBSaveMode == enumDef.DBSaveMode.UpdateMode)
            {
                uniBase.UMessage.DisplayMessageBox("200005", MessageBoxButtons.OK,"");
                e.Cancel = true;
                return;
            }

            if (cstrSoTypeRetItemFlag.ToUpper() != "Y")
            {
                uniBase.UMessage.DisplayMessageBox("203155", MessageBoxButtons.OK,"");
                e.Cancel = true;
                return;
            }
            
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.s3112ra5";
            e.PopupPassData.PopupWinTitle = "S/O Ref. ";
            e.PopupPassData.PopupWinWidth = 780;
            e.PopupPassData.PopupWinHeight = 450;
        }
        # endregion

        #region lblSORef_AfterPopupClosed
        private void lblSORef_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            if (iDataSet == null || iDataSet.Tables.Count == 0)
                return;

            cstrHSONo = iDataSet.Tables[0].Rows[0][0].ToString();

            SetSORef(iDataSet.Tables[0]);
        }
        # endregion

        # region lblProjectReference_BeforePopupOpen
        private void lblProjectReference_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (base.viewDBSaveMode == enumDef.DBSaveMode.UpdateMode)
            {
                uniBase.UMessage.DisplayMessageBox("200005", MessageBoxButtons.OK,"");
                e.Cancel = true;
                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.s3111ra9";
            e.PopupPassData.PopupWinTitle = "Project Ref. ";
            e.PopupPassData.PopupWinWidth = 780;
            e.PopupPassData.PopupWinHeight = 450;

            string[] istrPara = new string[3];
            istrPara[0] = "";
            istrPara[1] = "";
            istrPara[2] = "";
            e.PopupPassData.Data = istrPara;
        }
        # endregion

        # region lblProjectReference_AfterPopupClosed
        private void lblProjectReference_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            if (iDataSet.Tables[0].Rows[0][0].ToString() == string.Empty)
                return;

            SetPrjRef(iDataSet.Tables[0]);

        }
        #endregion

        # region SetPrjRef | tangwei modified
        private bool SetPrjRef(DataTable ptable)
        {
            cstrProjectCd = ptable.Rows[0][0].ToString();

            //SubProjectRef() -- S3111mb1
            string iCommandSent = "QUERY";
            string I1_s_so_hdr = cstrProjectCd;

            wsPS3G105FL.DsSLookupProjectSvr iqtDsSLookupProjectSvr = new uniERP.App.UI.SD.S3111MA1__KO883.wsPS3G105FL.DsSLookupProjectSvr();
            
            try
            {
                using (wsPS3G105FL.PS3G105FL iwsPS3G105FL = (wsPS3G105FL.PS3G105FL)
                    uniBase.UConfig.SetWebServiceProxyEnv(new wsPS3G105FL.PS3G105FL()))
                {
                    iqtDsSLookupProjectSvr = iwsPS3G105FL.cLookupProjectSvr_S_LOOKUP_PROJECT_SVR(
                        CommonVariable.gStrGlobalCollection, iCommandSent, I1_s_so_hdr);
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
            }

            cstrProjectCd = iqtDsSLookupProjectSvr.ES_SO_HDR[0].prj_cd;
            //cstrReq_dlvy_dt = iqtDsSLookupProjectSvr.ES_SO_HDR[0].req_dlvy_dt.ToString();
            if (iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["req_dlvy_dt"] != System.DBNull.Value)
            {
                dtReq_dlvy_dt.Value = iqtDsSLookupProjectSvr.ES_SO_HDR[0].req_dlvy_dt;
            }
            else
            {
                dtReq_dlvy_dt.Value = null;
            }
            if (dtReq_dlvy_dt.uniValue >= Convert.ToDateTime( CommonVariable.gMaximumDate)
                || dtReq_dlvy_dt.uniValue <= Convert.ToDateTime(CommonVariable.gMinimumDate))
            {
                dtReq_dlvy_dt.Value = null;
            }

            //수주번호 참조 추가
            txtSoNo.Value = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["prj_cd"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].prj_cd.ToString();

            popSold_to_party.CodeValue = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["bp_cd"] == System.DBNull.Value?"":
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].bp_cd;
            popSold_to_party.CodeName = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["bp_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].bp_nm;

            //2018-07-13 Add
            popShip_to_party.CodeValue = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["bp_cd"] == System.DBNull.Value ? "" : iqtDsSLookupProjectSvr.ES_SO_HDR[0].bp_cd;
            popShip_to_party.CodeName = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["bp_nm"] == System.DBNull.Value ? "" : iqtDsSLookupProjectSvr.ES_SO_HDR[0].bp_nm;

            popBill_to_party.CodeValue = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["bp_cd"] == System.DBNull.Value ? "" : iqtDsSLookupProjectSvr.ES_SO_HDR[0].bp_cd;
            popBill_to_party.CodeName = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["bp_nm"] == System.DBNull.Value ? "" : iqtDsSLookupProjectSvr.ES_SO_HDR[0].bp_nm;

            popPayer.CodeValue = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["bp_cd"] == System.DBNull.Value ? "" : iqtDsSLookupProjectSvr.ES_SO_HDR[0].bp_cd;
            popPayer.CodeName = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["bp_nm"] == System.DBNull.Value ? "" : iqtDsSLookupProjectSvr.ES_SO_HDR[0].bp_nm;
            //

            popSales_Grp.CodeValue = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["sales_grp"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].sales_grp;
            popSales_Grp.CodeName = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["sales_grp_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].sales_grp_nm;
            popPay_terms.CodeValue = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["pay_meth"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].pay_meth;
            popPay_terms.CodeName = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["pay_meth_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].pay_meth_nm;
            popVat_Type.CodeValue = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["vat_type"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].vat_type;
            popVat_Type.CodeName = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["vat_type_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].vat_type_nm;          

            numVat_rate.Value = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["vat_rate"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].vat_rate.ToString();
            popDoc_cur.CodeValue = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["cur"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].cur;
            numDoc_cur.Value = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["net_amt"] == System.DBNull.Value ? 0 :
                   iqtDsSLookupProjectSvr.ES_SO_HDR[0].net_amt;
            numVat_amt.Value = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["vat_amt"] == System.DBNull.Value ? 0 :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].vat_amt;
            if (popDoc_cur.CodeValue.ToUpper() == CommonVariable.gCurrency.ToUpper())
            {
                uniBase.UCommon.ChangeFieldLockAttribute(numXchg_rate, enumDef.FieldLockAttribute.Protected);
                numXchg_rate.FieldType = enumDef.FieldType.ReadOnly;
            }
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(numXchg_rate, enumDef.FieldLockAttribute.Required);
                numXchg_rate.FieldType = enumDef.FieldType.NotNull;
            }
            popVat_Inc_Flag.CodeValue = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["vat_inc_flag"] == System.DBNull.Value ? "" :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].vat_inc_flag;          

            if (iqtDsSLookupProjectSvr.ES_SO_HDR[0]["vat_inc_flag"] != System.DBNull.Value)
            {
                popVat_Inc_Flag.CodeName = GetVATIncludNM(iqtDsSLookupProjectSvr.ES_SO_HDR[0].vat_inc_flag);
            }

            numXchg_rate.Value = iqtDsSLookupProjectSvr.ES_SO_HDR.Rows[0]["xchg_rate"] == System.DBNull.Value ? 0 :
                iqtDsSLookupProjectSvr.ES_SO_HDR[0].xchg_rate;
            return true;
        }
        # endregion

        # region SetDefaultVal
        //private void SetDefaultVal()
        //{
        //    popConSo_no.Focus();
        //    rdoCfm_flag.CheckedIndex = 1;
        //    rdoPrice_flag.CheckedIndex = 0;
        //    dtCust_po_dt.Value = uniBase.UDate.GetDBServerDateTime();
        //    dtSo_dt.Value = uniBase.UDate.GetDBServerDateTime();
        //    dtValid_dt.Value = uniBase.UDate.GetDBServerDateTime();
        //    dtContract_dt.Value = uniBase.UDate.GetDBServerDateTime();
        //    cstrRadioFlag = rdoCfm_flag.CheckedItem.DataValue.ToString().Trim();
        //    cstrRadioType = rdoPrice_flag.CheckedItem.DataValue.ToString().Trim();
        //    popSales_Grp.CodeValue = CommonVariable.gSalesGrp;
        //    popTo_Biz_Grp.CodeValue = CommonVariable.gSalesGrp;
        //    popBeneficiary.CodeValue = CommonVariable.gCompany;
        //    popBeneficiary.CodeName = CommonVariable.gCompanyNm;
        //    popDoc_cur.CodeValue = CommonVariable.gCurrency;
        //    numXchg_rate.Value = "0";
        //    btnDNCheck.Enabled = true;
        //    btnCancel.Enabled = true;
        //    btnCancel.Text = "Release";

        //}
        # endregion       

        # region SetSORef | tangwei modified
        private bool SetSORef(DataTable pTable)
        {
            if (pTable == null || pTable.Rows.Count == 0)
                return false;
         
            string I1_s_so_hdr = pTable.Rows[0][0].ToString();
            string iCommandSent = "RETURNSOQUERY";
            wsPS3G102FL.DsSLookupSoHdrSvr iqtDsSLookupSoHdrSvr = null;
           
            try
            {
                using (wsPS3G102FL.PS3G102FL iwsPS3G102FL = 
                    (wsPS3G102FL.PS3G102FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPS3G102FL.PS3G102FL()))
                {
                    iqtDsSLookupSoHdrSvr = 
                        iwsPS3G102FL.cLookupSoHdrSvr_S_LOOKUP_SO_HDR_SVR(CommonVariable.gStrGlobalCollection,
                        iCommandSent, I1_s_so_hdr);
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
            }
            
            if (iqtDsSLookupSoHdrSvr == null || iqtDsSLookupSoHdrSvr.Tables.Count == 0)
                return false;

            #region   already modified
            popSold_to_party.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["sold_to_party"] == System.DBNull.Value ? "":
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].sold_to_party;
            popSold_to_party.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["sold_to_party_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].sold_to_party_nm;
            popSales_Grp.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["sales_grp"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].sales_grp;
            popSales_Grp.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["sales_grp_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].sales_grp_nm;
            popBill_to_party.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["bill_to_party"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].bill_to_party;
            popBill_to_party.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["bill_to_party_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].bill_to_party_nm;
            popShip_to_party.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["ship_to_party"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].ship_to_party;
            popShip_to_party.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["ship_to_party_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].ship_to_party_nm;
            popTo_Biz_Grp.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["to_biz_grp"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].to_biz_grp;
            popTo_Biz_Grp.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["to_biz_grp_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].to_biz_grp_nm;
            popPayer.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["payer"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].payer;
            popPayer.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["payer_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].payer_nm;
            popDeal_Type.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["deal_type"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].deal_type;
            popDeal_Type.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["deal_type_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].deal_type_nm;
            txtCust_po_no.Text = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["cust_po_no"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].cust_po_no;
            popPay_terms.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["pay_meth"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].pay_meth;
            popPay_terms.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["pay_meth_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].pay_meth_nm;
            popPay_type.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["pay_type"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].pay_type;
            popPay_type.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["pay_type_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].pay_type_nm;
            numPay_dur.Value = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["pay_dur"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].pay_dur.ToString();
            popVat_Type.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["vat_type"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].vat_type;
            popVat_Type.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["vat_type_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].vat_type_nm;
            numVat_rate.Value = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["vat_rate"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].vat_rate.ToString();
            popDoc_cur.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["cur"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].cur;

            if (iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].cur.ToUpper() == CommonVariable.gCurrency.ToUpper())
            {
                uniBase.UCommon.ChangeFieldLockAttribute(numXchg_rate, enumDef.FieldLockAttribute.Protected);
                numXchg_rate.FieldType = enumDef.FieldType.ReadOnly;
            }
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(numXchg_rate, enumDef.FieldLockAttribute.Normal);
                numXchg_rate.FieldType = enumDef.FieldType.Default;
            }

            popVat_Inc_Flag.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["vat_inc_flag"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].vat_inc_flag;
            popVat_Inc_Flag.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["vat_inc_flag_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].vat_inc_flag_nm;
            numXchg_rate.Value = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["xchg_rate"] == System.DBNull.Value ? 0 :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].xchg_rate;
            popTrans_Meth.CodeValue = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["trans_meth"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].trans_meth;
            popTrans_Meth.CodeName = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["trans_meth_nm"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].trans_meth_nm;
            txt_Payterms_txt.Text = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["pay_terms_txt"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].pay_terms_txt.Trim();
            txtRemark.Text = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["remark"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].remark;
            //cstrSoTypeRetItemFlag = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["ret_item_flag"] == System.DBNull.Value ? "" :
            //    iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].ret_item_flag;
            cstrRetItemFlag = iqtDsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["ret_item_flag"] == System.DBNull.Value ? "" :
                iqtDsSLookupSoHdrSvr.ES_SO_HDR[0].ret_item_flag;

            #endregion

            return true;

        }
        # endregion

        # region popSold_to_party_OnExitEditCode
        private void popSold_to_party_OnExitEditCode(object sender, EventArgs e)
        {
            //If Trim(frm1.txtSold_to_party.value) <> "" Then Call SoldToPartyLookUp()
            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows.Count > 0
                && cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["sold_to_party"] != System.DBNull.Value
                && popSold_to_party.CodeValue != cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].sold_to_party
                && popSold_to_party.CodeValue.Trim().Length > 0)
            {
                SubLookUp();
            }
            else
            {
                return;
            }

            # region tang comment
            // wsPB5CS41FL.DsBLookupBizPartnerSvr iqtdsDsBLookupBizPartnerSvr = new uniERP.App.UI.SD.S3111MA1__KO883.wsPB5CS41FL.DsBLookupBizPartnerSvr();

            // try
            // {
            //     wsPB5CS41FL.PB5CS41FL iwsPB5CS41FL = (wsPB5CS41FL.PB5CS41FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPB5CS41FL.PB5CS41FL());
            //     iqtdsDsBLookupBizPartnerSvr = iwsPB5CS41FL.cLookupBizPartnerSvr_B_LOOKUP_BIZ_PARTNER_SVR(CommonVariable.gStrGlobalCollection, "QUERY", popSold_to_party.CodeValue.Trim(), "");
            // }
            // catch (Exception ex)
            // {
            //     bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
            //     if (reThrow)
            //         throw;
            // }
            // wsPB5GS45FL.DsBListDefaultBpFtnSvr iqtdsDsBListDefaultBpFtnSvr = new uniERP.App.UI.SD.S3111MA1__KO883.wsPB5GS45FL.DsBListDefaultBpFtnSvr();
            // try
            // {
            //     wsPB5GS45FL.PB5GS45FL iwsPB5GS45FL = (wsPB5GS45FL.PB5GS45FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPB5GS45FL.PB5GS45FL());
            //     iqtdsDsBListDefaultBpFtnSvr = iwsPB5GS45FL.cBListDftBpFtnSvr_B_LIST_DEFAULT_BP_FTN_SVR(CommonVariable.gStrGlobalCollection, popSold_to_party.CodeValue.Trim());
            // }
            // catch (Exception ex)
            // {
            //     bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
            //     if (reThrow)
            //         throw;
            // }
            // popSold_to_party.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_cd"].ToString();
            // popSold_to_party.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            // popDeal_Type.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            // popDeal_Type.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            // popPay_terms.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            // popPay_terms.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();

            // //numPay_dur.Value = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            // popVat_Type.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            // popVat_Type.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            //// numVat_rate.Value = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();

            // popTrans_Meth.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            // popTrans_Meth.CodeName = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["bp_nm"].ToString();
            // //iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER.currencyColumn

            // if(iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["currency"].ToString()!="")
            // {
            //     popDoc_cur.CodeValue = iqtdsDsBLookupBizPartnerSvr.E1_B_BIZ_PARTNER[0]["currency"].ToString();
            // }

            // //don't finish!!! xiaomei jixu zuo ba!!!


            // popShip_to_party.CodeValue = iqtdsDsBListDefaultBpFtnSvr.E2_B_BIZ_PARTNER[0]["bp_cd"].ToString();
            # endregion 

        }
        # endregion

        # region btnDNCheck_Click | tangwei modified
        private void btnDNCheck_Click(object sender, EventArgs e)
        {   
            DialogResult iRet = DialogResult.None;
            if (uniBase.UCommon.CheckSingleDirty())
            {
                iRet = uniBase.UMessage.DisplayMessageBox("900017", MessageBoxButtons.YesNo, "");
                if (iRet == DialogResult.No)
                {   
                    return;
                }
            }
            else
            {
                this.Presenter.ProgressBarController.DisplayProgressBar();
                iRet = uniBase.UMessage.DisplayMessageBox("900018", MessageBoxButtons.YesNo, "");

                if (iRet == DialogResult.Yes)
                {
                    //--SubDNCheck
                    if (txtSoNo.Text.Trim() == "")
                    {
                        this.Presenter.ProgressBarController.HideProgressBar();
                        uniBase.UMessage.DisplayMessageBox("202517", MessageBoxButtons.OK, "");
                        return;
                    }
                    string ipvStrSoNo, ipvFlag;
                    ipvStrSoNo = txtSoNo.Text.Trim();
                    ipvFlag = cstrRdoDnReq;
                    string strDnNo = string.Empty; //2016-11-16 EJW

                    try
                    {
                        using (wsPS3G117FL.PS3G117FL iwsPS3G117FL = (wsPS3G117FL.PS3G117FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPS3G117FL.PS3G117FL()))
                        {
                            strDnNo = iwsPS3G117FL.cSCreateDnBySoSvr_S_CREATE_DN_BY_SO_SVR(CommonVariable.gStrGlobalCollection, ipvStrSoNo, ipvFlag);
                        }
                    }
                    catch (Exception ex)
                    {
                        this.Presenter.ProgressBarController.HideProgressBar();
                        bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                        if (reThrow)
                            throw;
                    }

                    if (strDnNo.Length > 0)
                    {
                        uniBase.UMessage.DisplayMessageBox("204262", MessageBoxButtons.OK, strDnNo); //%1 건이 등록되었습니다.
                    }
                    else
                    {
                        //uniBase.UMessage.DisplayMessageBox("990000", MessageBoxButtons.OK, strDnNo); //정상처리되었습니다.
                    }

                    OnFncQuery();
                    this.Presenter.ProgressBarController.HideProgressBar();
                    return;
                }
                else
                {
                    this.Presenter.ProgressBarController.HideProgressBar();
                    return;
                }                
            }
        }
        # endregion        

        # region btnConfirm_Click | tangwei modified
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //2017-05-15 EJW
            if (!chkMultiCompany())
            {
                uniBase.UMessage.DisplayMessageBox("20M010", MessageBoxButtons.OK, ""); //저장/삭제/확정/취소 할 수 없습니다. 멀티컴퍼니 모듈의 메뉴를 이용하세요.
                return;
            }

            DialogResult iRet = DialogResult.None;
            if (uniBase.UCommon.CheckSingleDirty())
            {
                iRet = uniBase.UMessage.DisplayMessageBox("900017", MessageBoxButtons.YesNo, "");
                if (iRet == DialogResult.No)
                {
                    this.Presenter.ProgressBarController.HideProgressBar();
                    return;
                }
            }
            else
            {
               iRet = uniBase.UMessage.DisplayMessageBox("900018", MessageBoxButtons.YesNo, "");

                if (iRet == DialogResult.Yes)
                {
                    this.Presenter.ProgressBarController.DisplayProgressBar();

                    if (cstrHRdoConfirm == "Y")
                    {
                        CheckCreditlimit();
                    }
                    else
                    {
                        SubbtnCONFIRM();
                    }
                    OnFncQuery();
                    this.Presenter.ProgressBarController.HideProgressBar();
                    return;
                }
                else
                {
                    this.Presenter.ProgressBarController.HideProgressBar();
                    return;
                }
            }            
        }
        # endregion

        # region CheckCreditlimit | tangwei added
        private void CheckCreditlimit()
        {
            double iReVal = 0;
            //Call PS3G113
            #region paramters
            wsPS3G113FL.DsChkcreditlimitsvr itdsDsChkcreditlimitsvr = new wsPS3G113FL.DsChkcreditlimitsvr();
            wsPS3G113FL.DsChkcreditlimitsvr.I_CHK_CREDIT_LIMIT_SVRDataTable idtI_CHK_CREDIT_LIMIT_SVR = itdsDsChkcreditlimitsvr.I_CHK_CREDIT_LIMIT_SVR;
            wsPS3G113FL.DsChkcreditlimitsvr.I_CHK_CREDIT_LIMIT_SVRRow iRowI_CHK_CREDIT_LIMIT_SVR = idtI_CHK_CREDIT_LIMIT_SVR.NewI_CHK_CREDIT_LIMIT_SVRRow();
            iRowI_CHK_CREDIT_LIMIT_SVR.caller = "SC";
            iRowI_CHK_CREDIT_LIMIT_SVR.doc_no = txtSoNo.Text.Trim();
            iRowI_CHK_CREDIT_LIMIT_SVR.doc_amt = 0;
            idtI_CHK_CREDIT_LIMIT_SVR.AddI_CHK_CREDIT_LIMIT_SVRRow(iRowI_CHK_CREDIT_LIMIT_SVR);
            itdsDsChkcreditlimitsvr.AcceptChanges();
            #endregion

            wsPS3G113FL.PS3G113FL iwsPS3G113FL = (wsPS3G113FL.PS3G113FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPS3G113FL.PS3G113FL());
            try
            {
               iReVal = 
                   iwsPS3G113FL.CChkCreditLimit_ChkCreditLimitSvr(CommonVariable.gStrGlobalCollection, itdsDsChkcreditlimitsvr);
            }
            catch (Exception ex)
            {
                if (ex.ToString().Contains("201929"))
                {
                   uniServerSoapException uniEx = new uniServerSoapException((SoapException)ex);

                    Decimal dAmt = Convert.ToDecimal(uniEx.SoapExceptionDetail.ErrorColPosition);
                    string sAmt = uniBase.UNumber.FormatNumber(dAmt, viewTB19029.ggAmtOfMoney, 0).ToString(viewTB19029.ggAmtOfMoney.DataFormat);

                    if (uniBase.UMessage.DisplayMessageBox("201929", MessageBoxButtons.YesNo, uniEx.SoapExceptionDetail.ErrorRowPosition, sAmt) == DialogResult.Yes)
                    {
                        SubbtnCONFIRM();
                        return;
                    }
                    else
                    {
                        this.Presenter.ProgressBarController.HideProgressBar();
                        return;
                    }
                }
                else if (ex.ToString().Contains("201722"))
                {
                    uniServerSoapException uniEx = new uniServerSoapException((SoapException)ex);

                    Decimal dAmt = Convert.ToDecimal(uniEx.SoapExceptionDetail.ErrorColPosition);
                    string sAmt = uniBase.UNumber.FormatNumber(dAmt, viewTB19029.ggAmtOfMoney, 0).ToString(viewTB19029.ggAmtOfMoney.DataFormat);

                    this.Presenter.ProgressBarController.HideProgressBar();
                    uniBase.UMessage.DisplayMessageBox("201722", MessageBoxButtons.OK, uniEx.SoapExceptionDetail.ErrorRowPosition, sAmt);

                    return;
                }
                else
                {
                    this.Presenter.ProgressBarController.HideProgressBar();
                    bool reThrow = ExceptionControler.AutoProcessException(ex);

                    if (reThrow)
                        throw;
                    return;
                }
            }

            SubbtnCONFIRM();            
            return;
        }
        # endregion

        # region SubbtnCONFIRM | tangwei added
        private void SubbtnCONFIRM()
        {
            wsPS3G150FL.DsSConfirmSalesOrderSvr isettDsSConfirmSalesOrderSvr = new wsPS3G150FL.DsSConfirmSalesOrderSvr();
            wsPS3G150FL.DsSConfirmSalesOrderSvr.IS_SO_HDRRow iRowIS_SO_HDR = isettDsSConfirmSalesOrderSvr.IS_SO_HDR.NewIS_SO_HDRRow();
            //cqtdsSLookupSoHdrSvr.ES_SO_HDR.Merge(isettDsSConfirmSalesOrderSvr.IS_SO_HDR, true, MissingSchemaAction.Ignore);
            iRowIS_SO_HDR.so_no = txtSoNo.Text.Trim();
            iRowIS_SO_HDR.cfm_flag = cstrHRdoConfirm;//rdoCfm_flag.Value.ToString();
            iRowIS_SO_HDR.rel_bill_flag = cstrelbillflag;
            isettDsSConfirmSalesOrderSvr.IS_SO_HDR.AddIS_SO_HDRRow(iRowIS_SO_HDR);
            isettDsSConfirmSalesOrderSvr.AcceptChanges();
            try
            {
                using (wsPS3G150FL.PS3G150FL iwsPS3G150FL = (wsPS3G150FL.PS3G150FL)uniBase.UConfig.SetWebServiceProxyEnv(new wsPS3G150FL.PS3G150FL()))
                {
                    iwsPS3G150FL.cSConfirmSalesOrderSvr_S_CONFIRM_SALES_ORDER_SVR(CommonVariable.gStrGlobalCollection, isettDsSConfirmSalesOrderSvr);
                }
            }
            catch (Exception ex)
            {
                this.Presenter.ProgressBarController.HideProgressBar();
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
            }
            this.Presenter.ProgressBarController.HideProgressBar();
            
        }
        # endregion

        #endregion

        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        # region SoTypeExportCheck
        private int SoTypeExportCheck()
        {
            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows.Count < 1)
            {
                if (cstrSoTypeExportFlag.ToUpper() == "Y" || cstrSoTypeCiFlag.ToUpper() == "Y")
                {
                    //tangwei added but maybe can't find from ASP
                    SoTypeExpRequiredChg();
                    return 1;
                }
                else if (cstrSoTypeExportFlag.ToUpper() == "" || cstrSoTypeCiFlag.ToUpper() == "")
                {
                    //tangwei added but maybe can't find from ASP
                    SoTypeExpDefaultChg();
                    return 2;
                }
                else
                {
                    //tangwei added but maybe can't find from ASP
                    SoTypeExpDefaultChg();
                    return 3;
                }
            }
            else
            {
                if ((cstrSoTypeExportFlag.ToUpper() == "Y" || cstrSoTypeCiFlag.ToUpper() == "Y")
                    && cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].cfm_flag !="Y")
                {
                    //tangwei added but maybe can't find from ASP
                    SoTypeExpRequiredChg();
                    return 1;
                }
                else if (((cstrSoTypeExportFlag.ToUpper() == "Y" || cstrSoTypeCiFlag.ToUpper() == "Y")
                    && cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].cfm_flag == "Y"))
                {
                    SoTypeExpProtectedChg();
                    return 1;
                }
                else if (cstrSoTypeExportFlag.ToUpper() == "" || cstrSoTypeCiFlag.ToUpper() == "")
                {
                    //tangwei added but maybe can't find from ASP
                    SoTypeExpDefaultChg();
                    return 2;
                }
                else
                {
                    //tangwei added but maybe can't find from ASP
                    SoTypeExpDefaultChg();
                    return 3;
                }
            }

        }
        # endregion

        #endregion

        # region popConSo_no_BeforePopupOpen
        private void popConSo_no_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.s3111pa1";
            e.PopupPassData.PopupWinTitle = "S/O No. ";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;

            DataSet iDataSet = new DataSet();
            DataTable iDataTable = new DataTable();
            iDataSet.Tables.Add(iDataTable);
            iDataTable.Columns.Add("flag");
            DataRow iDataRow = iDataTable.NewRow();
            iDataTable.Rows.Add(iDataRow);
            iDataTable.Rows[0]["flag"] = "SO_REG";
            e.PopupPassData.Data = iDataSet;
        }
        # endregion

        # region popConSo_no_AfterPopupClosed
        private void popConSo_no_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popConSo_no.CodeValue = iDataSet.Tables[0].Rows[0][0].ToString();
            popConSo_no.Focus();
        }
        #endregion      

        #endregion        

        # region LockFieldInit | tangwei added
        private void LockFieldInit(string pvFlag)
        {
            uniBase.UCommon.ChangeFieldLockAttribute(txtSoNo, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(dtSo_dt, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(dtReq_dlvy_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(dtCust_po_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(dtContract_dt, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(dtValid_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(dtship_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(numPay_dur, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(numXchg_rate, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(numVat_rate, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(numVat_amt, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(numNet_Amt_Loc, enumDef.FieldLockAttribute.Protected);

            txtSoNo.FieldType = enumDef.FieldType.ReadOnly;
            dtSo_dt.FieldType = enumDef.FieldType.NotNull;
            dtReq_dlvy_dt.FieldType = enumDef.FieldType.Default;
            dtCust_po_dt.FieldType = enumDef.FieldType.Default;
            dtContract_dt.FieldType = enumDef.FieldType.NotNull;
            dtValid_dt.FieldType = enumDef.FieldType.Default;
            dtship_dt.FieldType = enumDef.FieldType.Default;
            numPay_dur.FieldType = enumDef.FieldType.Default;
            numXchg_rate.FieldType = enumDef.FieldType.Default;
            numVat_rate.FieldType = enumDef.FieldType.ReadOnly;
            numVat_amt.FieldType = enumDef.FieldType.ReadOnly;
            numNet_Amt_Loc.FieldType = enumDef.FieldType.ReadOnly;

            if (pvFlag.ToUpper() == "N")
            {
                uniBase.UCommon.ChangeFieldLockAttribute(txtSoNo, enumDef.FieldLockAttribute.Protected);
                txtSoNo.FieldType = enumDef.FieldType.ReadOnly;
            }
        }
        # endregion

        # region UnLockColor_CfmNo | tangwei added
        private void UnLockColor_CfmNo()
        {
            uniBase.UCommon.ChangeFieldLockAttribute(popTo_Biz_Grp, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popDoc_cur, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(popVat_Inc_Flag, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popVat_Type, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popTrans_Meth, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popPay_terms, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(txtCust_po_no, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(dtCust_po_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(dtReq_dlvy_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(numPay_dur, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(txt_Payterms_txt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popBill_to_party, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popPayer, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(popCurr, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(numExt2Amt, enumDef.FieldLockAttribute.Normal);

            popTo_Biz_Grp.FieldType = enumDef.FieldType.Default;
            popDoc_cur.FieldType = enumDef.FieldType.NotNull;
            popVat_Inc_Flag.FieldType = enumDef.FieldType.Default;
            popVat_Type.FieldType = enumDef.FieldType.Default;
            popTrans_Meth.FieldType = enumDef.FieldType.Default;
            popPay_terms.FieldType = enumDef.FieldType.NotNull;
            txtCust_po_no.FieldType = enumDef.FieldType.Default;
            dtCust_po_dt.FieldType = enumDef.FieldType.Default;
            dtReq_dlvy_dt.FieldType = enumDef.FieldType.Default;
            numPay_dur.FieldType = enumDef.FieldType.Default;
            txt_Payterms_txt.FieldType = enumDef.FieldType.Default;
            txtRemark.FieldType = enumDef.FieldType.Default;
            popBill_to_party.FieldType = enumDef.FieldType.Default;
            popPayer.FieldType = enumDef.FieldType.Default;
            popCurr.FieldType = enumDef.FieldType.Default;
            numExt2Amt.FieldType = enumDef.FieldType.Default;

        }
        # endregion

        # region LockColor_CfmYes | tangwei added
        private void LockColor_CfmYes()
        {
            uniBase.UCommon.ChangeFieldLockAttribute(popPay_terms, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popTo_Biz_Grp, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popDoc_cur, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popVat_Inc_Flag, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popVat_Type, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popTrans_Meth, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(txtCust_po_no, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(dtCust_po_dt, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(dtReq_dlvy_dt, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(numPay_dur, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(txt_Payterms_txt, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popBill_to_party, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(popPayer, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(numXchg_rate, enumDef.FieldLockAttribute.Protected);

            uniBase.UCommon.ChangeFieldLockAttribute(popCurr, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(numExt2Amt, enumDef.FieldLockAttribute.Protected);

            popPay_terms.FieldType = enumDef.FieldType.ReadOnly;
            popTo_Biz_Grp.FieldType = enumDef.FieldType.ReadOnly;
            popDoc_cur.FieldType = enumDef.FieldType.ReadOnly;
            popVat_Inc_Flag.FieldType = enumDef.FieldType.ReadOnly;
            popVat_Type.FieldType = enumDef.FieldType.ReadOnly;
            popTrans_Meth.FieldType = enumDef.FieldType.ReadOnly;
            txtCust_po_no.FieldType = enumDef.FieldType.ReadOnly;
            dtCust_po_dt.FieldType = enumDef.FieldType.ReadOnly;
            dtReq_dlvy_dt.FieldType = enumDef.FieldType.ReadOnly;
            numPay_dur.FieldType = enumDef.FieldType.ReadOnly;
            txt_Payterms_txt.FieldType = enumDef.FieldType.ReadOnly;
            txtRemark.FieldType = enumDef.FieldType.ReadOnly;
            popBill_to_party.FieldType = enumDef.FieldType.ReadOnly;
            popPayer.FieldType = enumDef.FieldType.ReadOnly;
            numXchg_rate.FieldType = enumDef.FieldType.ReadOnly;

            popCurr.FieldType = enumDef.FieldType.ReadOnly;
            numExt2Amt.FieldType = enumDef.FieldType.ReadOnly;

        }
        #endregion

        # region LockField | tangwei added
        private void LockField()
        {
            uniBase.UCommon.ChangeFieldLockAttribute(txtSoNo, enumDef.FieldLockAttribute.Protected);

            uniBase.UCommon.ChangeFieldLockAttribute(numVat_rate, enumDef.FieldLockAttribute.Protected);
            numVat_rate.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(dtSo_dt, enumDef.FieldLockAttribute.Protected);
            dtSo_dt.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popSo_Type, enumDef.FieldLockAttribute.Protected);
            popSo_Type.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popShip_to_party, enumDef.FieldLockAttribute.Protected);
            popShip_to_party.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popSales_Grp, enumDef.FieldLockAttribute.Protected);
            popSales_Grp.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popDeal_Type, enumDef.FieldLockAttribute.Protected);
            popDeal_Type.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popPay_type, enumDef.FieldLockAttribute.Protected);
            popPay_type.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popIncoTerms, enumDef.FieldLockAttribute.Protected);
            popIncoTerms.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popBeneficiary, enumDef.FieldLockAttribute.Protected);
            popBeneficiary.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(dtContract_dt, enumDef.FieldLockAttribute.Protected);
            dtContract_dt.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(dtValid_dt, enumDef.FieldLockAttribute.Protected);
            dtValid_dt.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(dtship_dt, enumDef.FieldLockAttribute.Protected);
            dtship_dt.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popOrigin, enumDef.FieldLockAttribute.Protected);
            popOrigin.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(txtShip_dt_txt, enumDef.FieldLockAttribute.Protected);
            txtShip_dt_txt.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popLoading_port_Cd, enumDef.FieldLockAttribute.Protected);
            popLoading_port_Cd.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popSending_Bank, enumDef.FieldLockAttribute.Protected);
            popSending_Bank.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popDischge_port_Cd, enumDef.FieldLockAttribute.Protected);
            popDischge_port_Cd.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(txtDischge_city, enumDef.FieldLockAttribute.Protected);
            txtDischge_city.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popPack_cond, enumDef.FieldLockAttribute.Protected);
            popPack_cond.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popInspect_meth, enumDef.FieldLockAttribute.Protected);
            popInspect_meth.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popManufacturer, enumDef.FieldLockAttribute.Protected);
            popManufacturer.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popAgent, enumDef.FieldLockAttribute.Protected);
            popAgent.FieldType = enumDef.FieldType.ReadOnly;

            uniBase.UCommon.ChangeFieldLockAttribute(popSold_to_party, enumDef.FieldLockAttribute.Protected);
            popSold_to_party.FieldType = enumDef.FieldType.ReadOnly;
        }
        # endregion

        # region ChkSoByInf | tangwei added
        private bool ChkSoByInf()
        {
            DataSet iDs = new DataSet();
            string iStrSelectList = "";
            string iStrFromList = "";
            string iStrWhereList = "";
            string istrSoNo = cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].so_no.ToString();
            istrSoNo = uniBase.UCommon.FilterVariable(istrSoNo, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);

            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["cust_po_no"] == System.DBNull.Value
                || cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].cust_po_no == "")
            {
                return false;
            }

            iStrSelectList = " COUNT(*) ";
            iStrFromList  = " S_SO_DTL ";
            iStrWhereList = " INF_NO IS NOT NULL AND SO_NO =  " + istrSoNo;

            iDs = uniBase.UDataAccess.CommonQueryRs(iStrSelectList, iStrFromList, iStrWhereList);
            if (Convert.ToDecimal(iDs.Tables[0].Rows[0][0]) > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        # endregion

        # region LockField | tangwei added
        private void LockField(string pvStrCaller, bool pvBlnLock)
        {
            if (pvStrCaller.ToUpper() == "INF")
            {
                if (pvBlnLock)
                {
                    uniBase.UCommon.ChangeFieldLockAttribute(this.txtCust_po_no, enumDef.FieldLockAttribute.Protected);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.dtCust_po_dt, enumDef.FieldLockAttribute.Protected);

                    uniBase.UCommon.ChangeFieldLockAttribute(this.dtSo_dt, enumDef.FieldLockAttribute.Required);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popPayer, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popPay_terms, enumDef.FieldLockAttribute.Required);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popVat_Inc_Flag, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popVat_Type, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.txt_Payterms_txt, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.txtRemark, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.dtReq_dlvy_dt, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popBill_to_party, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popTo_Biz_Grp, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popTrans_Meth, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.numPay_dur, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popDoc_cur, enumDef.FieldLockAttribute.Required);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popDeal_Type, enumDef.FieldLockAttribute.Protected);
                    //uniBase.UCommon.ChangeFieldLockAttribute(this.popPay_type, enumDef.FieldLockAttribute.Protected);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popPay_type, enumDef.FieldLockAttribute.Normal);
                    
                    txtCust_po_no.FieldType = enumDef.FieldType.ReadOnly;
                    dtCust_po_dt.FieldType = enumDef.FieldType.ReadOnly;
                    dtSo_dt.FieldType = enumDef.FieldType.NotNull;
                    popPayer.FieldType = enumDef.FieldType.Default;
                    popPay_terms.FieldType = enumDef.FieldType.NotNull;
                    popVat_Inc_Flag.FieldType = enumDef.FieldType.Default;
                    popVat_Type.FieldType = enumDef.FieldType.Default;
                    txt_Payterms_txt.FieldType = enumDef.FieldType.Default;
                    txtRemark.FieldType = enumDef.FieldType.Default;
                    dtReq_dlvy_dt.FieldType = enumDef.FieldType.Default;
                    popBill_to_party.FieldType = enumDef.FieldType.Default;
                    popTo_Biz_Grp.FieldType = enumDef.FieldType.Default;
                    popTrans_Meth.FieldType = enumDef.FieldType.Default;
                    numPay_dur.FieldType = enumDef.FieldType.Default;
                    popDoc_cur.FieldType = enumDef.FieldType.NotNull;
                    popDeal_Type.FieldType = enumDef.FieldType.ReadOnly;
                    //popPay_type.FieldType = enumDef.FieldType.ReadOnly;
                    popPay_type.FieldType = enumDef.FieldType.Nullable;
                }
                else
                {
                    uniBase.UCommon.ChangeFieldLockAttribute(this.txtCust_po_no, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.dtCust_po_dt, enumDef.FieldLockAttribute.Normal);

                    txtCust_po_no.FieldType = enumDef.FieldType.Nullable;
                    dtCust_po_dt.FieldType = enumDef.FieldType.Nullable;

                    uniBase.UCommon.ChangeFieldLockAttribute(this.dtSo_dt, enumDef.FieldLockAttribute.Required);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popPayer, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popPay_terms, enumDef.FieldLockAttribute.Required);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popVat_Inc_Flag, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popVat_Type, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.txt_Payterms_txt, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.txtRemark, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.dtReq_dlvy_dt, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popBill_to_party, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popTo_Biz_Grp, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popTrans_Meth, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.numPay_dur, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popDoc_cur, enumDef.FieldLockAttribute.Required);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popDeal_Type, enumDef.FieldLockAttribute.Required);
                    //uniBase.UCommon.ChangeFieldLockAttribute(this.popPay_type, enumDef.FieldLockAttribute.Protected);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popPay_type, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popLoading_port_Cd, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popDischge_port_Cd, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popPack_cond, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popManufacturer, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popOrigin, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popSending_Bank, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popInspect_meth, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.popAgent, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.txtShip_dt_txt, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.txtDischge_city, enumDef.FieldLockAttribute.Normal);
                    uniBase.UCommon.ChangeFieldLockAttribute(this.dtship_dt, enumDef.FieldLockAttribute.Normal);
                    dtSo_dt.FieldType = enumDef.FieldType.NotNull;
                    popPayer.FieldType = enumDef.FieldType.Default;
                    popPay_terms.FieldType = enumDef.FieldType.NotNull;
                    popVat_Inc_Flag.FieldType = enumDef.FieldType.Default;
                    popVat_Type.FieldType = enumDef.FieldType.Default;
                    txt_Payterms_txt.FieldType = enumDef.FieldType.Default;
                    txtRemark.FieldType = enumDef.FieldType.Default;
                    dtReq_dlvy_dt.FieldType = enumDef.FieldType.Default;
                    popBill_to_party.FieldType = enumDef.FieldType.Default;
                    popTo_Biz_Grp.FieldType = enumDef.FieldType.Default;
                    popTrans_Meth.FieldType = enumDef.FieldType.Default;
                    numPay_dur.FieldType = enumDef.FieldType.Default;
                    popDoc_cur.FieldType = enumDef.FieldType.NotNull;
                    popDeal_Type.FieldType = enumDef.FieldType.NotNull;
                    //popPay_type.FieldType = enumDef.FieldType.ReadOnly;
                    popPay_type.FieldType = enumDef.FieldType.Nullable;
                    dtship_dt.FieldType = enumDef.FieldType.Default;
                    popLoading_port_Cd.FieldType = enumDef.FieldType.Default;
                    popDischge_port_Cd.FieldType = enumDef.FieldType.Default;
                    popPack_cond.FieldType = enumDef.FieldType.Default;
                    popManufacturer.FieldType = enumDef.FieldType.Default;
                    popOrigin.FieldType = enumDef.FieldType.Default;
                    popSending_Bank.FieldType = enumDef.FieldType.Default;
                    popInspect_meth.FieldType = enumDef.FieldType.Default;
                    popAgent.FieldType = enumDef.FieldType.Default;
                    txtShip_dt_txt.FieldType = enumDef.FieldType.Default;
                    txtDischge_city.FieldType = enumDef.FieldType.Default;
                }
            }
        }
        # endregion

        # region SetbtnConfirmButton | tangwei added
        private void SetbtnConfirmButton()
        {
            DataSet iDs = new DataSet();
            string iStrSelectList = "";
            string iStrFromList = "";
            string iStrWhereList = "";

            if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["so_no"] == System.DBNull.Value
                || cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].so_no == "")
            {
                return;
            }

            string istrSoNo = cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].so_no.ToString();
            istrSoNo = uniBase.UCommon.FilterVariable(istrSoNo, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);            

            iStrSelectList = " COUNT(*) ";
            iStrFromList = " S_SO_DTL ";
            iStrWhereList = " SO_NO =  " + istrSoNo;

            iDs = uniBase.UDataAccess.CommonQueryRs(iStrSelectList, iStrFromList, iStrWhereList);
            if (iDs.Tables[0].Rows.Count > 0)
            {
                if (Convert.ToDecimal(iDs.Tables[0].Rows[0][0]) > 0)
                {
                    if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["cfm_flag"].ToString() == "Y")
                    {
                        uniBase.UCommon.DisableButton(this.btnConfirm, false);
                        uniBase.UCommon.DisableButton(this.btnCancel, true);
                    }
                    else
                    {
                        uniBase.UCommon.DisableButton(this.btnConfirm, true);
                        uniBase.UCommon.DisableButton(this.btnCancel, false);
                    }
                }
                else
                {
                    uniBase.UCommon.DisableButton(this.btnConfirm, false);                    
                }
            }

            return;
        }
        # endregion

        # region CurrencyOnChange | tangwei added
        private void CurrencyOnChange()
        {
            if (popDoc_cur.CodeValue.Trim().ToUpper() == CommonVariable.gCurrency.ToUpper())
            {
                numXchg_rate.Value = uniBase.UNumber.FormatNumberByCurrecny(0, popDoc_cur.CodeValue, enumDef.NumericType.ExchangeRate);
                numVat_amt.Value = uniBase.UNumber.FormatNumberByTax(Convert.ToDouble(numVat_amt.Value),popDoc_cur.CodeValue, enumDef.NumericType.AmtOfMoney);
                uniBase.UCommon.ChangeFieldLockAttribute( this.numXchg_rate,enumDef.FieldLockAttribute.Protected );
                this.numXchg_rate.FieldType = enumDef.FieldType.ReadOnly;
            }
            else if (popDoc_cur.CodeValue.Trim().ToUpper() == cstrCur.ToUpper())
            {
                numXchg_rate.Value = uniBase.UNumber.FormatNumberByCurrecny(Convert.ToDouble(numXchg_rate.Value), popDoc_cur.CodeValue, enumDef.NumericType.ExchangeRate);
                numVat_amt.Value = uniBase.UNumber.FormatNumberByTax(Convert.ToDouble(numVat_amt.Value), popDoc_cur.CodeValue, enumDef.NumericType.AmtOfMoney);
                uniBase.UCommon.ChangeFieldLockAttribute(this.numXchg_rate, enumDef.FieldLockAttribute.Required);
                this.numXchg_rate.FieldType = enumDef.FieldType.NotNull;
            }
            else
            {
                numXchg_rate.Value = uniBase.UNumber.FormatNumberByCurrecny(0, popDoc_cur.CodeValue, enumDef.NumericType.ExchangeRate);
                numVat_amt.Value = uniBase.UNumber.FormatNumberByTax(Convert.ToDouble(numVat_amt.Value), popDoc_cur.CodeValue, enumDef.NumericType.AmtOfMoney);
                uniBase.UCommon.ChangeFieldLockAttribute(this.numXchg_rate, enumDef.FieldLockAttribute.Required);
                this.numXchg_rate.FieldType = enumDef.FieldType.NotNull;
            }
            uniBase.UData.ChangeSingleCurrency();
        }
        # endregion

        # region CurrencyOnChangeLock | tangwei add
        private void CurrencyOnChangeLock()
        {
            if (popDoc_cur.CodeValue.Trim().ToUpper() == CommonVariable.gCurrency.ToUpper())
            {                
                uniBase.UCommon.ChangeFieldLockAttribute( this.numXchg_rate,enumDef.FieldLockAttribute.Protected );
                this.numXchg_rate.FieldType = enumDef.FieldType.ReadOnly;
            }
            else
            {                
                uniBase.UCommon.ChangeFieldLockAttribute(this.numXchg_rate, enumDef.FieldLockAttribute.Required);
                this.numXchg_rate.FieldType = enumDef.FieldType.NotNull; 
            }
        }

        # endregion

        # region popVat_Type_OnExitEditCode | tangwei added
        private void popVat_Type_OnExitEditCode(object sender, EventArgs e)
        {
            SetVatType();
        }
        # endregion

        # region SetVatType | tangwei added
        private void SetVatType()
        {
            string istrVatType = this.popVat_Type.CodeValue.Trim();
            string istrVatTypeNm = "";
            string istrVatRate = "";

            DataSet iDs = new DataSet();
            iDs = InitCollectType();
            GetCollectTypeRef(istrVatType, iDs, ref  istrVatTypeNm, ref istrVatRate);
            popVat_Type.CodeName = istrVatTypeNm;
            numVat_rate.Value = istrVatRate;
        }
        # endregion

        # region InitCollectType | tangwei added
        private DataSet InitCollectType()
        {
            DataSet iDs = new DataSet();
            iDs = uniBase.UDataAccess.CommonQueryRs(" Minor.MINOR_CD,  Minor.MINOR_NM, Config.REFERENCE ", 
            " B_MINOR Minor,B_CONFIGURATION Config ",
            " Minor.MAJOR_CD= 'B9001' AND Config.MAJOR_CD = Minor.MAJOR_CD And Config.MINOR_CD = Minor.MINOR_CD And Config.SEQ_NO = 1 ");

            return iDs;
        }
        # endregion 

        # region GetCollectTypeRef | tangwei added
        private void GetCollectTypeRef(string pstrVatType , DataSet pDs, ref string VatTypeNm, ref string VatRate)
        {
            for (int i = 0; i < pDs.Tables[0].Rows.Count; i++)
            {
                if (pDs.Tables[0].Rows[i][0].ToString() == pstrVatType)
                {
                    VatTypeNm = pDs.Tables[0].Rows[i][1].ToString();
                    VatRate = pDs.Tables[0].Rows[i][2].ToString();
                }
            }
        }
        # endregion

        # region checkSoDtlExist | tangwei added
        private bool checkSoDtlExist()
        {
            DataSet iDs = new DataSet();
            string istrSoNo = txtSoNo.Text.Trim();
            istrSoNo = uniBase.UCommon.FilterVariable(istrSoNo,"''",enumDef.FilterVarType.BraceWithSingleQuotation,true);
            iDs = uniBase.UDataAccess.CommonQueryRs(" COUNT(*) ", " S_SO_DTL ", " SO_NO =  " + istrSoNo);
            if (iDs.Tables[0].Rows.Count > 0)
            {
                if (Convert.ToDecimal(iDs.Tables[0].Rows[0][0]) == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        # endregion

        # region SoTypeExpRequiredChg | tangwei added
        private void SoTypeExpRequiredChg()
        {
            uniBase.UCommon.ChangeFieldLockAttribute(this.popBeneficiary,enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.dtContract_dt, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.dtValid_dt, enumDef.FieldLockAttribute.Required);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popIncoTerms, enumDef.FieldLockAttribute.Required);

            popBeneficiary.FieldType = enumDef.FieldType.NotNull;
            dtContract_dt.FieldType = enumDef.FieldType.NotNull;
            dtValid_dt.FieldType = enumDef.FieldType.NotNull;
            popIncoTerms.FieldType = enumDef.FieldType.NotNull;

        }
        # endregion

        # region SoTypeExpDefaultChg | tangwei added
        private void SoTypeExpDefaultChg()
        {
            uniBase.UCommon.ChangeFieldLockAttribute(this.popBeneficiary, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.dtContract_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.dtValid_dt, enumDef.FieldLockAttribute.Normal);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popIncoTerms, enumDef.FieldLockAttribute.Normal);

            popBeneficiary.FieldType = enumDef.FieldType.Default;
            dtContract_dt.FieldType = enumDef.FieldType.Default;
            dtValid_dt.FieldType = enumDef.FieldType.Default;
            popIncoTerms.FieldType = enumDef.FieldType.Default;
        }
        # endregion

        # region SoTypeExpProtectedChg | tangwei added
        private void SoTypeExpProtectedChg()
        {
            uniBase.UCommon.ChangeFieldLockAttribute(this.popBeneficiary, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(this.dtContract_dt, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(this.dtValid_dt, enumDef.FieldLockAttribute.Protected);
            uniBase.UCommon.ChangeFieldLockAttribute(this.popIncoTerms, enumDef.FieldLockAttribute.Protected);

            popBeneficiary.FieldType = enumDef.FieldType.ReadOnly;
            dtContract_dt.FieldType = enumDef.FieldType.ReadOnly;
            dtValid_dt.FieldType = enumDef.FieldType.ReadOnly;
            popIncoTerms.FieldType = enumDef.FieldType.ReadOnly;
        }
        # endregion

        # region LocValidDateCheck | tangwei added
        private void LocValidDateCheck()        
        {
            if (dtReq_dlvy_dt.Value != null)
            {
                if (dtSo_dt.uniValue > dtReq_dlvy_dt.uniValue)
                {
                    string [] strMsg = {dtReq_dlvy_dt.uniALT,dtCust_po_dt.uniALT};
                    uniBase.UMessage.DisplayMessageBox("970022", MessageBoxButtons.OK, strMsg);
                    tab1.SelectedTab = tab1.Tabs[0];
                    dtSo_dt.Focus();
                }
            }

            if (dtCust_po_dt.Value != null && dtReq_dlvy_dt.Value != null)
            {
                if (dtCust_po_dt.uniValue > dtReq_dlvy_dt.uniValue)
                {
                    string[] strMsg = { dtReq_dlvy_dt.uniALT, dtCust_po_dt.uniALT };
                    uniBase.UMessage.DisplayMessageBox("970022", MessageBoxButtons.OK, strMsg);
                    tab1.SelectedTab = tab1.Tabs[0];
                    dtCust_po_dt.Focus();
                }
            }
        }
        # endregion

        # region dtSo_dt_ValueChanged
        private void dtSo_dt_ValueChanged(object sender, EventArgs e)
        {
            if (dtSo_dt.Value != null)
            {
                if (cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows.Count > 0 &&
                    cqtdsSLookupSoHdrSvr.ES_SO_HDR.Rows[0]["so_dt"] != System.DBNull.Value &&
                    Convert.ToDateTime(dtSo_dt.Value) != cqtdsSLookupSoHdrSvr.ES_SO_HDR[0].so_dt &&
                    dtSo_dt.IsInEditMode)
                {
                 //   dtReq_dlvy_dt.Value = Convert.ToDateTime(dtSo_dt.Value).AddDays(GetDBDouble(cstrDlvyLt));
                }
            }
        }
        # endregion                    

        # region popSo_Type_OnExitEditCode
        private void popSo_Type_OnExitEditCode(object sender, EventArgs e)
        {
            cstrSoTypeExportFlag = "";
            cstrSoTypeRetItemFlag = "";
            cstrSoTypeCiFlag = "";

            DataSet iDs = new DataSet();
            DataTable iDt = new DataTable();
            iDs.Tables.Add(iDt);
            iDt.Columns.Add("so_type");
            DataRow iRow = iDt.NewRow();
            iDt.Rows.Add(iRow);
            iDt.Rows[0]["so_type"] = popSo_Type.CodeValue.Trim();

            if (popSo_Type.CodeValue.Trim().Length > 0)
            {
                SubSoTypeExp(iDs);
            }
        }
        # endregion

        # region fncSoTypeExpChange
        private void fncSoTypeExpChange()
        {
            if ((cstrRetItemFlag.ToUpper() != cstrSoTypeRetItemFlag.ToUpper())
               && !checkSoDtlExist())
            {
                uniBase.UMessage.DisplayMessageBox("203244", MessageBoxButtons.OK, "");
                return;
            }

            if (rdoCfm_flag.CheckedIndex == 0)
            {
                //popBeneficiary
                uniBase.UCommon.ChangeFieldLockAttribute(popBeneficiary,enumDef.FieldLockAttribute.Protected);
                popBeneficiary.FieldType = enumDef.FieldType.ReadOnly;
                //dtContract_dt
                uniBase.UCommon.ChangeFieldLockAttribute(dtContract_dt, enumDef.FieldLockAttribute.Protected);
                dtContract_dt.FieldType = enumDef.FieldType.ReadOnly;
                //dtValid_dt
                uniBase.UCommon.ChangeFieldLockAttribute(dtValid_dt, enumDef.FieldLockAttribute.Protected);
                dtValid_dt.FieldType = enumDef.FieldType.ReadOnly;
                //popIncoTerms
                uniBase.UCommon.ChangeFieldLockAttribute(popIncoTerms, enumDef.FieldLockAttribute.Protected);
                popIncoTerms.FieldType = enumDef.FieldType.ReadOnly;

                return;
            }

            if (cstrSoTypeExportFlag.ToUpper() == "Y" || cstrSoTypeCiFlag.ToUpper() == "Y")
            {
                SoTypeExpRequiredChg();
            }
            else
            {
                SoTypeExpDefaultChg();
            }
            if (viewDBSaveMode != enumDef.DBSaveMode.UpdateMode 
                && Convert.ToDateTime(dtSo_dt.uniValue) >= Convert.ToDateTime(CommonVariable.gMinimumDate)
                && Convert.ToDateTime(dtSo_dt.uniValue) <= Convert.ToDateTime(CommonVariable.gMaximumDate))
            {
                if (cstrDlvyLt != "0")               
                {
                    dtReq_dlvy_dt.Value = dtSo_dt.uniValue.AddDays(Convert.ToDouble(cstrDlvyLt));
                }
            }
            return;
        }
        # endregion

        # region popDoc_cur_OnChange
        private void popDoc_cur_OnExitEditCode(object sender, EventArgs e)
        {
            CurrencyOnChange();
        }
        # endregion

        # region GetVATIncludNM
        private string GetVATIncludNM(string pVat_include_flag)
        {
            string iRet = string.Empty;
            DataSet ids = new DataSet();
            string istrSQL = "SELECT MINOR_CD , MINOR_NM FROM B_MINOR WHERE MAJOR_CD = 'S0029' AND MINOR_CD = " +uniBase.UCommon.FilterVariable
                ( pVat_include_flag, "''", enumDef.FilterVarType.BraceWithSingleQuotation,true);
            ids = uniBase.UDataAccess.CommonQuerySQL(istrSQL);
            if (ids != null && ids.Tables[0].Rows.Count > 0)
            {
                iRet = ids.Tables[0].Rows[0]["MINOR_NM"].ToString();
            }

            return iRet;
        }
        # endregion

        # region GetDBValue
        public string GetDBValue(object obj)
        {
            if (IsNull_DBNull_Empty(obj))
            {
                return "";
            }
            else { return obj.ToString().Trim(); }
        }
        # endregion

        # region GetDBDecimal
        public decimal GetDBDecimal(object obj)
        {
            if (IsNull_DBNull_Empty(obj))
            {
                return 0;
            }
            else
            {
                decimal backValue = 0;
                decimal.TryParse(obj.ToString().Trim(), out backValue);
                return backValue;
            }
        }
        # endregion

        # region GetDBDouble
        public double GetDBDouble(object obj)
        {
            if (IsNull_DBNull_Empty(obj))
            {
                return 0;
            }
            else
            {
                double backValue = 0;
                double.TryParse(obj.ToString().Trim(), out backValue);
                return backValue;
            }
        }
        # endregion

        # region IsNull_DBNull_Empty
        public bool IsNull_DBNull_Empty(object obj)
        {
            if (obj == null || obj == DBNull.Value || obj.ToString().Trim() == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        # endregion

        private bool chkMultiCompany()
        {
            string strSQL = string.Format(@"Select Isnull(SH.INTERCOM_FLG,'N') INTERCOM_FLG From S_SO_HDR SH (Nolock) Where SH.SO_NO = {0}"
                , uniBase.UCommon.FilterVariable(popConSo_no.CodeValue.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));

            DataSet dsSQL = uniBase.UDataAccess.CommonQuerySQL(strSQL);

            if (dsSQL.Tables[0].Rows.Count > 0)
            {
                if (dsSQL.Tables[0].Rows[0]["INTERCOM_FLG"].ToString().ToUpper() == "Y")
                {
                    return false;
                }
            }
            return true;
        }

        private void popCurr_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "PIT통화";
            e.PopupPassData.ConditionCaption = "PIT통화";

            e.PopupPassData.SQLFromStatements = "B_Currency";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.SQLWhereInputCodeValue = popCurr.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "Currency";
            e.PopupPassData.GridCellCode[1] = "Currency_Desc";

            e.PopupPassData.GridCellCaption[0] = "PIT통화";
            e.PopupPassData.GridCellCaption[1] = "PIT통화명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popCurr_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popCurr.CodeValue = iDataSet.Tables[0].Rows[0]["Currency"].ToString();
            popCurr.CodeName = iDataSet.Tables[0].Rows[0]["Currency_Desc"].ToString();


        }

        public Control popSo_Nm { get; set; }
    }
} 
