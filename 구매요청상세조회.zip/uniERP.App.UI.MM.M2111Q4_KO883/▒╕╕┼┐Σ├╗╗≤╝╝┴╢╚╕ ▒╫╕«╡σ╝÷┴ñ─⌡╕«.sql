--select * from z_ado_field_inf_net where PGM_ID = 'M2111QA4_KO883'


--insert into z_ado_field_inf_net
--(PGM_ID,TYPE_CD,SPD_NO,SEQ_NO,FIELD_CD,FIELD_NM,FIELD_LEN,FIELD_TYPE,DEFAULT_T,NEXT_SEQ,KEY_TAG,INSRT_UID,INSRT_DT,UPDT_UID,UPDT_DT,EXT1,EXT2,EXT3,FIELD_ALIAS)
--values
--(
--'M2111QA4_KO883',
--'S',
--'A',
--43,
--'isnull(X.RECV_INSPEC_FLG,''N'')',
--'Flag',
--2,
--'ED',
--'43',
--0,
--42,
--'ckskagns',
--GETDATE(),
--'ckskagns',
--GETDATE(),
--NULL,
--NULL,
--NULL,
--'Flag'
--)

update z_ado_field_inf_net
set
--SEQ_NO = 9,
--KEY_TAG = 10,
--DEFAULT_T = 10
FIELD_LEN = 10
where
PGM_ID = 'M2111QA4_KO883' and FIELD_CD = 'isnull(X.RECV_INSPEC_FLG,''N'')'

A.DLVY_DT

update z_ado_field_inf_net
set
SEQ_NO = 43,
KEY_TAG = 42,
DEFAULT_T = 43
where
PGM_ID = 'M2111QA4_KO883' and FIELD_CD = 'A.DLVY_DT'
