﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Controls.Popup;

#endregion

namespace uniERP.App.UI.MM.M2111Q4_KO883
{

    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①uniERP.App.UI.MM.M2111Q4_KO883</NameSpace>
        /// <Module>②MM</Module>
        /// <Class>③class name</Class>
        /// <Desc>④
        ///   구매요청 상세를 조회한다. 
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="LYK" Date="2018-06-07">구매요청상세조회(S)(M2111QA4_KO293)…</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        enum IntWhere
        {
            C_PopSoldToParty,
            C_PopSalesGrp,
            C_PopBillType,
            C_PopSoNo
        }

        #endregion

        #region ■ 1.3. Class global variables (common)

        #endregion

        #region ■ 1.4 Class global constants (grid)

        #endregion

        #region ■ 1.5 Class global variables (grid)

        // change your code
        //private wsMyBizFL.TypedDataSet dsAnyName = new wsMyBizFL.TypedDataSet();
        //private DataSet cqdsBilingQuery = null;

        tdsM2111QA4 cqtdsM2111QA4 = new tdsM2111QA4();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(cqtdsM2111QA4);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T04_MultiMulti | enumDef.ViewType.T90_ZAdo);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Query, enumDef.ModuleInformation.Purchase);  // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format

        }

        protected override void Form_Load_Completed()
        {
            this.popPlantCd.Focus();
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            // init Dataset Row : change your code
            //dsAnyName.Clear();
        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            DateTime idttoay = uniBase.UDate.GetDBServerDateTime();

            dtPdFrDt.uniFromValue = idttoay.AddMonths(-1); ;
            dtPdFrDt.uniToValue = idttoay.AddMonths(1);

            dtPrFrDt.uniFromValue = idttoay.AddMonths(-1); ;
            dtPrFrDt.uniToValue = idttoay.AddMonths(1);
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            uniBase.UData.ComboMajorAdd(cboEXT6_CD_KO883.Name, "XPR01");
            uniBase.UData.ComboMajorAdd(cboEcnFlag.Name, "SM003");
        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {
            base.viewTB19029.ggUserDefined6.DecPoint = 6;
            base.viewTB19029.ggUserDefined6.Integeral = 15;

            base.viewTB19029.ggUserDefined7.DecPoint = 3;
            base.viewTB19029.ggUserDefined7.Integeral = 15;
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            uniBase.UZAdo.InitialZAdoGrid("M2111QA4_KO883", enumDef.ZAdoOrderByOrGroupByType.OrderBy, enumDef.ZAdoGridNo.GridA, uniGrid1);   // S :enumDef.ZAdoOrderByOrGroupByType.OrderBy , "Supplier",135, enumDef.FieldType.ReadOnly,enumDef.CharCase.Default, false,enumDef.HAlign.Left,int.MaxValue);

            tdsM2111QA4.E_M_PR_QUOTA_BY_SPPLDataTable uniGridTB1 = cqtdsM2111QA4.E_M_PR_QUOTA_BY_SPPL;
            uniGrid2.SSSetEdit(uniGridTB1.pr_noColumn.ColumnName, "PR_NO", 180, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);
            uniGrid2.SSSetEdit(uniGridTB1.bp_nmColumn.ColumnName, "Supplier Name", 180, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            uniGrid2.SSSetFloat(uniGridTB1.quota_rateColumn.ColumnName, "Dist.(%)", 135, viewTB19029.ggExchRate, enumDef.FieldType.ReadOnly, enumDef.HAlign.Right, true, enumDef.PosZero.nonNegative, int.MinValue, int.MaxValue);
            uniGrid2.SSSetFloat(uniGridTB1.apportion_qtyColumn.ColumnName, "Apportion Quantity", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly, enumDef.HAlign.Right, true, enumDef.PosZero.nonNegative, int.MinValue, int.MaxValue);
            uniGrid2.SSSetDate(uniGridTB1.pur_plan_dtColumn.ColumnName, "P/O Sch. Date", 135, enumDef.FieldType.ReadOnly, CommonVariable.gDateFormat, enumDef.HAlign.Center);
            uniGrid2.SSSetEdit(uniGridTB1.pur_grpColumn.ColumnName, "Purchase Group", 90, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            uniGrid2.SSSetEdit(uniGridTB1.pur_grp_nmColumn.ColumnName, "Purchase Group Name", 180, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);

            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid2.InitializeGrid(enumDef.IsOutlookGroupBy.Yes, enumDef.IsSearch.Yes);

            #endregion

            #region ■■ 3.1.3 Setting etc grid
            this.uniGrid2.SSSetColHidden(uniGridTB1.pr_noColumn.ColumnName);

            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
        }
        #endregion

        #region ■ 3.4 InitControlBinding

        protected override void InitControlBinding()
        {
            InitSpreadSheet();
            uniGrid2.uniGridSetDataBinding(cqtdsM2111QA4.E_M_PR_QUOTA_BY_SPPL);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //TO-DO : code business oriented logic
            return DBQuery();
        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)

        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic

            return DBSave();
        }

        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            //TO-DO : code business oriented logic


            if (dtPdFrDt.uniDateTimeF.Value != null && dtPdFrDt.uniDateTimeT.Value != null)
            {
                if (!uniBase.UDate.CompareDateBetween(this.dtPdFrDt.uniDateTimeF, dtPdFrDt.uniDateTimeT))
                {
                    uniBase.UMessage.DisplayMessageBox("17a003", MessageBoxButtons.OK, dtPdFrDt.uniDateTimeF.uniALT);
                    dtPdFrDt.Focus();
                    return false;
                }
            }


            if (dtPrFrDt.uniDateTimeF.Value != null && dtPrFrDt.uniDateTimeT.Value != null)
            {
                if (!uniBase.UDate.CompareDateBetween(this.dtPrFrDt.uniDateTimeF, dtPrFrDt.uniDateTimeT))
                {
                    uniBase.UMessage.DisplayMessageBox("17a003", MessageBoxButtons.OK, dtPrFrDt.uniDateTimeF.uniALT);
                    dtPrFrDt.Focus();
                    return false;
                }
            }

            string CLS_FG_Y = rdoClsFlg.Value.ToString();
            string CLS_FG_N = rdoClsFlg.Value.ToString();

            string[] UNISqlId = new string[] { "M2111QA401_KO883" };
            string[][] UNIValue = new string[1][];
            UNIValue[0] = new string[24];

            UNIValue[0][0] = uniBase.UZAdo.GetSQLSelectList(enumDef.ZAdoGridNo.GridA);

            UNIValue[0][1] = uniBase.UCommon.FilterVariable(CommonVariable.gChangeOrgId, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);

            UNIValue[0][2] = uniBase.UCommon.FilterVariable(popPlantCd.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][3] = uniBase.UCommon.FilterVariable(popPlantCd.CodeValue.Trim(), uniBase.UString.GetLargestStringValue(popPlantCd.CodeMaxLength, true), enumDef.FilterVarType.BraceWithSingleQuotation, true);

            UNIValue[0][4] = uniBase.UCommon.FilterVariable(popItemCd.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][5] = uniBase.UCommon.FilterVariable(popItemCd.CodeValue.Trim(), uniBase.UString.GetLargestStringValue(popItemCd.CodeMaxLength, true), enumDef.FilterVarType.BraceWithSingleQuotation, true);

            UNIValue[0][6] = uniBase.UDate.DateTimeToString(dtPrFrDt.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD, true);
            UNIValue[0][7] = uniBase.UDate.DateTimeToString(dtPrFrDt.uniDateTimeT, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD, true);
            UNIValue[0][8] = uniBase.UDate.DateTimeToString(dtPdFrDt.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD, true);
            UNIValue[0][9] = uniBase.UDate.DateTimeToString(dtPdFrDt.uniDateTimeT, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD, true);

            UNIValue[0][10] = uniBase.UCommon.FilterVariable(popPrStsCd.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][11] = uniBase.UCommon.FilterVariable(popPrStsCd.CodeValue.Trim(), uniBase.UString.GetLargestStringValue(popPrStsCd.CodeMaxLength, true), enumDef.FilterVarType.BraceWithSingleQuotation, true);

            UNIValue[0][12] = uniBase.UCommon.FilterVariable(popRqDeptCd.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][13] = uniBase.UCommon.FilterVariable(popRqDeptCd.CodeValue.Trim(), uniBase.UString.GetLargestStringValue(popRqDeptCd.CodeMaxLength, true), enumDef.FilterVarType.BraceWithSingleQuotation, true);

            UNIValue[0][14] = uniBase.UCommon.FilterVariable(popPrType.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][15] = uniBase.UCommon.FilterVariable(popPrType.CodeValue.Trim(), uniBase.UString.GetLargestStringValue(popPrType.CodeMaxLength, true), enumDef.FilterVarType.BraceWithSingleQuotation, true);

            //UNIValue[0][16] = string.IsNullOrEmpty(this.popTrackNo.CodeValue.Trim()) ? " A.TRACKING_NO " : uniBase.UCommon.FilterVariable(popTrackNo.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);

            UNIValue[0][16] = "and a.TRACKING_NO like '" + this.popTrackNo.CodeValue.Trim() + "%'";
            UNIValue[0][17] = "and a.ext3_cd like '%" + this.popPxNo.CodeValue.Trim() + "%'";
            UNIValue[0][18] = "and a.req_prsn like '%" + this.popReqPrsn.CodeValue.Trim() + "%'";
            UNIValue[0][19] = "and a.pr_no like '%" + this.txtPrNo.Text.Trim() + "%'";
            if(rdoClsFlg.Value.ToString() == "A")
            {
                CLS_FG_Y = "Y";
                CLS_FG_N = "N";
            }
            else if(rdoClsFlg.Value.ToString() == "Y")
            {
                CLS_FG_Y = "Y";
                CLS_FG_N = "Y";
            }
            else
            {
                CLS_FG_Y = "N";
                CLS_FG_N = "N";
            }
            UNIValue[0][20] = "and (ISNULL(a.cls_flg,'N') ='" + CLS_FG_N + "' OR ISNULL(a.cls_flg,'N') ='" + CLS_FG_Y + "')";
            UNIValue[0][21] = " AND	 (ISNULL('" + cboEXT6_CD_KO883.Value.ToString() + "','') = '' OR ISNULL(A.ext6_cd_ko883,'') = '" + cboEXT6_CD_KO883.Value.ToString() + "')	";
            UNIValue[0][22] = " AND	 (ISNULL('" + cboEcnFlag.Value.ToString() + "','') = '' OR ISNULL(L.APPROVAL_RTN,'') = '" + cboEcnFlag.Value.ToString() + "')	";

            UNIValue[0][23] = uniBase.UZAdo.GetSQLGroupOrderByList(enumDef.ZAdoGridNo.GridA);

            DataSet pDataSet = null;

            try
            {
                pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return true;
                }

            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }

            // DBQuery OK 
            uniGrid1.uniGridSetDataBinding(pDataSet.Tables[0]);
            return true;
        }

        // Modify Input Parameters
        private bool DBQuery2(string ConditionKey)
        {
            cqtdsM2111QA4.E_M_PR_QUOTA_BY_SPPL.Clear();

            if (dtPdFrDt.uniDateTimeF.Value != null && dtPdFrDt.uniDateTimeT.Value != null)
            {
                if (!uniBase.UDate.CompareDateBetween(this.dtPdFrDt.uniDateTimeF, dtPdFrDt.uniDateTimeT))
                {
                    uniBase.UMessage.DisplayMessageBox("17a003", MessageBoxButtons.OK, dtPdFrDt.uniDateTimeF.uniALT);
                    dtPdFrDt.Focus();
                    return false;
                }
            }


            if (dtPrFrDt.uniDateTimeF.Value != null && dtPrFrDt.uniDateTimeT.Value != null)
            {
                if (!uniBase.UDate.CompareDateBetween(this.dtPrFrDt.uniDateTimeF, dtPrFrDt.uniDateTimeT))
                {
                    uniBase.UMessage.DisplayMessageBox("17a003", MessageBoxButtons.OK, dtPrFrDt.uniDateTimeF.uniALT);
                    dtPrFrDt.Focus();
                    return false;
                }
            }

            DataSet iqtdsM2111QA4 = null;

            string[] UNISqlId = new string[] { "m2111ma201" };
            string[][] UNIValue = new string[1][];

            UNIValue[0] = new string[1];

            UNIValue[0][0] = ConditionKey;

            try
            {
                iqtdsM2111QA4 = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (iqtdsM2111QA4 == null || iqtdsM2111QA4.Tables[0].Rows.Count == 0)
                {
                    uniGrid2.clearSpreadData();
                }

            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }

            // DBQuery OK 
            uniBase.UData.MergeDataTable(cqtdsM2111QA4.E_M_PR_QUOTA_BY_SPPL, iqtdsM2111QA4.Tables[0]);
            return true;
        }
        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            //TO-DO : code business oriented logic

            return true;

        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        #region ■■ 5.2.1 ButtonClicked >>> ClickCellButton

        #endregion ■■ ButtonClicked >>> ClickCellButton

        #region ■■ 5.2.2 Change >>> CellChange

        #endregion ■■ Change >>> CellChange

        #region ■■ 5.2.3 Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        private void uniGrid1_AfterRowActive(object sender, EventArgs e)
        {
            if (uniGrid1.Rows.Count != 0)
            {
                if (uniGrid1.ActiveRow.Cells != null)
                {
                    string strPr_No = uniBase.UCommon.FilterVariable(uniGrid1.Rows[uniGrid1.ActiveRow.Index].Cells["pr_no"].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);

                    this.DBQuery2(strPr_No);
                }
            }
        }
        #endregion ■■ Click >>> AfterSelectChange

        #region ■■ 5.2.4 ComboSelChange >>> CellListSelect
        #endregion ■■ ComboSelChange >>> CellListSelect

        #region ■■ 5.2.5 DblClick >>> DoubleClickCell

        #endregion ■■ DblClick >>> DoubleClickCell

        #region ■■ 5.2.6 MouseDown >>> MouseDown

        #endregion ■■ MouseDown >>> MouseDown

        #region ■■ 5.2.7 ScriptLeaveCell >>> BeforeCellDeactivate

        #endregion ■■ ScriptLeaveCell >>> BeforeCellDeactivate

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        #endregion

        #endregion

        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        #endregion

        #endregion

        private void popPlantCd_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {

            e.PopupPassData.PopupWinTitle = "Plant";
            e.PopupPassData.ConditionCaption = "Plant";

            e.PopupPassData.SQLFromStatements = "B_Plant(NOLOCK)";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.SQLWhereInputCodeValue = popPlantCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "Plant_Cd";
            e.PopupPassData.GridCellCode[1] = "Plant_NM";

            e.PopupPassData.GridCellCaption[0] = "Plant";
            e.PopupPassData.GridCellCaption[1] = "Plant Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;


        }

        private void popPlantCd_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPlantCd.CodeValue = iDataSet.Tables[0].Rows[0]["Plant_Cd"].ToString();
            popPlantCd.CodeName = iDataSet.Tables[0].Rows[0]["Plant_NM"].ToString();

        }

        private void popPrStsCd_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {

            e.PopupPassData.PopupWinTitle = "P/R Status";
            e.PopupPassData.ConditionCaption = "P/R Status";

            e.PopupPassData.SQLFromStatements = "B_MINOR(NOLOCK)";
            e.PopupPassData.SQLWhereStatements = "  MAJOR_CD = 'M2101'";
            e.PopupPassData.SQLWhereInputCodeValue = popPrStsCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "P/R Status";
            e.PopupPassData.GridCellCaption[1] = "P/R Status Description";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;


        }

        private void popPrStsCd_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPrStsCd.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popPrStsCd.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();

        }

        private void popPrType_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {

            e.PopupPassData.PopupWinTitle = "P/R Type";
            e.PopupPassData.ConditionCaption = "P/R Type";

            e.PopupPassData.SQLFromStatements = "B_MINOR(NOLOCK)";
            e.PopupPassData.SQLWhereStatements = "  MAJOR_CD = 'M2102'";
            e.PopupPassData.SQLWhereInputCodeValue = popPrType.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "P/R Type";
            e.PopupPassData.GridCellCaption[1] = "P/R Type Description";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;


        }

        private void popPrType_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPrType.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popPrType.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();

        }

        private void popRqDeptCd_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {

            e.PopupPassData.PopupWinTitle = "P/R Dept.";
            e.PopupPassData.ConditionCaption = "P/R Dept.";

            e.PopupPassData.SQLFromStatements = "B_ACCT_DEPT(NOLOCK)";
            e.PopupPassData.SQLWhereStatements = " ORG_CHANGE_ID= '" + CommonVariable.gChangeOrgId + "'";
            e.PopupPassData.SQLWhereInputCodeValue = popRqDeptCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "DEPT_CD";
            e.PopupPassData.GridCellCode[1] = "DEPT_NM";

            e.PopupPassData.GridCellCaption[0] = "P/R Dept.";
            e.PopupPassData.GridCellCaption[1] = "P/R Dept. Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;


        }

        private void popRqDeptCd_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popRqDeptCd.CodeValue = iDataSet.Tables[0].Rows[0]["DEPT_CD"].ToString();
            popRqDeptCd.CodeName = iDataSet.Tables[0].Rows[0]["DEPT_NM"].ToString();

        }


        private void popItemCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (popPlantCd.CodeValue.Trim() == "")
            {
                uniBase.UMessage.DisplayMessageBox("17A002", MessageBoxButtons.OK, popPlantCd.uniALT);
                popPlantCd.Focus();
                e.Cancel = true;
                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.B1B11PA3";
            e.PopupPassData.PopupWinTitle = "Item by Plant Popup";
            e.PopupPassData.PopupWinWidth = 871;
            e.PopupPassData.PopupWinHeight = 680;

            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            dt.Columns.Add("PlantCd");
            dt.Columns.Add("ItemCd");
            dt.Columns.Add("Param3");
            dt.Columns.Add("Param4");
            dt.Columns.Add("Param5");
            dt.Columns.Add("Param6");

            DataRow dr = dt.NewRow();
            if (this.popPlantCd.CodeValue.Trim().Length > 0)
            {
                dr["PlantCd"] = this.popPlantCd.CodeValue.Trim();
            }
            else
            {
                dr["PlantCd"] = "";
            }
            if (this.popItemCd.CodeValue.Trim().Length > 0)
            {
                dr["ItemCd"] = this.popItemCd.CodeValue.Trim();
            }
            else
            {
                dr["ItemCd"] = "";
            }

            dr["Param3"] = "!";
            dr["Param4"] = ""; //원자재(30)로 Default되어 있는 사항 변경 (2014-10-30 EJW)
            dr["Param5"] = "";
            dr["Param6"] = "";

            dt.Rows.Add(dr);
            ds.Tables.Add(dt);

            e.PopupPassData.Data = ds;
        }

        private void popItemCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            this.popItemCd.CodeValue = iDataSet.Tables[0].Rows[0]["ITEM_CD"].ToString();
            this.popItemCd.CodeName = iDataSet.Tables[0].Rows[0]["ITEM_NM"].ToString();
        }


        private void popTrackNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.S3135PA1";
            e.PopupPassData.PopupWinTitle = "Tracking No.";
            e.PopupPassData.PopupWinWidth = 780;
            e.PopupPassData.PopupWinHeight = 768;

            string[] appParam = new string[6];
            appParam[0] = "";
            appParam[1] = "";
            appParam[2] = popPlantCd.CodeValue.Trim();
            appParam[3] = "";
            appParam[4] = "";
            appParam[5] = "";

            e.PopupPassData.Data = appParam;
        }

        private void popTrackNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            this.popTrackNo.CodeValue = iDataSet.Tables[0].Rows[0]["tracking_no"].ToString();

        }

        private void popReqPrsn_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "요청자 Popup";
            e.PopupPassData.ConditionCaption = "요청자";

            //e.PopupPassData.SQLFromStatements = "HAA010T(NOLOCK)";


            e.PopupPassData.SQLFromStatements = "HAA010T(NOLOCK), B_ACCT_DEPT(NOLOCK)";
            e.PopupPassData.SQLWhereStatements = string.Format("HAA010T.DEPT_CD = B_ACCT_DEPT.DEPT_CD AND B_ACCT_DEPT.ORG_CHANGE_ID = (SELECT MAX(ORG_CHANGE_ID) FROM B_ACCT_DEPT)");
            e.PopupPassData.SQLWhereInputCodeValue = ""; // popEmp_No.CodeValue.ToString();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[4];
            e.PopupPassData.GridCellCaption = new String[4];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[4];
            e.PopupPassData.GridCellLength = new int[4];

            e.PopupPassData.GridCellCode[0] = "EMP_NO";
            e.PopupPassData.GridCellCode[1] = "NAME";
            e.PopupPassData.GridCellCode[2] = "HAA010T.DEPT_CD";
            e.PopupPassData.GridCellCode[3] = "B_ACCT_DEPT.DEPT_NM";

            e.PopupPassData.GridCellCaption[0] = "사번";
            e.PopupPassData.GridCellCaption[1] = "이름";
            e.PopupPassData.GridCellCaption[2] = "부서코드";
            e.PopupPassData.GridCellCaption[3] = "부서명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;


            e.PopupPassData.GridCellLength[0] = 150;
            e.PopupPassData.GridCellLength[1] = 150;
            e.PopupPassData.GridCellLength[2] = 150;
            e.PopupPassData.GridCellLength[3] = 150;
        }

        private void popReqPrsn_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;
            iDataSet = (DataSet)e.ResultData.Data;
            popReqPrsn.CodeValue = iDataSet.Tables[0].Rows[0][0].ToString();
            popReqPrsn.CodeName = iDataSet.Tables[0].Rows[0][1].ToString();
        }

        private void popPxNo_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            string[] sParam = new string[2];

            sParam[0] = txtPrNo.Text;
            sParam[1] = popReqPrsn.CodeName.ToString().Trim();

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.M2111P1_KO883";
            e.PopupPassData.PopupWinTitle = "구매의뢰번호";
            e.PopupPassData.PopupWinWidth = 871;
            e.PopupPassData.PopupWinHeight = 680;

            e.PopupPassData.Data = sParam;
        }

        private void popPxNo_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            if (iDataSet.Tables[0].Rows[0]["pr_req_no"].ToString() != "" || iDataSet.Tables[0].Rows[0]["pr_req_no"].ToString() != null)
            {
                popPxNo.CodeValue = iDataSet.Tables[0].Rows[0]["pr_req_no"].ToString();
            }
        }
    }
}