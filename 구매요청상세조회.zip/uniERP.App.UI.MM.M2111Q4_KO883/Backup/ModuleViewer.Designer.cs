﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.MM.M2111Q4_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance206 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance207 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance208 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance209 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance210 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance211 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance212 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance213 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance214 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance215 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance216 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance217 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance218 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance219 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance220 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance221 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance222 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance223 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance224 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance225 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance226 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance227 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance228 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance191 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance192 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance193 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance194 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance195 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance196 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance197 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance198 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance199 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance200 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance201 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem16 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem17 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem18 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance202 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance203 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance204 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance205 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniGrid2 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblPurchaseRequisition = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.cboEXT6_CD_KO883 = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.lblPlantCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPrFrDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPrStsCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPrType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblItemCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblPdFrDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblRqDeptCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblTrackNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtPrFrDt = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.dtPdFrDt = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.popPlantCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popPrStsCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popPrType = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popItemCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popRqDeptCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popTrackNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblPxNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblReqPrsn = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popReqPrsn = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popPxNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblPrNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.rdoClsFlg = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.lblClsFlg = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtPrNo = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblChgType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblApprvStatus = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.cboEcnFlag = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).BeginInit();
            this.uniTBL_MainBatch.SuspendLayout();
            this.uniTBL_MainCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboEXT6_CD_KO883)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoClsFlg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboEcnFlag)).BeginInit();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.ConditionRowCount = 4;
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 177F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(979, 740);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.uniGrid2, 0, 1);
            this.uniTBL_MainData.DefaultRowSize = 25;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 212);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 2;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70.1107F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 29.8893F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(979, 496);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 1;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance206.BackColor = System.Drawing.SystemColors.Window;
            appearance206.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance206;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance207.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance207.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance207.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance207.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance207;
            appearance208.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance208;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance209.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance209.BackColor2 = System.Drawing.SystemColors.Control;
            appearance209.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance209.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance209;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance210.BackColor = System.Drawing.SystemColors.Window;
            appearance210.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance210;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance211.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance211;
            appearance212.BorderColor = System.Drawing.Color.Silver;
            appearance212.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance212;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance213.BackColor = System.Drawing.SystemColors.Control;
            appearance213.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance213.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance213.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance213.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance213;
            appearance214.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance214;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance215.BackColor = System.Drawing.SystemColors.Window;
            appearance215.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance215;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance216.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance216;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0, 0, 0, 9);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(979, 338);
            this.uniGrid1.StyleSetName = "Default";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.AfterRowActivate += new System.EventHandler(this.uniGrid1_AfterRowActive);
            // 
            // uniGrid2
            // 
            this.uniGrid2.AddEmptyRow = false;
            this.uniGrid2.DirectPaste = false;
            appearance217.BackColor = System.Drawing.SystemColors.Window;
            appearance217.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid2.DisplayLayout.Appearance = appearance217;
            this.uniGrid2.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid2.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance218.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance218.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance218.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance218.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.GroupByBox.Appearance = appearance218;
            appearance219.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.BandLabelAppearance = appearance219;
            this.uniGrid2.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance220.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance220.BackColor2 = System.Drawing.SystemColors.Control;
            appearance220.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance220.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.PromptAppearance = appearance220;
            this.uniGrid2.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid2.DisplayLayout.MaxRowScrollRegions = 1;
            appearance221.BackColor = System.Drawing.SystemColors.Window;
            appearance221.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid2.DisplayLayout.Override.ActiveCellAppearance = appearance221;
            this.uniGrid2.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid2.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid2.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance222.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.CardAreaAppearance = appearance222;
            appearance223.BorderColor = System.Drawing.Color.Silver;
            appearance223.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid2.DisplayLayout.Override.CellAppearance = appearance223;
            this.uniGrid2.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid2.DisplayLayout.Override.CellPadding = 0;
            appearance224.BackColor = System.Drawing.SystemColors.Control;
            appearance224.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance224.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance224.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance224.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.GroupByRowAppearance = appearance224;
            appearance225.TextHAlignAsString = "Left";
            this.uniGrid2.DisplayLayout.Override.HeaderAppearance = appearance225;
            this.uniGrid2.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid2.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance226.BackColor = System.Drawing.SystemColors.Window;
            appearance226.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid2.DisplayLayout.Override.RowAppearance = appearance226;
            this.uniGrid2.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance227.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid2.DisplayLayout.Override.TemplateAddRowAppearance = appearance227;
            this.uniGrid2.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid2.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid2.EnableContextMenu = true;
            this.uniGrid2.EnableGridInfoContextMenu = true;
            this.uniGrid2.ExceptInExcel = false;
            this.uniGrid2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid2.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid2.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.ClearDetail;
            this.uniGrid2.Location = new System.Drawing.Point(0, 347);
            this.uniGrid2.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid2.Name = "uniGrid2";
            this.uniGrid2.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid2.PopupDeleteMenuVisible = true;
            this.uniGrid2.PopupInsertMenuVisible = true;
            this.uniGrid2.PopupUndoMenuVisible = true;
            this.uniGrid2.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid2.ShowHeaderCheck = true;
            this.uniGrid2.Size = new System.Drawing.Size(979, 149);
            this.uniGrid2.StyleSetName = "Default";
            this.uniGrid2.TabIndex = 1;
            this.uniGrid2.Text = "uniGrid2";
            this.uniGrid2.UseDynamicFormat = false;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.DefaultRowSize = 25;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(979, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 5;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.Controls.Add(this.lblPurchaseRequisition, 3, 0);
            this.uniTBL_MainBatch.DefaultRowSize = 25;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 711);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(979, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblPurchaseRequisition
            // 
            appearance228.TextHAlignAsString = "Left";
            appearance228.TextVAlignAsString = "Middle";
            this.lblPurchaseRequisition.Appearance = appearance228;
            this.lblPurchaseRequisition.AutoPopupID = null;
            this.uniTBL_MainBatch.SetColumnSpan(this.lblPurchaseRequisition, 2);
            this.lblPurchaseRequisition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPurchaseRequisition.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Jump;
            this.lblPurchaseRequisition.Location = new System.Drawing.Point(779, 3);
            this.lblPurchaseRequisition.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblPurchaseRequisition.Name = "lblPurchaseRequisition";
            this.lblPurchaseRequisition.Size = new System.Drawing.Size(200, 22);
            this.lblPurchaseRequisition.StyleSetName = "uniLabel_Jump";
            this.lblPurchaseRequisition.TabIndex = 0;
            this.lblPurchaseRequisition.Text = "(E) Purchase Requisition";
            this.lblPurchaseRequisition.UseMnemonic = false;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ConditionRowCount = 4;
            this.uniTBL_MainCondition.Controls.Add(this.cboEXT6_CD_KO883, 0, 6);
            this.uniTBL_MainCondition.Controls.Add(this.lblPlantCd, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblPrFrDt, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblPrStsCd, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblPrType, 0, 3);
            this.uniTBL_MainCondition.Controls.Add(this.lblItemCd, 2, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblPdFrDt, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblRqDeptCd, 2, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblTrackNo, 2, 3);
            this.uniTBL_MainCondition.Controls.Add(this.dtPrFrDt, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.dtPdFrDt, 3, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popPlantCd, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popPrStsCd, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.popPrType, 1, 3);
            this.uniTBL_MainCondition.Controls.Add(this.popItemCd, 3, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popRqDeptCd, 3, 2);
            this.uniTBL_MainCondition.Controls.Add(this.popTrackNo, 3, 3);
            this.uniTBL_MainCondition.Controls.Add(this.lblPxNo, 0, 4);
            this.uniTBL_MainCondition.Controls.Add(this.lblReqPrsn, 2, 4);
            this.uniTBL_MainCondition.Controls.Add(this.popReqPrsn, 3, 4);
            this.uniTBL_MainCondition.Controls.Add(this.popPxNo, 1, 4);
            this.uniTBL_MainCondition.Controls.Add(this.lblPrNo, 0, 5);
            this.uniTBL_MainCondition.Controls.Add(this.rdoClsFlg, 3, 5);
            this.uniTBL_MainCondition.Controls.Add(this.lblClsFlg, 2, 5);
            this.uniTBL_MainCondition.Controls.Add(this.txtPrNo, 1, 5);
            this.uniTBL_MainCondition.Controls.Add(this.lblChgType, 0, 6);
            this.uniTBL_MainCondition.Controls.Add(this.lblApprvStatus, 2, 6);
            this.uniTBL_MainCondition.Controls.Add(this.cboEcnFlag, 3, 6);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 7;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(979, 177);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 0;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // cboEXT6_CD_KO883
            // 
            this.cboEXT6_CD_KO883.AddEmptyRow = true;
            this.cboEXT6_CD_KO883.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboEXT6_CD_KO883.ComboFrom = "";
            this.cboEXT6_CD_KO883.ComboMajorCd = "";
            this.cboEXT6_CD_KO883.ComboSelect = "";
            this.cboEXT6_CD_KO883.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboEXT6_CD_KO883.ComboWhere = "";
            this.cboEXT6_CD_KO883.DropDownListWidth = -1;
            this.cboEXT6_CD_KO883.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboEXT6_CD_KO883.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.cboEXT6_CD_KO883.Location = new System.Drawing.Point(137, 145);
            this.cboEXT6_CD_KO883.LockedField = false;
            this.cboEXT6_CD_KO883.Margin = new System.Windows.Forms.Padding(0);
            this.cboEXT6_CD_KO883.Name = "cboEXT6_CD_KO883";
            this.cboEXT6_CD_KO883.RequiredField = false;
            this.cboEXT6_CD_KO883.Size = new System.Drawing.Size(144, 22);
            this.cboEXT6_CD_KO883.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboEXT6_CD_KO883.StyleSetName = "Default";
            this.cboEXT6_CD_KO883.TabIndex = 30;
            this.cboEXT6_CD_KO883.uniALT = "Change Type(C/T)";
            // 
            // lblPlantCd
            // 
            appearance191.TextHAlignAsString = "Left";
            appearance191.TextVAlignAsString = "Middle";
            this.lblPlantCd.Appearance = appearance191;
            this.lblPlantCd.AutoPopupID = null;
            this.lblPlantCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPlantCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPlantCd.Location = new System.Drawing.Point(15, 6);
            this.lblPlantCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPlantCd.Name = "lblPlantCd";
            this.lblPlantCd.Size = new System.Drawing.Size(122, 22);
            this.lblPlantCd.StyleSetName = "Default";
            this.lblPlantCd.TabIndex = 0;
            this.lblPlantCd.Text = "Plant";
            this.lblPlantCd.UseMnemonic = false;
            // 
            // lblPrFrDt
            // 
            appearance192.TextHAlignAsString = "Left";
            appearance192.TextVAlignAsString = "Middle";
            this.lblPrFrDt.Appearance = appearance192;
            this.lblPrFrDt.AutoPopupID = null;
            this.lblPrFrDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrFrDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPrFrDt.Location = new System.Drawing.Point(15, 29);
            this.lblPrFrDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPrFrDt.Name = "lblPrFrDt";
            this.lblPrFrDt.Size = new System.Drawing.Size(122, 22);
            this.lblPrFrDt.StyleSetName = "Default";
            this.lblPrFrDt.TabIndex = 1;
            this.lblPrFrDt.Text = "P/R Date";
            this.lblPrFrDt.UseMnemonic = false;
            // 
            // lblPrStsCd
            // 
            appearance193.TextHAlignAsString = "Left";
            appearance193.TextVAlignAsString = "Middle";
            this.lblPrStsCd.Appearance = appearance193;
            this.lblPrStsCd.AutoPopupID = null;
            this.lblPrStsCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrStsCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPrStsCd.Location = new System.Drawing.Point(15, 52);
            this.lblPrStsCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPrStsCd.Name = "lblPrStsCd";
            this.lblPrStsCd.Size = new System.Drawing.Size(122, 22);
            this.lblPrStsCd.StyleSetName = "Default";
            this.lblPrStsCd.TabIndex = 2;
            this.lblPrStsCd.Text = "P/R Status";
            this.lblPrStsCd.UseMnemonic = false;
            // 
            // lblPrType
            // 
            appearance194.TextHAlignAsString = "Left";
            appearance194.TextVAlignAsString = "Middle";
            this.lblPrType.Appearance = appearance194;
            this.lblPrType.AutoPopupID = null;
            this.lblPrType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPrType.Location = new System.Drawing.Point(15, 75);
            this.lblPrType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPrType.Name = "lblPrType";
            this.lblPrType.Size = new System.Drawing.Size(122, 22);
            this.lblPrType.StyleSetName = "Default";
            this.lblPrType.TabIndex = 3;
            this.lblPrType.Text = "P/R Type";
            this.lblPrType.UseMnemonic = false;
            // 
            // lblItemCd
            // 
            appearance195.TextHAlignAsString = "Left";
            appearance195.TextVAlignAsString = "Middle";
            this.lblItemCd.Appearance = appearance195;
            this.lblItemCd.AutoPopupID = null;
            this.lblItemCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblItemCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblItemCd.Location = new System.Drawing.Point(504, 6);
            this.lblItemCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblItemCd.Name = "lblItemCd";
            this.lblItemCd.Size = new System.Drawing.Size(122, 22);
            this.lblItemCd.StyleSetName = "Default";
            this.lblItemCd.TabIndex = 4;
            this.lblItemCd.Text = "Item";
            this.lblItemCd.UseMnemonic = false;
            // 
            // lblPdFrDt
            // 
            appearance196.TextHAlignAsString = "Left";
            appearance196.TextVAlignAsString = "Middle";
            this.lblPdFrDt.Appearance = appearance196;
            this.lblPdFrDt.AutoPopupID = null;
            this.lblPdFrDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPdFrDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPdFrDt.Location = new System.Drawing.Point(504, 29);
            this.lblPdFrDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPdFrDt.Name = "lblPdFrDt";
            this.lblPdFrDt.Size = new System.Drawing.Size(122, 22);
            this.lblPdFrDt.StyleSetName = "Default";
            this.lblPdFrDt.TabIndex = 5;
            this.lblPdFrDt.Text = "Delivery Date";
            this.lblPdFrDt.UseMnemonic = false;
            // 
            // lblRqDeptCd
            // 
            appearance197.TextHAlignAsString = "Left";
            appearance197.TextVAlignAsString = "Middle";
            this.lblRqDeptCd.Appearance = appearance197;
            this.lblRqDeptCd.AutoPopupID = null;
            this.lblRqDeptCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRqDeptCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRqDeptCd.Location = new System.Drawing.Point(504, 52);
            this.lblRqDeptCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRqDeptCd.Name = "lblRqDeptCd";
            this.lblRqDeptCd.Size = new System.Drawing.Size(122, 22);
            this.lblRqDeptCd.StyleSetName = "Default";
            this.lblRqDeptCd.TabIndex = 6;
            this.lblRqDeptCd.Text = "P/R Dept.";
            this.lblRqDeptCd.UseMnemonic = false;
            // 
            // lblTrackNo
            // 
            appearance198.TextHAlignAsString = "Left";
            appearance198.TextVAlignAsString = "Middle";
            this.lblTrackNo.Appearance = appearance198;
            this.lblTrackNo.AutoPopupID = null;
            this.lblTrackNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTrackNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblTrackNo.Location = new System.Drawing.Point(504, 75);
            this.lblTrackNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblTrackNo.Name = "lblTrackNo";
            this.lblTrackNo.Size = new System.Drawing.Size(122, 22);
            this.lblTrackNo.StyleSetName = "Default";
            this.lblTrackNo.TabIndex = 7;
            this.lblTrackNo.Text = "Tracking No.";
            this.lblTrackNo.UseMnemonic = false;
            // 
            // dtPrFrDt
            // 
            this.dtPrFrDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtPrFrDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtPrFrDt.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtPrFrDt.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtPrFrDt.Location = new System.Drawing.Point(137, 30);
            this.dtPrFrDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtPrFrDt.Name = "dtPrFrDt";
            this.dtPrFrDt.Size = new System.Drawing.Size(225, 21);
            this.dtPrFrDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtPrFrDt.TabIndex = 2;
            this.dtPrFrDt.uniFromALT = "Start Date";
            this.dtPrFrDt.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtPrFrDt.uniTabSameValue = false;
            this.dtPrFrDt.uniToALT = "End Date";
            this.dtPrFrDt.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // dtPdFrDt
            // 
            this.dtPdFrDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtPdFrDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtPdFrDt.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtPdFrDt.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.dtPdFrDt.Location = new System.Drawing.Point(626, 30);
            this.dtPdFrDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtPdFrDt.Name = "dtPdFrDt";
            this.dtPdFrDt.Size = new System.Drawing.Size(225, 21);
            this.dtPdFrDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtPdFrDt.TabIndex = 3;
            this.dtPdFrDt.uniFromALT = "Start Date";
            this.dtPdFrDt.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtPdFrDt.uniTabSameValue = false;
            this.dtPdFrDt.uniToALT = "End Date";
            this.dtPdFrDt.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // popPlantCd
            // 
            this.popPlantCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPlantCd.AutoPopupCodeParameter = null;
            this.popPlantCd.AutoPopupID = null;
            this.popPlantCd.AutoPopupNameParameter = null;
            this.popPlantCd.CodeMaxLength = 4;
            this.popPlantCd.CodeName = "";
            this.popPlantCd.CodeSize = 100;
            this.popPlantCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPlantCd.CodeTextBoxName = null;
            this.popPlantCd.CodeValue = "";
            this.popPlantCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popPlantCd.Location = new System.Drawing.Point(137, 7);
            this.popPlantCd.LockedField = false;
            this.popPlantCd.Margin = new System.Windows.Forms.Padding(0);
            this.popPlantCd.Name = "popPlantCd";
            this.popPlantCd.NameDisplay = true;
            this.popPlantCd.NameId = null;
            this.popPlantCd.NameMaxLength = 50;
            this.popPlantCd.NamePopup = false;
            this.popPlantCd.NameSize = 150;
            this.popPlantCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPlantCd.Parameter = null;
            this.popPlantCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPlantCd.PopupId = null;
            this.popPlantCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPlantCd.QueryIfEnterKeyPressed = true;
            this.popPlantCd.RequiredField = false;
            this.popPlantCd.Size = new System.Drawing.Size(271, 21);
            this.popPlantCd.TabIndex = 0;
            this.popPlantCd.uniALT = "Plant";
            this.popPlantCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPlantCd.UseDynamicFormat = false;
            this.popPlantCd.ValueTextBoxName = null;
            this.popPlantCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPlantCd_BeforePopupOpen);
            this.popPlantCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPlantCd_AfterPopupClosed);
            // 
            // popPrStsCd
            // 
            this.popPrStsCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPrStsCd.AutoPopupCodeParameter = null;
            this.popPrStsCd.AutoPopupID = null;
            this.popPrStsCd.AutoPopupNameParameter = null;
            this.popPrStsCd.CodeMaxLength = 5;
            this.popPrStsCd.CodeName = "";
            this.popPrStsCd.CodeSize = 100;
            this.popPrStsCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPrStsCd.CodeTextBoxName = null;
            this.popPrStsCd.CodeValue = "";
            this.popPrStsCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popPrStsCd.Location = new System.Drawing.Point(137, 53);
            this.popPrStsCd.LockedField = false;
            this.popPrStsCd.Margin = new System.Windows.Forms.Padding(0);
            this.popPrStsCd.Name = "popPrStsCd";
            this.popPrStsCd.NameDisplay = true;
            this.popPrStsCd.NameId = null;
            this.popPrStsCd.NameMaxLength = 50;
            this.popPrStsCd.NamePopup = false;
            this.popPrStsCd.NameSize = 150;
            this.popPrStsCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPrStsCd.Parameter = null;
            this.popPrStsCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPrStsCd.PopupId = null;
            this.popPrStsCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPrStsCd.QueryIfEnterKeyPressed = true;
            this.popPrStsCd.RequiredField = false;
            this.popPrStsCd.Size = new System.Drawing.Size(271, 21);
            this.popPrStsCd.TabIndex = 4;
            this.popPrStsCd.uniALT = "P/R Status";
            this.popPrStsCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPrStsCd.UseDynamicFormat = false;
            this.popPrStsCd.ValueTextBoxName = null;
            this.popPrStsCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPrStsCd_BeforePopupOpen);
            this.popPrStsCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPrStsCd_AfterPopupClosed);
            // 
            // popPrType
            // 
            this.popPrType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPrType.AutoPopupCodeParameter = null;
            this.popPrType.AutoPopupID = null;
            this.popPrType.AutoPopupNameParameter = null;
            this.popPrType.CodeMaxLength = 5;
            this.popPrType.CodeName = "";
            this.popPrType.CodeSize = 100;
            this.popPrType.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPrType.CodeTextBoxName = null;
            this.popPrType.CodeValue = "";
            this.popPrType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popPrType.Location = new System.Drawing.Point(137, 76);
            this.popPrType.LockedField = false;
            this.popPrType.Margin = new System.Windows.Forms.Padding(0);
            this.popPrType.Name = "popPrType";
            this.popPrType.NameDisplay = true;
            this.popPrType.NameId = null;
            this.popPrType.NameMaxLength = 50;
            this.popPrType.NamePopup = false;
            this.popPrType.NameSize = 150;
            this.popPrType.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPrType.Parameter = null;
            this.popPrType.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPrType.PopupId = null;
            this.popPrType.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPrType.QueryIfEnterKeyPressed = true;
            this.popPrType.RequiredField = false;
            this.popPrType.Size = new System.Drawing.Size(271, 21);
            this.popPrType.TabIndex = 6;
            this.popPrType.uniALT = "P/R Type";
            this.popPrType.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPrType.UseDynamicFormat = false;
            this.popPrType.ValueTextBoxName = null;
            this.popPrType.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPrType_BeforePopupOpen);
            this.popPrType.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPrType_AfterPopupClosed);
            // 
            // popItemCd
            // 
            this.popItemCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popItemCd.AutoPopupCodeParameter = null;
            this.popItemCd.AutoPopupID = null;
            this.popItemCd.AutoPopupNameParameter = null;
            this.popItemCd.CodeMaxLength = 50;
            this.popItemCd.CodeName = "";
            this.popItemCd.CodeSize = 100;
            this.popItemCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popItemCd.CodeTextBoxName = null;
            this.popItemCd.CodeValue = "";
            this.popItemCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popItemCd.Location = new System.Drawing.Point(626, 7);
            this.popItemCd.LockedField = false;
            this.popItemCd.Margin = new System.Windows.Forms.Padding(0);
            this.popItemCd.Name = "popItemCd";
            this.popItemCd.NameDisplay = true;
            this.popItemCd.NameId = null;
            this.popItemCd.NameMaxLength = 50;
            this.popItemCd.NamePopup = false;
            this.popItemCd.NameSize = 150;
            this.popItemCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popItemCd.Parameter = null;
            this.popItemCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popItemCd.PopupId = null;
            this.popItemCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popItemCd.QueryIfEnterKeyPressed = true;
            this.popItemCd.RequiredField = false;
            this.popItemCd.Size = new System.Drawing.Size(271, 21);
            this.popItemCd.TabIndex = 1;
            this.popItemCd.uniALT = "Item";
            this.popItemCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popItemCd.UseDynamicFormat = false;
            this.popItemCd.ValueTextBoxName = null;
            this.popItemCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popItemCd_BeforePopupOpen);
            this.popItemCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popItemCd_AfterPopupClosed);
            // 
            // popRqDeptCd
            // 
            this.popRqDeptCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popRqDeptCd.AutoPopupCodeParameter = null;
            this.popRqDeptCd.AutoPopupID = null;
            this.popRqDeptCd.AutoPopupNameParameter = null;
            this.popRqDeptCd.CodeMaxLength = 10;
            this.popRqDeptCd.CodeName = "";
            this.popRqDeptCd.CodeSize = 100;
            this.popRqDeptCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popRqDeptCd.CodeTextBoxName = null;
            this.popRqDeptCd.CodeValue = "";
            this.popRqDeptCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popRqDeptCd.Location = new System.Drawing.Point(626, 53);
            this.popRqDeptCd.LockedField = false;
            this.popRqDeptCd.Margin = new System.Windows.Forms.Padding(0);
            this.popRqDeptCd.Name = "popRqDeptCd";
            this.popRqDeptCd.NameDisplay = true;
            this.popRqDeptCd.NameId = null;
            this.popRqDeptCd.NameMaxLength = 50;
            this.popRqDeptCd.NamePopup = false;
            this.popRqDeptCd.NameSize = 150;
            this.popRqDeptCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popRqDeptCd.Parameter = null;
            this.popRqDeptCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popRqDeptCd.PopupId = null;
            this.popRqDeptCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popRqDeptCd.QueryIfEnterKeyPressed = true;
            this.popRqDeptCd.RequiredField = false;
            this.popRqDeptCd.Size = new System.Drawing.Size(271, 21);
            this.popRqDeptCd.TabIndex = 5;
            this.popRqDeptCd.uniALT = "P/R Dept.";
            this.popRqDeptCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popRqDeptCd.UseDynamicFormat = false;
            this.popRqDeptCd.ValueTextBoxName = null;
            this.popRqDeptCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popRqDeptCd_BeforePopupOpen);
            this.popRqDeptCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popRqDeptCd_AfterPopupClosed);
            // 
            // popTrackNo
            // 
            this.popTrackNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popTrackNo.AutoPopupCodeParameter = null;
            this.popTrackNo.AutoPopupID = null;
            this.popTrackNo.AutoPopupNameParameter = null;
            this.popTrackNo.CodeMaxLength = 25;
            this.popTrackNo.CodeName = "";
            this.popTrackNo.CodeSize = 150;
            this.popTrackNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popTrackNo.CodeTextBoxName = null;
            this.popTrackNo.CodeValue = "";
            this.popTrackNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popTrackNo.Location = new System.Drawing.Point(626, 76);
            this.popTrackNo.LockedField = false;
            this.popTrackNo.Margin = new System.Windows.Forms.Padding(0);
            this.popTrackNo.Name = "popTrackNo";
            this.popTrackNo.NameDisplay = false;
            this.popTrackNo.NameId = null;
            this.popTrackNo.NameMaxLength = 50;
            this.popTrackNo.NamePopup = false;
            this.popTrackNo.NameSize = 150;
            this.popTrackNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popTrackNo.Parameter = null;
            this.popTrackNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popTrackNo.PopupId = null;
            this.popTrackNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popTrackNo.QueryIfEnterKeyPressed = true;
            this.popTrackNo.RequiredField = false;
            this.popTrackNo.Size = new System.Drawing.Size(321, 21);
            this.popTrackNo.TabIndex = 7;
            this.popTrackNo.uniALT = "Tracking No.";
            this.popTrackNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popTrackNo.UseDynamicFormat = false;
            this.popTrackNo.ValueTextBoxName = null;
            this.popTrackNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popTrackNo_BeforePopupOpen);
            this.popTrackNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popTrackNo_AfterPopupClosed);
            // 
            // lblPxNo
            // 
            appearance199.TextHAlignAsString = "Left";
            appearance199.TextVAlignAsString = "Middle";
            this.lblPxNo.Appearance = appearance199;
            this.lblPxNo.AutoPopupID = null;
            this.lblPxNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPxNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPxNo.Location = new System.Drawing.Point(15, 98);
            this.lblPxNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPxNo.Name = "lblPxNo";
            this.lblPxNo.Size = new System.Drawing.Size(122, 22);
            this.lblPxNo.StyleSetName = "Default";
            this.lblPxNo.TabIndex = 8;
            this.lblPxNo.Text = "구매의뢰번호";
            this.lblPxNo.UseMnemonic = false;
            // 
            // lblReqPrsn
            // 
            appearance200.TextHAlignAsString = "Left";
            appearance200.TextVAlignAsString = "Middle";
            this.lblReqPrsn.Appearance = appearance200;
            this.lblReqPrsn.AutoPopupID = null;
            this.lblReqPrsn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReqPrsn.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReqPrsn.Location = new System.Drawing.Point(504, 98);
            this.lblReqPrsn.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReqPrsn.Name = "lblReqPrsn";
            this.lblReqPrsn.Size = new System.Drawing.Size(122, 22);
            this.lblReqPrsn.StyleSetName = "Default";
            this.lblReqPrsn.TabIndex = 9;
            this.lblReqPrsn.Text = "요청자";
            this.lblReqPrsn.UseMnemonic = false;
            // 
            // popReqPrsn
            // 
            this.popReqPrsn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popReqPrsn.AutoPopupCodeParameter = null;
            this.popReqPrsn.AutoPopupID = null;
            this.popReqPrsn.AutoPopupNameParameter = null;
            this.popReqPrsn.CodeMaxLength = 13;
            this.popReqPrsn.CodeName = "";
            this.popReqPrsn.CodeSize = 100;
            this.popReqPrsn.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReqPrsn.CodeTextBoxName = null;
            this.popReqPrsn.CodeValue = "";
            this.popReqPrsn.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popReqPrsn.Location = new System.Drawing.Point(626, 99);
            this.popReqPrsn.LockedField = false;
            this.popReqPrsn.Margin = new System.Windows.Forms.Padding(0);
            this.popReqPrsn.Name = "popReqPrsn";
            this.popReqPrsn.NameDisplay = true;
            this.popReqPrsn.NameId = null;
            this.popReqPrsn.NameMaxLength = 50;
            this.popReqPrsn.NamePopup = false;
            this.popReqPrsn.NameSize = 150;
            this.popReqPrsn.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReqPrsn.Parameter = null;
            this.popReqPrsn.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popReqPrsn.PopupId = null;
            this.popReqPrsn.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popReqPrsn.QueryIfEnterKeyPressed = true;
            this.popReqPrsn.RequiredField = false;
            this.popReqPrsn.Size = new System.Drawing.Size(271, 21);
            this.popReqPrsn.TabIndex = 11;
            this.popReqPrsn.uniALT = null;
            this.popReqPrsn.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popReqPrsn.UseDynamicFormat = false;
            this.popReqPrsn.ValueTextBoxName = null;
            this.popReqPrsn.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popReqPrsn_BeforePopupOpen);
            this.popReqPrsn.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popReqPrsn_AfterPopupClosed);
            // 
            // popPxNo
            // 
            this.popPxNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPxNo.AutoPopupCodeParameter = null;
            this.popPxNo.AutoPopupID = null;
            this.popPxNo.AutoPopupNameParameter = null;
            this.popPxNo.CodeMaxLength = 20;
            this.popPxNo.CodeName = "";
            this.popPxNo.CodeSize = 150;
            this.popPxNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPxNo.CodeTextBoxName = null;
            this.popPxNo.CodeValue = "";
            this.popPxNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popPxNo.Location = new System.Drawing.Point(137, 99);
            this.popPxNo.LockedField = false;
            this.popPxNo.Margin = new System.Windows.Forms.Padding(0);
            this.popPxNo.Name = "popPxNo";
            this.popPxNo.NameDisplay = false;
            this.popPxNo.NameId = null;
            this.popPxNo.NameMaxLength = 50;
            this.popPxNo.NamePopup = false;
            this.popPxNo.NameSize = 150;
            this.popPxNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPxNo.Parameter = null;
            this.popPxNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPxNo.PopupId = null;
            this.popPxNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPxNo.QueryIfEnterKeyPressed = true;
            this.popPxNo.RequiredField = false;
            this.popPxNo.Size = new System.Drawing.Size(171, 21);
            this.popPxNo.TabIndex = 12;
            this.popPxNo.uniALT = "구매의뢰번호";
            this.popPxNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPxNo.UseDynamicFormat = false;
            this.popPxNo.ValueTextBoxName = null;
            this.popPxNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPxNo_BeforePopupOpen);
            this.popPxNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPxNo_AfterPopupClosed);
            // 
            // lblPrNo
            // 
            appearance201.TextHAlignAsString = "Left";
            appearance201.TextVAlignAsString = "Middle";
            this.lblPrNo.Appearance = appearance201;
            this.lblPrNo.AutoPopupID = null;
            this.lblPrNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPrNo.Location = new System.Drawing.Point(15, 121);
            this.lblPrNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPrNo.Name = "lblPrNo";
            this.lblPrNo.Size = new System.Drawing.Size(122, 22);
            this.lblPrNo.StyleSetName = "Default";
            this.lblPrNo.TabIndex = 13;
            this.lblPrNo.Text = "구매요청번호";
            this.lblPrNo.UseMnemonic = false;
            // 
            // rdoClsFlg
            // 
            this.rdoClsFlg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rdoClsFlg.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.rdoClsFlg.CheckedIndex = 0;
            this.rdoClsFlg.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            valueListItem16.DataValue = "A";
            valueListItem16.DisplayText = "전체";
            valueListItem17.DataValue = "Y";
            valueListItem17.DisplayText = "마감";
            valueListItem18.DataValue = "N";
            valueListItem18.DisplayText = "미마감";
            this.rdoClsFlg.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem16,
            valueListItem17,
            valueListItem18});
            this.rdoClsFlg.ItemSpacingHorizontal = 30;
            this.rdoClsFlg.ItemSpacingVertical = 10;
            this.rdoClsFlg.Location = new System.Drawing.Point(626, 124);
            this.rdoClsFlg.LockedField = false;
            this.rdoClsFlg.Margin = new System.Windows.Forms.Padding(0, 4, 1, 0);
            this.rdoClsFlg.Name = "rdoClsFlg";
            this.rdoClsFlg.RequiredField = false;
            this.rdoClsFlg.Size = new System.Drawing.Size(225, 19);
            this.rdoClsFlg.StyleSetName = "Default";
            this.rdoClsFlg.TabIndex = 14;
            this.rdoClsFlg.Text = "전체";
            this.rdoClsFlg.uniALT = null;
            // 
            // lblClsFlg
            // 
            appearance202.TextHAlignAsString = "Left";
            appearance202.TextVAlignAsString = "Middle";
            this.lblClsFlg.Appearance = appearance202;
            this.lblClsFlg.AutoPopupID = null;
            this.lblClsFlg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblClsFlg.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblClsFlg.Location = new System.Drawing.Point(504, 121);
            this.lblClsFlg.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblClsFlg.Name = "lblClsFlg";
            this.lblClsFlg.Size = new System.Drawing.Size(122, 22);
            this.lblClsFlg.StyleSetName = "Default";
            this.lblClsFlg.TabIndex = 15;
            this.lblClsFlg.Text = "마감여부";
            this.lblClsFlg.UseMnemonic = false;
            // 
            // txtPrNo
            // 
            this.txtPrNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance203.TextVAlignAsString = "Bottom";
            this.txtPrNo.Appearance = appearance203;
            this.txtPrNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtPrNo.Location = new System.Drawing.Point(137, 121);
            this.txtPrNo.LockedField = false;
            this.txtPrNo.Margin = new System.Windows.Forms.Padding(0);
            this.txtPrNo.Name = "txtPrNo";
            this.txtPrNo.QueryIfEnterKeyPressed = true;
            this.txtPrNo.RequiredField = false;
            this.txtPrNo.Size = new System.Drawing.Size(170, 22);
            this.txtPrNo.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtPrNo.StyleSetName = "Default";
            this.txtPrNo.TabIndex = 16;
            this.txtPrNo.uniALT = null;
            this.txtPrNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPrNo.UseDynamicFormat = false;
            // 
            // lblChgType
            // 
            appearance204.TextHAlignAsString = "Left";
            appearance204.TextVAlignAsString = "Middle";
            this.lblChgType.Appearance = appearance204;
            this.lblChgType.AutoPopupID = null;
            this.lblChgType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblChgType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblChgType.Location = new System.Drawing.Point(15, 144);
            this.lblChgType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblChgType.Name = "lblChgType";
            this.lblChgType.Size = new System.Drawing.Size(122, 23);
            this.lblChgType.StyleSetName = "Default";
            this.lblChgType.TabIndex = 17;
            this.lblChgType.Text = "CHANGE TYPE(C/T)";
            this.lblChgType.UseMnemonic = false;
            // 
            // lblApprvStatus
            // 
            appearance205.TextHAlignAsString = "Left";
            appearance205.TextVAlignAsString = "Middle";
            this.lblApprvStatus.Appearance = appearance205;
            this.lblApprvStatus.AutoPopupID = null;
            this.lblApprvStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblApprvStatus.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblApprvStatus.Location = new System.Drawing.Point(504, 144);
            this.lblApprvStatus.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblApprvStatus.Name = "lblApprvStatus";
            this.lblApprvStatus.Size = new System.Drawing.Size(122, 23);
            this.lblApprvStatus.StyleSetName = "Default";
            this.lblApprvStatus.TabIndex = 18;
            this.lblApprvStatus.Text = "결재상태";
            this.lblApprvStatus.UseMnemonic = false;
            // 
            // cboEcnFlag
            // 
            this.cboEcnFlag.AddEmptyRow = true;
            this.cboEcnFlag.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboEcnFlag.ComboFrom = "";
            this.cboEcnFlag.ComboMajorCd = "";
            this.cboEcnFlag.ComboSelect = "";
            this.cboEcnFlag.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboEcnFlag.ComboWhere = "";
            this.cboEcnFlag.DropDownListWidth = -1;
            this.cboEcnFlag.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboEcnFlag.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.cboEcnFlag.Location = new System.Drawing.Point(626, 145);
            this.cboEcnFlag.LockedField = false;
            this.cboEcnFlag.Margin = new System.Windows.Forms.Padding(0);
            this.cboEcnFlag.Name = "cboEcnFlag";
            this.cboEcnFlag.RequiredField = false;
            this.cboEcnFlag.Size = new System.Drawing.Size(144, 22);
            this.cboEcnFlag.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboEcnFlag.StyleSetName = "Default";
            this.cboEcnFlag.TabIndex = 31;
            this.cboEcnFlag.uniALT = "결재상";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(990, 760);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).EndInit();
            this.uniTBL_MainBatch.ResumeLayout(false);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboEXT6_CD_KO883)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoClsFlg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboEcnFlag)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid2;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPlantCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPrFrDt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPrStsCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPrType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblItemCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPdFrDt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRqDeptCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblTrackNo;
        private uniERP.AppFramework.UI.Controls.uniDateTerm dtPrFrDt;
        private uniERP.AppFramework.UI.Controls.uniDateTerm dtPdFrDt;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPlantCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPrStsCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPrType;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popItemCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popRqDeptCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popTrackNo;
        private AppFramework.UI.Controls.uniLabel lblPxNo;
        private AppFramework.UI.Controls.uniLabel lblReqPrsn;
        private AppFramework.UI.Controls.uniOpenPopup popReqPrsn;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPxNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPrNo;
        private uniERP.AppFramework.UI.Controls.uniRadioButton rdoClsFlg;
        private uniERP.AppFramework.UI.Controls.uniLabel lblClsFlg;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtPrNo;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPurchaseRequisition;
        private uniERP.AppFramework.UI.Controls.uniLabel lblChgType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblApprvStatus;
        private uniERP.AppFramework.UI.Controls.uniCombo cboEXT6_CD_KO883;
        private uniERP.AppFramework.UI.Controls.uniCombo cboEcnFlag;

    }
}
