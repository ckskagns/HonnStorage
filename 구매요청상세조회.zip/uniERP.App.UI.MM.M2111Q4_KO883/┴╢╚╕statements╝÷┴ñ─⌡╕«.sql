--select * from statements where id ='M2111QA401_KO883'


SELECT DISTINCT    ?                    
 FROM    M_PUR_REQ A(NOLOCK)          
 LEFT JOIN B_PLANT B(NOLOCK) ON A.PLANT_CD = B.PLANT_CD              
 INNER JOIN B_ITEM C(NOLOCK) ON A.ITEM_CD = C.ITEM_CD
 INNER JOIN B_ITEM_BY_PLANT X(NOLOCK) ON A.ITEM_CD = X.ITEM_CD              
 LEFT JOIN  B_ACCT_DEPT D(NOLOCK) ON A.REQ_DEPT    = D.DEPT_CD AND D.ORG_CHANGE_ID = ?            
 INNER JOIN B_MINOR E(NOLOCK) ON A.PR_STS =    E.MINOR_CD AND E.MAJOR_CD='M2101'            
 INNER JOIN  B_MINOR F(NOLOCK) ON A.PR_TYPE = F.MINOR_CD AND F.MAJOR_CD='M2102'           
 LEFT JOIN  B_PUR_GRP H(NOLOCK)  ON A.PUR_GRP = H.PUR_GRP             
 LEFT JOIN  B_BIZ_PARTNER I(NOLOCK) ON A.SPPL_CD = I.BP_CD AND I.BP_TYPE <> 'C'           
 LEFT JOIN M_PUR_ORD_DTL J (NOLOCK) ON J.PR_NO = A.PR_NO          
 LEFT JOIN Z_USR_MAST_REC K (NOLOCK) ON J.INSRT_USER_ID  = K.USR_ID            
 LEFT JOIN ERP_IF_APPROVAL L(NOLOCK) ON A.EXT3_CD = L.DOC_NO     
 LEFT JOIN P_ECN_MASTER M(NOLOCK) ON A.EXT1_CD = M.ECN_NO      
 WHERE  A.PLANT_CD >= ?        
 AND  A.PLANT_CD <= ?           
 AND A.ITEM_CD >= ?        
 AND  A.ITEM_CD <= ?          
 AND A.REQ_DT >= ?        
 AND A.REQ_DT <= ?           
 AND A.DLVY_DT >= ?        
 AND  A.DLVY_DT <=?           
 AND A.PR_STS >= ?        
 AND  A.PR_STS <= ?           
 AND A.REQ_DEPT >= ?        
 AND A.REQ_DEPT <= ?           
 AND A.PR_TYPE >= ?       
 AND  A.PR_TYPE <= ?             ? ? ? ? ? ? ? ?



 begin tran
 UPDATE statements
 set
 head = '
 
SELECT DISTINCT    ?                    
 FROM    M_PUR_REQ A(NOLOCK)          
 LEFT JOIN B_PLANT B(NOLOCK) ON A.PLANT_CD = B.PLANT_CD              
 INNER JOIN B_ITEM C(NOLOCK) ON A.ITEM_CD = C.ITEM_CD
 INNER JOIN B_ITEM_BY_PLANT X(NOLOCK) ON A.ITEM_CD = X.ITEM_CD              
 LEFT JOIN  B_ACCT_DEPT D(NOLOCK) ON A.REQ_DEPT    = D.DEPT_CD AND D.ORG_CHANGE_ID = ?            
 INNER JOIN B_MINOR E(NOLOCK) ON A.PR_STS =    E.MINOR_CD AND E.MAJOR_CD=''M2101''            
 INNER JOIN  B_MINOR F(NOLOCK) ON A.PR_TYPE = F.MINOR_CD AND F.MAJOR_CD=''M2102''           
 LEFT JOIN  B_PUR_GRP H(NOLOCK)  ON A.PUR_GRP = H.PUR_GRP             
 LEFT JOIN  B_BIZ_PARTNER I(NOLOCK) ON A.SPPL_CD = I.BP_CD AND I.BP_TYPE <> ''C''           
 LEFT JOIN M_PUR_ORD_DTL J (NOLOCK) ON J.PR_NO = A.PR_NO          
 LEFT JOIN Z_USR_MAST_REC K (NOLOCK) ON J.INSRT_USER_ID  = K.USR_ID            
 LEFT JOIN ERP_IF_APPROVAL L(NOLOCK) ON A.EXT3_CD = L.DOC_NO     
 LEFT JOIN P_ECN_MASTER M(NOLOCK) ON A.EXT1_CD = M.ECN_NO      
 WHERE  A.PLANT_CD >= ?        
 AND  A.PLANT_CD <= ?           
 AND A.ITEM_CD >= ?        
 AND  A.ITEM_CD <= ?          
 AND A.REQ_DT >= ?        
 AND A.REQ_DT <= ?           
 AND A.DLVY_DT >= ?        
 AND  A.DLVY_DT <=?           
 AND A.PR_STS >= ?        
 AND  A.PR_STS <= ?           
 AND A.REQ_DEPT >= ?        
 AND A.REQ_DEPT <= ?           
 AND A.PR_TYPE >= ?       
 AND  A.PR_TYPE <= ?             ? ? ? ? ? ? ? ?

 '
 where
 id ='M2111QA401_KO883'
 commit