﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Common.Exceptions;
using uniERP.AppFramework.DataBridge;

#endregion

namespace uniERP.App.UI.MDM.B1B11M2_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①uniERP.App.UI.MDM.B1B11M2_KO883</NameSpace>
        /// <Module>②MDM</Module>
        /// <Class>③class name</Class>
        /// <Desc>④
        ///   품목명을 입력하면 품목명을 비교하여 품목등록여부를 확인한다.
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="LYK" Date="2018-06-19">품목등록여부(S)…</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        #endregion

        #region ■ 1.4 Class global constants (grid)


        #endregion

        #region ■ 1.5 Class global variables (grid)

        // change your code
        private tdsItemInfoChk cstdsItemInfoChk = new tdsItemInfoChk();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(this.cstdsItemInfoChk);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.Common);  // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format
        }

        protected override void Form_Load_Completed()
        {
            popPlantCd.Focus();// Set focus


            dtValidDt.uniDateTimeF.Value = null;
            dtValidDt.uniDateTimeT.Value = null;


            //uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.DeleteRow, false);
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            // init Dataset Row : change your code
            //dsAnyName.Clear();
        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            // Assign default value to controls

            dtValidDt.uniDateTimeF.Value = null;
            dtValidDt.uniDateTimeT.Value = null;

            popPlantCd.CodeValue = CommonVariable.gPlant;
            popPlantCd.CodeName = CommonVariable.gPlantNm;
            uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, false);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.New, true);

            return;

        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            // Example: Set ComboBox List (Column Name, Select, From, Where)
            //uniBase.UData.ComboMajorAdd("TaxPolicy", "B0004");
            //uniBase.UData.ComboCustomAdd("MSG_TYPE", "MINOR_CD , MINOR_NM ", "B_MINOR", "MAJOR_CD='A1001'");
            //uniBase.UData.ComboMajorAdd("ITEM_ACCT", ""); 
        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆
            base.viewTB19029.ggUserDefined6.DecPoint = 0;
            base.viewTB19029.ggUserDefined6.Integeral = 15;
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            tdsItemInfoChk.E_ITEM_INFO_CHKDataTable uniGridTB1 = cstdsItemInfoChk.E_ITEM_INFO_CHK ;
            uniGrid1.SSSetEdit(uniGridTB1.item_type_nmColumn.ColumnName, "품목구분", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.item_group_cdColumn.ColumnName, "품목그룹", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.item_group_nmColumn.ColumnName, "품목그룹명", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.item_cdColumn.ColumnName, "품목코드", 150, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetEdit(uniGridTB1.item_nm_inputColumn.ColumnName, "품목(입력)", 200, enumDef.FieldType.NotNull);
            //uniGrid1.SSSetEdit(uniGridTB1.item_cntColumn.ColumnName, "중복건수", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.item_nmColumn.ColumnName, "품목명", 200, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.item_nm_engColumn.ColumnName, "품목영문명", 200, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.formal_nmColumn.ColumnName, "품목일반정보", 150, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.specColumn.ColumnName, "규격", 200, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.spec_inputColumn.ColumnName, "규격(입력)", 200, enumDef.FieldType.NotNull);
            uniGrid1.SSSetEdit(uniGridTB1.spec_cntColumn.ColumnName, "중복건수", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.phantom_flgColumn.ColumnName, "팬텀", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.tracking_flgColumn.ColumnName, "Tracking여부", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.item_acct_nmColumn.ColumnName, "품목계정", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.procur_type_nmColumn.ColumnName, "조달구분", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.basic_unitColumn.ColumnName, "재고단위", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.order_unit_purColumn.ColumnName, "구매단위", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.rcpt_sl_cdColumn.ColumnName, "입고창고", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.rcpt_sl_nmColumn.ColumnName, "입고창고명", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.issue_sl_cdColumn.ColumnName, "출고창고", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.issue_sl_nmColumn.ColumnName, "출고창고명", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.issue_mthd_nmColumn.ColumnName, "출고방법", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.prc_type_nmColumn.ColumnName, "단가구분", 100, enumDef.FieldType.ReadOnly); 
            uniGrid1.SSSetFloat(uniGridTB1.std_prcColumn.ColumnName, "단가", 120, viewTB19029.ggUnitCost,enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.order_typeColumn.ColumnName, "오더생성여부", 110, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.order_fromColumn.ColumnName, "오더생성구분", 110, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.reorder_pntColumn.ColumnName, "발주점", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.wc_cdColumn.ColumnName, "작업장", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.wc_nmColumn.ColumnName, "작업장명", 90, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.order_lt_mfgColumn.ColumnName, "제조L/T", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.order_lt_purColumn.ColumnName, "구매L/T", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.pur_orgColumn.ColumnName, "구매조직", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.pur_org_nmColumn.ColumnName, "구매조직명", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.prod_inspec_flgColumn.ColumnName, "공정검사", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.recv_inspec_flgColumn.ColumnName, "수입검사", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.final_inspec_flgColumn.ColumnName, "최종검사", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.ship_inspec_flgColumn.ColumnName, "출하검사", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.valid_flgColumn.ColumnName, "유효구분", 80, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetDate(uniGridTB1.valid_from_dtColumn.ColumnName, "유효시작일", enumDef.FieldType.ReadOnly, CommonVariable.CDT_YYYY_MM_DD);
            uniGrid1.SSSetDate(uniGridTB1.valid_to_dtColumn.ColumnName, "유효종료일", enumDef.FieldType.ReadOnly, CommonVariable.CDT_YYYY_MM_DD);
            uniGrid1.SSSetEdit(uniGridTB1.hs_cdColumn.ColumnName, "H/S Code", 100, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.plant_cdColumn.ColumnName, "공장", 90, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.plant_nmColumn.ColumnName, "공장명", 100, enumDef.FieldType.ReadOnly);

            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            // Hidden Column Setting
            //this.uniGrid1.SSSetColHidden(uniGridTB1.cmb_colColumn.ColumnName);

            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
            // TO-DO: 컨트롤을 초기화(또는 초기값)할때 할일 
            // SetDefaultVal과의 차이점은 전자는 Form_Load 시점에 콘트롤에 초기값을 세팅하는것이고
            // 후자는 특정 시점(조회후 또는 행추가후 등 특정이벤트)에서 초기값을 셋팅한다.
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            // Grid binding with global dataset variable.
            this.InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(this.cstdsItemInfoChk.E_ITEM_INFO_CHK);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            if ((dtValidDt.uniDateTimeF.Value != null) && (dtValidDt.uniDateTimeT.Value != null))
            {
                if (!uniBase.UDate.CompareDateBetween(dtValidDt.uniDateTimeF, dtValidDt.uniDateTimeT, "970023"))      //%1은(는) %2보다 크거나 같아야합니다.
                {
                    dtValidDt.uniDateTimeF.Focus();
                    return false;
                }

            }
            return DBQuery();
        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)

        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic
         

            return DBSave();
        }

        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            
            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            DataSet dsQuery = null;

            string strFromDt = uniBase.UDate.DateTimeToString(dtValidDt.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD, false);
            string strToDt = uniBase.UDate.DateTimeToString(dtValidDt.uniDateTimeT, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD, false);

            try
            {
                using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_PAMTEK_B1B11M2_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PLANT_CD", SqlDbType.NVarChar, popPlantCd.CodeValue);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_CD", SqlDbType.NVarChar, txtItemCd.Value);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_NM_SPEC", SqlDbType.NVarChar, txtItemNmSpec.Value);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_GROUP_CD", SqlDbType.NVarChar, popItemGroupCd.CodeValue);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@FORMAL_NM", SqlDbType.NVarChar, txtFormalNm.Value);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_ACCT", SqlDbType.NVarChar, cboItemAcct.Value);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_TYPE", SqlDbType.NVarChar, cboItemType.Value);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PROCUR_TYPE", SqlDbType.NChar, cboProcurType.Value);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@VALID_FLAG", SqlDbType.NChar, rdoValidFlag.Value);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@VALID_FR_DT", SqlDbType.NVarChar, strFromDt);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@VALID_TO_DT", SqlDbType.NVarChar, strToDt);

                    dsQuery = uniBase.UDatabase.ExecuteDataSet(iuniCommand);

                    if (dsQuery == null || dsQuery.Tables.Count == 0 || dsQuery.Tables[0].Rows.Count == 0)
                    {
                        uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK); //검색 된 Data가 없습니다
                        return false;
                    }
                    else
                    {
                        uniBase.UData.MergeDataTable(cstdsItemInfoChk.E_ITEM_INFO_CHK, dsQuery.Tables[0], false, MissingSchemaAction.Ignore);

                        tdsItemInfoChk.E_ITEM_INFO_CHKDataTable uniGridTB1 = cstdsItemInfoChk.E_ITEM_INFO_CHK;
                        uniGrid1.SpreadLock(uniGridTB1.spec_inputColumn.ColumnName, 0, uniGrid1.Rows.Count - 1);
                    }
                }

            }


            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                //if (iqtdsTypedDataSet != null) iqtdsTypedDataSet.Dispose();
                //if (iqtdsICondition != null) iqtdsICondition.Dispose();
            }

            return true;
        }

        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            //TO-DO : code business oriented logic
            this.uniGrid1.UpdateData();

            //wsMyBizFL.TypedDataSet isettdsTypedDataSet = new wsMyBizFL.TypedDataSet();

            try
            {
                //wsMyBizFL.TypedDataSet.IESaveDTDataTable igettdtTypedDataSet =
                //    (wsMyBizFL.TypedDataSet.IESaveDTDataTable)this.cstdsTypedDataSet.IESaveDT.GetChanges();

                //using (wsMyBizFL.Service iwsMyBizFL = (wsMyBizFL.Service)uniBase.UConfig.SetWebServiceProxyEnv(new wsMyBizFL.Service()))
                //{
                //    isettdsTypedDataSet.IESaveDT.Merge(igettdtTypedDataSet, false, MissingSchemaAction.Ignore);
                //    iwsMyBizFL.SaveWebMethod(CommonVariable.gStrGlobalCollection, isettdsTypedDataSet);
                //}
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                //if (isettdsTypedDataSet != null) isettdsTypedDataSet.Dispose();
            }


            return true;

        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        #region ■■ 5.2.1 ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ButtonClicked >>> ClickCellButton

        #region ■■ 5.2.2 Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeExitEditMode(object sender, Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs e)
        {
        }

        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {
            switch (uniGrid1.ActiveCell.Column.Key.ToUpper())
            {
                case "SPEC_INPUT":
                    DataSet dsQuery = null;
                    string strFromDt = uniBase.UDate.DateTimeToString(dtValidDt.uniDateTimeF, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD, false);
                    string strToDt = uniBase.UDate.DateTimeToString(dtValidDt.uniDateTimeT, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD, false);

                    if (uniGrid1.ActiveRow.Cells["SPEC_INPUT"].Value.ToString() == "")  //규격(입력)에 들어온 값X
                    {
                        for (int i = 0; i <= uniGrid1.ActiveRow.Cells.Count - 1; i++)
                        {
                            uniGrid1.SetCellBackColor(uniGrid1.ActiveRow.Index, i, Color.Empty);    //ROW색비우고, 값들도 비워줌

                            uniGrid1.ActiveRow.Cells["ITEM_TYPE_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["ITEM_GROUP_CD"].Value = "";
                            uniGrid1.ActiveRow.Cells["ITEM_GROUP_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["ITEM_CD"].Value = "";
                            //uniGrid1.ActiveRow.Cells["ITEM_CNT"].Value = "";
                            uniGrid1.ActiveRow.Cells["ITEM_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["ITEM_NM_ENG"].Value = "";
                            uniGrid1.ActiveRow.Cells["FORMAL_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["SPEC_CNT"].Value = "";
                            uniGrid1.ActiveRow.Cells["SPEC"].Value = "";
                            uniGrid1.ActiveRow.Cells["PHANTOM_FLG"].Value = "";
                            uniGrid1.ActiveRow.Cells["TRACKING_FLG"].Value = "";
                            uniGrid1.ActiveRow.Cells["ITEM_ACCT_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["PROCUR_TYPE_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["BASIC_UNIT"].Value = "";
                            uniGrid1.ActiveRow.Cells["ORDER_UNIT_PUR"].Value = "";
                            uniGrid1.ActiveRow.Cells["RCPT_SL_CD"].Value = "";
                            uniGrid1.ActiveRow.Cells["RCPT_SL_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["ISSUE_SL_CD"].Value = "";
                            uniGrid1.ActiveRow.Cells["ISSUE_SL_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["ISSUE_MTHD_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["PRC_TYPE_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["STD_PRC"].Value = 0;  //
                            uniGrid1.ActiveRow.Cells["ORDER_TYPE"].Value = "";
                            uniGrid1.ActiveRow.Cells["ORDER_FROM"].Value = "";
                            uniGrid1.ActiveRow.Cells["REORDER_PNT"].Value = 0;  //
                            uniGrid1.ActiveRow.Cells["WC_CD"].Value = "";
                            uniGrid1.ActiveRow.Cells["WC_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["ORDER_LT_MFG"].Value = "";
                            uniGrid1.ActiveRow.Cells["ORDER_LT_PUR"].Value = "";
                            uniGrid1.ActiveRow.Cells["PUR_ORG"].Value = "";
                            uniGrid1.ActiveRow.Cells["PUR_ORG_NM"].Value = "";
                            uniGrid1.ActiveRow.Cells["PROD_INSPEC_FLG"].Value = "";
                            uniGrid1.ActiveRow.Cells["RECV_INSPEC_FLG"].Value = "";
                            uniGrid1.ActiveRow.Cells["FINAL_INSPEC_FLG"].Value = "";
                            uniGrid1.ActiveRow.Cells["SHIP_INSPEC_FLG"].Value = "";
                            uniGrid1.ActiveRow.Cells["VALID_FLG"].Value = "";
                            uniGrid1.ActiveRow.Cells["VALID_FROM_DT"].Value = "";    //
                            uniGrid1.ActiveRow.Cells["VALID_TO_DT"].Value = "";  //
                            uniGrid1.ActiveRow.Cells["HS_CD"].Value = "";
                            uniGrid1.ActiveRow.Cells["PLANT_CD"].Value = "";
                            uniGrid1.ActiveRow.Cells["PLANT_NM"].Value = "";
                        }
                        return;
                    }

                    else//규격(입력)에 들어온 값 O
                    {
                        try
                        {
                            using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_PAMTEK_B1B11M2_KO883_ITEM_CHECK"))  
                            {
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@SPEC_INPUT", SqlDbType.NVarChar, uniGrid1.ActiveRow.Cells["SPEC_INPUT"].Value);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@PLANT_CD", SqlDbType.NVarChar, popPlantCd.CodeValue);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_CD", SqlDbType.NVarChar, txtItemCd.Value);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_NM_SPEC", SqlDbType.NVarChar, txtItemNmSpec.Value);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_GROUP_CD", SqlDbType.NVarChar, popItemGroupCd.CodeValue);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@FORMAL_NM", SqlDbType.NVarChar, txtFormalNm.Value);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_ACCT", SqlDbType.NVarChar, cboItemAcct.Value);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@ITEM_TYPE", SqlDbType.NVarChar, cboItemType.Value);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@PROCUR_TYPE", SqlDbType.NChar, cboProcurType.Value);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@VALID_FLAG", SqlDbType.NChar, rdoValidFlag.Value);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@VALID_FR_DT", SqlDbType.NVarChar, strFromDt);
                                uniBase.UDatabase.AddInParameter(iuniCommand, "@VALID_TO_DT", SqlDbType.NVarChar, strToDt);


                                dsQuery = uniBase.UDatabase.ExecuteDataSet(iuniCommand);

                                if (dsQuery == null || dsQuery.Tables.Count == 0 || dsQuery.Tables[0].Rows.Count == 0)  //1.입력에 해당하는 데이터 X->row비워줌
                                {
                                    uniGrid1.ActiveRow.Cells["ITEM_TYPE_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ITEM_GROUP_CD"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ITEM_GROUP_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ITEM_CD"].Value = "";
                                   // uniGrid1.ActiveRow.Cells["ITEM_CNT"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ITEM_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ITEM_NM_ENG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["FORMAL_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["SPEC_CNT"].Value = "";
                                    uniGrid1.ActiveRow.Cells["SPEC"].Value = "";
                                    uniGrid1.ActiveRow.Cells["PHANTOM_FLG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["TRACKING_FLG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ITEM_ACCT_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["PROCUR_TYPE_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["BASIC_UNIT"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ORDER_UNIT_PUR"].Value = "";
                                    uniGrid1.ActiveRow.Cells["RCPT_SL_CD"].Value = "";
                                    uniGrid1.ActiveRow.Cells["RCPT_SL_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ISSUE_SL_CD"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ISSUE_SL_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ISSUE_MTHD_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["PRC_TYPE_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["STD_PRC"].Value = 0;  
                                    uniGrid1.ActiveRow.Cells["ORDER_TYPE"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ORDER_FROM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["REORDER_PNT"].Value = 0;  
                                    uniGrid1.ActiveRow.Cells["WC_CD"].Value = "";
                                    uniGrid1.ActiveRow.Cells["WC_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ORDER_LT_MFG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["ORDER_LT_PUR"].Value = "";
                                    uniGrid1.ActiveRow.Cells["PUR_ORG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["PUR_ORG_NM"].Value = "";
                                    uniGrid1.ActiveRow.Cells["PROD_INSPEC_FLG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["RECV_INSPEC_FLG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["FINAL_INSPEC_FLG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["SHIP_INSPEC_FLG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["VALID_FLG"].Value = "";
                                    uniGrid1.ActiveRow.Cells["VALID_FROM_DT"].Value = "";    
                                    uniGrid1.ActiveRow.Cells["VALID_TO_DT"].Value = "";  
                                    uniGrid1.ActiveRow.Cells["HS_CD"].Value = "";
                                    uniGrid1.ActiveRow.Cells["PLANT_CD"].Value = "";
                                    uniGrid1.ActiveRow.Cells["PLANT_NM"].Value = "";
                                    uniGrid1.ActiveRow.Appearance.BackColor = Color.LightPink;

                                    for (int i = 0; i <= uniGrid1.ActiveRow.Cells.Count - 1; i++)
                                    {
                                        uniGrid1.SetCellBackColor(uniGrid1.ActiveRow.Index, i, Color.LightPink);    //row에 색깔표시
                                    }

                                    return;
                                }
                                else//입력에 해당하는 데이터가 있을경우
                                {
                                    //uniBase.UData.MergeDataTable(cstdsItemInfoChk.E_ITEM_INFO_CHK, dsQuery.Tables[0], false, MissingSchemaAction.Ignore);
                                    for (int i = 0; i <= uniGrid1.ActiveRow.Cells.Count - 1; i++)
                                    {
                                        uniGrid1.SetCellBackColor(uniGrid1.ActiveRow.Index, i, Color.Empty);//row에 색 없애주고
                                    }
                                    //해당 데이터 입력
                                    uniGrid1.ActiveRow.Cells["ITEM_TYPE_NM"].Value = dsQuery.Tables[0].Rows[0]["ITEM_TYPE_NM"].ToString(); //품목구분
                                    uniGrid1.ActiveRow.Cells["ITEM_GROUP_CD"].Value = dsQuery.Tables[0].Rows[0]["ITEM_GROUP_CD"].ToString();   //품목그룹
                                    uniGrid1.ActiveRow.Cells["ITEM_GROUP_NM"].Value = dsQuery.Tables[0].Rows[0]["ITEM_GROUP_NM"].ToString();   //품목그룹명
                                    uniGrid1.ActiveRow.Cells["ITEM_CD"].Value = dsQuery.Tables[0].Rows[0]["ITEM_CD"].ToString();   //품목코드
                                   // uniGrid1.ActiveRow.Cells["ITEM_CNT"].Value = dsQuery.Tables[0].Rows[0]["ITEM_CNT"].ToString(); //중복건수
                                    uniGrid1.ActiveRow.Cells["ITEM_NM"].Value = dsQuery.Tables[0].Rows[0]["ITEM_NM"].ToString();   //품목명
                                    uniGrid1.ActiveRow.Cells["ITEM_NM_ENG"].Value = dsQuery.Tables[0].Rows[0]["ITEM_NM_ENG"].ToString();   //품목영문명
                                    uniGrid1.ActiveRow.Cells["FORMAL_NM"].Value = dsQuery.Tables[0].Rows[0]["FORMAL_NM"].ToString();   //품목일반정보
                                    uniGrid1.ActiveRow.Cells["SPEC_CNT"].Value = dsQuery.Tables[0].Rows[0]["SPEC_CNT"].ToString(); //중복건수
                                    uniGrid1.ActiveRow.Cells["SPEC"].Value = dsQuery.Tables[0].Rows[0]["SPEC"].ToString(); //규격
                                    uniGrid1.ActiveRow.Cells["PHANTOM_FLG"].Value = dsQuery.Tables[0].Rows[0]["PHANTOM_FLG"].ToString();   //팬텀
                                    uniGrid1.ActiveRow.Cells["TRACKING_FLG"].Value = dsQuery.Tables[0].Rows[0]["TRACKING_FLG"].ToString(); //Tracking여부
                                    uniGrid1.ActiveRow.Cells["ITEM_ACCT_NM"].Value = dsQuery.Tables[0].Rows[0]["ITEM_ACCT_NM"].ToString(); //품목계정
                                    uniGrid1.ActiveRow.Cells["PROCUR_TYPE_NM"].Value = dsQuery.Tables[0].Rows[0]["PROCUR_TYPE_NM"].ToString(); //조달구분
                                    uniGrid1.ActiveRow.Cells["BASIC_UNIT"].Value = dsQuery.Tables[0].Rows[0]["BASIC_UNIT"].ToString(); //재고단위
                                    uniGrid1.ActiveRow.Cells["ORDER_UNIT_PUR"].Value = dsQuery.Tables[0].Rows[0]["ORDER_UNIT_PUR"].ToString(); //구매단위
                                    uniGrid1.ActiveRow.Cells["RCPT_SL_CD"].Value = dsQuery.Tables[0].Rows[0]["RCPT_SL_CD"].ToString(); //입고창고
                                    uniGrid1.ActiveRow.Cells["RCPT_SL_NM"].Value = dsQuery.Tables[0].Rows[0]["RCPT_SL_NM"].ToString(); //입고창고명
                                    uniGrid1.ActiveRow.Cells["ISSUE_SL_CD"].Value = dsQuery.Tables[0].Rows[0]["ISSUE_SL_CD"].ToString();   //출고창고
                                    uniGrid1.ActiveRow.Cells["ISSUE_SL_NM"].Value = dsQuery.Tables[0].Rows[0]["ISSUE_SL_NM"].ToString();   //출고창고명
                                    uniGrid1.ActiveRow.Cells["ISSUE_MTHD_NM"].Value = dsQuery.Tables[0].Rows[0]["ISSUE_MTHD_NM"].ToString();   //출고방법명
                                    uniGrid1.ActiveRow.Cells["PRC_TYPE_NM"].Value = dsQuery.Tables[0].Rows[0]["PRC_TYPE_NM"].ToString(); //단가구분
                                    uniGrid1.ActiveRow.Cells["STD_PRC"].Value = dsQuery.Tables[0].Rows[0]["STD_PRC"].ToString(); //단가
                                    uniGrid1.ActiveRow.Cells["ORDER_TYPE"].Value = dsQuery.Tables[0].Rows[0]["ORDER_TYPE"].ToString(); //오더생성여부
                                    uniGrid1.ActiveRow.Cells["ORDER_FROM"].Value = dsQuery.Tables[0].Rows[0]["ORDER_FROM"].ToString(); //오더생성구분
                                    uniGrid1.ActiveRow.Cells["REORDER_PNT"].Value = dsQuery.Tables[0].Rows[0]["REORDER_PNT"].ToString();   //발주점
                                    uniGrid1.ActiveRow.Cells["WC_CD"].Value = dsQuery.Tables[0].Rows[0]["WC_CD"].ToString();   //작업장
                                    uniGrid1.ActiveRow.Cells["WC_NM"].Value = dsQuery.Tables[0].Rows[0]["WC_NM"].ToString();   //작업장명
                                    uniGrid1.ActiveRow.Cells["ORDER_LT_MFG"].Value = dsQuery.Tables[0].Rows[0]["ORDER_LT_MFG"].ToString(); //제조L/T
                                    uniGrid1.ActiveRow.Cells["ORDER_LT_PUR"].Value = dsQuery.Tables[0].Rows[0]["ORDER_LT_PUR"].ToString(); //구매L/T
                                    uniGrid1.ActiveRow.Cells["PUR_ORG"].Value = dsQuery.Tables[0].Rows[0]["PUR_ORG"].ToString();   //구매조직
                                    uniGrid1.ActiveRow.Cells["PUR_ORG_NM"].Value = dsQuery.Tables[0].Rows[0]["PUR_ORG_NM"].ToString(); //구매조직명
                                    uniGrid1.ActiveRow.Cells["PROD_INSPEC_FLG"].Value = dsQuery.Tables[0].Rows[0]["PROD_INSPEC_FLG"].ToString();   //공정검사
                                    uniGrid1.ActiveRow.Cells["RECV_INSPEC_FLG"].Value = dsQuery.Tables[0].Rows[0]["RECV_INSPEC_FLG"].ToString();   //수입검사
                                    uniGrid1.ActiveRow.Cells["FINAL_INSPEC_FLG"].Value = dsQuery.Tables[0].Rows[0]["FINAL_INSPEC_FLG"].ToString(); //최종검사
                                    uniGrid1.ActiveRow.Cells["SHIP_INSPEC_FLG"].Value = dsQuery.Tables[0].Rows[0]["SHIP_INSPEC_FLG"].ToString();   //출하검사
                                    uniGrid1.ActiveRow.Cells["VALID_FLG"].Value = dsQuery.Tables[0].Rows[0]["VALID_FLG"].ToString();   //유효구분
                                    uniGrid1.ActiveRow.Cells["VALID_FROM_DT"].Value = dsQuery.Tables[0].Rows[0]["VALID_FROM_DT"].ToString();   //유효시작일
                                    uniGrid1.ActiveRow.Cells["VALID_TO_DT"].Value = dsQuery.Tables[0].Rows[0]["VALID_TO_DT"].ToString();   //유효종료일
                                    uniGrid1.ActiveRow.Cells["HS_CD"].Value = dsQuery.Tables[0].Rows[0]["HS_CD"].ToString();   //H/SCode
                                    uniGrid1.ActiveRow.Cells["PLANT_CD"].Value = dsQuery.Tables[0].Rows[0]["PLANT_CD"].ToString(); //공장
                                    uniGrid1.ActiveRow.Cells["PLANT_NM"].Value = dsQuery.Tables[0].Rows[0]["PLANT_NM"].ToString(); //공장명
                                }
                            }
                        }

                        catch (Exception ex)
                        {
                            bool reThrow = ExceptionControler.AutoProcessException(ex);
                            if (reThrow)
                                throw;
                            return;
                        }
                        break;
                    }
            }
        }
        #endregion ■■ Change >>> CellChange

        #region ■■ 5.2.3 Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
        }
        #endregion ■■ Click >>> AfterSelectChange

        #region ■■ 5.2.4 ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ComboSelChange >>> CellListSelect

        #region ■■ 5.2.5 DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
        }
        #endregion ■■ DblClick >>> DoubleClickCell

        #region ■■ 5.2.6 MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
        }
        #endregion ■■ MouseDown >>> MouseDown

        #region ■■ 5.2.7 ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
        }
        #endregion ■■ ScriptLeaveCell >>> BeforeCellDeactivate

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors
            //CommonPopup cp = new CommonUtil.CommonPopup(PopupType.AutoNumbering);

            //string[] arrRet = cp.showModalDialog(InputParam1);

            #endregion

            #region ▶▶▶ 10.1.2.2 Setting Returned Data

            //if (iWhere) 
            //{
            //    txtMinor.value = arrRet[0];
            //    txtMinorNm.value = arrRet[1];
            //}
            //else
            //{
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingCd].value = arrRet[0];
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingNm].value = arrRet[1];

            //    if (arrRet[2].Length > 0) 
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = arrRet[2];
            //    else
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = "18";

            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.PrefixCd].value = arrRet[0];

            //}

            #endregion

            //CommonVariable.lgBlnFlgChgValue = true;  // 사용자 액션 발생 알림
        }

        #endregion
        //공장팝업
        private void popPlantCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "공장";
            e.PopupPassData.ConditionCaption = "공장";

            e.PopupPassData.SQLFromStatements = "B_PLANT (NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popPlantCd.CodeValue.Trim();
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new string[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "PLANT_CD";
            e.PopupPassData.GridCellCode[1] = "PLANT_NM";

            e.PopupPassData.GridCellCaption[0] = "공장";
            e.PopupPassData.GridCellCaption[1] = "공장명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }


        #endregion

        private void popPlantCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
             DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popPlantCd.CodeValue = iDataSet.Tables[0].Rows[0]["PLANT_CD"].ToString();
            popPlantCd.CodeName = iDataSet.Tables[0].Rows[0]["PLANT_NM"].ToString();
        }

        //품목그룹
        private void popItemGroupCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {

            e.PopupPassData.PopupWinTitle = "품목그룹";
            e.PopupPassData.ConditionCaption = "품목그룹";

            e.PopupPassData.SQLFromStatements = "B_ITEM_GROUP (NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popItemGroupCd.CodeValue.Trim();
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new string[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "ITEM_GROUP_CD";
            e.PopupPassData.GridCellCode[1] = "ITEM_GROUP_NM";

            e.PopupPassData.GridCellCaption[0] = "품목그룹";
            e.PopupPassData.GridCellCaption[1] = "품목그룹명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popItemGroupCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popItemGroupCd.CodeValue = iDataSet.Tables[0].Rows[0]["ITEM_GROUP_CD"].ToString();
            popItemGroupCd.CodeName = iDataSet.Tables[0].Rows[0]["ITEM_GROUP_NM"].ToString();
        }

        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        #endregion

        #endregion

    }
}