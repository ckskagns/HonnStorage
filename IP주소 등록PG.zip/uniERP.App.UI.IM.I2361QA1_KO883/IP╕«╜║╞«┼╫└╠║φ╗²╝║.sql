﻿begin tran
CREATE TABLE IP_DTL (
       Row_Num        int NOT NULL,
       IP          nvarchar(40)   NOT NULL,            -- IP주소  
	   EMP_NO      nvarchar(26),                       -- 사번
       EMP_NM      nvarchar(26),					   -- 성명
	   DEPT_CD     nvarchar(26),                       -- 부서코드
	   DEPT_NM	   nvarchar(26),				       -- 부서명
	   Net_Line    nvarchar(16),                       -- 지역구분(팸텍/구미/TIS)
	   Phone       nvarchar(26),                       -- KT전화번호
	   ETC_QTY1    nvarchar(40),					   -- 비고
	   ISRT_DT     datetime,						   -- 기입일
	   UPDT_EMP_NO nvarchar(40),					   -- 수정자
	   UPDT_DT     datetime      					   -- 수정일자

    
      CONSTRAINT PK_IP_DTL PRIMARY KEY (Row_Num,IP)
    
);


rollback
commit


begin tran
declare 
@count int,
@ip_head nvarchar(26),
@ip_body int
set @count = 1

while @count < 255
begin
set @ip_head = '192.168.180.'
--select @ip_body = convert(float,substring( max(ip),13,3))+1  from IP_DTL
select @ip_body = @count


insert into IP_DTL (Row_Num,ip,Net_Line) 
values (@count+508,concat(@ip_head,convert(nvarchar(40), @ip_body)),'TIS')
set @count= @count+1
end



