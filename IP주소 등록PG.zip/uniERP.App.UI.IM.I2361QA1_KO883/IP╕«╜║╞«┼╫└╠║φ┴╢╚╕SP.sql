--exec USP_I2359QA1_KO883 @EMP_NO=N'',@Pur_FROM=N'1900-01-01',@Pur_TO=N'2999-12-31',@PC_NAME=N'',@TV_NAME=N''

ALTER PROCEDURE [dbo].[USP_I2361QA1_KO883]            
 (                        
	  @EMP_NO    NVARCHAR(26) --���                
	, @DEPT_CD   NVARCHAR(26) --�μ���
    , @NET_LINE   NVARCHAR(26)--IP����(����/����/TIS)                  
	, @ET_Check   bit         --�� IPȮ��
 ) AS                      
                
 BEGIN                                          
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                    
                                       
SET NOCOUNT ON                    
             
    
select 
	*

from IP_DTL
where
 (@EMP_NO ='' or EMP_NO = @EMP_NO ) 
 and (@DEPT_CD ='' or DEPT_CD = @DEPT_CD )
 and (Net_Line =(CASE  WHEN @NET_LINE ='0' THEN '����'
					     WHEN @NET_LINE ='1' THEN '����'
					     WHEN @NET_LINE ='2' THEN 'TIS'
						 ELSE ''
				   END ))
 and (LEN(EMP_NM) < (CASE WHEN @ET_Check ='0' THEN 9999
                       ELSE 2
				  END  ))

 --   B.IP,
 --   B.EMP_NO,
	--B.EMP_NM,
	--B.DEPT_NM,
	--B.Net_Line,
	--B.Phone,
	--B.ETC_QTY1

 --from HAA010T A(NOLOCK)
 --join IP_DTL B(NOLOCK) on A.EMP_NO = B.EMP_NO  
 --where 
 --(@EMP_NO ='' or A.EMP_NO = @EMP_NO ) 
 --and (@DEPT_CD ='' or A.DEPT_CD = @DEPT_CD )
 --and (B.Net_Line =(CASE  WHEN @NET_LINE ='0' THEN '����'
	--				     WHEN @NET_LINE ='1' THEN '����'
	--				     WHEN @NET_LINE ='2' THEN 'TIS'
	--					 ELSE ''
	--			   END )) 
 --and (B.DEPT_NM= (CASE WHEN @ET_Check ='A' THEN ''
 --                      ELSE null
	--			  END  ))
  order by  Row_Num  
            
 END 

--exec USP_I2361QA1_KO883 @EMP_NO=N'',@DEPT_CD=N'',@NET_Line=N'0',@ET_Check=N'False'
