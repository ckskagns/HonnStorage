--drop procedure  [dbo].[USP_H4007M6_KO883]               
                
CREATE PROCEDURE [dbo].[USP_H4007M6_A_KO883]                
 (      
 
 @Work_From nvarchar(26), -- ��������From       
    @Work_To  nvarchar(26)  -- ��������To    
                 
 ) AS                          
                    
 BEGIN                                              
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                        
                                           
SET NOCOUNT ON                        
    
  IF @Work_From IS NULL OR @Work_From = '' SET @Work_From ='1900-01-01'         
  IF @Work_To IS NULL OR @Work_To = '' SET @Work_To ='2099-12-31'     
    
SELECT A.EMP_NO,A.NAME,CONVERT (varchar,A.WORK_DT,23) as WORK_DT
from WT_SG1_KO883 A            
join HAA010T B on A.EMP_NO = B.EMP_NO    

where
CONVERT (DATETIME, A.WORK_DT) BETWEEN  CONVERT (DATETIME, @Work_From) AND  CONVERT (DATETIME, @Work_To )  
AND convert(char(8),A.TOT_TIME,108) Like '%-%'
order by A.WORK_DT    
                
 END 

