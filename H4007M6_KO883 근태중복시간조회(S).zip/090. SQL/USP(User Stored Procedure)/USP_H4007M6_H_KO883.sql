--drop procedure  [dbo].[USP_H4007M6_KO883]               
                
ALTER PROCEDURE [dbo].[USP_H4007M6_H_KO883]                
 (      
 
 @Work_From nvarchar(26), -- ��������From       
    @Work_To  nvarchar(26)  -- ��������To    
                 
 ) AS                          
                    
 BEGIN                                              
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                        
                                           
SET NOCOUNT ON                        
    
  IF @Work_From IS NULL OR @Work_From = '' SET @Work_From ='1900-01-01'         
  IF @Work_To IS NULL OR @Work_To = '' SET @Work_To ='2099-12-31'     
    
SELECT A.EMP_NO,A.NAME,CONVERT (varchar,A.WORK_DT,23) as WORK_DT
from WT_SG1_KO883 A            
join HAA010T B on A.EMP_NO = B.EMP_NO    

where
CONVERT (DATETIME, A.WORK_DT) BETWEEN  CONVERT (DATETIME, @Work_From) AND  CONVERT (DATETIME, @Work_To )  
AND (A.ETC1 in ('����ٹ�1','����ٹ�2','����(����)') )
GROUP BY A.EMP_NO,A.NAME,A.WORK_DT 
HAVING COUNT(A.WORK_DT )>1  -- ���ڰ������� �ߺ������� ��ȸ
order by A.WORK_DT    
                
 END 

