﻿namespace uniERP.App.UI.FI.F2107MA2_KO883.tdsY8101M2_KO883TableAdapters
{
}
namespace uniERP.App.UI.FI.F2107MA2_KO883
{
    
    
    public partial class tdsY8101M2_KO883 {
        partial class E_FI_MA3DataTable
        {
        }
    
        partial class E_WT_MADataTable
        {
        }
    
        partial class E_WT_MA_DETAILDataTable
        {
        }   
        partial class E_WT_PROJECTDataTable
        {
        }
    }
}
