﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.HR.H4006M1_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem2 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem3 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.cboBizAreaCd = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.lblValidDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblBizArea = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDept = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTBL_1 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.popFrDeptNm = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblFromTo1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtFrInternalCd = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTBL_2 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.popToDeptNm = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.txtToInternalCd = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.popEmpNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblEmpNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtDilgTerm = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.lblBaseDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtBase = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.lblFlag = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.rdoConfYn = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboBizAreaCd)).BeginInit();
            this.uniTBL_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrInternalCd)).BeginInit();
            this.uniTBL_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtToInternalCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtBase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoConfYn)).BeginInit();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.ConditionRowCount = 3;
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(1004, 420);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.cboBizAreaCd, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblValidDt, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblBizArea, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblCd, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblDept, 2, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popCd, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.uniTBL_1, 3, 0);
            this.uniTBL_MainCondition.Controls.Add(this.uniTBL_2, 3, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popEmpNo, 3, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblEmpNo, 2, 2);
            this.uniTBL_MainCondition.Controls.Add(this.dtDilgTerm, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblBaseDt, 0, 3);
            this.uniTBL_MainCondition.Controls.Add(this.dtBase, 1, 3);
            this.uniTBL_MainCondition.Controls.Add(this.lblFlag, 2, 3);
            this.uniTBL_MainCondition.Controls.Add(this.rdoConfYn, 3, 3);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 4;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(1004, 107);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 0;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // cboBizAreaCd
            // 
            this.cboBizAreaCd.AddEmptyRow = true;
            this.cboBizAreaCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboBizAreaCd.ComboFrom = "";
            this.cboBizAreaCd.ComboMajorCd = "";
            this.cboBizAreaCd.ComboSelect = "";
            this.cboBizAreaCd.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboBizAreaCd.ComboWhere = "";
            this.cboBizAreaCd.DropDownListWidth = -1;
            this.cboBizAreaCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboBizAreaCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.cboBizAreaCd.Location = new System.Drawing.Point(140, 52);
            this.cboBizAreaCd.LockedField = false;
            this.cboBizAreaCd.Margin = new System.Windows.Forms.Padding(0);
            this.cboBizAreaCd.Name = "cboBizAreaCd";
            this.cboBizAreaCd.RequiredField = false;
            this.cboBizAreaCd.Size = new System.Drawing.Size(123, 22);
            this.cboBizAreaCd.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboBizAreaCd.StyleSetName = "Default";
            this.cboBizAreaCd.TabIndex = 14;
            this.cboBizAreaCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboBizAreaCd.uniALT = "Business Area";
            this.cboBizAreaCd.ValueChanged += new System.EventHandler(this.cboBizAreaCd_ValueChanged);
            // 
            // lblValidDt
            // 
            appearance1.TextHAlignAsString = "Left";
            appearance1.TextVAlignAsString = "Middle";
            this.lblValidDt.Appearance = appearance1;
            this.lblValidDt.AutoPopupID = null;
            this.lblValidDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblValidDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblValidDt.Location = new System.Drawing.Point(15, 6);
            this.lblValidDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblValidDt.Name = "lblValidDt";
            this.lblValidDt.Size = new System.Drawing.Size(125, 22);
            this.lblValidDt.StyleSetName = "Default";
            this.lblValidDt.TabIndex = 0;
            this.lblValidDt.Text = "Date";
            this.lblValidDt.UseMnemonic = false;
            // 
            // lblBizArea
            // 
            appearance2.TextHAlignAsString = "Left";
            appearance2.TextVAlignAsString = "Middle";
            this.lblBizArea.Appearance = appearance2;
            this.lblBizArea.AutoPopupID = null;
            this.lblBizArea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBizArea.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBizArea.Location = new System.Drawing.Point(15, 52);
            this.lblBizArea.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblBizArea.Name = "lblBizArea";
            this.lblBizArea.Size = new System.Drawing.Size(125, 22);
            this.lblBizArea.StyleSetName = "Default";
            this.lblBizArea.TabIndex = 13;
            this.lblBizArea.Text = "Business Area";
            this.lblBizArea.UseMnemonic = false;
            // 
            // lblCd
            // 
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.lblCd.Appearance = appearance3;
            this.lblCd.AutoPopupID = null;
            this.lblCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCd.Location = new System.Drawing.Point(15, 29);
            this.lblCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCd.Name = "lblCd";
            this.lblCd.Size = new System.Drawing.Size(125, 22);
            this.lblCd.StyleSetName = "Default";
            this.lblCd.TabIndex = 0;
            this.lblCd.Text = "Attendance";
            this.lblCd.UseMnemonic = false;
            // 
            // lblDept
            // 
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.lblDept.Appearance = appearance4;
            this.lblDept.AutoPopupID = null;
            this.lblDept.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDept.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDept.Location = new System.Drawing.Point(516, 6);
            this.lblDept.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDept.Name = "lblDept";
            this.lblDept.Size = new System.Drawing.Size(125, 22);
            this.lblDept.StyleSetName = "Default";
            this.lblDept.TabIndex = 0;
            this.lblDept.Text = "Department";
            this.lblDept.UseMnemonic = false;
            // 
            // popCd
            // 
            this.popCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popCd.AutoPopupCodeParameter = null;
            this.popCd.AutoPopupID = null;
            this.popCd.AutoPopupNameParameter = null;
            this.popCd.CodeMaxLength = 2;
            this.popCd.CodeName = "";
            this.popCd.CodeSize = 100;
            this.popCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCd.CodeTextBoxName = null;
            this.popCd.CodeValue = "";
            this.popCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popCd.Location = new System.Drawing.Point(140, 30);
            this.popCd.LockedField = false;
            this.popCd.Margin = new System.Windows.Forms.Padding(0);
            this.popCd.Name = "popCd";
            this.popCd.NameDisplay = true;
            this.popCd.NameId = null;
            this.popCd.NameMaxLength = 50;
            this.popCd.NamePopup = false;
            this.popCd.NameSize = 150;
            this.popCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCd.Parameter = null;
            this.popCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popCd.PopupId = null;
            this.popCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popCd.QueryIfEnterKeyPressed = true;
            this.popCd.RequiredField = false;
            this.popCd.Size = new System.Drawing.Size(271, 21);
            this.popCd.TabIndex = 3;
            this.popCd.uniALT = "Attendance";
            this.popCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popCd.UseDynamicFormat = false;
            this.popCd.ValueTextBoxName = null;
            this.popCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popCd_BeforePopupOpen);
            this.popCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popCd_AfterPopupClosed);
            // 
            // uniTBL_1
            // 
            this.uniTBL_1.AutoFit = false;
            this.uniTBL_1.AutoFitColumnCount = 4;
            this.uniTBL_1.AutoFitRowCount = 4;
            this.uniTBL_1.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_1.ColumnCount = 3;
            this.uniTBL_1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 271F));
            this.uniTBL_1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.uniTBL_1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_1.Controls.Add(this.popFrDeptNm, 0, 0);
            this.uniTBL_1.Controls.Add(this.lblFromTo1, 1, 0);
            this.uniTBL_1.Controls.Add(this.txtFrInternalCd, 2, 0);
            this.uniTBL_1.DefaultRowSize = 23;
            this.uniTBL_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_1.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_1.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_1.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_1.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_1.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_1.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_1.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_1.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_1.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_1.Location = new System.Drawing.Point(641, 5);
            this.uniTBL_1.Margin = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.uniTBL_1.Name = "uniTBL_1";
            this.uniTBL_1.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_1.RowCount = 1;
            this.uniTBL_1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_1.Size = new System.Drawing.Size(361, 23);
            this.uniTBL_1.SizeTD5 = 14F;
            this.uniTBL_1.SizeTD6 = 36F;
            this.uniTBL_1.TabIndex = 2;
            this.uniTBL_1.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_1.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // popFrDeptNm
            // 
            this.popFrDeptNm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popFrDeptNm.AutoPopupCodeParameter = null;
            this.popFrDeptNm.AutoPopupID = null;
            this.popFrDeptNm.AutoPopupNameParameter = null;
            this.popFrDeptNm.CodeMaxLength = 10;
            this.popFrDeptNm.CodeName = "";
            this.popFrDeptNm.CodeSize = 100;
            this.popFrDeptNm.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popFrDeptNm.CodeTextBoxName = null;
            this.popFrDeptNm.CodeValue = "";
            this.popFrDeptNm.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popFrDeptNm.Location = new System.Drawing.Point(0, 2);
            this.popFrDeptNm.LockedField = false;
            this.popFrDeptNm.Margin = new System.Windows.Forms.Padding(0);
            this.popFrDeptNm.Name = "popFrDeptNm";
            this.popFrDeptNm.NameDisplay = true;
            this.popFrDeptNm.NameId = null;
            this.popFrDeptNm.NameMaxLength = 50;
            this.popFrDeptNm.NamePopup = false;
            this.popFrDeptNm.NameSize = 150;
            this.popFrDeptNm.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popFrDeptNm.Parameter = null;
            this.popFrDeptNm.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popFrDeptNm.PopupId = null;
            this.popFrDeptNm.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popFrDeptNm.QueryIfEnterKeyPressed = true;
            this.popFrDeptNm.RequiredField = false;
            this.popFrDeptNm.Size = new System.Drawing.Size(271, 21);
            this.popFrDeptNm.TabIndex = 2;
            this.popFrDeptNm.uniALT = "FromDepartment";
            this.popFrDeptNm.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popFrDeptNm.UseDynamicFormat = false;
            this.popFrDeptNm.ValueTextBoxName = null;
            this.popFrDeptNm.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDeptNm_BeforePopupOpen);
            this.popFrDeptNm.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDeptNm_AfterPopupClosed);
            // 
            // lblFromTo1
            // 
            appearance5.TextHAlignAsString = "Left";
            appearance5.TextVAlignAsString = "Middle";
            this.lblFromTo1.Appearance = appearance5;
            this.lblFromTo1.AutoPopupID = null;
            this.lblFromTo1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Default_NoStyle;
            this.lblFromTo1.Location = new System.Drawing.Point(286, 1);
            this.lblFromTo1.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblFromTo1.Name = "lblFromTo1";
            this.lblFromTo1.Size = new System.Drawing.Size(1, 22);
            this.lblFromTo1.StyleSetName = "uniLabel_NoStyle";
            this.lblFromTo1.TabIndex = 1;
            this.lblFromTo1.Text = "~";
            this.lblFromTo1.UseMnemonic = false;
            // 
            // txtFrInternalCd
            // 
            this.txtFrInternalCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance6.TextVAlignAsString = "Bottom";
            this.txtFrInternalCd.Appearance = appearance6;
            this.txtFrInternalCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtFrInternalCd.Location = new System.Drawing.Point(281, 1);
            this.txtFrInternalCd.LockedField = false;
            this.txtFrInternalCd.Margin = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.txtFrInternalCd.Name = "txtFrInternalCd";
            this.txtFrInternalCd.QueryIfEnterKeyPressed = true;
            this.txtFrInternalCd.RequiredField = false;
            this.txtFrInternalCd.Size = new System.Drawing.Size(68, 22);
            this.txtFrInternalCd.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtFrInternalCd.StyleSetName = "Default";
            this.txtFrInternalCd.TabIndex = 2;
            this.txtFrInternalCd.uniALT = "From Intarnal Cd.";
            this.txtFrInternalCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtFrInternalCd.UseDynamicFormat = false;
            this.txtFrInternalCd.Visible = false;
            // 
            // uniTBL_2
            // 
            this.uniTBL_2.AutoFit = false;
            this.uniTBL_2.AutoFitColumnCount = 4;
            this.uniTBL_2.AutoFitRowCount = 4;
            this.uniTBL_2.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_2.ColumnCount = 3;
            this.uniTBL_2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 271F));
            this.uniTBL_2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.uniTBL_2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_2.Controls.Add(this.popToDeptNm, 0, 0);
            this.uniTBL_2.Controls.Add(this.txtToInternalCd, 2, 0);
            this.uniTBL_2.DefaultRowSize = 23;
            this.uniTBL_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_2.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_2.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_2.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_2.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_2.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_2.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_2.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_2.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_2.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_2.Location = new System.Drawing.Point(641, 28);
            this.uniTBL_2.Margin = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.uniTBL_2.Name = "uniTBL_2";
            this.uniTBL_2.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_2.RowCount = 1;
            this.uniTBL_2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_2.Size = new System.Drawing.Size(361, 23);
            this.uniTBL_2.SizeTD5 = 14F;
            this.uniTBL_2.SizeTD6 = 36F;
            this.uniTBL_2.TabIndex = 12;
            this.uniTBL_2.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_2.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // popToDeptNm
            // 
            this.popToDeptNm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popToDeptNm.AutoPopupCodeParameter = null;
            this.popToDeptNm.AutoPopupID = null;
            this.popToDeptNm.AutoPopupNameParameter = null;
            this.popToDeptNm.CodeMaxLength = 10;
            this.popToDeptNm.CodeName = "";
            this.popToDeptNm.CodeSize = 100;
            this.popToDeptNm.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popToDeptNm.CodeTextBoxName = null;
            this.popToDeptNm.CodeValue = "";
            this.popToDeptNm.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popToDeptNm.Location = new System.Drawing.Point(0, 2);
            this.popToDeptNm.LockedField = false;
            this.popToDeptNm.Margin = new System.Windows.Forms.Padding(0);
            this.popToDeptNm.Name = "popToDeptNm";
            this.popToDeptNm.NameDisplay = true;
            this.popToDeptNm.NameId = null;
            this.popToDeptNm.NameMaxLength = 50;
            this.popToDeptNm.NamePopup = false;
            this.popToDeptNm.NameSize = 150;
            this.popToDeptNm.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popToDeptNm.Parameter = null;
            this.popToDeptNm.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popToDeptNm.PopupId = null;
            this.popToDeptNm.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popToDeptNm.QueryIfEnterKeyPressed = true;
            this.popToDeptNm.RequiredField = false;
            this.popToDeptNm.Size = new System.Drawing.Size(271, 21);
            this.popToDeptNm.TabIndex = 4;
            this.popToDeptNm.uniALT = "To Department";
            this.popToDeptNm.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popToDeptNm.UseDynamicFormat = false;
            this.popToDeptNm.ValueTextBoxName = null;
            this.popToDeptNm.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDeptNm_BeforePopupOpen);
            this.popToDeptNm.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDeptNm_AfterPopupClosed);
            // 
            // txtToInternalCd
            // 
            this.txtToInternalCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance7.TextVAlignAsString = "Bottom";
            this.txtToInternalCd.Appearance = appearance7;
            this.txtToInternalCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtToInternalCd.Location = new System.Drawing.Point(281, 1);
            this.txtToInternalCd.LockedField = false;
            this.txtToInternalCd.Margin = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.txtToInternalCd.Name = "txtToInternalCd";
            this.txtToInternalCd.QueryIfEnterKeyPressed = true;
            this.txtToInternalCd.RequiredField = false;
            this.txtToInternalCd.Size = new System.Drawing.Size(68, 22);
            this.txtToInternalCd.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtToInternalCd.StyleSetName = "Default";
            this.txtToInternalCd.TabIndex = 0;
            this.txtToInternalCd.uniALT = "To Internal Cd.";
            this.txtToInternalCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtToInternalCd.UseDynamicFormat = false;
            this.txtToInternalCd.Visible = false;
            // 
            // popEmpNo
            // 
            this.popEmpNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popEmpNo.AutoPopupCodeParameter = null;
            this.popEmpNo.AutoPopupID = null;
            this.popEmpNo.AutoPopupNameParameter = null;
            this.popEmpNo.CodeMaxLength = 13;
            this.popEmpNo.CodeName = "";
            this.popEmpNo.CodeSize = 100;
            this.popEmpNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popEmpNo.CodeTextBoxName = null;
            this.popEmpNo.CodeValue = "";
            this.popEmpNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popEmpNo.Location = new System.Drawing.Point(641, 53);
            this.popEmpNo.LockedField = false;
            this.popEmpNo.Margin = new System.Windows.Forms.Padding(0);
            this.popEmpNo.Name = "popEmpNo";
            this.popEmpNo.NameDisplay = true;
            this.popEmpNo.NameId = "";
            this.popEmpNo.NameMaxLength = 50;
            this.popEmpNo.NamePopup = false;
            this.popEmpNo.NameSize = 150;
            this.popEmpNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popEmpNo.Parameter = null;
            this.popEmpNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popEmpNo.PopupId = null;
            this.popEmpNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popEmpNo.QueryIfEnterKeyPressed = true;
            this.popEmpNo.RequiredField = false;
            this.popEmpNo.Size = new System.Drawing.Size(271, 21);
            this.popEmpNo.TabIndex = 5;
            this.popEmpNo.uniALT = "Employee";
            this.popEmpNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popEmpNo.UseDynamicFormat = false;
            this.popEmpNo.ValueTextBoxName = null;
            this.popEmpNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popEmpNo_BeforePopupOpen);
            this.popEmpNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popEmpNo_AfterPopupClosed);
            // 
            // lblEmpNo
            // 
            appearance8.TextHAlignAsString = "Left";
            appearance8.TextVAlignAsString = "Middle";
            this.lblEmpNo.Appearance = appearance8;
            this.lblEmpNo.AutoPopupID = null;
            this.lblEmpNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmpNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblEmpNo.Location = new System.Drawing.Point(516, 52);
            this.lblEmpNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblEmpNo.Name = "lblEmpNo";
            this.lblEmpNo.Size = new System.Drawing.Size(125, 22);
            this.lblEmpNo.StyleSetName = "Default";
            this.lblEmpNo.TabIndex = 0;
            this.lblEmpNo.Text = "Employee";
            this.lblEmpNo.UseMnemonic = false;
            // 
            // dtDilgTerm
            // 
            this.dtDilgTerm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtDilgTerm.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtDilgTerm.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtDilgTerm.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtDilgTerm.Location = new System.Drawing.Point(140, 7);
            this.dtDilgTerm.Margin = new System.Windows.Forms.Padding(0);
            this.dtDilgTerm.Name = "dtDilgTerm";
            this.dtDilgTerm.Size = new System.Drawing.Size(225, 21);
            this.dtDilgTerm.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtDilgTerm.TabIndex = 15;
            this.dtDilgTerm.uniFromALT = null;
            this.dtDilgTerm.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtDilgTerm.uniTabSameValue = false;
            this.dtDilgTerm.uniToALT = null;
            this.dtDilgTerm.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // lblBaseDt
            // 
            appearance9.TextHAlignAsString = "Left";
            appearance9.TextVAlignAsString = "Middle";
            this.lblBaseDt.Appearance = appearance9;
            this.lblBaseDt.AutoPopupID = null;
            this.lblBaseDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBaseDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBaseDt.Location = new System.Drawing.Point(15, 75);
            this.lblBaseDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblBaseDt.Name = "lblBaseDt";
            this.lblBaseDt.Size = new System.Drawing.Size(125, 22);
            this.lblBaseDt.StyleSetName = "Default";
            this.lblBaseDt.TabIndex = 13;
            this.lblBaseDt.Text = "BaseDt";
            this.lblBaseDt.UseMnemonic = false;
            // 
            // dtBase
            // 
            this.dtBase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance10.TextHAlignAsString = "Center";
            this.dtBase.Appearance = appearance10;
            this.dtBase.DateTime = new System.DateTime(2016, 12, 29, 0, 0, 0, 0);
            this.dtBase.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.Default;
            this.dtBase.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtBase.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtBase.Location = new System.Drawing.Point(140, 75);
            this.dtBase.LockedField = false;
            this.dtBase.Margin = new System.Windows.Forms.Padding(0);
            this.dtBase.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtBase.Name = "dtBase";
            this.dtBase.QueryIfEnterKeyPressed = true;
            this.dtBase.RequiredField = false;
            this.dtBase.Size = new System.Drawing.Size(100, 22);
            this.dtBase.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtBase.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.Default;
            this.dtBase.StyleSetName = "Default";
            this.dtBase.TabIndex = 16;
            this.dtBase.uniALT = "baseDt";
            this.dtBase.uniValue = new System.DateTime(2016, 12, 29, 0, 0, 0, 0);
            this.dtBase.Value = new System.DateTime(2016, 12, 29, 0, 0, 0, 0);
            // 
            // lblFlag
            // 
            appearance11.TextHAlignAsString = "Left";
            appearance11.TextVAlignAsString = "Middle";
            this.lblFlag.Appearance = appearance11;
            this.lblFlag.AutoPopupID = null;
            this.lblFlag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFlag.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblFlag.Location = new System.Drawing.Point(516, 75);
            this.lblFlag.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblFlag.Name = "lblFlag";
            this.lblFlag.Size = new System.Drawing.Size(125, 22);
            this.lblFlag.StyleSetName = "Default";
            this.lblFlag.TabIndex = 17;
            this.lblFlag.Text = "승인여부";
            this.lblFlag.UseMnemonic = false;
            // 
            // rdoConfYn
            // 
            this.rdoConfYn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rdoConfYn.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.rdoConfYn.CheckedIndex = 0;
            this.rdoConfYn.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            valueListItem1.DataValue = "A";
            valueListItem1.DisplayText = "전체";
            valueListItem2.DataValue = "Y";
            valueListItem2.DisplayText = "승인";
            valueListItem3.DataValue = "N";
            valueListItem3.DisplayText = "미승인";
            this.rdoConfYn.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1,
            valueListItem2,
            valueListItem3});
            this.rdoConfYn.ItemSpacingHorizontal = 30;
            this.rdoConfYn.ItemSpacingVertical = 10;
            this.rdoConfYn.Location = new System.Drawing.Point(641, 78);
            this.rdoConfYn.LockedField = false;
            this.rdoConfYn.Margin = new System.Windows.Forms.Padding(0, 4, 1, 0);
            this.rdoConfYn.Name = "rdoConfYn";
            this.rdoConfYn.RequiredField = false;
            this.rdoConfYn.Size = new System.Drawing.Size(349, 19);
            this.rdoConfYn.StyleSetName = "Default";
            this.rdoConfYn.TabIndex = 18;
            this.rdoConfYn.Text = "전체";
            this.rdoConfYn.uniALT = null;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.DefaultRowSize = 25;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(1004, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 5;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.DefaultRowSize = 25;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 391);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(1004, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 143);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(1004, 245);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 4;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance12.BackColor = System.Drawing.SystemColors.Window;
            appearance12.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance12;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance13.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance13.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance13;
            appearance14.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance14;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance15.BackColor2 = System.Drawing.SystemColors.Control;
            appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance15.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance15;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance16.BackColor = System.Drawing.SystemColors.Window;
            appearance16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance16;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance17.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance17;
            appearance18.BorderColor = System.Drawing.Color.Silver;
            appearance18.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance18;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance19.BackColor = System.Drawing.SystemColors.Control;
            appearance19.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance19.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance19.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance19;
            appearance20.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance20;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance21.BackColor = System.Drawing.SystemColors.Window;
            appearance21.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance21;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance22.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance22;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(1004, 245);
            this.uniGrid1.StyleSetName = "Default";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.uniGrid1_BeforePopupOpen);
            this.uniGrid1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.uniGrid1_AfterPopupClosed);
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(1015, 440);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboBizAreaCd)).EndInit();
            this.uniTBL_1.ResumeLayout(false);
            this.uniTBL_1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrInternalCd)).EndInit();
            this.uniTBL_2.ResumeLayout(false);
            this.uniTBL_2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtToInternalCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtBase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoConfYn)).EndInit();
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniLabel lblValidDt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblEmpNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDept;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popEmpNo;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popFrDeptNm;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popToDeptNm;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblFromTo1;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtFrInternalCd;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_2;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtToInternalCd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBizArea;
        private uniERP.AppFramework.UI.Controls.uniCombo cboBizAreaCd;
        private uniERP.AppFramework.UI.Controls.uniDateTerm dtDilgTerm;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBaseDt;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtBase;
        private AppFramework.UI.Controls.uniLabel lblFlag;
        private AppFramework.UI.Controls.uniRadioButton rdoConfYn;

    }
}
