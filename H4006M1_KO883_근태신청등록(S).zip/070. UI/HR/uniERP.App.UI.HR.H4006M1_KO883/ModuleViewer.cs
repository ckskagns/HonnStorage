﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;

using uniERP.AppFramework.UI.Controls.Popup;
using uniERP.AppFramework.DataBridge;

#endregion

namespace uniERP.App.UI.HR.H4006M1_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①namespace</NameSpace>
        /// <Module>②module name</Module>
        /// <Class>③class name</Class>
        /// <Desc>④
        ///   펨텍 - 근태신청등록(S)
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="HSY" Date="2018-06-04">근태신청승인 프로세스 중 개인별 근태신청자료 등록하는 화면</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        private tdsDataSet cqtdsDataSet = new tdsDataSet();
        private bool _isEmpChange = false;
        #endregion

        #region ■ 1.4 Class global constants (grid)


        #endregion

        #region ■ 1.5 Class global variables (grid)

        // change your code
        //private wsMyBizFL.TypedDataSet dsAnyName = new wsMyBizFL.TypedDataSet();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(cqtdsDataSet);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.Common);  // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format
        }

        protected override void Form_Load_Completed()
        {
            //dtValidDt.Focus();
            dtDilgTerm.uniDateTimeF.Focus();
            uniBase.UCommon.SetToolBarMultiAll(false);
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            // init Dataset Row : change your code
            //dsAnyName.Clear();
            base.viewDBSaveMode = enumDef.DBSaveMode.CreateMode;
            cqtdsDataSet.Clear();
        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            // TO-DO: Assign default value to controls
            // dtValidDt.Value = uniBase.UDate.GetDBServerDateTime();
            //20151104
            dtDilgTerm.uniDateTimeF.Value = uniBase.UDate.GetDBServerDateTime();
            dtDilgTerm.uniDateTimeT.Value = uniBase.UDate.GetDBServerDateTime();
            //dtDilgTerm.uniDateTimeT.Value = uniBase.UDate.GetDBServerDateTime();
            dtBase.uniValue = uniBase.UDate.GetDBServerDateTime();

            return;
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            uniBase.UData.ComboCustomAdd(cboBizAreaCd.Name, "b_biz_area.biz_area_cd CODE, b_biz_area.biz_area_nm NAME ",
    "b_biz_area join dbo.ufn_AuthBizAreaCD_ByUsrID('" + CommonVariable.gUsrID + "') AUTH ON b_biz_area.biz_area_cd = AUTH.biz_area_cd", "1=1");
            uniBase.UData.ComboMajorAdd("CONF_YN", "XH001");

        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆
            base.viewTB19029.ggUserDefined6.DecPoint = 0;
            base.viewTB19029.ggUserDefined6.Integeral = 2;
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            tdsDataSet.IE_DATADataTable uniGridTB = cqtdsDataSet.IE_DATA;
            //20151104
            this.uniGrid1.SSSetDate(uniGridTB.dilig_dtColumn.ColumnName, "Attendance Date.", enumDef.FieldType.Primary, CommonVariable.CDT_YYYY_MM_DD);

            this.uniGrid1.SSSetEdit(uniGridTB.emp_noColumn.ColumnName, "Employee ID.", enumDef.FieldType.Primary, true, 13);
            this.uniGrid1.SSSetEdit(uniGridTB.nameColumn.ColumnName, "Name", enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB.roll_pstn_nmColumn.ColumnName, "Position", 100, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB.dept_nmColumn.ColumnName, "Department", 120, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetEdit(uniGridTB.biz_area_nmColumn.ColumnName, "Business Area", 120, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);//사업장명
            this.uniGrid1.SSSetEdit(uniGridTB.dilig_cdColumn.ColumnName, "Attendance Code", enumDef.FieldType.Primary, true, 2);
            this.uniGrid1.SSSetEdit(uniGridTB.dilig_nmColumn.ColumnName, "Attendance Name", 100, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);
            this.uniGrid1.SSSetFloat(uniGridTB.dilig_hhColumn.ColumnName, "Hour", 100, viewTB19029.ggUserDefined6, enumDef.FieldType.Primary, enumDef.HAlign.Right, true, enumDef.PosZero.Positive, 0, 23); //hour
            this.uniGrid1.SSSetFloat(uniGridTB.dilig_mmColumn.ColumnName, "Min", 100, viewTB19029.ggUserDefined6, enumDef.FieldType.Primary, enumDef.HAlign.Right, true, enumDef.PosZero.Positive, 0, 59); //min
            this.uniGrid1.SSSetEdit(uniGridTB.day_timeColumn.ColumnName, "day time", enumDef.FieldType.ReadOnly); // 2012년 01/14  FH10494 관련 추가

            this.uniGrid1.SSSetEdit(uniGridTB.remarkColumn.ColumnName, "비고", 200, enumDef.FieldType.Default);
            this.uniGrid1.SSSetCombo(uniGridTB.conf_ynColumn.ColumnName, "승인여부", viewDataSet.Tables["CONF_YN"], enumDef.FieldType.ReadOnly);

            this.uniGrid1.SSSetEdit(uniGridTB.biz_area_cdColumn.ColumnName, " ", enumDef.FieldType.ReadOnly);


            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.flagInformation("cud_char", "row_num");
            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            // Hidden Column Setting
            uniGrid1.SSSetColHidden(uniGridTB.biz_area_nmColumn.ColumnName);
            uniGrid1.SSSetColHidden(uniGridTB.biz_area_cdColumn.ColumnName);
            uniGrid1.SSSetColHidden(uniGridTB.day_timeColumn.ColumnName);
            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
            // TO-DO: 컨트롤을 초기화(또는 초기값)할때 할일 
            // SetDefaultVal과의 차이점은 전자는 Form_Load 시점에 콘트롤에 초기값을 세팅하는것이고
            // 후자는 특정 시점(조회후 또는 행추가후 등 특정이벤트)에서 초기값을 셋팅한다.
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(cqtdsDataSet.IE_DATA);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {

            //TO-DO : code business oriented logic
            if (!uniBase.UString.CompareUNIOpenPopupCode(popFrDeptNm, popToDeptNm))
            {

                return false;
            }
            if (dtDilgTerm.uniDateTimeF.Value == null)
                dtDilgTerm.uniDateTimeF.uniValue = Convert.ToDateTime("1900-01-01");

            if (string.IsNullOrEmpty(dtDilgTerm.uniDateTimeF.Value.ToString()))
            {
                dtDilgTerm.uniDateTimeF.uniValue = Convert.ToDateTime("1900-01-01");
            }

            if (dtDilgTerm.uniDateTimeT.Value == null)
                dtDilgTerm.uniDateTimeT.uniValue = Convert.ToDateTime("2999-12-31");

            if (string.IsNullOrEmpty(dtDilgTerm.uniDateTimeT.Value.ToString()))
            {
                dtDilgTerm.uniDateTimeT.uniValue = Convert.ToDateTime("2999-12-31");
            }

            if (!uniBase.UDate.CompareDateBetween(dtDilgTerm.uniDateTimeF, dtDilgTerm.uniDateTimeT))
            {
                return false;
            }

            if (dtDilgTerm.uniDateTimeF.uniValue == Convert.ToDateTime("1900-01-01"))
            {
                dtDilgTerm.uniDateTimeF.Value = null;
            }
            if (dtDilgTerm.uniDateTimeT.uniValue == Convert.ToDateTime("2999-12-31"))
            {
                dtDilgTerm.uniDateTimeT.Value = null;
            }

            return DBQuery();
        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)

        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic
            string str_select_SQL = null;
            string str_from_SQL = null;
            string str_where_SQL = null;
            DataSet temp_ds = null;
            uniDateTime temp_date = new uniDateTime();
            string strReturn_value = "N";
            DateTime strCloseDt, strValidDt;

            tdsDataSet istdsHListDailyAttendance = new tdsDataSet();

            tdsDataSet.IE_DATADataTable tb1 = (tdsDataSet.IE_DATADataTable)cqtdsDataSet.IE_DATA.GetChanges();
            istdsHListDailyAttendance.IE_DATA.Merge(tb1, false, MissingSchemaAction.Ignore);

            for (int i = 0; i < istdsHListDailyAttendance.IE_DATA.Rows.Count; i++)
            {
                temp_date.uniValue = istdsHListDailyAttendance.IE_DATA[i].dilig_dt;
                str_select_SQL = " Retire_dt ";
                str_from_SQL = " haa010t a ";
                str_where_SQL = " EMP_NO= '" + istdsHListDailyAttendance.IE_DATA[i].emp_no.ToString() + "' AND isnull(retire_dt, '" + uniBase.UDate.DateTimeToString(temp_date, "", CommonVariable.CDT_YYYY_MM_DD) + "' ) < '" + uniBase.UDate.DateTimeToString(temp_date, "", CommonVariable.CDT_YYYY_MM_DD) + "'";

                temp_ds = uniBase.UDataAccess.CommonQueryRs(str_select_SQL, str_from_SQL, str_where_SQL);

                if (temp_ds != null && temp_ds.Tables[0].Rows.Count != 0)
                {
                    // FH10022 :  메세지 수정 (2012-05-14)
                    //uniBase.UMessage.DisplayMessageBox("800494", MessageBoxButtons.OK, uniBase.UDate.DateTimeToString(temp_date, "", CommonVariable.CDT_YYYY_MM_DD), temp_ds.Tables[0].Columns[0].ToString());
                    String ret_date = temp_ds.Tables[0].Rows[0]["Retire_dt"].ToString().Substring(0, 10);

                    uniBase.UMessage.DisplayMessageBox("800494", MessageBoxButtons.OK, "사번 " + istdsHListDailyAttendance.IE_DATA[i].emp_no.ToString(), ret_date.ToString());
                    return false;
                }
                //20120619-199105  저장시, 해당사원의 사업장으로 마감체크하도록 row단위 저장 
                str_select_SQL = " close_type, convert(char(10),close_dt,20), emp_no ";
                str_from_SQL = " hda270t ";
                //str_where_SQL = " org_cd = '1' AND pay_gubun = 'Z' AND PAY_TYPE ='#' AND BIZ_AREA_CD='"+cboBizAreaCd.SelectedItem.DataValue.ToString()+"'";
                str_where_SQL = " org_cd = '1' AND pay_gubun = 'Z' AND PAY_TYPE ='#' AND BIZ_AREA_CD='" + istdsHListDailyAttendance.IE_DATA[i].biz_area_cd.ToString() + "'";

                temp_ds = uniBase.UDataAccess.CommonQueryRs(str_select_SQL, str_from_SQL, str_where_SQL);

                if (temp_ds != null && temp_ds.Tables[0].Rows.Count != 0)
                {
                    strCloseDt = Convert.ToDateTime(temp_ds.Tables[0].Rows[0][1].ToString());
                    // strValidDt = Convert.ToDateTime(uniBase.UDate.DateTimeToString(dtValidDt, "", CommonVariable.CDT_YYYY_MM_DD));
                    //20151104
                    strValidDt = Convert.ToDateTime(istdsHListDailyAttendance.IE_DATA[i].dilig_dt);//(uniBase.UDate.DateTimeToString(dtValidDt, "", CommonVariable.CDT_YYYY_MM_DD));

                    switch (temp_ds.Tables[0].Rows[0][0].ToString())
                    {
                        case "1":  //마감형태 : 정상 
                            if (strCloseDt <= strValidDt)
                            {
                                strReturn_value = "Y";
                            }
                            else
                            {
                                strReturn_value = "N";
                            }
                            break;
                        case "2":  //마감형태 : 마감 
                            if (strCloseDt < strValidDt)
                            {
                                strReturn_value = "Y";
                            }
                            else
                            {
                                strReturn_value = "N";
                            }
                            break;
                    }
                }
                else
                {
                    strReturn_value = "Y";
                }

                if (strReturn_value == "N")
                {
                    uniBase.UMessage.DisplayMessageBox("800291", MessageBoxButtons.OK, "X", "X");

                    return false;
                }

            }

            return DBSave();
        }

        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic
            //this.uniGrid1.ActiveRow.Cells["dilig_dt"].Value = dtValidDt.uniValue.ToShortDateString();
            //날짜형식 변경 2007/11/27
            //this.uniGrid1.ActiveRow.Cells["dilig_dt"].Value = uniBase.UDate.DateTimeToString(dtValidDt, "", CommonVariable.CDT_YYYY_MM_DD);
            //20151004
            if (dtBase.uniValue.Year.ToString().Equals("1"))
            {
                this.uniGrid1.ActiveRow.Cells["dilig_dt"].Value = uniBase.UDate.GetDBServerDateTime();// uniBase.UDate.DateTimeToString(uniBase.UDate.GetDBServerDateTime(), "", CommonVariable.CDT_YYYY_MM_DD);
            }
            else
            {
                this.uniGrid1.ActiveRow.Cells["dilig_dt"].Value = dtBase.Value;
            }
            if (!string.IsNullOrEmpty(this.popEmpNo.CodeValue.ToString()))
            {

                //this.uniGrid1_AfterExitEditMode(null, null);  // 인서트 로우할때 해당 사번으로 사번, 직위, 이름, 사업장등을 자동으로 넣어주기 위해
                //this.uniGrid1_ClickCellButton(null, null);
                this.uniGrid1.ActiveRow.Cells["emp_no"].Value = this.popEmpNo.CodeValue.ToString();
                this.uniGrid1.ActiveRow.Cells["EMP_NO"].Activate();
                this.uniGrid1.UpdatePopupNameByCode();

                return false;
            }
            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)

        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            //uniGrid1.ActiveRow.Cells["dilig_hh"].Value = 
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            string istrValidDtF = string.Empty;
            string istrValidDtT = string.Empty;
            string istrDiligCd = string.Empty;
            string istrFrInternalCd = string.Empty;
            string istrToInternalCd = string.Empty;
            string istrEmpNo = string.Empty;
            string istrBizAreaCd = string.Empty;

            string istrBaseDt = string.Empty;
            string istrConfYn = string.Empty;

            //istrValidDt = dtValidDt.uniValue.ToShortDateString();
            //날짜형식 변경 2007/11/27
            istrValidDtF = uniBase.UDate.DateTimeToString(dtDilgTerm.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD);
            istrValidDtT = uniBase.UDate.DateTimeToString(dtDilgTerm.uniDateTimeT, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD);

            
            istrDiligCd = string.IsNullOrEmpty(popCd.CodeValue) ? "" : popCd.CodeValue;
            istrFrInternalCd = string.IsNullOrEmpty(popFrDeptNm.CodeValue) ? "" : txtFrInternalCd.Text;
            istrToInternalCd = string.IsNullOrEmpty(popToDeptNm.CodeValue) ? "" : txtToInternalCd.Text;
            istrEmpNo = string.IsNullOrEmpty(popEmpNo.CodeValue) ? "" : popEmpNo.CodeValue;
            istrBizAreaCd = string.IsNullOrEmpty(cboBizAreaCd.SelectedItem.DataValue.ToString()) ? "%" : cboBizAreaCd.SelectedItem.DataValue.ToString();

            istrConfYn = rdoConfYn.Value.ToString();
            if ( dtBase.Value == null)
                istrBaseDt = "";
            else
                istrBaseDt = dtBase.uniValue.ToString(CommonVariable.CDT_YYYY_MM_DD);

            try
            {
                DataSet ds = new DataSet();
                using (uniCommand unicmd1 = uniBase.UDatabase.GetStoredProcCommand("USP_HR_H4006M1_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(unicmd1, "@DILIG_DT_FR", SqlDbType.NVarChar, istrValidDtF);
                    uniBase.UDatabase.AddInParameter(unicmd1, "@DILIG_DT_TO", SqlDbType.NVarChar, istrValidDtT);
                    uniBase.UDatabase.AddInParameter(unicmd1, "@BIZ_AREA_CD", SqlDbType.NVarChar, istrBizAreaCd);
                    uniBase.UDatabase.AddInParameter(unicmd1, "@DILIG_CD", SqlDbType.NVarChar, istrDiligCd);
                    uniBase.UDatabase.AddInParameter(unicmd1, "@EMP_NO", SqlDbType.NVarChar, istrEmpNo);
                    uniBase.UDatabase.AddInParameter(unicmd1, "@INTERNAL_CD_FR", SqlDbType.NVarChar, istrFrInternalCd);
                    uniBase.UDatabase.AddInParameter(unicmd1, "@INTERNAL_CD_TO", SqlDbType.NVarChar, istrToInternalCd);
                    uniBase.UDatabase.AddInParameter(unicmd1, "@BASE_DT", SqlDbType.NVarChar, istrBaseDt);
                    uniBase.UDatabase.AddInParameter(unicmd1, "@CONF_YN", SqlDbType.NVarChar, istrConfYn);
                    uniBase.UDatabase.AddInParameter(unicmd1, "@USER_ID", SqlDbType.NVarChar, CommonVariable.gUsrID);

                    DataSet dsData = uniBase.UDatabase.ExecuteDataSet(unicmd1);

                    if (dsData == null || dsData.Tables.Count == 0 || dsData.Tables[0].Rows.Count == 0)
                    {
                        uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                        return true;
                    }
                    else
                    {
                        cqtdsDataSet.IE_DATA.Merge(dsData.Tables[0], false, MissingSchemaAction.Ignore);
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                uniBase.UCommon.SetToolBarAll(false);
                uniBase.UCommon.SetToolBarCommonAll(true);
                uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.InsertRow | enumDef.ToolBitMulti.DeleteRow | enumDef.ToolBitMulti.Cancel | enumDef.ToolBitMulti.CopyRow, true);
            }

            foreach (UltraGridRow row in uniGrid1.Rows)       //조회후 그리드에 Day_time이 2번(시간근태)일 경우는 풀어준다.    2013.01.14
            {
                switch (row.Cells["day_time"].Value.ToString())
                {
                    case "2":
                        uniGrid1.SpreadUnLock(cqtdsDataSet.IE_DATA.dilig_hhColumn.ColumnName, row.Index, row.Index);
                        uniGrid1.SpreadUnLock(cqtdsDataSet.IE_DATA.dilig_mmColumn.ColumnName, row.Index, row.Index);

                        break;
                }
            }

            return true;

        }

        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            this.uniGrid1.ActiveRow = null;

            string istrEmpNm = string.Empty;
            string istrNm = string.Empty;
            string istrValidDt = string.Empty;
            string istrSelect = string.Empty;
            string istrFrom = string.Empty;
            string istrWhere = string.Empty;
            string istrEmpNo = string.Empty;
            string istrRetCd = string.Empty;
            string istrCd = string.Empty;
            string istrDayTime = string.Empty;
            string istrHour = string.Empty;
            string istrMin = string.Empty;
            bool ibHFlag = false;
            bool ibMFlag = false;
            string istrReturnValue = string.Empty;
            string istrCloseDt = string.Empty;

            DataTable tbMulti = new DataTable();

            try
            {
                tbMulti.Merge(new tdsDataSet.IE_DATADataTable(), false, MissingSchemaAction.Add);

                if (cqtdsDataSet.IE_DATA.GetChanges() != null)
                    tbMulti.Merge(cqtdsDataSet.IE_DATA.GetChanges(), false, MissingSchemaAction.Ignore);

            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }


            for (int i = 0; i < tbMulti.Rows.Count; i++)
            {
                //2011.08.29 추가
                string hhValue = tbMulti.Rows[i]["dilig_hh"].ToString();
                if (string.IsNullOrEmpty(hhValue) == true)
                {
                    tbMulti.Rows[i]["dilig_hh"] = "0";
                }
                if (tbMulti.Rows[i]["cud_char"].ToString() == "U")
                {
                    istrEmpNm = tbMulti.Rows[i]["name"].ToString();

                    if (string.IsNullOrEmpty(istrEmpNm) == true)
                    {
                        uniBase.UMessage.DisplayMessageBox("800048", MessageBoxButtons.OK, "X", "X");
                        return false;
                    }

                    istrNm = tbMulti.Rows[i]["dilig_nm"].ToString();

                    if (string.IsNullOrEmpty(istrNm) == true)
                    {
                        uniBase.UMessage.DisplayMessageBox("800099", MessageBoxButtons.OK, "X", "X");
                        return false;
                    }


                    istrDayTime = tbMulti.Rows[i]["day_time"].ToString();  // FH10494 그리드에 Day_time값을 가지고 온다.



                    if (istrDayTime == "2") //'근태코드테이블(hca010t)의 일수구분이 시간일 경우만 해당됨.
                    {
                        istrHour = tbMulti.Rows[i]["dilig_hh"].ToString();

                        if (istrHour == "0")
                        {
                            //istdsHListDailyAttendance.E_HCA060T[i][istdsHListDailyAttendance.E_HCA060T.dilig_hhColumn] = "0";
                            ibHFlag = true;
                        }
                        else
                        {
                            ibHFlag = false;
                        }


                        istrMin = tbMulti.Rows[i]["dilig_mm"].ToString();
                        if (istrMin == "0")
                        {
                            //istdsHListDailyAttendance.E_HCA060T[i][istdsHListDailyAttendance.E_HCA060T.dilig_mmColumn] = "0";
                            ibMFlag = true;
                        }
                        else
                        {
                            ibMFlag = false;
                        }

                        if (ibHFlag && ibMFlag)
                        {
                            uniBase.UMessage.DisplayMessageBox("800443", MessageBoxButtons.OK, "시간/분", "0");
                            return false;
                        }
                    }
                }
                if (tbMulti.Rows[i]["cud_char"].ToString() != "D")  //20170926-272913 
                {
                    if (!SubCheckHoliday(tbMulti.Rows[i]))
                    {
                        return false;
                    }
                }
                else
                {
                    if (tbMulti.Rows[i]["conf_yn"].ToString() == "Y")
                    {
                        uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "승인된 데이터는 삭제할 수 없습니다.");
                        return false;
                    }
                }


            }


            try
            {
                using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_HR_H4006M1_KO883_CUD"))
                {
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@TBL_GRID", SqlDbType.Structured, tbMulti);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PARAM_USER_ID", SqlDbType.NVarChar, CommonVariable.gUsrID);
                    uniBase.UDatabase.AddOutParameter(iuniCommand, "@MSG_CD", SqlDbType.NVarChar, 6);
                    uniBase.UDatabase.AddOutParameter(iuniCommand, "@MESSAGE", SqlDbType.NVarChar, 200);

                    uniBase.UDatabase.AddReturnParameter(iuniCommand, "RETURN_VALUE", SqlDbType.Int, 1);
                    uniBase.UDatabase.ExecuteNonQuery(iuniCommand, false);

                    int iReturn = (int)uniBase.UDatabase.GetParameterValue(iuniCommand, "RETURN_VALUE");

                    if (iReturn < 0)
                    {
                        string sMsgCd = uniBase.UDatabase.GetParameterValue(iuniCommand, "@MSG_CD") as string;
                        string sMessage = uniBase.UDatabase.GetParameterValue(iuniCommand, "@MESSAGE") as string;


                        if (string.IsNullOrEmpty(sMsgCd)) sMsgCd = "DT9999";

                        uniBase.UMessage.DisplayMessageBox(sMsgCd, MessageBoxButtons.OK, sMessage);

                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            return true;



        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group


        #endregion

        #region ■ 5.2 Grid   control event implementation group

        #region ■■ 5.2.1 ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ButtonClicked >>> ClickCellButton

        #region ■■ 5.2.2 Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>


        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {


        }
        #endregion ■■ Change >>> CellChange

        #region ■■ 5.2.3 Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
        }
        #endregion ■■ Click >>> AfterSelectChange

        #region ■■ 5.2.4 ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ComboSelChange >>> CellListSelect

        #region ■■ 5.2.5 DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
        }
        #endregion ■■ DblClick >>> DoubleClickCell

        #region ■■ 5.2.6 MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
        }
        #endregion ■■ MouseDown >>> MouseDown

        #region ■■ 5.2.7 ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
        }
        #endregion ■■ ScriptLeaveCell >>> BeforeCellDeactivate


        private void uniGrid1_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            switch (this.uniGrid1.ActiveCell.Column.Key)
            {
                case "emp_no":
                    this.uniGrid1.ActiveRow.Cells["emp_no"].Value = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
                    this.uniGrid1.ActiveRow.Cells["name"].Value = iDataSet.Tables[0].Rows[0]["name"].ToString();
                    this.uniGrid1.ActiveRow.Cells["dept_cd"].Value = iDataSet.Tables[0].Rows[0]["dept_cd"].ToString();
                    this.uniGrid1.ActiveRow.Cells["dept_nm"].Value = iDataSet.Tables[0].Rows[0]["dept_nm"].ToString();
                    this.uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = iDataSet.Tables[0].Rows[0]["roll_pstn_nm"].ToString();
                    this.uniGrid1.ActiveRow.Cells["biz_area_cd"].Value = iDataSet.Tables[0].Rows[0]["biz_area_cd"].ToString();
                    this.uniGrid1.ActiveRow.Cells["biz_area_nm"].Value = iDataSet.Tables[0].Rows[0]["biz_area_nm"].ToString();
                    break;

                case "dilig_cd":

                    this.uniGrid1.ActiveRow.Cells["dilig_cd"].Value = iDataSet.Tables[0].Rows[0]["dilig_cd"].ToString();
                    this.uniGrid1.ActiveRow.Cells["dilig_nm"].Value = iDataSet.Tables[0].Rows[0]["dilig_nm"].ToString();


                    switch (iDataSet.Tables[0].Rows[0]["day_time"].ToString())
                    {
                        case "1":
                            this.uniGrid1.ActiveRow.Cells["dilig_hh"].Value = "0";
                            this.uniGrid1.ActiveRow.Cells["dilig_mm"].Value = "0";

                            this.uniGrid1.SpreadLock(cqtdsDataSet.IE_DATA.dilig_hhColumn.ColumnName);
                            this.uniGrid1.SpreadLock(cqtdsDataSet.IE_DATA.dilig_mmColumn.ColumnName);

                            break;

                        case "2":
                            //  this.uniGrid1.ActiveRow.Cells["dilig_hh"].Value = "0";
                            //this.uniGrid1.ActiveRow.Cells["dilig_mm"].Value = "0";


                            this.uniGrid1.SpreadUnLock(cqtdsDataSet.IE_DATA.dilig_hhColumn.ColumnName);
                            this.uniGrid1.SpreadUnLock(cqtdsDataSet.IE_DATA.dilig_mmColumn.ColumnName);
                            break;

                        default:
                            this.uniGrid1.ActiveRow.Cells["dilig_hh"].Value = "4";
                            // this.uniGrid1.ActiveRow.Cells["dilig_mm"].Value = "0";


                            this.uniGrid1.SpreadLock(cqtdsDataSet.IE_DATA.dilig_hhColumn.ColumnName);
                            this.uniGrid1.SpreadLock(cqtdsDataSet.IE_DATA.dilig_mmColumn.ColumnName);

                            break;
                    }

                    break;
            }
        }



        private void uniGrid1_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {

            switch (this.uniGrid1.ActiveCell.Column.Key)
            {
                case "emp_no":
                    string emp = uniGrid1.ActiveRow.Cells[cqtdsDataSet.IE_DATA.emp_noColumn.ColumnName].Text;
                    string name = uniGrid1.ActiveRow.Cells[cqtdsDataSet.IE_DATA.nameColumn.ColumnName].Text;
                    //
                    string dt = Convert.ToDateTime(uniGrid1.ActiveRow.Cells[cqtdsDataSet.IE_DATA.dilig_dtColumn.ColumnName].Value).ToString("yyyy-MM-dd");//Convert.ToDateTime(uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.dilig_dtColumn.ColumnName].Value);
                    string[] param_array = new string[] { emp, "", dt, "1", this.cboBizAreaCd.SelectedItem.DataValue.ToString() };
                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup";
                    e.PopupPassData.PopupWinTitle = "Name/Employee No. Query Popup";
                    e.PopupPassData.PopupWinWidth = 800;
                    e.PopupPassData.PopupWinHeight = 700;
                    e.PopupPassData.Data = param_array;
                    e.PopupPassData.UserParameters = new string[5];   // 2013.11.12 STATEMENTS에 들어가 값들
                    e.PopupPassData.UserParameters[0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    //                    e.PopupPassData.UserParameters[1] = uniBase.UCommon.FilterVariable(dtValidDt.uniValue.ToShortDateString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    e.PopupPassData.UserParameters[1] = uniBase.UCommon.FilterVariable(dt, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    e.PopupPassData.UserParameters[2] = uniBase.UCommon.FilterVariable(emp, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    e.PopupPassData.UserParameters[3] = uniBase.UCommon.FilterVariable(emp, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    e.PopupPassData.UserParameters[4] = " AND DEPT.BIZ_AREA_CD LIKE " + uniBase.UCommon.FilterVariable(cboBizAreaCd.SelectedItem.DataValue.ToString(), "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true);

                    break;
                case "dilig_cd":
                    if (string.IsNullOrEmpty(this.uniGrid1.ActiveRow.Cells["dilig_cd"].ToString()))

                        e.PopupPassData.PopupWinTitle = "Attendance Code Popup";
                    e.PopupPassData.ConditionCaption = "Attendance Code ";
                    e.PopupPassData.SQLFromStatements = " hca010t";
                    e.PopupPassData.SQLWhereStatements = " biz_area_cd like " + uniBase.UCommon.FilterVariable(this.uniGrid1.ActiveRow.Cells["biz_area_cd"].Value.ToString(), "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true) + "";
                    e.PopupPassData.SQLWhereInputCodeValue = this.uniGrid1.ActiveRow.Cells["dilig_cd"].Text;
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.DistinctOrNot = true;
                    //e.PopupPassData.PopupWinWidth = 500;
                    //e.PopupPassData.PopupWinHeight = 400;

                    e.PopupPassData.GridCellCode = new string[4];
                    e.PopupPassData.GridCellCodeAlias = new String[4];
                    e.PopupPassData.GridCellCaption = new string[4];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[4];
                    e.PopupPassData.GridCellLength = new int[4];

                    e.PopupPassData.GridCellCode[0] = "dilig_cd";
                    e.PopupPassData.GridCellCode[1] = "dilig_nm";
                    e.PopupPassData.GridCellCode[2] = "dbo.ufn_GetCodeName('H0086',day_time)";
                    e.PopupPassData.GridCellCode[3] = "day_time";

                    e.PopupPassData.GridCellCodeAlias[0] = "dilig_cd";
                    e.PopupPassData.GridCellCodeAlias[1] = "dilig_nm";
                    e.PopupPassData.GridCellCodeAlias[2] = "day_time";
                    e.PopupPassData.GridCellCodeAlias[3] = "day_time_type";

                    e.PopupPassData.GridCellCaption[0] = "Deduction Code";
                    e.PopupPassData.GridCellCaption[1] = "Deduction Code Name";
                    e.PopupPassData.GridCellCaption[2] = "Days/Hours";
                    e.PopupPassData.GridCellCaption[3] = "Days/Hours_type";

                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;

                    e.PopupPassData.GridCellLength[0] = 150;
                    e.PopupPassData.GridCellLength[1] = 150;
                    e.PopupPassData.GridCellLength[2] = 150;
                    e.PopupPassData.GridCellLength[3] = 150;
                    break;
            }

        }


        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        private void popCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popCd.CodeValue = iDataSet.Tables[0].Rows[0]["dilig_cd"].ToString();
            popCd.CodeName = iDataSet.Tables[0].Rows[0]["dilig_nm"].ToString();
        }

        private void popCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Attendance Code Popup";
            e.PopupPassData.ConditionCaption = "Attendance Code ";
            e.PopupPassData.SQLFromStatements = " hca010t";
            e.PopupPassData.SQLWhereStatements = " biz_area_cd like " + uniBase.UCommon.FilterVariable(cboBizAreaCd.SelectedItem.DataValue.ToString(), "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true) + "";
            e.PopupPassData.SQLWhereInputCodeValue = popCd.Text;
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = true;
            //e.PopupPassData.PopupWinWidth = 500;
            //e.PopupPassData.PopupWinHeight = 400;

            e.PopupPassData.GridCellCode = new string[3];
            e.PopupPassData.GridCellCodeAlias = new String[3];
            e.PopupPassData.GridCellCaption = new string[3];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[3];
            e.PopupPassData.GridCellLength = new int[3];

            e.PopupPassData.GridCellCode[0] = "dilig_cd";
            e.PopupPassData.GridCellCode[1] = "dilig_nm";
            e.PopupPassData.GridCellCode[2] = "dbo.ufn_GetCodeName('H0086',day_time)";

            e.PopupPassData.GridCellCodeAlias[0] = "dilig_cd";
            e.PopupPassData.GridCellCodeAlias[1] = "dilig_nm";
            e.PopupPassData.GridCellCodeAlias[2] = "day_time";

            e.PopupPassData.GridCellCaption[0] = "Deduction Code";
            e.PopupPassData.GridCellCaption[1] = "Deduction Code Name";
            e.PopupPassData.GridCellCaption[2] = "Days/Hours";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Edit;

            e.PopupPassData.GridCellLength[0] = 150;
            e.PopupPassData.GridCellLength[1] = 150;
            e.PopupPassData.GridCellLength[2] = 150;
        }

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void popEmpNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            this._isEmpChange = true;   // 온체인지로 콤보박스 값이 들어갈때 해당 값이 ValueChange이벤트를 통해서 사번과 이름이 Empty값으로 변경되는 것을 마기위해
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popEmpNo.CodeValue = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
            popEmpNo.CodeName = iDataSet.Tables[0].Rows[0]["name"].ToString();
            this.cboBizAreaCd.Text = iDataSet.Tables[0].Rows[0]["biz_area_cd"].ToString();
            this._isEmpChange = false;
        }

        private void popEmpNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup";
            e.PopupPassData.PopupWinTitle = "Employee PopUp";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;

            string dt = string.Empty;
            if (dtDilgTerm.uniDateTimeF.uniValue.Year.ToString().Equals("1"))
                dt = uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD);

            else
                dt = uniBase.UDate.DateTimeToString(dtDilgTerm.uniDateTimeF, "1900-01-01", CommonVariable.CDT_YYYY_MM_DD, false);

            //e.PopupPassData.Data = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName, uniBase.UDate.DateTimeToString(dtValidDt, "1900-01-01", CommonVariable.CDT_YYYY_MM_DD, false), "1", cboBizAreaCd.SelectedItem.DataValue.ToString(), "", txtFrInternalCd.Text, txtToInternalCd.Text };
            e.PopupPassData.Data = new string[] { popEmpNo.CodeValue, "", dt, "1", cboBizAreaCd.SelectedItem.DataValue.ToString(), "", txtFrInternalCd.Text, txtToInternalCd.Text };

            e.PopupPassData.UserParameters = new string[5];   // 2013.11.12 STATEMENTS에 들어가 값들
            e.PopupPassData.UserParameters[0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[1] = uniBase.UCommon.FilterVariable(dt, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[2] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[3] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[4] = " AND DEPT.BIZ_AREA_CD LIKE " + uniBase.UCommon.FilterVariable(cboBizAreaCd.SelectedItem.DataValue.ToString(), "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true);

        }

        private void popDeptNm_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            uniOpenPopup pop = (sender as uniOpenPopup);
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.HDeptPopup";
            e.PopupPassData.PopupWinTitle = "Department Popup";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;

            //e.PopupPassData.Data = new string[] { pop.CodeValue, pop.CodeName, uniBase.UDate.DateTimeToString(dtValidDt, "1900-01-01", CommonVariable.CDT_YYYY_MM_DD, false), cboBizAreaCd.SelectedItem.DataValue.ToString() };
            e.PopupPassData.Data = new string[] { pop.CodeValue, pop.CodeName, uniBase.UDate.DateTimeToString(dtDilgTerm.uniDateTimeF, "1900-01-01", CommonVariable.CDT_YYYY_MM_DD, false), cboBizAreaCd.SelectedItem.DataValue.ToString() };

            e.PopupPassData.UserParameters = new string[5];
            e.PopupPassData.UserParameters[0] = "''";
            e.PopupPassData.UserParameters[1] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[2] = "'" + pop.CodeValue + "'";
            e.PopupPassData.UserParameters[3] = uniBase.UCommon.FilterVariable(cboBizAreaCd.SelectedItem.DataValue.ToString(), "'%'", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[4] = "";
        }
        private void popDeptNm_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {

            uniOpenPopup pop = (sender as uniOpenPopup);


            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            pop.CodeValue = iDataSet.Tables[0].Rows[0]["dept_cd"].ToString();
            pop.CodeName = iDataSet.Tables[0].Rows[0]["dept_nm"].ToString();
            if (pop.Name.ToString().Equals("popToDeptNm"))
            {
                txtToInternalCd.Text = iDataSet.Tables[0].Rows[0]["internal_cd"].ToString();
            }
            else
            {
                txtFrInternalCd.Text = iDataSet.Tables[0].Rows[0]["internal_cd"].ToString();
            }

            popEmpNo.CodeValue = string.Empty;
            popEmpNo.CodeName = string.Empty;
        }

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors
            #endregion
            #region ▶▶▶ 10.1.2.2 Setting Returned Data
            #endregion
        }

        #endregion

        private void cboBizAreaCd_ValueChanged(object sender, EventArgs e)
        {
            if (!this._isEmpChange)
            {
                popEmpNo.CodeValue = string.Empty;
                popEmpNo.CodeName = string.Empty;
                popFrDeptNm.CodeValue = string.Empty;
                popFrDeptNm.CodeName = string.Empty;
                popToDeptNm.CodeValue = string.Empty;
                popToDeptNm.CodeName = string.Empty;
                txtFrInternalCd.Text = string.Empty;
                txtToInternalCd.Text = string.Empty;
                popCd.CodeValue = string.Empty;
                popCd.CodeName = string.Empty;

            }
        }

        #endregion






        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group
        private bool SubCheckHoliday(DataRow drSender)
        {
            int flg = 0;
            string iCnt = string.Empty;
            string strFg = string.Empty;
            string strType = string.Empty;
            string strOrgId = string.Empty;
            string strHoli_type = string.Empty;
            string strHoliday_apply = string.Empty;
            string f_gazet_dt = string.Empty;
            string f_emp_no = string.Empty;


            DataSet dsTemp = null;
            StringBuilder sbSQL = new StringBuilder();
            f_gazet_dt = drSender["dilig_dt"].ToString().Substring(0, 10);
            f_emp_no = drSender["emp_no"].ToString();

            string sbSQL0 = string.Format(@"
SELECT wk_type
FROM hca040t
WHERE emp_no ={0}
        and chang_dt = (select max(chang_dt) from hca040t where emp_no ={0} and chang_dt <={1})"
           , uniBase.UCommon.FilterVariable(drSender["emp_no"], "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)

           , uniBase.UCommon.FilterVariable(f_gazet_dt, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
           );
            dsTemp = uniBase.UDataAccess.CommonQuerySQL(sbSQL0.ToString());
            if (dsTemp.Tables == null || dsTemp.Tables[0].Rows == null || dsTemp.Tables[0].Rows.Count <= 0)
            {
                uniBase.UMessage.DisplayMessageBox("800177", MessageBoxButtons.OK);

                return false;
            }

            strType = dsTemp.Tables[0].Rows[0]["wk_type"].ToString();

            if (strType == "X" || strType == "")
            {
                strType = "0";
            }




            string sbSQL1 = string.Format(@"
SELECT holi_type 
FROM    HCA020t
where
        biz_area_cd ={0}
        and wk_type ={1}
        and date ={2}"
                , uniBase.UCommon.FilterVariable(drSender["biz_area_cd"], "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                , uniBase.UCommon.FilterVariable(strType, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                , uniBase.UCommon.FilterVariable(f_gazet_dt, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                );
            dsTemp = uniBase.UDataAccess.CommonQuerySQL(sbSQL1.ToString());
            if (dsTemp.Tables == null || dsTemp.Tables[0].Rows == null || dsTemp.Tables[0].Rows.Count <= 0)  // 13.07.19
            {
                uniBase.UMessage.DisplayMessageBox("800453", MessageBoxButtons.OK);

                return false;
            }


            strFg = dsTemp.Tables[0].Rows[0]["holi_type"].ToString();

            if (string.IsNullOrEmpty(strFg) || strFg == "X") //800453
            {
                uniBase.UMessage.DisplayMessageBox("800453", MessageBoxButtons.OK);

                return false;

            }
            else
                strHoli_type = strFg;



            //--'근태코드에서 일수/시간 판별 

            string sbSQL2 = string.Format(@"
SELECT  
    A.DILIG_CD, A.DILIG_NM, DAY_TIME, HOLIDAY_APPLY
FROM HCA010T A 
WHERE  A.dilig_cd = {0}
  AND  biz_area_cd ={1} 
"
                , uniBase.UCommon.FilterVariable(drSender["dilig_cd"].ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                , uniBase.UCommon.FilterVariable(drSender["biz_area_cd"].ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)

                );
            dsTemp = uniBase.UDataAccess.CommonQuerySQL(sbSQL2.ToString());
            if (dsTemp.Tables == null || dsTemp.Tables[0].Rows == null || dsTemp.Tables[0].Rows.Count <= 0)
            {
                uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                return false;
            }

            strFg = dsTemp.Tables[0].Rows[0]["day_time"].ToString();
            strHoliday_apply = dsTemp.Tables[0].Rows[0]["holiday_apply"].ToString();

            string dilg = dsTemp.Tables[0].Rows[0]["dilig_cd"].ToString();

            // 휴일적용여부가 'N'이고 해당일이 휴일이면 등록 불가 
            if (strHoliday_apply == "N" && strHoli_type == "H" && drSender["cud_char"].ToString().ToUpper() != "D")
            {
                string msgtest = f_emp_no + " 사번에 근태코드 : " + dilg;
                uniBase.UMessage.DisplayMessageBox("800505", MessageBoxButtons.OK, msgtest);
                return false;

            }

            return true;

        }
        private void Call_GridPopup()
        {
            ////------------------Before Popup Open-----------------------------
            //string[] param_array = new string[] { this.uniGrid1.ActiveRow.Cells["emp_no"].Text, this.uniGrid1.ActiveRow.Cells["name"].Text, this.dtValidDt.uniValue.ToString(CommonVariable.CDT_YYYY_MM_DD), "", this.cboBizAreaCd.SelectedItem.DataValue.ToString() };
            //PopupRunningInfo popupRunningInfo = new PopupRunningInfo();

            //popupRunningInfo.ParentData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup";
            //popupRunningInfo.ParentData.PopupWinTitle = "Name/Employee No. Query Popup";

            //popupRunningInfo.ParentData.PopupWinWidth = 700;
            //popupRunningInfo.ParentData.PopupWinHeight = 800;
            //popupRunningInfo.ParentData.Data = param_array;

            //popupRunningInfo.ParentView = this;

            ////-------------------------------------------------------------------
            //popupRunningInfo.ReturnPopup = popEmpNo;

            //popupRunningInfo.ParentColumnID = "emp_no";


            ////---------------Call Popup-------------------------------------------

            //ControlManager.PopupLoad("uniERP.App.UI.POPUP.EmpPopup", popupRunningInfo, this.Presenter.WorkItem);



            ////---------------After Popup Closed-----------------------------------

            //DataSet iDataSet = new DataSet();

            //if (popupRunningInfo.PopupResult.Data == null)

            //    return;

            //iDataSet = (DataSet)popupRunningInfo.PopupResult.Data;

            ////---------------------------------------------------------------------          
            //uniGrid1.ActiveRow.Cells["emp_no"].Value =
            //    iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
            //uniGrid1.ActiveRow.Cells["name"].Value =
            //         iDataSet.Tables[0].Rows[0]["name"].ToString();
            //    uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value =
            //         iDataSet.Tables[0].Rows[0]["roll_pstn_nm"].ToString();
            //    uniGrid1.ActiveRow.Cells["biz_area_cd"].Value =
            //         iDataSet.Tables[0].Rows[0]["biz_area_cd"].ToString();
            //    uniGrid1.ActiveRow.Cells["biz_area_nm"].Value =
            //         iDataSet.Tables[0].Rows[0]["biz_area_nm"].ToString();
            //    uniGrid1.ActiveRow.Cells["dept_nm"].Value =
            //         iDataSet.Tables[0].Rows[0]["dept_nm"].ToString();
            //    uniGrid1.ActiveRow.Cells["dept_cd"].Value =
            //         iDataSet.Tables[0].Rows[0]["dept_cd"].ToString();
        }
        #endregion

        /*
        private void uniGrid1_AfterExitEditMode_1(object sender, EventArgs e)
        {
            //string baseDt = uniBase.UDate.DateTimeToString(this.dtValidDt, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD);

            string baseDt = uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.dilig_dtColumn.ColumnName].Value.ToString();// uniBase.UDate.DateTimeToString(, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD);
            if (this.uniGrid1.ActiveCell != null && uniGrid1.ActiveCell.Column.Key == "emp_no")
            {

                if (this.uniGrid1.ActiveRow.Cells["emp_no"].Value.ToString() == "")
                {
                    uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.emp_noColumn.ColumnName].Value = "";
                    uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.nameColumn.ColumnName].Value = "";
                    uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.dept_cdColumn.ColumnName].Value = "";
                    uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.dept_nmColumn.ColumnName].Value = "";
                    uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.roll_pstn_nmColumn.ColumnName].Value = "";
                    uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.biz_area_cdColumn.ColumnName].Value = "";
                    uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.biz_area_nmColumn.ColumnName].Value = "";
                }
                else
                {
                    string[] sqlIDs = new string[] { "ZN_HR_EMP_NM2" };
                    string[][] parameters = new string[][] { new string[5] };

                    parameters[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    parameters[0][1] = uniBase.UCommon.FilterVariable(baseDt, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    parameters[0][2] = uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.emp_noColumn.ColumnName].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    parameters[0][3] = uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.emp_noColumn.ColumnName].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
                    parameters[0][4] = " ";

                    DataSet set2 = null;

                    try
                    {
                        set2 = uniBase.UDataAccess.DBAgentQryRS(sqlIDs, parameters);

                        if ((set2 == null) || (set2.Tables[0].Rows.Count == 0))
                        {
                            uniBase.UMessage.DisplayMessageBox("810010", MessageBoxButtons.OK);
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.emp_noColumn.ColumnName].Value = "";
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.nameColumn.ColumnName].Value = "";
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.dept_cdColumn.ColumnName].Value = "";
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.dept_nmColumn.ColumnName].Value = "";
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.roll_pstn_nmColumn.ColumnName].Value = "";
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.biz_area_cdColumn.ColumnName].Value = "";
                        }
                        else if (set2.Tables[0].Rows.Count >= 2)  // 동명2인일경우에는 팝업을 뛰어서 선택할 수 있도록 수정
                        {
                            uniGrid1.BeforePopupOpenEvent();
                        }

                        else
                        {
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.emp_noColumn.ColumnName].Value = set2.Tables[0].Rows[0]["emp_no"].ToString().Trim();
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.nameColumn.ColumnName].Value = set2.Tables[0].Rows[0]["name"].ToString().Trim();
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.dept_cdColumn.ColumnName].Value = set2.Tables[0].Rows[0]["dept_cd"].ToString().Trim();
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.dept_nmColumn.ColumnName].Value = set2.Tables[0].Rows[0]["dept_nm"].ToString().Trim();
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.roll_pstn_nmColumn.ColumnName].Value = set2.Tables[0].Rows[0]["roll_pstn_nm"].ToString().Trim();
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.biz_area_cdColumn.ColumnName].Value = set2.Tables[0].Rows[0]["biz_area_cd"].ToString().Trim();
                            uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.biz_area_nmColumn.ColumnName].Value = set2.Tables[0].Rows[0]["biz_area_nm"].ToString().Trim();

                        }
                    }
                    catch (Exception ex)
                    {
                        bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                        if (reThrow)
                        {
                            throw;
                        }
                    }
                }
            }
        }
        */

        #endregion

    }
}