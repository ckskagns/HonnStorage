-- EXEC USP_F2107MA4_KO883 '', '', '2021', '',''    
-- DROP PROCEDURE DBO.[USP_F2107MA4_KO883]                                      
-- GO                                      
/********************************************************************/                                      
/*****    PROC NAME   :  [USP_F2107MA4_KO883]        *****/                                      
/*****    ���α׷�    :  USP_F2107MA4_KO883          *****/                                      
/*****    DEVELOPER   :  SONS                        *****/                                      
/*****    ���߳�¥    :  2021-04-21                  *****/                                      
/*****    �ֽż�����¥:                              *****/                                      
/*****    ��    ��    :  ������� ��ȸ - ������,     *****/    
/*****    Ư    ¡    :  @diff    ������, �μ��� => A, �ƴϸ� blank   */    
/*****                :  @quarter �б⺰         => A, �ƴϸ� blank   */    
/********************************************************************/         
  
CREATE  PROCEDURE [dbo].USP_F2107MA4_KO883 (     
  @diff nchar(1),    
  @quarter nchar(1),    
  @year datetime,   
  @bdg_cd nvarchar(12),    
  @dept_cd nchar(12)    
  ) AS    
    
BEGIN                                      
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                 
               
SET NOCOUNT ON         
    
--set @diff ='B'   --A ������, �μ���    
--set @quarter = 'A'  --A �б⺰    
--set @year ='2021-01-01'    
--set @bdg_cd = ''    
--set @dept_cd = ''    
    
declare @prestrym nvarchar(10),  --������۳��  
  @preendym nvarchar(10),  --����������  
  @strym nvarchar(10),   --�����۳��  
  @endym nvarchar(10),   --���������  
  @calyear nvarchar(10),  --���  
  @preyear nvarchar(10)   --����  
  
set @preyear = convert(nchar(4),DATEADD(year,-1,@year),112)  
set @calyear = convert(nchar(4),@year,112)  
  
set @prestrym = @preyear + '01'    
set @preendym = @preyear + '12'    
set @strym = @calyear + '01'    
set @endym = @calyear + '12'    
  
    
---����/�μ���, ����---------------------------------------------------    
if @diff = 'A' and @quarter <> 'A'    
begin    
select     
    D.GP_CD as gp_cd,    --�����׷�    
 E.GP_NM as gp_nm,    --�����׷��    
 A.BDG_CD as bdg_cd,    --�����ڵ�     
 B.GP_ACCT_NM as gp_acct_nm,  --�����ڵ��    
 B.ACCT_CD as acct_cd,   --�����ڵ�    
 D.ACCT_NM as acct_nm,   --�����ڵ��    
 A.DEPT_CD as dept_cd,   --���μ�    
 C.DEPT_NM dept_nm,    --�μ���  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) presum_amt,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) sum_amt,    
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end)) sum_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preJan_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jan_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Jan_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preFeb_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Feb_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Feb_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preMar_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Mar_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Mar_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preApr_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Apr_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Apr_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preMay_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) May_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) May_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preJun_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jun_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Jun_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preJul_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jul_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Jul_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preAug_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Aug_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Aug_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preSep_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Sep_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Sep_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preOct_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Oct_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Oct_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preNov_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Nov_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Nov_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preDec_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Dec_Sum,  
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Dec_bal  
 from f_bdg a    
 join f_bdg_acct b on b.BDG_CD = a.BDG_CD    
 join b_acct_dept c on A.dept_cd = C.dept_cd and A.org_change_id = C.org_change_id    
 join A_ACCT d on d.ACCT_CD = b.ACCT_CD    
 join A_ACCT_GP e on e.GP_CD = d.GP_CD    
 where A.bdg_yyyymm between  @prestrym and  @endym    
 and (@bdg_cd = '' or A.BDG_CD = @bdg_cd)    
 and (@dept_cd = '' or A.DEPT_CD = @dept_cd)    
  group by D.GP_CD, E.GP_NM, A.BDG_CD, B.GP_ACCT_NM, A.DEPT_CD, C.DEPT_NM, B.ACCT_CD, D.ACCT_NM    
 Order By A.BDG_CD ASC,B.GP_ACCT_NM , A.DEPT_CD ASC    
end    
  
------������, ����----------------------------------    
if @diff <> 'A' and @quarter <> 'A'    
begin     
select     
    D.GP_CD as gp_cd,    --�����׷�    
 E.GP_NM as gp_nm,    --�����׷��    
 A.BDG_CD as bdg_cd,    --�����ڵ�     
 B.GP_ACCT_NM as gp_acct_nm,  --�����ڵ��    
 B.ACCT_CD as acct_cd,   --�����ڵ�    
 D.ACCT_NM as acct_nm,   --�����ڵ��     
sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) presum_amt,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) sum_amt,    
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end)) sum_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preJan_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jan_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='01' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Jan_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preFeb_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Feb_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='02' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Feb_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preMar_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Mar_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='03' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Mar_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preApr_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Apr_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='04' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Apr_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preMay_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) May_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='05' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) May_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preJun_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jun_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='06' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Jun_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preJul_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Jul_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='07' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Jul_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preAug_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Aug_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='08' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Aug_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preSep_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Sep_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='09' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Sep_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preOct_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Oct_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='10' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Oct_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preNov_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Nov_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='11' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Nov_bal,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preDec_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) Dec_Sum,  
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and substring(A.BDG_YYYYMM,5,2)='12' then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) Dec_bal  
 from f_bdg a    
 join f_bdg_acct b on b.BDG_CD = a.BDG_CD    
 join b_acct_dept c on A.dept_cd = C.dept_cd and A.org_change_id = C.org_change_id    
 join A_ACCT d on d.ACCT_CD = b.ACCT_CD    
 join A_ACCT_GP e on e.GP_CD = d.GP_CD    
 where A.bdg_yyyymm between  @prestrym and  @endym    
 and (@bdg_cd = '' or A.BDG_CD = @bdg_cd)    
  group by D.GP_CD, E.GP_NM, A.BDG_CD, B.GP_ACCT_NM, B.ACCT_CD, D.ACCT_NM    
 Order By A.BDG_CD ASC,B.GP_ACCT_NM     
end    
  
---3. ����/�μ���, �б⺰---------------------------------------------------    
if @diff = 'A' and @quarter = 'A'    
begin    
select     
    D.GP_CD as gp_cd,    --�����׷�    
 E.GP_NM as gp_nm,    --�����׷��    
 A.BDG_CD as bdg_cd,    --�����ڵ�     
 B.GP_ACCT_NM as gp_acct_nm,  --�����ڵ��    
 B.ACCT_CD as acct_cd,   --�����ڵ�    
 D.ACCT_NM as acct_nm,   --�����ڵ��    
 A.DEPT_CD as dept_cd,   --���μ�    
 C.DEPT_NM dept_nm,    --�μ���    
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) presum_amt,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) sum_amt,    
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end)) sum_bal,  
  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preoneQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) oneQ_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)  
  - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) oneQ_bal,  
  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) pretwoQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) twoQ_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)  
  - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) twoQ_bal,  
  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) prethrQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) thrQ_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)  
  - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) thrQ_bal,  
  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preforQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) forQ_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)  
  - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) forQ_bal  
 from f_bdg a    
 join f_bdg_acct b on b.BDG_CD = a.BDG_CD    
 join b_acct_dept c on A.dept_cd = C.dept_cd and A.org_change_id = C.org_change_id    
 join A_ACCT d on d.ACCT_CD = b.ACCT_CD    
 join A_ACCT_GP e on e.GP_CD = d.GP_CD    
 where A.bdg_yyyymm between  @prestrym and  @endym    
 and (@bdg_cd = '' or A.BDG_CD = @bdg_cd)    
 and (@dept_cd = '' or A.DEPT_CD = @dept_cd)    
  group by D.GP_CD, E.GP_NM, A.BDG_CD, B.GP_ACCT_NM, A.DEPT_CD, C.DEPT_NM, B.ACCT_CD, D.ACCT_NM    
 Order By A.BDG_CD ASC,B.GP_ACCT_NM , A.DEPT_CD ASC    
end    
  
---4. ������, �б⺰---------------------------------------------------    
if @diff <> 'A' and @quarter = 'A'    
begin    
select     
    D.GP_CD as gp_cd,    --�����׷�    
 E.GP_NM as gp_nm,    --�����׷��    
 A.BDG_CD as bdg_cd,    --�����ڵ�     
 B.GP_ACCT_NM as gp_acct_nm,  --�����ڵ��    
 B.ACCT_CD as acct_cd,   --�����ڵ�    
 D.ACCT_NM as acct_nm,   --�����ڵ��     
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) presum_amt,  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) sum_amt,    
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end) - (case when substring(A.BDG_YYYYMM,1,4) = @preyear then A.BDG_GL_AMT + A.BDG_TMP_AMT else 0 end)) sum_bal,  
  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preoneQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) oneQ_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)  
  - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='01' or substring(A.BDG_YYYYMM,5,2)='02' or substring(A.BDG_YYYYMM,5,2)='03') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) oneQ_bal,  
  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) pretwoQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) twoQ_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)  
  - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='04' or substring(A.BDG_YYYYMM,5,2)='05' or substring(A.BDG_YYYYMM,5,2)='06') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) twoQ_bal,  
  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) prethrQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) thrQ_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)  
  - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='07' or substring(A.BDG_YYYYMM,5,2)='08' or substring(A.BDG_YYYYMM,5,2)='09') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) thrQ_bal,  
  
 sum(case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) preforQ_Sum,   
 sum(case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end) forQ_Sum,   
 sum((case when substring(A.BDG_YYYYMM,1,4) = @calyear and (substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)  
  - (case when substring(A.BDG_YYYYMM,1,4) = @preyear and (substring(A.BDG_YYYYMM,5,2)='10' or substring(A.BDG_YYYYMM,5,2)='11' or substring(A.BDG_YYYYMM,5,2)='12') then A.BDG_GL_AMT+A.BDG_TMP_AMT else 0 end)) forQ_bal  
 from f_bdg a    
 join f_bdg_acct b on b.BDG_CD = a.BDG_CD    
 join b_acct_dept c on A.dept_cd = C.dept_cd and A.org_change_id = C.org_change_id    
 join A_ACCT d on d.ACCT_CD = b.ACCT_CD    
 join A_ACCT_GP e on e.GP_CD = d.GP_CD    
 where A.bdg_yyyymm between  @prestrym and  @endym    
 and (@bdg_cd = '' or A.BDG_CD = @bdg_cd)    
 and (@dept_cd = '' or A.DEPT_CD = @dept_cd)    
  group by D.GP_CD, E.GP_NM, A.BDG_CD, B.GP_ACCT_NM, B.ACCT_CD, D.ACCT_NM    
 Order By A.BDG_CD ASC,B.GP_ACCT_NM ASC    
end    
  
end