﻿#region �� Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.DataBridge;

#endregion

namespace uniERP.App.UI.IM.I2211MA1_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region �� 1. Declaration part

        #region �� 1.1 Program information
        /// <NameSpace>��namespace</NameSpace>
        /// <Module>��module name</Module>
        /// <Class>��class name</Class>
        /// <Desc>��
        ///   This part describe the summary information about class 
        /// </Desc>
        /// <History>��
        ///   <FirstCreated>
        ///     <history name="creator" Date="created date">Make ��</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>��
        ///   <remark name="modifier"  Date="modified date">�� </remark>
        ///   <remark name="modifier"  Date="modified date">�� </remark>
        /// </Remarks>

        #endregion

        #region �� 1.2. Class global constants (common)

        #endregion

        #region �� 1.3. Class global variables (common)

        // change your code

        #endregion

        #region �� 1.4 Class global constants (grid)


        #endregion

        #region �� 1.5 Class global variables (grid)

        // change your code
        private wsPI3G010FL.DsIListOnhandStkSvr cqtdsIListOnhandStkSvr = new uniERP.App.UI.IM.I2211MA1_KO883.wsPI3G010FL.DsIListOnhandStkSvr();

        #endregion

        #endregion

        #region �� 2. Initialization part

        #region �� 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region �� 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(cqtdsIListOnhandStkSvr);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Query, enumDef.ModuleInformation.InventoryManagement);  // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format

        }

        protected override void Form_Load_Completed()
        {
            //ControlName.Focus();                // Set focus
            this.popPlant_Cd.Focus();//JiangXueyong20071204

            uniBase.UCommon.SetToolBarAll(false);
            uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Query | enumDef.ToolBitCommon.ViewExit, true);
        }

        #endregion

        #region �� 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            cqtdsIListOnhandStkSvr.Clear();
        }

        #endregion

        #region �� 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            // Assign default value to controls
            this.popPlant_Cd.CodeValue="P1";
            this.rdoGoodQtyFlag.CheckedIndex = 0;
            this.rdoValidDateCheck.CheckedIndex = 1;

            ////if (this.popPlant_Cd.CodeValue == string.Empty)
            ////{
            ////    this.popPlant_Cd.CodeName = string.Empty;
            ////}
            //if (CommonVariable.gPlant.Trim() != string.Empty)//JiangXueyong20071204
            //{
            //    this.popPlant_Cd.CodeValue = CommonVariable.gPlant.Trim();
            //    this.popPlant_Cd.CodeName = CommonVariable.gPlantNm.Trim();
            //    //this.popSL_Cd.Focus();
            //}
            ////else
            ////{
            ////this.popPlant_Cd.Focus();//JiangXueyong20071204
            ////}
            return;
        }

        #endregion

        #region �� 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            // Example: Set ComboBox List (Column Name, Select, From, Where)
            //unibase.udata.combomajoradd("taxpolicy", "b0004");
            //unibase.udata.combocustomadd("msg_type", "pant_cd code, plant_nm name", "b_minor", "major_cd='a1001'");

        }
        #endregion

        #region �� 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ��
            //base.viewTB19029.ggUserDefined6.DecPoint = 0;
            //base.viewTB19029.ggUserDefined6.Integeral = 15;
            #endregion
        }

        #endregion

        #endregion

        #region �� 3. Grid method part

        #region �� 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ��� 3.1.1 Pre-setting grid information

            wsPI3G010FL.DsIListOnhandStkSvr.E_EXPORT_GROUPDataTable uniGridTB1 = cqtdsIListOnhandStkSvr.E_EXPORT_GROUP;

            uniGrid1.SSSetEdit(uniGridTB1.item_cdColumn.ColumnName, "Item", 162, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            uniGrid1.SSSetEdit(uniGridTB1.item_nmColumn.ColumnName, "Item Desc.", 225, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            uniGrid1.SSSetEdit(uniGridTB1.basic_unitColumn.ColumnName, "Unit", 72, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            uniGrid1.SSSetEdit(uniGridTB1.specColumn.ColumnName, "Specification", 153, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            //uniGrid1.SSSetEdit(uniGridTB1.locationColumn.ColumnName, "Location", 180, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            uniGrid1.SSSetEdit(uniGridTB1.tracking_noColumn.ColumnName, "Tracking No.", 180, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left, int.MaxValue);
            uniGrid1.SSSetFloat(uniGridTB1.good_on_hand_qtyColumn.ColumnName, "Good Inventory Qty", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.bad_on_hand_qtyColumn.ColumnName, "Bad Inventory Qty", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.stk_on_insp_qtyColumn.ColumnName, "Insp. Qty", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.stk_in_trns_qtyColumn.ColumnName, "Stock in Transit Qty", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetFloat(uniGridTB1.schd_rcpt_qtyColumn.ColumnName, "Planned Receipt Qty", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetFloat(uniGridTB1.schd_issue_qtyColumn.ColumnName, "Planned Issue Qty", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetFloat(uniGridTB1.prev_good_qtyColumn.ColumnName, "Prev. Month Inv. Good Qty", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetFloat(uniGridTB1.prev_bad_qtyColumn.ColumnName, "Prev. Month Inv. Bad Qty", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetFloat(uniGridTB1.prev_stk_on_insp_qtyColumn.ColumnName, "Prev. Month Insp. Qty.", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetFloat(uniGridTB1.prev_stk_in_trns_qtyColumn.ColumnName, "Prev. Month Trns. Qty.", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetFloat(uniGridTB1.allocation_qtyColumn.ColumnName, "Allocation Qty.", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetFloat(uniGridTB1.detail_picking_qtyColumn.ColumnName, "Picking Qty.", 135, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);

            #endregion

            #region ��� 3.1.2 Formatting grid information

            uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.Yes , enumDef.IsSearch.Yes);

            // show sum column(bottom area of grid)
            string[] summaryColumn = new string[12];
            summaryColumn[0] = uniGridTB1.good_on_hand_qtyColumn.ColumnName;
            summaryColumn[1] = uniGridTB1.bad_on_hand_qtyColumn.ColumnName;
            summaryColumn[2] = uniGridTB1.stk_on_insp_qtyColumn.ColumnName;
            summaryColumn[3] = uniGridTB1.stk_in_trns_qtyColumn.ColumnName;
            summaryColumn[4] = uniGridTB1.schd_rcpt_qtyColumn.ColumnName;
            summaryColumn[5] = uniGridTB1.schd_issue_qtyColumn.ColumnName;
            summaryColumn[6] = uniGridTB1.prev_good_qtyColumn.ColumnName;
            summaryColumn[7] = uniGridTB1.prev_bad_qtyColumn.ColumnName;
            summaryColumn[8] = uniGridTB1.prev_stk_on_insp_qtyColumn.ColumnName;
            summaryColumn[9] = uniGridTB1.prev_stk_in_trns_qtyColumn.ColumnName;
            summaryColumn[10] = uniGridTB1.allocation_qtyColumn.ColumnName;
            summaryColumn[11] = uniGridTB1.detail_picking_qtyColumn.ColumnName;
            uniGrid1.SetSummary(summaryColumn);
            #endregion

            #region ��� 3.1.3 Setting etc grid

            #endregion
        }
        #endregion

        #region �� 3.2 InitData

        private void InitData()
        {
            // TO-DO: ��Ʈ���� �ʱ�ȭ(�Ǵ� �ʱⰪ)�Ҷ� ���� 
            // SetDefaultVal���� �������� ���ڴ� Form_Load ������ ��Ʈ�ѿ� �ʱⰪ�� �����ϴ°��̰�
            // ���ڴ� Ư�� ����(��ȸ�� �Ǵ� ���߰��� �� Ư���̺�Ʈ)���� �ʱⰪ�� �����Ѵ�.
        }

        #endregion

        #region �� 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow�� �׸��� �÷� ����

        }
        #endregion

        #region �� 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            // Grid binding with global dataset variable.

            InitSpreadSheet();

            uniGrid1.uniGridSetDataBinding(cqtdsIListOnhandStkSvr.E_EXPORT_GROUP);
        }
        #endregion

        #endregion

        #region �� 4. Toolbar method part

        #region �� 4.1 Common Fnction group

        #region ��� 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //TO-DO : code business oriented logic

            StringBuilder whereList = new StringBuilder();
            StringBuilder whereList2 = new StringBuilder();

            DataSet dsTemp = null;
            DataSet dsTemp2 = null;

            whereList.Append(string.Format(" PLANT_CD = {0}", uniBase.UCommon.FilterVariable(this.popPlant_Cd.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));

            dsTemp = uniBase.UDataAccess.CommonQueryRs(" PLANT_NM ", " B_PLANT ", whereList.ToString());
            if (dsTemp.Tables[0].Rows.Count <= 0)
            {
                uniBase.UMessage.DisplayMessageBox("125000", MessageBoxButtons.OK, "");
                return false;
            }
            this.popPlant_Cd.CodeName = dsTemp.Tables[0].Rows[0][0].ToString().Trim();

            whereList.Remove(0, whereList.Length);

            whereList.Append(string.Format(" PLANT_CD   = {0} AND SL_CD = {1}",
                uniBase.UCommon.FilterVariable(this.popPlant_Cd.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true),
                uniBase.UCommon.FilterVariable(this.popSL_Cd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));
            whereList2.Append(string.Format(" SL_CD = {0}",
                uniBase.UCommon.FilterVariable(this.popSL_Cd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));

            dsTemp = null;
            dsTemp = uniBase.UDataAccess.CommonQueryRs(" SL_NM ", " B_STORAGE_LOCATION ", whereList.ToString());
            dsTemp2 = uniBase.UDataAccess.CommonQueryRs(" SL_NM ", " B_STORAGE_LOCATION ", whereList2.ToString());
            if (dsTemp.Tables[0].Rows.Count <= 0)
            {
                if (dsTemp2.Tables[0].Rows.Count <= 0)
                {
                    uniBase.UMessage.DisplayMessageBox("125700", MessageBoxButtons.OK, "");
                }
                else
                {
                    uniBase.UMessage.DisplayMessageBox("125710", MessageBoxButtons.OK, "");
                }
                this.popSL_Cd.CodeName = string.Empty;
                this.popSL_Cd.Focus();
                return false;
            }
            this.popSL_Cd.CodeName = dsTemp.Tables[0].Rows[0][0].ToString().Trim();

            whereList.Remove(0, whereList.Length);

            if (this.popItem_Cd.CodeValue.Trim() != string.Empty)
            {
                whereList.Append(string.Format(" ITEM_CD = {0} ", uniBase.UCommon.FilterVariable(this.popItem_Cd.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));
                dsTemp = null;
                dsTemp = uniBase.UDataAccess.CommonQueryRs(" ITEM_NM ", " B_ITEM ", whereList.ToString());
                if (dsTemp.Tables[0].Rows.Count > 0)
                {
                    this.popItem_Cd.CodeName = dsTemp.Tables[0].Rows[0][0].ToString().Trim();
                }
                else
                {
                    this.popItem_Cd.CodeName = string.Empty;
                }
            }
            else
            {
                this.popItem_Cd.CodeName = string.Empty;
            }

            whereList.Remove(0, whereList.Length);

            if (this.popInvunit.CodeValue.Trim() != string.Empty)
            {
                whereList.Append(string.Format(" UNIT  = {0} ", uniBase.UCommon.FilterVariable(this.popInvunit.CodeValue.Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));
                dsTemp = null;
                dsTemp = uniBase.UDataAccess.CommonQueryRs(" UNIT_NM ", " B_UNIT_OF_MEASURE ", whereList.ToString());
                if (dsTemp.Tables[0].Rows.Count <= 0)
                {
                    uniBase.UMessage.DisplayMessageBox("124000", MessageBoxButtons.OK, "");
                    this.popInvunit.CodeName = string.Empty;
                    this.popInvunit.Focus();

                    return false;
                }
                this.popInvunit.CodeName = dsTemp.Tables[0].Rows[0][0].ToString().Trim();
            }
            else
            {
                this.popInvunit.CodeName = string.Empty;
            }

            return DBQuery();
        }

        #endregion

        #region ��� 4.1.2 OnFncSave(old:FncSave)

        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic

            return DBSave();
        }

        #endregion

        #endregion

        #region �� 4.2 Single Fnction group

        #region ��� 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ��� 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ��� 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ��� 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ��� 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ��� 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ��� 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region �� 4.3 Grid Fnction group

        #region ��� 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ��� 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ��� 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ��� 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region �� 4.4 Db function group

        #region ��� 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            cqtdsIListOnhandStkSvr.Clear();

            DataSet dsResult = null;
            //string dtPerFr = uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeF, CommonVariable.gMinimumDate, CommonVariable.CDT_YYYY_MM_DD, false);
            //string dtPerTo = uniBase.UDate.DateTimeToString(dtPerFromTo.uniDateTimeT, CommonVariable.gMaximumDate, CommonVariable.CDT_YYYY_MM_DD, false);


            try
            {
                using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_I2211MA1_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(uniCommand, "@PLANT_CD", SqlDbType.NVarChar, popPlant_Cd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@SL_CD", SqlDbType.NVarChar, popSL_Cd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@item_cd", SqlDbType.NVarChar, popItem_Cd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@basic_unit", SqlDbType.NVarChar, popInvunit.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@valid_flg", SqlDbType.NVarChar, rdoValidDateCheck.CheckedIndex);
                    uniBase.UDatabase.AddInParameter(uniCommand, "@Good_QTY", SqlDbType.NVarChar, rdoGoodQtyFlag.CheckedIndex);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@ET_Check", SqlDbType.NVarChar, NULL_IP.CheckedValue);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@PC_NAME", SqlDbType.NVarChar, PC_TXT.Text.ToString());
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@TV_NAME", SqlDbType.NVarChar, TV_TXT.Text.ToString());


                    dsResult = uniBase.UDatabase.ExecuteDataSet(uniCommand);
                }

                if (dsResult == null || dsResult.Tables.Count == 0 || dsResult.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return false;
                }
                cqtdsIListOnhandStkSvr.E_EXPORT_GROUP.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
            }



            catch (Exception ex)
            {
                bool reThrow = uniERP.AppFramework.UI.Common.Exceptions.ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }

            return true;

        }

        #endregion

        #region ��� 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ��� 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            //TO-DO : code business oriented logic

            uniGrid1.ActiveRow = null;

            try
            {
                //get Modified or Added or Deleted Dataset.
                //wsMyBizFL.TypedDataSet.TableName tb = dsAnyName.TableName.getChanges();

                //wsMyBizFL.SaveTypedDataSet saveDs = new wsMyBizFL.SaveTypedDataSet();

                // If schema is match : ��
                //saveDs.TableName.Merge(tb, false, MissingSchemaAction.Ignore)     

                // If schema is un-match : ��
                //saveDs.TableName.Merge(tb, false, MissingSchemaAction.Add)        
                //saveDs.TableName.TargetColumnNameColumn.Expression = tb.SourceColumnNameColumn.ColumnName;

                // choose one between �� and ��

                //wsMyBizFL.Service wsSave = new wsMyBizFL.Service();
                //wsSave.SaveWebMethod(CommonVariable.gStrGlobalCollection, saveDs);
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }

            return true;

        }

        #endregion

        #endregion

        #endregion

        #region �� 5. Event method part

        #region �� 5.1 Single control event implementation group

        #endregion

        #region �� 5.2 Grid   control event implementation group

        #region ��� 5.2.1 ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell ���� ��ư�� Ŭ���������� �Ϸ��۾����� �����մϴ�.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
        }
        #endregion ��� ButtonClicked >>> ClickCellButton

        #region ��� 5.2.2 Change >>> CellChange
        /// <summary>
        /// fpSpread�� Change �̺�Ʈ�� UltraGrid�� BeforeExitEditMode �Ǵ� AfterExitEditMode �̺�Ʈ�� ��ü�˴ϴ�.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeExitEditMode(object sender, Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs e)
        {
        }

        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {

        }
        #endregion ��� Change >>> CellChange

        #region ��� 5.2.3 Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
        }
        #endregion ��� Click >>> AfterSelectChange

        #region ��� 5.2.4 ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell ���� �޺��ڽ��� Item�� ���� ���������� �̺�Ʈ�� �߻��մϴ�.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
        }
        #endregion ��� ComboSelChange >>> CellListSelect

        #region ��� 5.2.5 DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread�� DblClick�̺�Ʈ�� UltraGrid�� DoubleClickCell�̺�Ʈ�� ���� �Ͻ� �� �ֽ��ϴ�.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
        }
        #endregion ��� DblClick >>> DoubleClickCell

        #region ��� 5.2.6 MouseDown >>> MouseDown
        /// <summary>
        /// ���콺 ���� ��ư Ŭ���� Context�޴��� �����ִ� �Ϸ��� �۾����� �� �̺�Ʈ���� �����մϴ�.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
        }
        #endregion ��� MouseDown >>> MouseDown

        #region ��� 5.2.7 ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread�� ScripLeaveCell �̺�Ʈ�� UltraGrid�� 
        /// BeforeCellDeactivate �̺�Ʈ�� AfterCellActivate �̺�Ʈ�� ���ؼ� ����մϴ�.
        /// BeforeCellDeactivate    : ����Cell���� ���ο� Cell�� �̵��ϱ� ���� ����Cell��ġ���� ó�� �� �Ϸ��� �۾����� ����մϴ�.
        /// AfterCellActivate       : ���ο� Cell�� �̵��ؼ� ó���� �Ϸ��� �۾����� ����մϴ�.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
        }
        #endregion ��� ScriptLeaveCell >>> BeforeCellDeactivate

        #endregion

        #region �� 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region �� 6. Popup method part

        #region �� 6.1 Common popup implementation group

        private void popPlant_Cd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Plant Popup";
            e.PopupPassData.ConditionCaption = "Plant";
            e.PopupPassData.PopupWinWidth = 450;
            e.PopupPassData.PopupWinHeight = 500;

            e.PopupPassData.SQLFromStatements = "B_PLANT with (nolock)";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.SQLWhereInputCodeValue = (sender as uniOpenPopup).CodeValue;
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "PLANT_CD";
            e.PopupPassData.GridCellCode[1] = "PLANT_NM";

            e.PopupPassData.GridCellCaption[0] = "Plant";
            e.PopupPassData.GridCellCaption[1] = "Plant Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popPlant_Cd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            (sender as uniOpenPopup).CodeValue = iDataSet.Tables[0].Rows[0]["PLANT_CD"].ToString();
            (sender as uniOpenPopup).CodeName = iDataSet.Tables[0].Rows[0]["PLANT_NM"].ToString();
            popPlant_Cd.Focus();
        }

        private void popSL_Cd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (string.IsNullOrEmpty(popPlant_Cd.CodeValue))
            {
                uniBase.UMessage.DisplayMessageBox("169901", MessageBoxButtons.OK, "", "");
                popPlant_Cd.Focus();
                e.Cancel = true;
                return;
            }
            DataSet dataSet = null;
            StringBuilder wherelist = new StringBuilder();

            try
            {
                wherelist.Append(string.Format(" PLANT_CD = {0} ", uniBase.UCommon.FilterVariable(popPlant_Cd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));
                dataSet = uniBase.UDataAccess.CommonQueryRs(" PLANT_NM ", " B_PLANT ", wherelist.ToString());

                if (dataSet == null || dataSet.Tables[0].Rows.Count <= 0)
                {
                    uniBase.UMessage.DisplayMessageBox("125000", MessageBoxButtons.OK);
                    popPlant_Cd.CodeName = string.Empty;
                    popPlant_Cd.Focus();
                    e.Cancel = true;
                    return;
                }
                this.popPlant_Cd.CodeName = dataSet.Tables[0].Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
            e.PopupPassData.PopupWinTitle = "Enter S/L Info. Pop";
            e.PopupPassData.ConditionCaption = "Storage Location";
            e.PopupPassData.PopupWinWidth = 450;
            e.PopupPassData.PopupWinHeight = 500;

            e.PopupPassData.SQLFromStatements = "B_STORAGE_LOCATION with (nolock)";
            e.PopupPassData.SQLWhereStatements = string.Format("PLANT_CD = '{0}' ", popPlant_Cd.CodeValue);
            e.PopupPassData.SQLWhereInputCodeValue = (sender as uniOpenPopup).CodeValue;
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "SL_CD";
            e.PopupPassData.GridCellCode[1] = "SL_NM";

            e.PopupPassData.GridCellCaption[0] = "Storage Location";
            e.PopupPassData.GridCellCaption[1] = "Storage Location Name";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

        }

        private void popSL_Cd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            (sender as uniOpenPopup).CodeValue = iDataSet.Tables[0].Rows[0]["SL_CD"].ToString();
            (sender as uniOpenPopup).CodeName = iDataSet.Tables[0].Rows[0]["SL_NM"].ToString();
            popSL_Cd.Focus();

        }

        private void popInvunit_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "Unit Popup";
            e.PopupPassData.ConditionCaption = "Unit";
            e.PopupPassData.PopupWinWidth = 450;
            e.PopupPassData.PopupWinHeight = 500;

            e.PopupPassData.SQLFromStatements = "B_UNIT_OF_MEASURE with (nolock)";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.SQLWhereInputCodeValue = (sender as uniOpenPopup).CodeValue;
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "UNIT";
            e.PopupPassData.GridCellCode[1] = "UNIT_NM";

            e.PopupPassData.GridCellCaption[0] = "Unit";
            e.PopupPassData.GridCellCaption[1] = "Unit Description";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popInvunit_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            (sender as uniOpenPopup).CodeValue = iDataSet.Tables[0].Rows[0]["UNIT"].ToString();
            (sender as uniOpenPopup).CodeName = iDataSet.Tables[0].Rows[0]["UNIT_NM"].ToString();
            popInvunit.Focus();
        }


        #endregion

        #region �� 6.2 User-defined popup implementation group

        private void popItem_Cd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (string.IsNullOrEmpty(popPlant_Cd.CodeValue))
            {
                uniBase.UMessage.DisplayMessageBox("169901", MessageBoxButtons.OK, "", "");
                popPlant_Cd.Focus();
                e.Cancel = true;
                return;
            }
            DataSet dataSet = null;
            StringBuilder wherelist = new StringBuilder();

            try
            {
                wherelist.Append(string.Format(" PLANT_CD = {0} ", uniBase.UCommon.FilterVariable(popPlant_Cd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));
                dataSet = uniBase.UDataAccess.CommonQueryRs(" PLANT_NM ", " B_PLANT ", wherelist.ToString());

                if (dataSet == null || dataSet.Tables[0].Rows.Count <= 0)
                {
                    uniBase.UMessage.DisplayMessageBox("125000", MessageBoxButtons.OK);
                    popPlant_Cd.CodeName = string.Empty;
                    popPlant_Cd.Focus();
                    e.Cancel = true;
                    return;
                }
                this.popPlant_Cd.CodeName = dataSet.Tables[0].Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.B1B11PA3";
            e.PopupPassData.PopupWinTitle = "Item by Plant Popup";
            e.PopupPassData.PopupWinWidth = 871;
            e.PopupPassData.PopupWinHeight = 758;

            DataSet ids = new DataSet();
            DataTable idt = new DataTable();
            DataRow idr = idt.NewRow();
            idt.Columns.Add("PlantCd");
            idt.Columns.Add("ItemCd");
            idt.Columns.Add("Param3");
            idt.Columns.Add("Param4");
            idt.Columns.Add("Param5");
            idt.Columns.Add("Param6");
            idr["PlantCd"] = this.popPlant_Cd.CodeValue.Trim();
            idr["ItemCd"] = this.popItem_Cd.CodeValue.Trim();
            idr["Param3"] = "";
            idr["Param4"] = "";
            idr["Param5"] = "";
            idr["Param6"] = "";
            idt.Rows.Add(idr);
            ids.Tables.Add(idt);
            e.PopupPassData.Data = ids;
        }

        private void popItem_Cd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popItem_Cd.CodeValue = iDataSet.Tables[0].Rows[0]["ITEM_CD"].ToString();
            popItem_Cd.CodeName = iDataSet.Tables[0].Rows[0]["ITEM_NM"].ToString();
            popItem_Cd.Focus();
        }
        private void popItem_Cd_OnExitEditCode(object sender, EventArgs e)
        {
            if (popItem_Cd.CodeValue.Trim() == string.Empty)
                popItem_Cd.CodeName = string.Empty;
        }
        private void OpenNumberingType(string iWhere)
        {
            #region ������ 10.1.2.1 Popup Constructors
            //CommonPopup cp = new CommonUtil.CommonPopup(PopupType.AutoNumbering);

            //string[] arrRet = cp.showModalDialog(InputParam1);

            #endregion

            #region ������ 10.1.2.2 Setting Returned Data

            //if (iWhere) 
            //{
            //    txtMinor.value = arrRet[0];
            //    txtMinorNm.value = arrRet[1];
            //}
            //else
            //{
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingCd].value = arrRet[0];
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingNm].value = arrRet[1];

            //    if (arrRet[2].Length > 0) 
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = arrRet[2];
            //    else
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = "18";

            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.PrefixCd].value = arrRet[0];

            //}

            #endregion

            //CommonVariable.lgBlnFlgChgValue = true;  // ����� �׼� �߻� �˸�
        }

        private void lblInventoryDetail_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            string iParam1 = this.popSL_Cd.CodeValue.Trim();
            string iParam7 = this.popSL_Cd.CodeName.Trim();
            string iParam4 = this.popPlant_Cd.CodeValue.Trim();
            string iParam5 = "I";
            string iParam2 = "";
            string iParam3 = "";
            string iParam8 = "";
            string iParam9 = "";

            DataSet dataSet = null;
            DataSet dataSet2 = null;
            StringBuilder wherelist = new StringBuilder();

            wherelist.Append(string.Format(" PLANT_CD = {0} ", uniBase.UCommon.FilterVariable(popPlant_Cd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));
            dataSet = uniBase.UDataAccess.CommonQueryRs(" PLANT_NM ", " B_PLANT ", wherelist.ToString());

            if (dataSet == null || dataSet.Tables[0].Rows.Count <= 0)
            {
                uniBase.UMessage.DisplayMessageBox("125000", MessageBoxButtons.OK, "");//JiangXueyong20071204
                popPlant_Cd.CodeName = string.Empty;
                popPlant_Cd.Focus();
                e.Cancel = true;
                return;
            }
            this.popPlant_Cd.CodeName = dataSet.Tables[0].Rows[0][0].ToString();

            if (iParam1 == "")
            {
                uniBase.UMessage.DisplayMessageBox("169902", MessageBoxButtons.OK);
                this.popSL_Cd.Focus();
                e.Cancel = true;
                return;
            }
            else
            {
                wherelist.Remove(0, wherelist.Length);
                wherelist.Append(string.Format(" PLANT_CD = {0} AND SL_CD = {1}",
                    uniBase.UCommon.FilterVariable(popPlant_Cd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true),
                    uniBase.UCommon.FilterVariable(popSL_Cd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));
                dataSet = uniBase.UDataAccess.CommonQueryRs(" SL_NM ", " B_STORAGE_LOCATION ", wherelist.ToString());
                if (dataSet == null || dataSet.Tables[0].Rows.Count <= 0)
                {
                    wherelist.Remove(0, wherelist.Length);
                    wherelist.Append(string.Format(" SL_CD = {0}",
                        uniBase.UCommon.FilterVariable(popSL_Cd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));
                    dataSet2 = uniBase.UDataAccess.CommonQueryRs(" SL_NM ", " B_STORAGE_LOCATION ", wherelist.ToString());
                    if (dataSet2 == null || dataSet2.Tables[0].Rows.Count <= 0)
                    {
                        uniBase.UMessage.DisplayMessageBox("125700", MessageBoxButtons.OK);
                    }
                    else
                    {
                        uniBase.UMessage.DisplayMessageBox("169922", MessageBoxButtons.OK);
                    }
                    this.popSL_Cd.CodeName = "";
                    this.popSL_Cd.Focus();
                    e.Cancel = true;
                    return;
                }
                this.popSL_Cd.CodeName = dataSet.Tables[0].Rows[0][0].ToString();
            }
            if (cqtdsIListOnhandStkSvr.E_EXPORT_GROUP.Rows.Count < 1)
            {
                uniBase.UMessage.DisplayMessageBox("169903", MessageBoxButtons.OK);
                e.Cancel = true;
                return;
            }
            else
            {
                int selectedRowIndex = uniGrid1.ActiveRow.Index;
                wsPI3G010FL.DsIListOnhandStkSvr.E_EXPORT_GROUPDataTable uniGridTB1 = new uniERP.App.UI.IM.I2211MA1_KO883.wsPI3G010FL.DsIListOnhandStkSvr.E_EXPORT_GROUPDataTable();
                iParam2 = uniGrid1.ActiveRow.Cells["item_cd"].Value.ToString();
                iParam8 = uniGrid1.ActiveRow.Cells["item_nm"].Value.ToString();
                iParam3 = uniGrid1.ActiveRow.Cells["tracking_no"].Value.ToString();
                iParam9 = uniGrid1.ActiveRow.Cells["basic_unit"].Value.ToString();
            }
            if (iParam2 == "")
            {
                uniBase.UMessage.DisplayMessageBox("169903", MessageBoxButtons.OK);
                e.Cancel = true;
                return;
            }
            else
            {
                wherelist.Remove(0, wherelist.Length);
                dataSet = null;
                wherelist.Append(string.Format("ITEM_CD= {0} AND PLANT_CD ={1}",
                    uniBase.UCommon.FilterVariable(iParam2, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true),
                    uniBase.UCommon.FilterVariable(iParam4, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));
                dataSet = uniBase.UDataAccess.CommonQueryRs(" ITEM_CD ", " B_ITEM_BY_PLANT ", wherelist.ToString());
                if (dataSet == null || dataSet.Tables[0].Rows.Count <= 0)
                {

                    uniBase.UMessage.DisplayMessageBox("122700", MessageBoxButtons.OK);
                    e.Cancel = true;
                    return;
                }
            }
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.I2212RA1";
            e.PopupPassData.PopupWinTitle = "Present Inventory Details Query";
            e.PopupPassData.PopupWinWidth = 753;
            e.PopupPassData.PopupWinHeight = 768;

            //DataSet ids = new DataSet();
            //DataTable idt = new DataTable();
            //DataRow idr = idt.NewRow();
            //idr["sl_cd"] = Param1;
            //idr["item_cd"] = Param2;
            //idr["tracking_no"] = Param3;
            //idr["plant_cd"] = Param4;
            //idr["select_char"] = Param5;
            //idr["lot_no"] = "";
            //idr["sl_nm"] = Param7;
            //idr["item_nm"] = Param8;
            //idr["unit"] = Param9;
            //idt.Rows.Add(idr);
            //ids.Tables[0].Merge(idt);
            //e.PopupPassData.Data = ids;

            DsI2212RA1 idsI2212RA1 = new DsI2212RA1();
            DsI2212RA1.DtI2212RA1DataTable idtI2212RA1 = new DsI2212RA1.DtI2212RA1DataTable();
            DsI2212RA1.DtI2212RA1Row idrI2212RA1 = idtI2212RA1.NewDtI2212RA1Row();
            idrI2212RA1.sl_cd = iParam1;
            idrI2212RA1.item_cd = iParam2;
            idrI2212RA1.tracking_no = iParam3;
            idrI2212RA1.plant_cd = iParam4;
            idrI2212RA1.select_char = iParam5;
            idrI2212RA1.lot_no = "";
            idrI2212RA1.sl_nm = iParam7;
            idrI2212RA1.item_nm = iParam8;
            idrI2212RA1.unit = iParam9;
            idtI2212RA1.Rows.Add(idrI2212RA1);
            idsI2212RA1.DtI2212RA1.Merge(idtI2212RA1);

            e.PopupPassData.Data = idsI2212RA1;
        }
        #endregion

        #endregion

        #region �� 7. User-defined method part

        #region �� 7.1 User-defined function group


        #endregion


        #endregion

    }
}