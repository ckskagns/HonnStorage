﻿using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;
using uniERP.AppFramework.UI.Module;

namespace uniERP.App.UI.IM.I2211MA1_KO883
{
   public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }
    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem2 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem3 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem4 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblPlant_Cd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblSL_Cd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblItem_Cd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblInvunit = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblValidDateCheck = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblGoodQtyFlag = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popPlant_Cd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popSL_Cd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popItem_Cd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popInvunit = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.rdoValidDateCheck = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.rdoGoodQtyFlag = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblInventoryDetail = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoValidDateCheck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoGoodQtyFlag)).BeginInit();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.uniTBL_MainReference.SuspendLayout();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.ConditionRowCount = 3;
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 84F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(979, 740);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.lblPlant_Cd, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblSL_Cd, 2, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblItem_Cd, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblInvunit, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblValidDateCheck, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblGoodQtyFlag, 2, 2);
            this.uniTBL_MainCondition.Controls.Add(this.popPlant_Cd, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popSL_Cd, 3, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popItem_Cd, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popInvunit, 3, 1);
            this.uniTBL_MainCondition.Controls.Add(this.rdoValidDateCheck, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.rdoGoodQtyFlag, 3, 2);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 3;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(979, 84);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 0;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblPlant_Cd
            // 
            appearance1.TextHAlignAsString = "Left";
            appearance1.TextVAlignAsString = "Middle";
            this.lblPlant_Cd.Appearance = appearance1;
            this.lblPlant_Cd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPlant_Cd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblPlant_Cd.Location = new System.Drawing.Point(15, 6);
            this.lblPlant_Cd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblPlant_Cd.Name = "lblPlant_Cd";
            this.lblPlant_Cd.Size = new System.Drawing.Size(122, 22);
            this.lblPlant_Cd.StyleSetName = "Default";
            this.lblPlant_Cd.TabIndex = 0;
            this.lblPlant_Cd.Text = "Plant";
            this.lblPlant_Cd.UseMnemonic = false;
            // 
            // lblSL_Cd
            // 
            appearance2.TextHAlignAsString = "Left";
            appearance2.TextVAlignAsString = "Middle";
            this.lblSL_Cd.Appearance = appearance2;
            this.lblSL_Cd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSL_Cd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSL_Cd.Location = new System.Drawing.Point(504, 6);
            this.lblSL_Cd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSL_Cd.Name = "lblSL_Cd";
            this.lblSL_Cd.Size = new System.Drawing.Size(122, 22);
            this.lblSL_Cd.StyleSetName = "Default";
            this.lblSL_Cd.TabIndex = 1;
            this.lblSL_Cd.Text = "Storage Location";
            this.lblSL_Cd.UseMnemonic = false;
            // 
            // lblItem_Cd
            // 
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.lblItem_Cd.Appearance = appearance3;
            this.lblItem_Cd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblItem_Cd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblItem_Cd.Location = new System.Drawing.Point(15, 29);
            this.lblItem_Cd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblItem_Cd.Name = "lblItem_Cd";
            this.lblItem_Cd.Size = new System.Drawing.Size(122, 22);
            this.lblItem_Cd.StyleSetName = "Default";
            this.lblItem_Cd.TabIndex = 2;
            this.lblItem_Cd.Text = "Item";
            this.lblItem_Cd.UseMnemonic = false;
            // 
            // lblInvunit
            // 
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.lblInvunit.Appearance = appearance4;
            this.lblInvunit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInvunit.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblInvunit.Location = new System.Drawing.Point(504, 29);
            this.lblInvunit.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblInvunit.Name = "lblInvunit";
            this.lblInvunit.Size = new System.Drawing.Size(122, 22);
            this.lblInvunit.StyleSetName = "Default";
            this.lblInvunit.TabIndex = 3;
            this.lblInvunit.Text = "SKU";
            this.lblInvunit.UseMnemonic = false;
            // 
            // lblValidDateCheck
            // 
            appearance5.TextHAlignAsString = "Left";
            appearance5.TextVAlignAsString = "Middle";
            this.lblValidDateCheck.Appearance = appearance5;
            this.lblValidDateCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblValidDateCheck.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblValidDateCheck.Location = new System.Drawing.Point(15, 52);
            this.lblValidDateCheck.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblValidDateCheck.Name = "lblValidDateCheck";
            this.lblValidDateCheck.Size = new System.Drawing.Size(122, 22);
            this.lblValidDateCheck.StyleSetName = "Default";
            this.lblValidDateCheck.TabIndex = 4;
            this.lblValidDateCheck.Text = "Valid Data Check";
            this.lblValidDateCheck.UseMnemonic = false;
            // 
            // lblGoodQtyFlag
            // 
            appearance6.TextHAlignAsString = "Left";
            appearance6.TextVAlignAsString = "Middle";
            this.lblGoodQtyFlag.Appearance = appearance6;
            this.lblGoodQtyFlag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGoodQtyFlag.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblGoodQtyFlag.Location = new System.Drawing.Point(504, 52);
            this.lblGoodQtyFlag.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblGoodQtyFlag.Name = "lblGoodQtyFlag";
            this.lblGoodQtyFlag.Size = new System.Drawing.Size(122, 22);
            this.lblGoodQtyFlag.StyleSetName = "Default";
            this.lblGoodQtyFlag.TabIndex = 5;
            this.lblGoodQtyFlag.Text = "Good Qty. Exist Flag";
            this.lblGoodQtyFlag.UseMnemonic = false;
            // 
            // popPlant_Cd
            // 
            this.popPlant_Cd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popPlant_Cd.AutoPopupCodeParameter = null;
            this.popPlant_Cd.AutoPopupID = null;
            this.popPlant_Cd.AutoPopupNameParameter = null;
            this.popPlant_Cd.CodeMaxLength = 4;
            this.popPlant_Cd.CodeName = "";
            this.popPlant_Cd.CodeSize = 100;
            this.popPlant_Cd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPlant_Cd.CodeTextBoxName = null;
            this.popPlant_Cd.CodeValue = "";
            this.popPlant_Cd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popPlant_Cd.Location = new System.Drawing.Point(137, 7);
            this.popPlant_Cd.LockedField = false;
            this.popPlant_Cd.Margin = new System.Windows.Forms.Padding(0);
            this.popPlant_Cd.Name = "popPlant_Cd";
            this.popPlant_Cd.NameDisplay = true;
            this.popPlant_Cd.NameId = null;
            this.popPlant_Cd.NameMaxLength = 50;
            this.popPlant_Cd.NamePopup = false;
            this.popPlant_Cd.NameSize = 150;
            this.popPlant_Cd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popPlant_Cd.Parameter = null;
            this.popPlant_Cd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popPlant_Cd.PopupId = null;
            this.popPlant_Cd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popPlant_Cd.QueryIfEnterKeyPressed = true;
            this.popPlant_Cd.RequiredField = false;
            this.popPlant_Cd.Size = new System.Drawing.Size(271, 21);
            this.popPlant_Cd.TabIndex = 0;
            this.popPlant_Cd.uniALT = "Plant";
            this.popPlant_Cd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popPlant_Cd.UseDynamicFormat = false;
            this.popPlant_Cd.ValueTextBoxName = null;
            this.popPlant_Cd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popPlant_Cd_BeforePopupOpen);
            this.popPlant_Cd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popPlant_Cd_AfterPopupClosed);
            // 
            // popSL_Cd
            // 
            this.popSL_Cd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSL_Cd.AutoPopupCodeParameter = null;
            this.popSL_Cd.AutoPopupID = null;
            this.popSL_Cd.AutoPopupNameParameter = null;
            this.popSL_Cd.CodeMaxLength = 10;
            this.popSL_Cd.CodeName = "";
            this.popSL_Cd.CodeSize = 100;
            this.popSL_Cd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSL_Cd.CodeTextBoxName = null;
            this.popSL_Cd.CodeValue = "";
            this.popSL_Cd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popSL_Cd.Location = new System.Drawing.Point(626, 7);
            this.popSL_Cd.LockedField = false;
            this.popSL_Cd.Margin = new System.Windows.Forms.Padding(0);
            this.popSL_Cd.Name = "popSL_Cd";
            this.popSL_Cd.NameDisplay = true;
            this.popSL_Cd.NameId = null;
            this.popSL_Cd.NameMaxLength = 50;
            this.popSL_Cd.NamePopup = false;
            this.popSL_Cd.NameSize = 150;
            this.popSL_Cd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSL_Cd.Parameter = null;
            this.popSL_Cd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSL_Cd.PopupId = null;
            this.popSL_Cd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSL_Cd.QueryIfEnterKeyPressed = true;
            this.popSL_Cd.RequiredField = false;
            this.popSL_Cd.Size = new System.Drawing.Size(271, 21);
            this.popSL_Cd.TabIndex = 1;
            this.popSL_Cd.uniALT = "Storage Location";
            this.popSL_Cd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popSL_Cd.UseDynamicFormat = false;
            this.popSL_Cd.ValueTextBoxName = null;
            this.popSL_Cd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSL_Cd_BeforePopupOpen);
            this.popSL_Cd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSL_Cd_AfterPopupClosed);
            // 
            // popItem_Cd
            // 
            this.popItem_Cd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popItem_Cd.AutoPopupCodeParameter = null;
            this.popItem_Cd.AutoPopupID = null;
            this.popItem_Cd.AutoPopupNameParameter = null;
            this.popItem_Cd.CodeMaxLength = 50;
            this.popItem_Cd.CodeName = "";
            this.popItem_Cd.CodeSize = 150;
            this.popItem_Cd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popItem_Cd.CodeTextBoxName = null;
            this.popItem_Cd.CodeValue = "";
            this.popItem_Cd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popItem_Cd.Location = new System.Drawing.Point(137, 30);
            this.popItem_Cd.LockedField = false;
            this.popItem_Cd.Margin = new System.Windows.Forms.Padding(0);
            this.popItem_Cd.Name = "popItem_Cd";
            this.popItem_Cd.NameDisplay = true;
            this.popItem_Cd.NameId = null;
            this.popItem_Cd.NameMaxLength = 50;
            this.popItem_Cd.NamePopup = false;
            this.popItem_Cd.NameSize = 150;
            this.popItem_Cd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popItem_Cd.Parameter = null;
            this.popItem_Cd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popItem_Cd.PopupId = null;
            this.popItem_Cd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popItem_Cd.QueryIfEnterKeyPressed = true;
            this.popItem_Cd.RequiredField = false;
            this.popItem_Cd.Size = new System.Drawing.Size(321, 21);
            this.popItem_Cd.TabIndex = 2;
            this.popItem_Cd.uniALT = "Item";
            this.popItem_Cd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popItem_Cd.UseDynamicFormat = false;
            this.popItem_Cd.ValueTextBoxName = null;
            this.popItem_Cd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popItem_Cd_BeforePopupOpen);
            this.popItem_Cd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popItem_Cd_AfterPopupClosed);
            // 
            // popInvunit
            // 
            this.popInvunit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popInvunit.AutoPopupCodeParameter = null;
            this.popInvunit.AutoPopupID = null;
            this.popInvunit.AutoPopupNameParameter = null;
            this.popInvunit.CodeMaxLength = 3;
            this.popInvunit.CodeName = "";
            this.popInvunit.CodeSize = 100;
            this.popInvunit.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popInvunit.CodeTextBoxName = null;
            this.popInvunit.CodeValue = "";
            this.popInvunit.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Nullable;
            this.popInvunit.Location = new System.Drawing.Point(626, 30);
            this.popInvunit.LockedField = false;
            this.popInvunit.Margin = new System.Windows.Forms.Padding(0);
            this.popInvunit.Name = "popInvunit";
            this.popInvunit.NameDisplay = true;
            this.popInvunit.NameId = null;
            this.popInvunit.NameMaxLength = 50;
            this.popInvunit.NamePopup = false;
            this.popInvunit.NameSize = 150;
            this.popInvunit.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popInvunit.Parameter = null;
            this.popInvunit.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popInvunit.PopupId = null;
            this.popInvunit.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popInvunit.QueryIfEnterKeyPressed = true;
            this.popInvunit.RequiredField = false;
            this.popInvunit.Size = new System.Drawing.Size(271, 21);
            this.popInvunit.TabIndex = 3;
            this.popInvunit.uniALT = "SKU";
            this.popInvunit.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popInvunit.UseDynamicFormat = false;
            this.popInvunit.ValueTextBoxName = null;
            this.popInvunit.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popInvunit_BeforePopupOpen);
            this.popInvunit.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popInvunit_AfterPopupClosed);
            // 
            // rdoValidDateCheck
            // 
            appearance7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.rdoValidDateCheck.Appearance = appearance7;
            this.rdoValidDateCheck.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.rdoValidDateCheck.CheckedIndex = 1;
            this.rdoValidDateCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rdoValidDateCheck.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            valueListItem1.DataValue = "Y";
            valueListItem1.DisplayText = "Yes";
            valueListItem2.DataValue = "N";
            valueListItem2.DisplayText = "No";
            this.rdoValidDateCheck.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1,
            valueListItem2});
            this.rdoValidDateCheck.ItemSpacingHorizontal = 30;
            this.rdoValidDateCheck.ItemSpacingVertical = 10;
            this.rdoValidDateCheck.Location = new System.Drawing.Point(137, 51);
            this.rdoValidDateCheck.LockedField = false;
            this.rdoValidDateCheck.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.rdoValidDateCheck.Name = "rdoValidDateCheck";
            this.rdoValidDateCheck.RequiredField = false;
            this.rdoValidDateCheck.Size = new System.Drawing.Size(349, 23);
            this.rdoValidDateCheck.StyleSetName = "Default";
            this.rdoValidDateCheck.TabIndex = 4;
            this.rdoValidDateCheck.Text = "No";
            this.rdoValidDateCheck.uniALT = "Valid Data Check";
            // 
            // rdoGoodQtyFlag
            // 
            appearance8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.rdoGoodQtyFlag.Appearance = appearance8;
            this.rdoGoodQtyFlag.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.rdoGoodQtyFlag.CheckedIndex = 1;
            this.rdoGoodQtyFlag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rdoGoodQtyFlag.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            valueListItem3.DataValue = "Y";
            valueListItem3.DisplayText = "Exist Only";
            valueListItem4.DataValue = "N";
            valueListItem4.DisplayText = "All Item";
            this.rdoGoodQtyFlag.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem3,
            valueListItem4});
            this.rdoGoodQtyFlag.ItemSpacingHorizontal = 30;
            this.rdoGoodQtyFlag.ItemSpacingVertical = 10;
            this.rdoGoodQtyFlag.Location = new System.Drawing.Point(626, 51);
            this.rdoGoodQtyFlag.LockedField = false;
            this.rdoGoodQtyFlag.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.rdoGoodQtyFlag.Name = "rdoGoodQtyFlag";
            this.rdoGoodQtyFlag.RequiredField = false;
            this.rdoGoodQtyFlag.Size = new System.Drawing.Size(350, 23);
            this.rdoGoodQtyFlag.StyleSetName = "Default";
            this.rdoGoodQtyFlag.TabIndex = 5;
            this.rdoGoodQtyFlag.Text = "All Item";
            this.rdoGoodQtyFlag.uniALT = "Good Qty. Exist Flag";
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 25;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 120);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(979, 588);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 0;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance9.BackColor = System.Drawing.SystemColors.Window;
            appearance9.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance9;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance10.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance10.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance10;
            appearance11.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance11;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance12.BackColor2 = System.Drawing.SystemColors.Control;
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance12.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance12;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance13.BackColor = System.Drawing.SystemColors.Window;
            appearance13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance13;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance14.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance14;
            appearance15.BorderColor = System.Drawing.Color.Silver;
            appearance15.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance15;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance16.BackColor = System.Drawing.SystemColors.Control;
            appearance16.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance16.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance16.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance16;
            appearance17.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance17;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance18.BackColor = System.Drawing.SystemColors.Window;
            appearance18.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance18;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance19.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance19;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(979, 588);
            this.uniGrid1.StyleSetName = "Default";
            this.uniGrid1.TabIndex = 0;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.Controls.Add(this.lblInventoryDetail, 2, 0);
            this.uniTBL_MainReference.DefaultRowSize = 25;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(979, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblInventoryDetail
            // 
            appearance20.TextHAlignAsString = "Left";
            appearance20.TextVAlignAsString = "Middle";
            this.lblInventoryDetail.Appearance = appearance20;
            this.lblInventoryDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInventoryDetail.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblInventoryDetail.Location = new System.Drawing.Point(879, 3);
            this.lblInventoryDetail.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblInventoryDetail.Name = "lblInventoryDetail";
            this.lblInventoryDetail.Size = new System.Drawing.Size(100, 15);
            this.lblInventoryDetail.StyleSetName = "uniLabel_Reference";
            this.lblInventoryDetail.TabIndex = 1;
            this.lblInventoryDetail.Text = "Inventory Detail";
            this.lblInventoryDetail.UseMnemonic = false;
            this.lblInventoryDetail.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblInventoryDetail_BeforePopupOpen);
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 5;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.DefaultRowSize = 25;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 711);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(979, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(990, 760);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainCondition.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoValidDateCheck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoGoodQtyFlag)).EndInit();
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.uniTBL_MainReference.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblPlant_Cd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSL_Cd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblItem_Cd;
        private uniERP.AppFramework.UI.Controls.uniLabel lblInvunit;
        private uniERP.AppFramework.UI.Controls.uniLabel lblValidDateCheck;
        private uniERP.AppFramework.UI.Controls.uniLabel lblGoodQtyFlag;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popPlant_Cd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSL_Cd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popItem_Cd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popInvunit;
        private uniERP.AppFramework.UI.Controls.uniLabel lblInventoryDetail;
        private uniERP.AppFramework.UI.Controls.uniRadioButton rdoValidDateCheck;
        private uniERP.AppFramework.UI.Controls.uniRadioButton rdoGoodQtyFlag;

    }
}
