ALTER PROCEDURE [dbo].[USP_I2211MA1_KO883]            
 (                        
	  @PLANT_CD    NVARCHAR(26) --����                
	, @SL_CD   NVARCHAR(26) --â����
	, @basic_unit   NVARCHAR(26) --�������
    , @item_cd   NVARCHAR(26)--ǰ��                 
	, @valid_flg  int-- ǰ����ȿ��üũ
	, @Good_QTY   int -- ��ǰ����üũ
 ) AS                      
                
 BEGIN                                          
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                    
                                       
SET NOCOUNT ON                    
             
  select  
 e.location,  
 d.plant_cd, 
 d.plant_nm,  
 c.sl_cd, 
 c.sl_nm,  
 b.item_cd, 
 b.item_nm,  
 b.spec, 
 b.basic_unit,  
 a.tracking_no, 
 a.good_on_hand_qty,  -- ��ǰ����
 a.bad_on_hand_qty,   -- �ҷ� �������
 a.stk_on_insp_qty,   -- �˻��߼���
 a.stk_in_trns_qty,   -- �̵��߼���
 e.VALID_FLG
  
 from  i_onhand_stock a(nolock)     
 inner join b_item_by_plant e(nolock)        on  a.plant_cd = e.plant_cd and a.item_cd = e.item_cd     
 inner join b_storage_location c(nolock)        on  a.sl_cd = c.sl_cd     
 inner join b_plant d(nolock)        on  a.plant_cd = d.plant_cd     
 inner join b_item b(nolock)        on  a.item_cd = b.item_cd     
 left outer join ( select   plant_cd, sl_cd, item_cd, tracking_no, sum(picking_qty) picking_qty                         
 from   i_onhand_stock_detail(nolock)                        
 group by plant_cd, sl_cd, item_cd, tracking_no ) f        on a.plant_cd = f.plant_cd and a.sl_cd = f.sl_cd and a.item_cd = f.item_cd and a.tracking_no = f.tracking_no  
 where 
 (
 ( @valid_flg = 0 and (
	 (@PLANT_CD ='' or @PLANT_CD = d.plant_cd )
	 and (@SL_CD ='' or @SL_CD = c.sl_cd )
	 and (a.tracking_no >= '') 
	 and (@basic_unit='' or @basic_unit = b.basic_unit )
	 and (@item_cd ='' or b.item_cd like @item_cd ) 
	 and (e.valid_flg = 'y' and e.valid_from_dt <=  getdate() and e.valid_to_dt >= getdate()) )
	 and (
			(@Good_QTY=0 and 
				(a.good_on_hand_qty <> 0) )  
							or (@Good_QTY=1 and (a.GOOD_ON_HAND_QTY>=0))
			)
		 )

			  or 
					( @valid_flg = 1 and(
					(@PLANT_CD ='' or @PLANT_CD = d.plant_cd )
					and (@SL_CD ='' or @SL_CD = c.sl_cd )
					and (a.tracking_no >= '' )
					and (@basic_unit='' or @basic_unit = b.basic_unit )
					and (@item_cd ='' or b.item_cd like @item_cd ) 
					and (
			(@Good_QTY=0 and 
				(a.good_on_hand_qty <> 0) )  
							or (@Good_QTY=1 and (a.GOOD_ON_HAND_QTY>=0))
			)
		 )
		 
			)
		)
	

  order by c.sl_cd asc, b.item_cd asc,  a.tracking_no  asc 
 END 


 --(LEN(EMP_NM) < (CASE WHEN @ET_Check ='0' THEN 9999
 --                      ELSE 2


 --(@gubun = 'Y' AND (ToiDate != '____/__/__' and ToiDate <= @ToiDate))


 --exec USP_I2211MA1_KO883 @PLANT_CD=N'P1',@SL_CD=N'I101',@item_cd=N'',@basic_unit=N'',@valid_flg=NULL

exec USP_I2211MA1_KO883 @PLANT_CD=N'P1',@SL_CD=N'I101',@item_cd=N'301-F-072067',@basic_unit=N'CDM',@valid_flg=N'1',@Good_QTY=N'1'