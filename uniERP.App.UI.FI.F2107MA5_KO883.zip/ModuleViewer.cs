﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Common.Exceptions;
using uniERP.AppFramework.DataBridge;
//using System.Xml.Linq;
using System.Linq;


#endregion

namespace uniERP.App.UI.FI.F2107MA5_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①uniERP.App.UI.HR.H4007M2_KO883</NameSpace>
        /// <Module>②PS</Module>
        /// <Class>③ModuleViewer name</Class>
        /// <Desc>④
        ///   This part describe the summary information about class 
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="KSK" Date="2018-07-26">Make …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        #endregion

        #region ■ 1.4 Class global constants (grid)


        #endregion

        #region ■ 1.5 Class global variables (grid)

        // change your code
        private tdsY8101M2_KO883 cstdsY8101M2_KO883 = new tdsY8101M2_KO883();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(this.cstdsY8101M2_KO883);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T06_SingleMultiMulti);
            //uniBase.UCommon.SetViewType(enumDef.ViewType.T04_MultiMulti);

            //uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.Common);  // Load company numeric format. I: Input Program, *: All Module

            //uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Query, enumDef.ModuleInformation.Purchase);  // Load company numeric format. I: Input Program, *: All Module

            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format
        }

        protected override void Form_Load_Completed()
        {
            // popProject.Focus();                // Set focus
            //dtYYYYMM.Value = uniBase.UDate.GetDBServerDateTime();
            //dtDocumentDt.Value = uniBase.UDate.GetDBServerDateTime();

            //uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.DeleteRow, false);

            //uniBase.UCommon.DisableButton(btnConfirm, true);

            //uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, false);
            //uniBase.UCommon.SetToolBarMultiAll(false);
            //uniBase.UCommon.SetToolBarSingleAll(false);

            uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, false);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Copy, false);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Delete, false);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.First, false);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Last, false);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Next, false);
            uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Prev, false);
            uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.Cancel, false);
            uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.CopyRow, false);
            uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.DeleteAll, false);
            uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.DeleteRow, false);
            uniBase.UCommon.SetToolBarMulti(enumDef.ToolBitMulti.InsertRow, false);


            DateTime today = uniBase.UDate.GetDBServerDateTime();


        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            // init Dataset Row : change your code
            cstdsY8101M2_KO883.Clear();
        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            //uniBase.UCommon.SetToolBarMultiAll(false);
            //uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, false);

            // Assign default value to controls

            Rdo_Type1.CheckedIndex = 0;
            Rdo_Type2.CheckedIndex = 0;
            popDeptCd.Enabled = false;

            uniGrid2.Visible = false;
            uniGrid3.Visible = false;
            uniGrid4.Visible = false;

            return;
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            // Example: Set ComboBox List (Column Name, Select, From, Where)

            //sdf
            //uniBase.UData.ComboCustomAdd("DAY_WEEK", " w_day ", " ( select	'평일' as w_day union all select	'휴일' as w_day ) a ", "1=1");
            //uniBase.UData.ComboCustomAdd("DefaultFilePath", " MINOR_NM ", " B_MINOR ", " MAJOR_CD = 'ZH006' ");


            // Example: Set ComboBox List (Column Name, Select, From, Where)
            //uniBase.UData.ComboMajorAdd("TaxPolicy", "B0004");
            //uniBase.UData.ComboCustomAdd("DAY_WEEK", "MINOR_CD , MINOR_NM ", "B_MINOR", "MAJOR_CD='XH004'");
        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆
            base.viewTB19029.ggUserDefined6.DecPoint = 1;
            base.viewTB19029.ggUserDefined6.Integeral = 18;
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            tdsY8101M2_KO883.E_FI_MA1DataTable uniGridTB1 = cstdsY8101M2_KO883.E_FI_MA1;
            tdsY8101M2_KO883.E_FI_MA2DataTable uniGridTB2 = cstdsY8101M2_KO883.E_FI_MA2;
            tdsY8101M2_KO883.E_FI_MA3DataTable uniGridTB3 = cstdsY8101M2_KO883.E_FI_MA3;
            tdsY8101M2_KO883.E_FI_MA4DataTable uniGridTB4 = cstdsY8101M2_KO883.E_FI_MA4;


            //if (Rdo_Type1.CheckedIndex.ToString().Trim() == "0")
            //{
            //    if (Rdo_Type2.CheckedIndex.ToString().Trim() == "0") // 계정별, 분기별---------------------------------------------------  
            //    {

            //uniGrid2.SSSetEdit(uniGridTB2.bdg_cdColumn.ColumnName, "예산코드", 90, enumDef.FieldType.ReadOnly);
            //uniGrid2.SSSetEdit(uniGridTB2.gp_acct_nmColumn.ColumnName, "예산코드명", 120, enumDef.FieldType.ReadOnly);
            //uniGrid2.SSSetEdit(uniGridTB2.acct_cdColumn.ColumnName, "계정코드", 90, enumDef.FieldType.ReadOnly);
            //uniGrid2.SSSetEdit(uniGridTB2.acct_nmColumn.ColumnName, "계정코드명", 120, enumDef.FieldType.ReadOnly);  
            uniGrid2.SSSetEdit(uniGridTB2.gp_cdColumn.ColumnName, "계정그룹", 90, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetEdit(uniGridTB2.gp_nmColumn.ColumnName, "계정그룹명", 120, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.bdg_plan_amtColumn.ColumnName, "계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.bdg_amtColumn.ColumnName, "실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.sum_amtColumn.ColumnName, "실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.sum_balColumn.ColumnName, "잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.oneQ_plan_amtColumn.ColumnName, "1분기계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.oneQ_budget_amtColumn.ColumnName, "1분기계획실적", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.oneQ_SumColumn.ColumnName, "1분기실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.oneQ_balColumn.ColumnName, "1분기잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.twoQ_Plan_AmtColumn.ColumnName, "2분기계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.twoQ_Budget_AmtColumn.ColumnName, "2분기계획실적", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.twoQ_SumColumn.ColumnName, "2분기실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.twoQ_balColumn.ColumnName, "2분기잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.thrQ_Plan_AmtColumn.ColumnName, "3분기계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.thrQ_Budget_AmtColumn.ColumnName, "3분기계획실적", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.thrQ_SumColumn.ColumnName, "3분기실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.thrQ_balColumn.ColumnName, "3분기잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.forQ_Plan_AmtColumn.ColumnName, "4분기계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.forQ_Budget_AmtColumn.ColumnName, "4분기계획실적", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.for_SumColumn.ColumnName, "4분기실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid2.SSSetFloat(uniGridTB2.for_balColumn.ColumnName, "4분기잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);



            //}
            //else if (Rdo_Type2.CheckedIndex.ToString().Trim() == "1") // ------계정별, 월별----------------------------------  
            //{

            //uniGrid1.SSSetEdit(uniGridTB1.bdg_cdColumn.ColumnName, "예산코드", 90, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetEdit(uniGridTB1.gp_acct_nmColumn.ColumnName, "예산코드명", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.gp_cdColumn.ColumnName, "계정그룹", 90, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetEdit(uniGridTB1.gp_nmColumn.ColumnName, "계정그룹명", 120, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetEdit(uniGridTB1.acct_cdColumn.ColumnName, "계정코드", 90, enumDef.FieldType.ReadOnly);
            //uniGrid1.SSSetEdit(uniGridTB1.acct_nmColumn.ColumnName, "계정코드명", 120, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.bdg_plan_amtColumn.ColumnName, "계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.bdg_amtColumn.ColumnName, "실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.sum_amtColumn.ColumnName, "실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.sum_balColumn.ColumnName, "잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.jan_plan_amtColumn.ColumnName, "1월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.jan_budget_amtColumn.ColumnName, "1월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jan_SumColumn.ColumnName, "1월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jan_balColumn.ColumnName, "1월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Feb_Plan_AmtColumn.ColumnName, "2월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Feb_Budget_AmtColumn.ColumnName, "2월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Feb_SumColumn.ColumnName, "2월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Feb_balColumn.ColumnName, "2월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Mar_Plan_AmtColumn.ColumnName, "3월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Mar_Budget_AmtColumn.ColumnName, "3월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Mar_SumColumn.ColumnName, "3월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Mar_balColumn.ColumnName, "3월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Apr_Plan_AmtColumn.ColumnName, "4월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Apr_Budget_AmtColumn.ColumnName, "4월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Apr_SumColumn.ColumnName, "4월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Apr_balColumn.ColumnName, "4월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.May_Plan_AmtColumn.ColumnName, "5월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.May_Budget_AmtColumn.ColumnName, "5월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.May_SumColumn.ColumnName, "5월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.May_balColumn.ColumnName, "5월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jun_Plan_AmtColumn.ColumnName, "6월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jun_Budget_AmtColumn.ColumnName, "6월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jun_SumColumn.ColumnName, "6월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jun_balColumn.ColumnName, "6월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jul_Plan_AmtColumn.ColumnName, "7월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jul_Budget_AmtColumn.ColumnName, "7월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jul_SumColumn.ColumnName, "7월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Jul_balColumn.ColumnName, "7월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Aug_Plan_AmtColumn.ColumnName, "8월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Aug_Budget_AmtColumn.ColumnName, "8월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Aug_SumColumn.ColumnName, "8월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Aug_balColumn.ColumnName, "8월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Sep_Plan_AmtColumn.ColumnName, "9월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Sep_Budget_AmtColumn.ColumnName, "9월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Sep_SumColumn.ColumnName, "9월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Sep_balColumn.ColumnName, "9월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Oct_Plan_AmtColumn.ColumnName, "10월실적예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Oct_Budget_AmtColumn.ColumnName, "10월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Oct_SumColumn.ColumnName, "10월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Oct_balColumn.ColumnName, "10월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Nov_Plan_AmtColumn.ColumnName, "11월실적예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Nov_Budget_AmtColumn.ColumnName, "11월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Nov_SumColumn.ColumnName, "11월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Nov_balColumn.ColumnName, "11월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Dec_Plan_AmtColumn.ColumnName, "12월실적예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Dec_Budget_AmtColumn.ColumnName, "12월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Dec_SumColumn.ColumnName, "12월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid1.SSSetFloat(uniGridTB1.Dec_balColumn.ColumnName, "12월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            //    }

            //}
            //else if (Rdo_Type1.CheckedIndex.ToString().Trim() == "1")
            //{
            //    if (Rdo_Type2.CheckedIndex.ToString().Trim() == "0")  // 계정/부서별, 분기별---------------------------------------------------  
            //    {

            //uniGrid4.SSSetEdit(uniGridTB4.bdg_cdColumn.ColumnName, "예산코드", 90, enumDef.FieldType.ReadOnly);
            //uniGrid4.SSSetEdit(uniGridTB4.gp_acct_nmColumn.ColumnName, "예산코드명", 120, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetEdit(uniGridTB4.gp_cdColumn.ColumnName, "계정그룹", 90, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetEdit(uniGridTB4.gp_nmColumn.ColumnName, "계정그룹명", 120, enumDef.FieldType.ReadOnly);
            //uniGrid4.SSSetEdit(uniGridTB4.acct_cdColumn.ColumnName, "계정코드", 90, enumDef.FieldType.ReadOnly);
            //uniGrid4.SSSetEdit(uniGridTB4.acct_nmColumn.ColumnName, "계정코드명", 120, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetEdit(uniGridTB4.dept_cdColumn.ColumnName, "부서코드", 90, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetEdit(uniGridTB4.dept_nmColumn.ColumnName, "부서명", 90, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.bdg_plan_amtColumn.ColumnName, "계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.bdg_amtColumn.ColumnName, "실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.sum_amtColumn.ColumnName, "실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.sum_balColumn.ColumnName, "잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.oneQ_plan_amtColumn.ColumnName, "1분기계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.oneQ_budget_amtColumn.ColumnName, "1분기계획실적", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.oneQ_SumColumn.ColumnName, "1분기실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.oneQ_balColumn.ColumnName, "1분기잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.twoQ_Plan_AmtColumn.ColumnName, "2분기계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.twoQ_Budget_AmtColumn.ColumnName, "2분기계획실적", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.twoQ_SumColumn.ColumnName, "2분기실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.twoQ_balColumn.ColumnName, "2분기잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.thrQ_Plan_AmtColumn.ColumnName, "3분기계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.thrQ_Budget_AmtColumn.ColumnName, "3분기계획실적", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.thrQ_SumColumn.ColumnName, "3분기실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.thrQ_balColumn.ColumnName, "3분기잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.forQ_Plan_AmtColumn.ColumnName, "4분기계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.forQ_Budget_AmtColumn.ColumnName, "4분기계획실적", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.for_SumColumn.ColumnName, "4분기실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid4.SSSetFloat(uniGridTB4.for_balColumn.ColumnName, "4분기잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            //}
            //else if (Rdo_Type2.CheckedIndex.ToString().Trim() == "1")  //계정/부서별, 월별---------------------------------------------------  
            //{

            //uniGrid3.SSSetEdit(uniGridTB3.bdg_cdColumn.ColumnName, "예산코드", 90, enumDef.FieldType.ReadOnly);
            //uniGrid3.SSSetEdit(uniGridTB3.gp_acct_nmColumn.ColumnName, "예산코드명", 120, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetEdit(uniGridTB3.gp_cdColumn.ColumnName, "계정그룹", 90, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetEdit(uniGridTB3.gp_nmColumn.ColumnName, "계정그룹명", 120, enumDef.FieldType.ReadOnly);
            //uniGrid3.SSSetEdit(uniGridTB3.acct_cdColumn.ColumnName, "계정코드", 90, enumDef.FieldType.ReadOnly);
            //uniGrid3.SSSetEdit(uniGridTB3.acct_nmColumn.ColumnName, "계정코드명", 120, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetEdit(uniGridTB3.dept_cdColumn.ColumnName, "부서코드", 90, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetEdit(uniGridTB3.dept_nmColumn.ColumnName, "부서명", 90, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.bdg_plan_amtColumn.ColumnName, "계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.bdg_amtColumn.ColumnName, "실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.sum_amtColumn.ColumnName, "실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.sum_balColumn.ColumnName, "잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.jan_plan_amtColumn.ColumnName, "1월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.jan_budget_amtColumn.ColumnName, "1월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jan_SumColumn.ColumnName, "1월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jan_balColumn.ColumnName, "1월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Feb_Plan_AmtColumn.ColumnName, "2월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Feb_Budget_AmtColumn.ColumnName, "2월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Feb_SumColumn.ColumnName, "2월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Feb_balColumn.ColumnName, "2월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Mar_Plan_AmtColumn.ColumnName, "3월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Mar_Budget_AmtColumn.ColumnName, "3월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Mar_SumColumn.ColumnName, "3월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Mar_balColumn.ColumnName, "3월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Apr_Plan_AmtColumn.ColumnName, "4월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Apr_Budget_AmtColumn.ColumnName, "4월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Apr_SumColumn.ColumnName, "4월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Apr_balColumn.ColumnName, "4월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.May_Plan_AmtColumn.ColumnName, "5월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.May_Budget_AmtColumn.ColumnName, "5월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.May_SumColumn.ColumnName, "5월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.May_balColumn.ColumnName, "5월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jun_Plan_AmtColumn.ColumnName, "6월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jun_Budget_AmtColumn.ColumnName, "6월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jun_SumColumn.ColumnName, "6월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jun_balColumn.ColumnName, "6월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jul_Plan_AmtColumn.ColumnName, "7월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jul_Budget_AmtColumn.ColumnName, "7월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jul_SumColumn.ColumnName, "7월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Jul_balColumn.ColumnName, "7월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Aug_Plan_AmtColumn.ColumnName, "8월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Aug_Budget_AmtColumn.ColumnName, "8월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Aug_SumColumn.ColumnName, "8월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Aug_balColumn.ColumnName, "8월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Sep_Plan_AmtColumn.ColumnName, "9월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Sep_Budget_AmtColumn.ColumnName, "9월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Sep_SumColumn.ColumnName, "9월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Sep_balColumn.ColumnName, "9월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Oct_Plan_AmtColumn.ColumnName, "10월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Oct_Budget_AmtColumn.ColumnName, "10월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Oct_SumColumn.ColumnName, "10월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Oct_balColumn.ColumnName, "10월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Nov_Plan_AmtColumn.ColumnName, "11월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Nov_Budget_AmtColumn.ColumnName, "11월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Nov_SumColumn.ColumnName, "11월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Nov_balColumn.ColumnName, "11월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Dec_Plan_AmtColumn.ColumnName, "12월계획예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Dec_Budget_AmtColumn.ColumnName, "12월실행예산", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Dec_SumColumn.ColumnName, "12월실적합계", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            uniGrid3.SSSetFloat(uniGridTB3.Dec_balColumn.ColumnName, "12월잔액", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            //}
            //        }
            //}


            #endregion

            #region ■■ 3.1.2 Formatting grid information

            //this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);
            //this.uniGrid2.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);
            //this.uniGrid3.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);
            //this.uniGrid4.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);
            //열머리끌어이동으로 그리드 조회방식 수정
            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.Yes, enumDef.IsSearch.Yes);
            this.uniGrid2.InitializeGrid(enumDef.IsOutlookGroupBy.Yes, enumDef.IsSearch.Yes);
            this.uniGrid3.InitializeGrid(enumDef.IsOutlookGroupBy.Yes, enumDef.IsSearch.Yes);
            this.uniGrid4.InitializeGrid(enumDef.IsOutlookGroupBy.Yes, enumDef.IsSearch.Yes);

            uniGrid1.flagInformation("select_char", "count");
            //uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);

            string[] summaryColumn = new string[52];  // 계정별 , 월별 
            summaryColumn[0] = "bdg_plan_amt";
            summaryColumn[1] = "bdg_amt";
            summaryColumn[2] = "sum_amt";
            summaryColumn[3] = "sum_bal";
            summaryColumn[4] = "jan_plan_amt";
            summaryColumn[5] = "jan_budget_amt";
            summaryColumn[6] = "Jan_Sum";
            summaryColumn[7] = "Jan_bal";
            summaryColumn[8] = "Feb_Plan_Amt";
            summaryColumn[9] = "Feb_Budget_Amt";
            summaryColumn[10] = "Feb_Sum";
            summaryColumn[11] = "Feb_bal";
            summaryColumn[12] = "Mar_Plan_Amt";
            summaryColumn[13] = "Mar_Budget_Amt";
            summaryColumn[14] = "Mar_Sum";
            summaryColumn[15] = "Mar_bal";
            summaryColumn[16] = "Apr_Plan_Amt";
            summaryColumn[17] = "Apr_Budget_Amt";
            summaryColumn[18] = "Apr_Sum";
            summaryColumn[19] = "Apr_bal";
            summaryColumn[20] = "May_Plan_Amt";
            summaryColumn[21] = "May_Budget_Amt";
            summaryColumn[22] = "May_Sum";
            summaryColumn[23] = "May_bal";
            summaryColumn[24] = "Jun_Plan_Amt";
            summaryColumn[25] = "Jun_Budget_Amt";
            summaryColumn[26] = "Jun_Sum";
            summaryColumn[27] = "Jun_bal";
            summaryColumn[28] = "Jul_Plan_Amt";
            summaryColumn[29] = "Jul_Budget_Amt";
            summaryColumn[30] = "Jul_Sum";
            summaryColumn[31] = "Jul_bal";
            summaryColumn[32] = "Aug_Plan_Amt";
            summaryColumn[33] = "Aug_Budget_Amt";
            summaryColumn[34] = "Aug_Sum";
            summaryColumn[35] = "Aug_bal";
            summaryColumn[36] = "Sep_Plan_Amt";
            summaryColumn[37] = "Sep_Budget_Amt";
            summaryColumn[38] = "Sep_Sum";
            summaryColumn[39] = "Sep_bal";
            summaryColumn[40] = "Oct_Plan_Amt";
            summaryColumn[41] = "Oct_Budget_Amt";
            summaryColumn[42] = "Oct_Sum";
            summaryColumn[43] = "Oct_bal";
            summaryColumn[44] = "Nov_Plan_Amt";
            summaryColumn[45] = "Nov_Budget_Amt";
            summaryColumn[46] = "Nov_Sum";
            summaryColumn[47] = "Nov_bal";
            summaryColumn[48] = "Dec_Plan_Amt";
            summaryColumn[49] = "Dec_Budget_Amt";
            summaryColumn[50] = "Dec_Sum";
            summaryColumn[51] = "Dec_bal";



            string[] summaryColumn_2 = new string[20];  // 계정별 , 월별 
            summaryColumn_2[0] = "bdg_plan_amt";
            summaryColumn_2[1] = "bdg_amt";
            summaryColumn_2[2] = "sum_amt";
            summaryColumn_2[3] = "sum_bal";
            summaryColumn_2[4] = "oneQ_plan_amt";
            summaryColumn_2[5] = "oneQ_budget_amt";
            summaryColumn_2[6] = "oneQ_Sum";
            summaryColumn_2[7] = "oneQ_bal";
            summaryColumn_2[8] = "twoQ_Plan_Amt";
            summaryColumn_2[9] = "twoQ_Budget_Amt";
            summaryColumn_2[10] = "twoQ_Sum";
            summaryColumn_2[11] = "twoQ_bal";
            summaryColumn_2[12] = "thrQ_Plan_Amt";
            summaryColumn_2[13] = "thrQ_Budget_Amt";
            summaryColumn_2[14] = "thrQ_Sum";
            summaryColumn_2[15] = "thrQ_bal";
            summaryColumn_2[16] = "forQ_Plan_Amt";
            summaryColumn_2[17] = "forQ_Budget_Amt";
            summaryColumn_2[18] = "for_Sum";
            summaryColumn_2[19] = "for_bal";





            uniGrid1.SetSummary(summaryColumn);
            uniGrid2.SetSummary(summaryColumn_2);
            uniGrid3.SetSummary(summaryColumn);
            uniGrid4.SetSummary(summaryColumn_2);

            #endregion

            #region ■■ 3.1.3 Setting etc grid
            //this.uniGrid1.SSSetColHidden(uniGridTB1.YYYYColumn.ColumnName);
            //this.uniGrid1.SSSetColHidden(uniGridTB1.DILIG_DTColumn.ColumnName);

            // 계정별,월별
            this.uniGrid1.SSSetColHidden(uniGridTB1.bdg_amtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.sum_amtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.sum_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.jan_budget_amtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Feb_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Mar_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Apr_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.May_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Jun_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Jul_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Aug_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Sep_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Oct_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Nov_Budget_AmtColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Dec_Budget_AmtColumn.ColumnName);

            this.uniGrid1.SSSetColHidden(uniGridTB1.Jan_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Feb_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Mar_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Apr_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.May_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Jun_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Jul_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Aug_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Sep_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Oct_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Nov_SumColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Dec_SumColumn.ColumnName);

            this.uniGrid1.SSSetColHidden(uniGridTB1.Jan_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Feb_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Mar_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Apr_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.May_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Jun_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Jul_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Aug_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Sep_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Oct_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Nov_balColumn.ColumnName);
            this.uniGrid1.SSSetColHidden(uniGridTB1.Dec_balColumn.ColumnName);

            // 계정별,분기별
            this.uniGrid2.SSSetColHidden(uniGridTB2.bdg_amtColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.sum_amtColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.sum_balColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.oneQ_budget_amtColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.twoQ_Budget_AmtColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.thrQ_Budget_AmtColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.forQ_Budget_AmtColumn.ColumnName);

            this.uniGrid2.SSSetColHidden(uniGridTB2.oneQ_SumColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.twoQ_SumColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.thrQ_SumColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.for_SumColumn.ColumnName);

            this.uniGrid2.SSSetColHidden(uniGridTB2.oneQ_balColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.twoQ_balColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.thrQ_balColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.for_balColumn.ColumnName);

            // 계정/부서별,월별
            this.uniGrid3.SSSetColHidden(uniGridTB3.bdg_amtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.sum_amtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.sum_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.jan_budget_amtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Feb_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Mar_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Apr_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.May_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Jun_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Jul_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Aug_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Sep_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Oct_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Nov_Budget_AmtColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Dec_Budget_AmtColumn.ColumnName);

            this.uniGrid3.SSSetColHidden(uniGridTB3.Jan_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Feb_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Mar_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Apr_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.May_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Jun_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Jul_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Aug_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Sep_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Oct_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Nov_SumColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Dec_SumColumn.ColumnName);

            this.uniGrid3.SSSetColHidden(uniGridTB3.Jan_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Feb_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Mar_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Apr_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.May_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Jun_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Jul_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Aug_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Sep_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Oct_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Nov_balColumn.ColumnName);
            this.uniGrid3.SSSetColHidden(uniGridTB3.Dec_balColumn.ColumnName);

            // 계정/부서별, 분기별
            this.uniGrid4.SSSetColHidden(uniGridTB4.bdg_amtColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.sum_amtColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.sum_balColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.oneQ_budget_amtColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.twoQ_Budget_AmtColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.thrQ_Budget_AmtColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.forQ_Budget_AmtColumn.ColumnName);

            this.uniGrid4.SSSetColHidden(uniGridTB4.oneQ_SumColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.twoQ_SumColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.thrQ_SumColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.for_SumColumn.ColumnName);

            this.uniGrid4.SSSetColHidden(uniGridTB4.oneQ_balColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.twoQ_balColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.thrQ_balColumn.ColumnName);
            this.uniGrid4.SSSetColHidden(uniGridTB4.for_balColumn.ColumnName);

            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
            // TO-DO: 컨트롤을 초기화(또는 초기값)할때 할일 
            // SetDefaultVal과의 차이점은 전자는 Form_Load 시점에 콘트롤에 초기값을 세팅하는것이고
            // 후자는 특정 시점(조회후 또는 행추가후 등 특정이벤트)에서 초기값을 셋팅한다.
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            // Grid binding with global dataset variable.
            this.InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(this.cstdsY8101M2_KO883.E_FI_MA1);
            this.uniGrid2.uniGridSetDataBinding(this.cstdsY8101M2_KO883.E_FI_MA2);
            this.uniGrid3.uniGridSetDataBinding(this.cstdsY8101M2_KO883.E_FI_MA3);
            this.uniGrid4.uniGridSetDataBinding(this.cstdsY8101M2_KO883.E_FI_MA4);
            //this.uniGrid2.uniGridSetDataBinding(this.cstdsY8101M2_KO883.E_PMS_PROJECT_RATE_Common);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //TO-DO : code business oriented logic

            if (Rdo_Type1.CheckedIndex == 0)
            {
                if (Rdo_Type2.CheckedIndex == 0)
                {
                    uniGrid1.Visible = true;
                    uniGrid1.Enabled = true;

                    uniGrid2.Visible = false;
                    uniGrid2.Enabled = false;
                    uniGrid3.Visible = false;
                    uniGrid3.Enabled = false;
                    uniGrid4.Visible = false;
                    uniGrid4.Enabled = false;

                    return DBQuery();

                }
                else if (Rdo_Type2.CheckedIndex == 1)
                {
                    uniGrid2.Visible = true;
                    uniGrid2.Enabled = true;

                    uniGrid1.Visible = false;
                    uniGrid1.Enabled = false;
                    uniGrid3.Visible = false;
                    uniGrid3.Enabled = false;
                    uniGrid4.Visible = false;
                    uniGrid4.Enabled = false;

                    return DBQuery2();
                }
            }
            else if (Rdo_Type1.CheckedIndex == 1)
            {
                if (Rdo_Type2.CheckedIndex == 0)
                {
                    uniGrid3.Visible = true;
                    uniGrid3.Enabled = true;

                    uniGrid1.Visible = false;
                    uniGrid1.Enabled = false;
                    uniGrid2.Visible = false;
                    uniGrid2.Enabled = false;
                    uniGrid4.Visible = false;
                    uniGrid4.Enabled = false;


                    return DBQuery3();
                }
                else if (Rdo_Type2.CheckedIndex == 1)
                {
                    uniGrid4.Visible = true;
                    uniGrid4.Enabled = true;

                    uniGrid1.Visible = false;
                    uniGrid1.Enabled = false;
                    uniGrid2.Visible = false;
                    uniGrid2.Enabled = false;
                    uniGrid3.Visible = false;
                    uniGrid3.Enabled = false;


                    return DBQuery4();
                }
            }


            return true;

        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)

        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic
            string strCloseFlag = "";

            try
            {
                StringBuilder iSQL = new StringBuilder();
                iSQL.Remove(0, iSQL.Length);

                if (iSQL.Length > 0)
                {
                    uniERP.AppFramework.DataBridge.uniCommand uniCmd = uniBase.UDatabase.GetSqlStringCommand(iSQL.ToString());
                    DataSet dsCloseStatus = uniBase.UDatabase.ExecuteDataSet(uniCmd);

                    if (dsCloseStatus != null && dsCloseStatus.Tables[0].Rows.Count > 0)
                    {
                        strCloseFlag = dsCloseStatus.Tables[0].Rows[0][0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }

            //if (strCloseFlag == "I")
            //{
            //    uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "해당월에 수불마감되어 자료를 \n 저장/삭제/변경 할 수 없습니다.");
            //    //236002 --해당월의 수불마감이 이미 되었습니다.
            //    return false;
            //}


            return DBSave();

        }

        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic



            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)


        protected override bool OnPreFncInsertRow()
        {
            //if (uniTabControl1.ActiveTab.Index != 0)
            //{
            //    return false;
            //}

            return base.OnPreFncInsertRow();



        }

        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic           

            if (this.uniGrid1.ActiveRow != null)
            {
                this.uniGrid1.ActiveRow.Cells["work_dt"].Value = uniBase.UDate.GetDBServerDateTime(); // dtYYYYMM.uniValue.ToString("yyyy");


            }



            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            cstdsY8101M2_KO883.Clear();

            DataSet dsResult = null;

            //string dtPerFr = uniBase.UDate.DateTimeToString(DtYear.DateTime.Year);
            //uniBase.UMessage.DisplayMessageBox("Test01", MessageBoxButtons.OK, "테스트 메세지");



            try
            {
                //using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_H4007M2_KO883"))
                using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_F2107MA3_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(uniCommand, "@diff", SqlDbType.NVarChar, Rdo_Type1.CheckedItem.DataValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@quarter", SqlDbType.NVarChar, Rdo_Type2.CheckedItem.DataValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@year", SqlDbType.NVarChar, DtYear.DateTime.Year.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@gp_cd", SqlDbType.NVarChar, popBdgcd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@dept_cd", SqlDbType.NVarChar, popDeptCd.CodeValue.Trim());
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@FLEX_SYS", SqlDbType.NVarChar, popFlexSys.CodeValue.Trim());
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Work_From", SqlDbType.NVarChar, dtPerFr);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Work_To", SqlDbType.NVarChar, dtPerTo);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Start_Time", SqlDbType.NVarChar, dtStartTime);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@End_Time", SqlDbType.NVarChar, dtEndTime);



                    dsResult = uniBase.UDatabase.ExecuteDataSet(uniCommand);

                    //uniGrid1.ActiveRow.Cells["emp_name"].Value = dsResult.Tables[0].Rows[0]["name"].ToString().Trim();


                }

                if (dsResult == null || dsResult.Tables.Count == 0 || dsResult.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return false;
                }

                cstdsY8101M2_KO883.E_FI_MA1.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);


                //cstdsY8101M2_KO883.E_FI_MA1.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA2.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA3.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA4.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);

                //sbSQL.Append("   INSERT WT_MA_KO883 (WORK_DT, EMP_NO , NAME, DAY_WEEK, START_TIME, END_TIME , TOT_TIME, OT, HT, TT, ISRT_EMP_NO , ISRT_DT ,UPDT_EMP_NO ,UPDT_DT ) VALUES(").Append(uniBase.UCommon.FilterVariable(row["WORK_DT"].ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));


                //for (int i = 0; i < uniGrid1.Rows.Count; i++)
                //{
                //    uniGrid1.SpreadLock("EMP_NO", i, i);
                //    uniGrid1.SpreadLock("NAME", i, i);
                //    uniGrid1.SpreadLock("WORK_DT", i, i);
                //   // uniGrid1.SpreadLock("DAY_WEEK", i, i);

                //}

                uniBase.UCommon.SetToolBarMultiAll(true);
                uniBase.UCommon.SetToolBarCommonAll(true);

                // DBQuery2();
            }



            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }
            return true;
        }

        private bool DBQuery2()
        {
            cstdsY8101M2_KO883.Clear();

            DataSet dsResult = null;

            //string dtPerFr = uniBase.UDate.DateTimeToString(DtYear.DateTime.Year);
            //uniBase.UMessage.DisplayMessageBox("Test01", MessageBoxButtons.OK, "테스트 메세지");



            try
            {
                //using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_H4007M2_KO883"))
                using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_F2107MA3_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(uniCommand, "@diff", SqlDbType.NVarChar, Rdo_Type1.CheckedItem.DataValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@quarter", SqlDbType.NVarChar, Rdo_Type2.CheckedItem.DataValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@year", SqlDbType.NVarChar, DtYear.DateTime.Year.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@gp_cd", SqlDbType.NVarChar, popBdgcd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@dept_cd", SqlDbType.NVarChar, popDeptCd.CodeValue.Trim());
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@FLEX_SYS", SqlDbType.NVarChar, popFlexSys.CodeValue.Trim());
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Work_From", SqlDbType.NVarChar, dtPerFr);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Work_To", SqlDbType.NVarChar, dtPerTo);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Start_Time", SqlDbType.NVarChar, dtStartTime);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@End_Time", SqlDbType.NVarChar, dtEndTime);



                    dsResult = uniBase.UDatabase.ExecuteDataSet(uniCommand);

                    //uniGrid1.ActiveRow.Cells["emp_name"].Value = dsResult.Tables[0].Rows[0]["name"].ToString().Trim();


                }

                if (dsResult == null || dsResult.Tables.Count == 0 || dsResult.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return false;
                }

                cstdsY8101M2_KO883.E_FI_MA2.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);


                //cstdsY8101M2_KO883.E_FI_MA1.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA2.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA3.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA4.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);

                //sbSQL.Append("   INSERT WT_MA_KO883 (WORK_DT, EMP_NO , NAME, DAY_WEEK, START_TIME, END_TIME , TOT_TIME, OT, HT, TT, ISRT_EMP_NO , ISRT_DT ,UPDT_EMP_NO ,UPDT_DT ) VALUES(").Append(uniBase.UCommon.FilterVariable(row["WORK_DT"].ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));


                //for (int i = 0; i < uniGrid1.Rows.Count; i++)
                //{
                //    uniGrid1.SpreadLock("EMP_NO", i, i);
                //    uniGrid1.SpreadLock("NAME", i, i);
                //    uniGrid1.SpreadLock("WORK_DT", i, i);
                //   // uniGrid1.SpreadLock("DAY_WEEK", i, i);

                //}

                uniBase.UCommon.SetToolBarMultiAll(true);
                uniBase.UCommon.SetToolBarCommonAll(true);

                // DBQuery2();
            }



            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }
            return true;
        }

        private bool DBQuery3()
        {
            cstdsY8101M2_KO883.Clear();

            DataSet dsResult = null;

            //string dtPerFr = uniBase.UDate.DateTimeToString(DtYear.DateTime.Year);
            //uniBase.UMessage.DisplayMessageBox("Test01", MessageBoxButtons.OK, "테스트 메세지");



            try
            {
                //using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_H4007M2_KO883"))
                using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_F2107MA3_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(uniCommand, "@diff", SqlDbType.NVarChar, Rdo_Type1.CheckedItem.DataValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@quarter", SqlDbType.NVarChar, Rdo_Type2.CheckedItem.DataValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@year", SqlDbType.NVarChar, DtYear.DateTime.Year.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@gp_cd", SqlDbType.NVarChar, popBdgcd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@dept_cd", SqlDbType.NVarChar, popDeptCd.CodeValue.Trim());
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@FLEX_SYS", SqlDbType.NVarChar, popFlexSys.CodeValue.Trim());
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Work_From", SqlDbType.NVarChar, dtPerFr);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Work_To", SqlDbType.NVarChar, dtPerTo);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Start_Time", SqlDbType.NVarChar, dtStartTime);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@End_Time", SqlDbType.NVarChar, dtEndTime);



                    dsResult = uniBase.UDatabase.ExecuteDataSet(uniCommand);

                    //uniGrid1.ActiveRow.Cells["emp_name"].Value = dsResult.Tables[0].Rows[0]["name"].ToString().Trim();


                }

                if (dsResult == null || dsResult.Tables.Count == 0 || dsResult.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return false;
                }

                cstdsY8101M2_KO883.E_FI_MA3.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);


                //cstdsY8101M2_KO883.E_FI_MA1.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA2.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA3.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA4.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);

                //sbSQL.Append("   INSERT WT_MA_KO883 (WORK_DT, EMP_NO , NAME, DAY_WEEK, START_TIME, END_TIME , TOT_TIME, OT, HT, TT, ISRT_EMP_NO , ISRT_DT ,UPDT_EMP_NO ,UPDT_DT ) VALUES(").Append(uniBase.UCommon.FilterVariable(row["WORK_DT"].ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));


                //for (int i = 0; i < uniGrid1.Rows.Count; i++)
                //{
                //    uniGrid1.SpreadLock("EMP_NO", i, i);
                //    uniGrid1.SpreadLock("NAME", i, i);
                //    uniGrid1.SpreadLock("WORK_DT", i, i);
                //   // uniGrid1.SpreadLock("DAY_WEEK", i, i);

                //}

                uniBase.UCommon.SetToolBarMultiAll(true);
                uniBase.UCommon.SetToolBarCommonAll(true);

                // DBQuery2();
            }



            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }
            return true;
        }


        private bool DBQuery4()
        {
            cstdsY8101M2_KO883.Clear();

            DataSet dsResult = null;

            //string dtPerFr = uniBase.UDate.DateTimeToString(DtYear.DateTime.Year);
            //uniBase.UMessage.DisplayMessageBox("Test01", MessageBoxButtons.OK, "테스트 메세지");



            try
            {
                //using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_H4007M2_KO883"))
                using (uniCommand uniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_F2107MA3_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(uniCommand, "@diff", SqlDbType.NVarChar, Rdo_Type1.CheckedItem.DataValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@quarter", SqlDbType.NVarChar, Rdo_Type2.CheckedItem.DataValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@year", SqlDbType.NVarChar, DtYear.DateTime.Year.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@gp_cd", SqlDbType.NVarChar, popBdgcd.CodeValue.Trim());
                    uniBase.UDatabase.AddInParameter(uniCommand, "@dept_cd", SqlDbType.NVarChar, popDeptCd.CodeValue.Trim());
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@FLEX_SYS", SqlDbType.NVarChar, popFlexSys.CodeValue.Trim());
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Work_From", SqlDbType.NVarChar, dtPerFr);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Work_To", SqlDbType.NVarChar, dtPerTo);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@Start_Time", SqlDbType.NVarChar, dtStartTime);
                    //uniBase.UDatabase.AddInParameter(uniCommand, "@End_Time", SqlDbType.NVarChar, dtEndTime);



                    dsResult = uniBase.UDatabase.ExecuteDataSet(uniCommand);

                    //uniGrid1.ActiveRow.Cells["emp_name"].Value = dsResult.Tables[0].Rows[0]["name"].ToString().Trim();


                }

                if (dsResult == null || dsResult.Tables.Count == 0 || dsResult.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return false;
                }

                cstdsY8101M2_KO883.E_FI_MA4.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);


                //cstdsY8101M2_KO883.E_FI_MA1.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA2.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA3.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);
                //cstdsY8101M2_KO883.E_FI_MA4.Merge(dsResult.Tables[0], false, MissingSchemaAction.Ignore);

                //sbSQL.Append("   INSERT WT_MA_KO883 (WORK_DT, EMP_NO , NAME, DAY_WEEK, START_TIME, END_TIME , TOT_TIME, OT, HT, TT, ISRT_EMP_NO , ISRT_DT ,UPDT_EMP_NO ,UPDT_DT ) VALUES(").Append(uniBase.UCommon.FilterVariable(row["WORK_DT"].ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));


                //for (int i = 0; i < uniGrid1.Rows.Count; i++)
                //{
                //    uniGrid1.SpreadLock("EMP_NO", i, i);
                //    uniGrid1.SpreadLock("NAME", i, i);
                //    uniGrid1.SpreadLock("WORK_DT", i, i);
                //   // uniGrid1.SpreadLock("DAY_WEEK", i, i);

                //}

                uniBase.UCommon.SetToolBarMultiAll(true);
                uniBase.UCommon.SetToolBarCommonAll(true);

                // DBQuery2();
            }



            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }
            return true;
        }

        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //TO-DO : code business oriented logic

            return true;
        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            this.uniGrid1.UpdateData();
            cstdsY8101M2_KO883.E_WT_PROJECT.Clear();
            DataTable saveDt = new DataTable();

            try
            {


                cstdsY8101M2_KO883.E_WT_PROJECT.Merge(cstdsY8101M2_KO883.E_WT_MA.GetChanges(), false, MissingSchemaAction.Ignore);
                saveDt.Merge(cstdsY8101M2_KO883.E_WT_PROJECT, false, MissingSchemaAction.Add);
                saveDt.AcceptChanges();

                using (uniCommand _uniCmd = uniBase.UDatabase.GetStoredProcCommand("dbo.USP_H4007M9_KO883_S"))
                {
                    uniBase.UDatabase.AddInParameter(_uniCmd, "@TBL_DATA", SqlDbType.Structured, saveDt);
                    uniBase.UDatabase.AddInParameter(_uniCmd, "@USER_ID", SqlDbType.NVarChar, 15, CommonVariable.gUsrID);
                    uniBase.UDatabase.AddOutParameter(_uniCmd, "@MSG_CD", SqlDbType.NVarChar, 6);
                    uniBase.UDatabase.AddOutParameter(_uniCmd, "@MESSAGE", SqlDbType.NVarChar, 200);
                    uniBase.UDatabase.AddOutParameter(_uniCmd, "@ERR_POS", SqlDbType.Int, 6);

                    uniBase.UDatabase.AddReturnParameter(_uniCmd, "RETURN_VALUE", SqlDbType.Int, 1);

                    uniBase.UDatabase.ExecuteNonQuery(_uniCmd, false);

                    int iReturn = (int)uniBase.UDatabase.GetParameterValue(_uniCmd, "RETURN_VALUE");

                    if (iReturn < 0)
                    {
                        string sMsgCd = uniBase.UDatabase.GetParameterValue(_uniCmd, "@MSG_CD") as string;
                        string sMessage = uniBase.UDatabase.GetParameterValue(_uniCmd, "@MESSAGE") as string;

                        if (string.IsNullOrEmpty(sMsgCd)) sMsgCd = "DT9999";

                        uniBase.UMessage.DisplayMessageBox(sMsgCd, MessageBoxButtons.OK, sMessage);

                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }


            return true;

        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        #region ■■ 5.2.1 ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ButtonClicked >>> ClickCellButton

        #region ■■ 5.2.2 Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeExitEditMode(object sender, Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs e)
        {
            if (e.CancellingEditOperation)
                return;

            switch (uniGrid1.ActiveCell.Column.Key)
            {
                case "AAA":
                    break;
                case "BBB":
                    break;
                case "CCC":
                    break;
                default:
                    break;
            }
        }

        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {
            if (uniGrid1.ActiveRow == null || uniGrid1.ActiveCell == null) return;

            string sKey = uniGrid1.ActiveCell.Column.Key.ToUpper();
            DataSet pDataSet = null;


            switch (sKey)
            {
                case "EMP_NO":
                    DataSet dsChg = uniBase.UDataAccess.CommonQueryRs(" haa010t.EMP_NO, haa010t.NAME, haa010t.DEPT_NM, dbo.ufn_getcodename('h0002',haa010t.roll_pstn) as roll_pstn_nm  ",
                       " haa010t ", " (haa010t.emp_no like '%'+" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                       + " +'%' OR haa010t.NAME LIKE '%' +" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " +'%')"
                       );
                    if (uniGrid1.ActiveRow.Cells["emp_no"].Value.ToString().Trim() != "")
                    {
                        if (dsChg != null && dsChg.Tables.Count > 0 && dsChg.Tables[0].Rows.Count > 0)
                        {
                            if (dsChg.Tables[0].Rows.Count == 1)
                            {
                                uniGrid1.ActiveRow.Cells["emp_no"].Value = dsChg.Tables[0].Rows[0]["emp_no"].ToString().Trim();
                                uniGrid1.ActiveRow.Cells["name"].Value = dsChg.Tables[0].Rows[0]["name"].ToString().Trim();
                                //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = dsChg.Tables[0].Rows[0]["DEPT_NM"].ToString().Trim();
                                //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = dsChg.Tables[0].Rows[0]["roll_pstn_nm"].ToString().Trim();
                            }
                            else
                            {

                                uniGrid1.BeforePopupOpenEvent();

                            }
                        }
                        else
                        {
                            uniGrid1.ActiveRow.Cells["emp_no"].Value = string.Empty;
                            uniGrid1.ActiveRow.Cells["name"].Value = string.Empty;
                            //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = string.Empty;
                            //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = string.Empty;

                            return;
                        }
                    }
                    else
                    {
                        uniGrid1.ActiveRow.Cells["emp_no"].Value = string.Empty;
                        uniGrid1.ActiveRow.Cells["name"].Value = string.Empty;
                        //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = string.Empty;
                        //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = string.Empty;

                        return;
                    }
                    break;
                case "FLEX_SYS":
                    DataSet dsChg2 = uniBase.UDataAccess.CommonQueryRs("b_minor.MINOR_CD, b_minor.MINOR_NM",
                       "b_minor", " (b_minor.MINOR_CD like '%'+" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["FLEX_SYS"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                       + " +'%' OR b_minor.MINOR_NM LIKE '%' +" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["MINOR_NM"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " +'%')"
                       );
                    if (uniGrid1.ActiveRow.Cells["emp_no"].Value.ToString().Trim() != "")
                    {
                        if (dsChg2 != null && dsChg2.Tables.Count > 0 && dsChg2.Tables[0].Rows.Count > 0)
                        {
                            if (dsChg2.Tables[0].Rows.Count == 1)
                            {
                                uniGrid1.ActiveRow.Cells["FLEX_SYS"].Value = dsChg2.Tables[0].Rows[0]["MINOR_CD"].ToString().Trim();
                                uniGrid1.ActiveRow.Cells["MINOR_NM"].Value = dsChg2.Tables[0].Rows[0]["MINOR_NM"].ToString().Trim();
                                //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = dsChg.Tables[0].Rows[0]["DEPT_NM"].ToString().Trim();
                                //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = dsChg.Tables[0].Rows[0]["roll_pstn_nm"].ToString().Trim();
                            }
                            else
                            {

                                uniGrid1.BeforePopupOpenEvent();

                            }
                        }
                        else
                        {
                            uniGrid1.ActiveRow.Cells["FLEX_SYS"].Value = string.Empty;
                            uniGrid1.ActiveRow.Cells["MINOR_NM"].Value = string.Empty;
                            //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = string.Empty;
                            //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = string.Empty;

                            return;
                        }
                    }
                    else
                    {
                        uniGrid1.ActiveRow.Cells["FLEX_SYS"].Value = string.Empty;
                        uniGrid1.ActiveRow.Cells["MINOR_NM"].Value = string.Empty;
                        //uniGrid1.ActiveRow.Cells["DEPT_NM"].Value = string.Empty;
                        //uniGrid1.ActiveRow.Cells["roll_pstn_nm"].Value = string.Empty;

                        return;
                    }
                    break;
            }



        }
        #endregion ■■ Change >>> CellChange

        #region ■■ 5.2.3 Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
        }
        #endregion ■■ Click >>> AfterSelectChange

        #region ■■ 5.2.4 ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
        }
        #endregion ■■ ComboSelChange >>> CellListSelect

        #region ■■ 5.2.5 DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
        }
        #endregion ■■ DblClick >>> DoubleClickCell

        #region ■■ 5.2.6 MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
        }
        #endregion ■■ MouseDown >>> MouseDown

        #region ■■ 5.2.7 ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
        }
        #endregion ■■ ScriptLeaveCell >>> BeforeCellDeactivate

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors


            #endregion

            #region ▶▶▶ 10.1.2.2 Setting Returned Data



            #endregion

        }

        #endregion

        private void popDeptCd_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "부서명";
            e.PopupPassData.ConditionCaption = "부서명 조회";

            e.PopupPassData.SQLFromStatements = "B_ACCT_DEPT(NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = this.popDeptCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "ORG_CHANGE_ID= " + uniBase.UCommon.FilterVariable(CommonVariable.gChangeOrgId, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "DEPT_CD";
            e.PopupPassData.GridCellCode[1] = "DEPT_NM";

            e.PopupPassData.GridCellCaption[0] = "부서 코드";
            e.PopupPassData.GridCellCaption[1] = "부서명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }


        #endregion

        private void popDeptCd_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popDeptCd.CodeValue = iDataSet.Tables[0].Rows[0]["dept_cd"].ToString().Trim();
            popDeptCd.CodeName = iDataSet.Tables[0].Rows[0]["dept_nm"].ToString().Trim();
            //txtInternalCd.Text = iDataSet.Tables[0].Rows[0]["internal_cd"].ToString();


        }

        private void popEmpNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {


        }

        private void popEmpNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {


        }

        private void uniGrid1_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            switch (uniGrid1.ActiveCell.Column.ToString().ToUpper().Trim())
            {
                case "EMP_NO":

                    //if (dtYYYYMM.Value == null)
                    //{
                    //    e.Cancel = true;
                    //    break;
                    //}

                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup_KO883";
                    e.PopupPassData.PopupWinTitle = "Employee PopUp";
                    e.PopupPassData.PopupWinWidth = 800;
                    e.PopupPassData.PopupWinHeight = 700;

                    //string strDate = dtYYYYMM.Value == null ? uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD) : uniBase.UDate.GetFirstDay(Convert.ToDateTime(dtYYYYMM.Value.ToString())).ToShortDateString();

                    //e.PopupPassData.Data = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName, strDate, "1", "" };
                    e.PopupPassData.Data = new string[] { "", "", uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD), "1", "" };

                    break;

                case "FLEX_SYS":


                    e.PopupPassData.ConditionCaption = "근무구분";

                    e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
                    e.PopupPassData.SQLWhereStatements = "  MAJOR_CD ='XH006' ";
                    e.PopupPassData.SQLWhereInputCodeValue = ""; // popPlantCd.CodeValue.Trim();
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.DistinctOrNot = false;

                    e.PopupPassData.GridCellCode = new String[2];
                    e.PopupPassData.GridCellCaption = new String[2];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

                    e.PopupPassData.GridCellCode[0] = "MINOR_CD";
                    e.PopupPassData.GridCellCode[1] = "MINOR_NM";

                    e.PopupPassData.GridCellCaption[0] = "근무구분";
                    e.PopupPassData.GridCellCaption[1] = "근무구분명";

                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

                    break;

                default:
                    break;
            }
        }

        private void uniGrid1_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null) return;

            iDataSet = (DataSet)e.ResultData.Data;

            switch (uniGrid1.ActiveCell.Column.Key.ToUpper().Trim())
            {
                case "EMP_NO":
                    uniBase.UGrid.SetGridValue(uniGrid1, "EMP_NO", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["EMP_NO"].ToString());
                    uniBase.UGrid.SetGridValue(uniGrid1, "NAME", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["NAME"].ToString());
                    //uniBase.UGrid.SetGridValue(uniGrid1, "dept_cd", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["dept_cd"].ToString());
                    uniBase.UGrid.SetGridValue(uniGrid1, "dept_nm", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["dept_nm"].ToString());
                    uniBase.UGrid.SetGridValue(uniGrid1, "ROLL_PSTN_NM", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["ROLL_PSTN_NM"].ToString());



                    break;

                case "FLEX_SYS":
                    uniBase.UGrid.SetGridValue(uniGrid1, "FLEX_SYS", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString());
                    uniBase.UGrid.SetGridValue(uniGrid1, "MINOR_NM", uniGrid1.ActiveRow.Index, iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString());
                    break;

                default:
                    break;
            }
        }

        private void popProject_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.Y7001PA_KO883";
            e.PopupPassData.PopupWinTitle = "Projecct State Pop-up";
            e.PopupPassData.Data = null;
        }

        private void popProject_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
        }

        private void uniTabControl1_SelectedTabChanged(object sender, Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventArgs e)
        {
            if (e.Tab.Index == 0)
            {
                uniBase.UCommon.SetToolBarMultiAll(true);
            }
            else
            {
                uniBase.UCommon.SetToolBarMultiAll(false);
            }
        }

        private void popEmpNo_OnExitEditCode(object sender, EventArgs e)
        {
        }

        //private void uniGrid1_OnExitEditCode(object sender, EventArgs e)
        //{
        //    if (uniGrid1.value == "")
        //    {
        //        popEmpNo.CodeName = "";
        //        return;
        //    }

        //    string[] UNISqlId = new string[] { "ZN_HR_EMP_NM2" };
        //    string[][] UNIValue = new string[1][];
        //    UNIValue[0] = new string[5];


        //    string strDate = dtYYYYMM.Value == null ? uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD) : uniBase.UDate.GetFirstDay(Convert.ToDateTime(dtYYYYMM.Value.ToString())).ToShortDateString();

        //    UNIValue[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
        //    UNIValue[0][1] = uniBase.UCommon.FilterVariable(strDate, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
        //    UNIValue[0][2] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
        //    UNIValue[0][3] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
        //    UNIValue[0][4] = " ";

        //    DataSet pDataSet = null;

        //    try
        //    {
        //        pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

        //        if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
        //        {
        //            uniBase.UMessage.DisplayMessageBox("810010", MessageBoxButtons.OK);
        //            popEmpNo.CodeName = "";
        //            popEmpNo.Focus();
        //            return;

        //        }
        //        popEmpNo.CodeValue = pDataSet.Tables[0].Rows[0]["emp_no"].ToString();
        //        popEmpNo.CodeName = pDataSet.Tables[0].Rows[0]["name"].ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
        //        if (reThrow)
        //            throw;
        //        return;
        //    }
        //}

        private void btnConfirm_Click(object sender, EventArgs e)
        {


            SubReleaseCheck();
        }


        private void SubReleaseCheck()
        {

        }



        private void uniGrid1_AfterCellUpdate(object sender, CellEventArgs e)
        {


        }

        private void popDeptCd_OnExitEditCode(object sender, EventArgs e)
        {
            if (popDeptCd.CodeValue == "")
            {
                popDeptCd.CodeName = "";
                return;
            }

            string[] UNISqlId = new string[] { "ZN_HR_EMP_NM4" };
            string[][] UNIValue = new string[1][];
            UNIValue[0] = new string[3];


            string strDate = uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD);

            //UNIValue[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            //UNIValue[0][1] = uniBase.UCommon.FilterVariable(strDate, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][0] = uniBase.UCommon.FilterVariable(popDeptCd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][1] = uniBase.UCommon.FilterVariable(popDeptCd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][2] = " ";

            DataSet pDataSet = null;


            try
            {
                pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                {
                    //uniBase.UMessage.DisplayMessageBox("810010", MessageBoxButtons.OK);
                    //popDeptCd.CodeName = "";
                    //popDeptCd.Focus();
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return;

                }
                popDeptCd.CodeValue = pDataSet.Tables[0].Rows[0]["DEPT_CD"].ToString();
                popDeptCd.CodeName = pDataSet.Tables[0].Rows[0]["DEPT_NM"].ToString();

            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
        }

        private void popFlexSys_BeforePopupOpen(object sender, AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            //e.PopupPassData.PopupWinTitle = "근무구분";
            //e.PopupPassData.ConditionCaption = "근무구분";

            //e.PopupPassData.SQLFromStatements = "B_MINOR (nolock)";
            //e.PopupPassData.SQLWhereStatements = "  MAJOR_CD ='XH006' ";
            //e.PopupPassData.SQLWhereInputCodeValue = ""; // popPlantCd.CodeValue.Trim();
            //e.PopupPassData.SQLWhereInputNameValue = "";
            //e.PopupPassData.DistinctOrNot = false;

            //e.PopupPassData.GridCellCode = new String[2];
            //e.PopupPassData.GridCellCaption = new String[2];
            //e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            //e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            //e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            //e.PopupPassData.GridCellCaption[0] = "근무구분";
            //e.PopupPassData.GridCellCaption[1] = "근무구분명";

            //e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            //e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popFlexSys_AfterPopupClosed(object sender, AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            //uniOpenPopup popFlexSys = (uniOpenPopup)sender;
            //DataSet iDataSet = new DataSet();

            //if (e.ResultData.Data == null)
            //    return;

            //iDataSet = (DataSet)e.ResultData.Data;

            //popFlexSys.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            //popFlexSys.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }

        private void uniTBL_OuterMost_Paint(object sender, PaintEventArgs e)
        {

        }

        private void uniDateTime1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void popBdgcd_BeforePopupOpen(object sender, AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "계정그룹";
            e.PopupPassData.ConditionCaption = "계정그룹";

            e.PopupPassData.SQLFromStatements = "A_ACCT A join A_ACCT_GP B on A.GP_CD = B.GP_CD";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.SQLWhereInputCodeValue = popBdgcd.CodeValue.Trim(); // popPlantCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = popBdgcd.CodeName.Trim();
            e.PopupPassData.DistinctOrNot = false;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];

            e.PopupPassData.GridCellCode[0] = "A.GP_CD";
            e.PopupPassData.GridCellCode[1] = "B.GP_NM";

            e.PopupPassData.GridCellCaption[0] = "계정그룹";
            e.PopupPassData.GridCellCaption[1] = "계정그룹명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popBdgcd_AfterPopupClosed(object sender, AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            uniOpenPopup popBdgcd = (uniOpenPopup)sender;
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popBdgcd.CodeValue = iDataSet.Tables[0].Rows[0]["GP_CD"].ToString();
            popBdgcd.CodeName = iDataSet.Tables[0].Rows[0]["GP_NM"].ToString();
        }

        private void popBdgcd_OnExitEditCode(object sender, EventArgs e)
        {
            if (popBdgcd.CodeValue == "")
            {
                popBdgcd.CodeName = "";
                return;
            }

            string[] UNISqlId = new string[] { "ZN_FI_GP_CD" };
            string[][] UNIValue = new string[1][];
            UNIValue[0] = new string[3];


            UNIValue[0][0] = uniBase.UCommon.FilterVariable(popBdgcd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][1] = uniBase.UCommon.FilterVariable(popBdgcd.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][2] = " ";

            DataSet pDataSet = null;


            try
            {
                pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                {
                    //uniBase.UMessage.DisplayMessageBox("810010", MessageBoxButtons.OK);
                    //popDeptCd.CodeName = "";
                    //popDeptCd.Focus();
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return;

                }
                popBdgcd.CodeValue = pDataSet.Tables[0].Rows[0]["GP_CD"].ToString();
                popBdgcd.CodeName = pDataSet.Tables[0].Rows[0]["GP_NM"].ToString();

            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
        }

        private void Rdo_Type1_ValueChanged(object sender, EventArgs e)
        {
            if (Rdo_Type1.CheckedIndex == 0)
            {
                popDeptCd.CodeValue = "";
                popDeptCd.CodeName = "";
                popDeptCd.Enabled = false;

            }
            else if (Rdo_Type1.CheckedIndex == 1)
            {
                popDeptCd.Enabled = true;
            }
        }


        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        #endregion

        #endregion

    }
}