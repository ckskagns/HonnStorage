﻿namespace uniERP.App.UI.HR.H4006M4_KO883.tdsY8101M2_KO883TableAdapters
{
}
namespace uniERP.App.UI.HR.H4006M4_KO883 {
    
    
    public partial class tdsY8101M2_KO883 {
        partial class I_PMS_PROJECT_RATEDataTable
        {
        }
    }
}
