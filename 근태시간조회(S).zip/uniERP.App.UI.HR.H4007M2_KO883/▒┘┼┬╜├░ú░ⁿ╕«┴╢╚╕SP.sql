          
            
ALTER PROCEDURE [dbo].[USP_H4007M2_KO883]            
 (  
	@EMP_NO nvarchar(26), -- ���
	@DEPT_NO nvarchar(26), -- �μ���ȣ
	@Work_From nvarchar(26), -- �ٹ�����From   
    @Work_To  nvarchar(26)  -- �ٹ�����To
             
 ) AS                      
                
 BEGIN                                          
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                    
                                       
SET NOCOUNT ON                    

  IF @Work_From IS NULL OR @Work_From = '' SET @Work_From ='1900-01-01'     
  IF @Work_To IS NULL OR @Work_To = '' SET @Work_To ='2099-12-31' 

select  distinct

	 A.EMP_NO    , 
	 A.EMP_NM      ,
	 A.DEPT_NM     ,
	 A.ROLL_PSTN_NM,
	 --A.Work_Day    ,
	 CONVERT (DATETIME,  A.Work_Day) as Work_Day ,
	 A.Work_Week   ,
	 CASE A.Attendance 
	   When '' THEN ''
	   ELSE A.Attendance 
	 END as Attendance,
	 CASE A.Leave 
	   When '' THEN '' 
	   ELSE A.Leave 
	 END as Leave,
	 --A.Attendance  ,
	 --A.Leave       ,
	 A.OT          ,
	 A.HT          ,
	 CASE A.TT 
	   When '' THEN '00:00'
	   ELSE A.TT 
	 END as TT,
	 --D.DILIG_NM as ETC_QTY1 ,
	 --A.EXT_QTY1    ,
	 --A.EXT_QTY3    ,
	 A.ISRT_DT     ,	
	 A.UPDT_EMP_NO ,
	 A.UPDT_DT,
	 isnull(E.DILIG_NM,'') as ETC_QTY2
  
 from WT_MA A        
join HAA010T B on A.EMP_NO = B.EMP_NO  
left outer join HCA060T C on A.EMP_NO = C.EMP_NO and A.Work_Day=C.DILIG_DT
left outer join hca010t E on E.DILIG_CD = C.DILIG_CD

where 
( @EMP_NO ='' or A.EMP_NO = @EMP_NO )
and (@DEPT_NO = '' or B.DEPT_CD = @DEPT_NO)    
and CONVERT (DATETIME, A.Work_Day) BETWEEN  CONVERT (DATETIME, @Work_From) AND  CONVERT (DATETIME, @Work_To )      


 order by Work_Day ASC
            
 END 
