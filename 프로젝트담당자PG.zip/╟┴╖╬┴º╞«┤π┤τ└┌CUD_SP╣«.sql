alter PROCEDURE [dbo].[USP_Y7204M9_KO883_CUD]                      
(                       
  @TBL_DATA   UTP_Y7204M9_KO883 READONLY                      
, @USER_ID    NVARCHAR(13)                      
, @MSG_CD     NVARCHAR(06)  OUTPUT                      
, @MESSAGE    NVARCHAR(200)  OUTPUT                      
, @ERR_POS    INT     OUTPUT                      
)                      
AS                      
                      
BEGIN                      
 SET NOCOUNT ON                      
                      
 DECLARE                            
    @PROJECT_CODE   NVARCHAR(25)                       
  , @EMP_NO   NVARCHAR(26)                       
  , @DEPT_TYPE      NVARCHAR(20)                 
  , @REMARK         NVARCHAR(255)                     
  , @CUD_CHAR NVARCHAR(2)                        
  , @ROW_NUM  INT                          
  , @ERROR_NUMBER INT                      
            
                      
  BEGIN TRY                      
  BEGIN TRANSACTION                      
                      
                       
  DECLARE CUR_Y7204M9_KO883 CURSOR LOCAL FOR                      
                      
  SELECT                      
     PROJECT_CODE        
   , EMP_NO        
   , DEPT_TYPE        
   , REMARK                        
   , CUD_CHAR                       
   , ROW_NUM                      
   FROM @TBL_DATA                      
                      
  OPEN CUR_Y7204M9_KO883                       
  FETCH NEXT FROM CUR_Y7204M9_KO883                      
  INTO                       
    @PROJECT_CODE                      
  , @EMP_NO                      
  , @DEPT_TYPE               
  , @REMARK                  
  , @CUD_CHAR              
  , @ROW_NUM                     
            
                            
  WHILE(@@FETCH_STATUS=0)                      
  BEGIN                      
   SET @ERR_POS = @ROW_NUM                      
                      
  IF (@CUD_CHAR = 'C')                      
  BEGIN                      
               
    INSERT INTO PMS_USER_KO883                      
    (                      
     PROJECT_CODE , EMP_NO   , DEPT_TYPE  ,   REMARK  , EXT1_CD , EXT2_CD , EXT3_CD          
  , INSRT_USER_ID , INSRT_DT, UPDT_USER_ID  , UPDT_DT                      
                          
    )                      
    VALUES                      
    (                      
      @PROJECT_CODE , @EMP_NO   , @DEPT_TYPE  , @REMARK  , NULL , NULL , NULL                        
    , @USER_ID , GETDATE()  , @USER_ID   , GETDATE()                        
                          
    )                      
  END                      
  ELSE IF (@CUD_CHAR = 'U')             
  BEGIN                      
    UPDATE PMS_USER_KO883                      
    SET                                           
    UPDT_USER_ID = @USER_ID                      
    ,UPDT_DT   = GETDATE()         
    ,EMP_NO = @EMP_NO    
    ,DEPT_TYPE = @DEPT_TYPE      
	,REMARK   = @REMARK 
                    
    WHERE                      
      PROJECT_CODE = @PROJECT_CODE                       
    AND EMP_NO = @EMP_NO                  
                          
                      
  END                      
  ELSE IF (@CUD_CHAR = 'D')                      
  BEGIN                      
                          
    DELETE FROM PMS_USER_KO883                       
    WHERE                      
      PROJECT_CODE = @PROJECT_CODE                        
    AND EMP_NO = @EMP_NO                     
              
                      
  END                      
         IF (@CUD_CHAR <> 'D')               
          BEGIN              
    IF (@PROJECT_CODE)  = '' or @EMP_NO = ''              
    BEGIN              
         SET @MSG_CD   = '122918' -- %1 ���忡 �����߽��ϴ�.                      
    SET @MESSAGE  = '������Ʈ/���(' + @PROJECT_CODE + '/' + @EMP_NO  + ')'                
     RAISERROR(@MSG_CD, 16, 1)              
    END              
    END              
                
                       
  FETCH NEXT FROM CUR_Y7204M9_KO883                
  INTO                       
    @PROJECT_CODE                      
  , @EMP_NO                      
  , @DEPT_TYPE               
  , @REMARK                        
  , @CUD_CHAR              
  , @ROW_NUM                     
                      
                      
  END --WHILE END                      
                       
                      
 CLOSE CUR_Y7204M9_KO883                      
 DEALLOCATE CUR_Y7204M9_KO883                             
                      
 END TRY                      
 BEGIN CATCH                      
                       
 SET @ERROR_NUMBER = ERROR_NUMBER()                      
                        
  IF @ERROR_NUMBER = 2627  --%1! ���� ���� '%2!'��(��) �����߽��ϴ�. ��ü '%3!'�� �ߺ� Ű�� ������ �� �����ϴ�. �ߺ� Ű ���� %4!�Դϴ�.                      
   BEGIN                      
    SET @MSG_CD   = '970001' -- %1 ��(��) �̹� �����մϴ�.                      
    SET @MESSAGE  = '������Ʈ/���(' + @PROJECT_CODE + '/' + @EMP_NO  + ')'                    
   END                      
                      
  ELSE IF @ERROR_NUMBER = 547  -- %1! ���� %2! ���� ���� "%3!"��(��) �浹�߽��ϴ�. �����ͺ��̽� "%4!", ���̺� "%5!"%6!%7!%8!���� �浹�� �߻��߽��ϴ�.                      
   BEGIN                      
    SET @MSG_CD   = '971000' -- %1 ��(��) �����ϰ� �ִ� �����Ͱ� �ֽ��ϴ�. �۾��� ������ �� �����ϴ�.                      
    SET @MESSAGE  = '������Ʈ/���(' + @PROJECT_CODE + '/' + @EMP_NO  + ')'                    
   END                      
                      
  ELSE IF @ERROR_NUMBER = 1205  -- Ʈ�����(���μ��� ID %1!)�� %2! ���ҽ����� �ٸ� ���μ������� ���� ���°� �߻��Ͽ� ������ �����Ǿ����ϴ�. Ʈ������� �ٽ� �����Ͻʽÿ�.                      
   BEGIN                      
    SET @MSG_CD   = '122918' -- %1 ���忡 �����߽��ϴ�.                      
    SET @MESSAGE  = '������Ʈ/���(' + @PROJECT_CODE + '/' + @EMP_NO  + ')'                    
   END                      
                      
  ELSE                      
   SET @MESSAGE  = ERROR_MESSAGE()                      
                      
  GOTO __ERROR                      
 END CATCH                      
                      
 IF @@TRANCOUNT > 0 COMMIT TRANSACTION                      
 RETURN 1                      
                      
 __ERROR:                      
 IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION                      
 RETURN -1                      
END 