﻿namespace uniERP.App.UI.PS.Y7204M9_KO883.tdsY8101M2_KO883TableAdapters
{
}
namespace uniERP.App.UI.PS.Y7204M9_KO883 {
    
    
    public partial class tdsY8101M2_KO883 {
        partial class I_PMS_USERDataTable
        {
        }
    
        partial class PMS_USERDataTable
        {
        }
    
        partial class E_PMS_PROJECT_RATEDataTable
        {
        }
    
        partial class PMS_USERDataTable
        {
        }
    
        partial class I_PMS_PROJECT_RATEDataTable
        {
        }
    }
}
