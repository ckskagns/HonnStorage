    
CREATE PROCEDURE [dbo].[USP_Y7204M9_KO883_DSP]                    
 (                                
      @PROJECT_CODE       NVARCHAR(25)                
 , @PROJECT_FROM    NVARCHAR(10)  -- ������Ʈ�ⰣFR          
    , @PROJECT_TO    NVARCHAR(10)  -- ������Ʈ�ⰣTO                           
    , @EMP_NO     nvarchar(26)  --���                        
 ) AS                              
         
         
  IF @PROJECT_FROM IS NULL OR @PROJECT_FROM = '' SET @PROJECT_FROM ='1900-01-01'         
  IF @PROJECT_TO IS NULL OR @PROJECT_TO = '' SET @PROJECT_TO ='2099-12-31'         
                        
 BEGIN                                                  
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED                                            
                                               
SET NOCOUNT ON                            
                     
 select A.PROJECT_CODE        
  ,B.PROJECT_NM        
  ,B.PLAN_START_DT        
  ,B.PLAN_END_DT           
  ,B.BP_CD        
  ,C.BP_NM        
  ,dbo.ufn_getcodename('XDP01', A.DEPT_TYPE) as DEPT_TYPE
  ,A.EMP_NO        
  ,D.NAME as EMP_NAM        
  ,a.REMARK  
        
  from PMS_USER_KO883 A(NOLOCK)            
  join PMS_PROJECT B(NOLOCK) on B.PROJECT_CODE = A.PROJECT_CODE        
  join B_BIZ_PARTNER C(NOLOCK) on C.BP_CD = B.BP_CD        
  join HAA010T D(NOLOCK) on D.EMP_NO = A.EMP_NO                     
  where (ISNULL(@PROJECT_CODE, '') = '' OR A.PROJECT_CODE = @PROJECT_CODE)         
  and B.PLAN_START_DT BETWEEN @PROJECT_FROM AND DATEADD(DD,1,@PROJECT_TO)             
  and ( ISNULL(@EMP_NO, '') = '' OR A.EMP_NO = @EMP_NO)        
   order by A.PROJECT_CODE, A.DEPT_TYPE, A.EMP_NO            
                    
 END 