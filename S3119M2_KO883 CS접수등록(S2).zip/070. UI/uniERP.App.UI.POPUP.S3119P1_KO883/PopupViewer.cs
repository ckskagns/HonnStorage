﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Library.UI;

using Infragistics.Win.UltraWinGrid;

using Microsoft.Practices.CompositeUI.SmartParts;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.Commands;


using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Controls.Popup;
using uniERP.AppFramework.UI.Providers;
using uniERP.AppFramework.UI.Common.Exceptions;

using uniERP.AppFramework.DataBridge;

#endregion


namespace uniERP.App.UI.POPUP.S3119P1_KO883
{

    [Microsoft.Practices.CompositeUI.SmartParts.SmartPart]
    public partial class PopupViewer : PopupViewBase
    {
        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①uniERP.App.UI.POPUP.S3119P1_KO883</NameSpace>
        /// <Module>②POPUP</Module>
        /// <Class>③PopupViewer</Class>
        /// <Desc>④
        ///   CS접수 참조 POPUP
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="IJM" Date="2018-06-19">CS접수 참조 …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        #endregion

        #region ■ 1.4 Class global constants (grid)

        private tdsS3119P1_KO883 cqtdsS3119P1_KO883 = new tdsS3119P1_KO883();
        DataSet dsRef = new DataSet();

        #endregion

        #region ■ 1.5 Class global variables (grid)

        // change your code
        //private wsMyBizFL.TypedDataSet cstdsTypedDataSet = new wsMyBizFL.TypedDataSet();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public PopupViewer()
        {
            InitializeComponent();

            SetLayoutBasePanel(uniTBL_OuterMost);  // Outer most TableLayout Panel Name

        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(this.cqtdsS3119P1_KO883);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi | enumDef.ViewType.TA1_UserPopup);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Query, enumDef.ModuleInformation.SalesManagement);      // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                                   // Load custom numeric format

        }

        protected override void Form_Load_Completed()
        {

        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {

        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            dtReceiptDt.uniDateTimeF.Value = uniBase.UDate.GetDBServerDateTime().AddMonths(-1);         // get DB Server DateTime 
            dtReceiptDt.uniDateTimeT.Value = uniBase.UDate.GetDBServerDateTime();
            OnFncQuery();
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringCode)

        protected override void GatheringComboData()
        {

        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆

            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            tdsS3119P1_KO883.E_S_CS_RECEIPT_KO883DataTable uniGridTB1 = cqtdsS3119P1_KO883.E_S_CS_RECEIPT_KO883;

            this.uniGrid1.SSSetEdit(uniGridTB1.receipt_noColumn.ColumnName, "접수번호", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.cs_statusColumn.ColumnName, "진행상태", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.cs_status_nmColumn.ColumnName, "진행상태명", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.serial_noColumn.ColumnName, "Serial No", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.project_codeColumn.ColumnName, "프로젝트 번호", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.project_nmColumn.ColumnName, "프로젝트명", 130, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.item_cdColumn.ColumnName, "품목코드", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.item_nmColumn.ColumnName, "품목코드명", 150, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.specColumn.ColumnName, "규격", 170, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.tracking_noColumn.ColumnName, "Tracking No", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.locationColumn.ColumnName, "Location", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.free_ynColumn.ColumnName, "유/무상 구분", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.bp_cdColumn.ColumnName, "고객사", 70, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.bp_nmColumn.ColumnName, "고객사명", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.modelColumn.ColumnName, "Model", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.model_nmColumn.ColumnName, "Model명", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.receipt_prnColumn.ColumnName, "접수자", 70, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.receipt_prn_nmColumn.ColumnName, "접수자명", 90, enumDef.FieldType.ReadOnly);

            this.uniGrid1.SSSetMask(uniGridTB1.comp_fr_timeColumn.ColumnName, "소요시간(From)", 80, enumDef.FieldType.ReadOnly, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.comp_to_timeColumn.ColumnName, "소요시간(To)", 80, enumDef.FieldType.ReadOnly, "{LOC}hh:mm", enumDef.HAlign.Center);
            

            this.uniGrid1.SSSetDate(uniGridTB1.receipt_dtColumn.ColumnName, "접수일", 100, enumDef.FieldType.ReadOnly, CommonVariable.CDT_YYYY_MM_DD, enumDef.HAlign.Center);
            this.uniGrid1.SSSetDate(uniGridTB1.repair_fr_dtColumn.ColumnName, "조치일(From)", 100, enumDef.FieldType.ReadOnly, CommonVariable.CDT_YYYY_MM_DD, enumDef.HAlign.Center);
            this.uniGrid1.SSSetDate(uniGridTB1.repair_to_dtColumn.ColumnName, "조치일(To)", 100, enumDef.FieldType.ReadOnly, CommonVariable.CDT_YYYY_MM_DD, enumDef.HAlign.Center);


            this.uniGrid1.SSSetEdit(uniGridTB1.receip_descColumn.ColumnName, "접수내용", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.etc_descColumn.ColumnName, "특기사항", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.repair_descColumn.ColumnName, "처리사항", 200, enumDef.FieldType.ReadOnly);


            tdsS3119P1_KO883.E_S_CS_USE_ITEM_KO883DataTable uniGridTB2 = cqtdsS3119P1_KO883.E_S_CS_USE_ITEM_KO883;


            this.uniGrid2.SSSetEdit(uniGridTB2.receipt_noColumn.ColumnName, "접수번호", 110, enumDef.FieldType.ReadOnly);

            this.uniGrid2.SSSetEdit(uniGridTB2.part_itemColumn.ColumnName, "Part No", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.part_item_nmColumn.ColumnName, "Part 명", 130, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.specColumn.ColumnName, "Part 규격", 150, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.basic_unitColumn.ColumnName, "단위", 90, enumDef.FieldType.ReadOnly);

            this.uniGrid2.SSSetEdit(uniGridTB2.part_typeColumn.ColumnName, "Part 구분", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.part_type_nmColumn.ColumnName, "Part 구분명", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.supply_typeColumn.ColumnName, "유/무상 구분", 90, enumDef.FieldType.ReadOnly);

            this.uniGrid2.SSSetFloat(uniGridTB2.repair_qtyColumn.ColumnName, "수량", 90, viewTB19029.ggQty, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetFloat(uniGridTB2.repair_priceColumn.ColumnName, "단가", 90, viewTB19029.ggUnitCost, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetFloat(uniGridTB2.repair_amountColumn.ColumnName, "금액", 90, viewTB19029.ggAmtOfMoney, enumDef.FieldType.ReadOnly);

            this.uniGrid2.SSSetEdit(uniGridTB2.plant_cdColumn.ColumnName, "공장", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.plant_nmColumn.ColumnName, "공장명", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.sl_cdColumn.ColumnName, "창고", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.sl_nmColumn.ColumnName, "창고명", 110, enumDef.FieldType.ReadOnly);

            this.uniGrid2.SSSetEdit(uniGridTB2.cs_statusColumn.ColumnName, "진행상태", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.serial_noColumn.ColumnName, "Serial No", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.project_codeColumn.ColumnName, "프로젝트 번호", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.item_cdColumn.ColumnName, "품목코드", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.item_nmColumn.ColumnName, "품목코드명", 150, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.tracking_noColumn.ColumnName, "Tracking No", 110, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.locationColumn.ColumnName, "Location", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.bp_cdColumn.ColumnName, "고객사", 70, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.bp_nmColumn.ColumnName, "고객사명", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.receipt_prnColumn.ColumnName, "접수자", 70, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.receipt_prn_nmColumn.ColumnName, "접수자명", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.receip_descColumn.ColumnName, "접수내용", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.etc_descColumn.ColumnName, "특기사항", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.repair_descColumn.ColumnName, "처리사항", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.repair_type_1Column.ColumnName, "조치유형(대분류)", 90, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.repair_type_1_nmColumn.ColumnName, "조치유형(대분류)명", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.repair_type_2Column.ColumnName, "조치유형(중분류)", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.repair_type_2_nmColumn.ColumnName, "조치유형(중분류)명", 200, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.modelColumn.ColumnName, "Model", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.model_nmColumn.ColumnName, "Model명", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetEdit(uniGridTB2.cs_typeColumn.ColumnName, "접수유형", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid2.SSSetMask(uniGridTB2.comp_fr_timeColumn.ColumnName, "소요시간(From)", 80, enumDef.FieldType.ReadOnly, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid2.SSSetMask(uniGridTB2.comp_to_timeColumn.ColumnName, "소요시간(To)", 80, enumDef.FieldType.ReadOnly, "{LOC}hh:mm", enumDef.HAlign.Center);
            this.uniGrid2.SSSetDate(uniGridTB2.repair_fr_dtColumn.ColumnName, "조치일(From)", 100, enumDef.FieldType.ReadOnly, CommonVariable.CDT_YYYY_MM_DD, enumDef.HAlign.Center);
            this.uniGrid2.SSSetDate(uniGridTB2.repair_to_dtColumn.ColumnName, "조치일(To)", 100, enumDef.FieldType.ReadOnly, CommonVariable.CDT_YYYY_MM_DD, enumDef.HAlign.Center);


            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.Yes, enumDef.IsSearch.Yes);
            this.uniGrid2.InitializeGrid(enumDef.IsOutlookGroupBy.Yes, enumDef.IsSearch.Yes);

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            //this.uniGrid1.SSSetColHidden(uniGridTB1.cmb_colColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.cs_statusColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.serial_noColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.project_codeColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.item_cdColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.item_nmColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.tracking_noColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.locationColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.bp_cdColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.bp_nmColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.receipt_prnColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.receipt_prn_nmColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.receip_descColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.etc_descColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.repair_descColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.repair_type_1Column.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.repair_type_1_nmColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.repair_type_2Column.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.repair_type_2_nmColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.modelColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.model_nmColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.cs_typeColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.comp_fr_timeColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.comp_to_timeColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.repair_fr_dtColumn.ColumnName);
            this.uniGrid2.SSSetColHidden(uniGridTB2.repair_to_dtColumn.ColumnName);

            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {

        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
        }
        #endregion

        #region ■ 3.4 initControlBinding
        protected override void InitControlBinding()
        {
            // Grid binding with global dataset variable.
            this.InitSpreadSheet();

            this.uniGrid1.uniGridSetDataBinding(this.cqtdsS3119P1_KO883.E_S_CS_RECEIPT_KO883);
            this.uniGrid2.uniGridSetDataBinding(this.cqtdsS3119P1_KO883.E_S_CS_USE_ITEM_KO883);

            string masterKey = this.cqtdsS3119P1_KO883.E_S_CS_RECEIPT_KO883.receipt_noColumn.ColumnName;
            string detailKey = this.cqtdsS3119P1_KO883.E_S_CS_USE_ITEM_KO883.receipt_noColumn.ColumnName;

            this.uniGrid1.RegisterDetailGrid(this.uniGrid2, masterKey, detailKey);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 FncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //TO-DO : code business oriented logic

            return DBQuery();

        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)
        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic
            return DBSave();
        }
        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)
        protected override bool OnFncCopy()
        {
            return true;
        }
        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)
        protected override bool OnFncPrev()
        {
            return true;
        }
        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)
        protected override bool OnFncNext()
        {
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 FncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic

            return true;
        }
        #endregion

        #region ■■ 4.3.2 FncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 FncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopyRow)
        protected override bool OnFncCopyRow()
        {
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.3 Db function group

        #region ■■ 4.3.1 DBQuery(Common)

        private bool DBQuery()
        {
            DataSet dsData = new DataSet();

            try
            {
                string strBpCd = (popBpCd.CodeValue.ToString() == string.Empty ? "%" : popBpCd.CodeValue.ToString());
                string strReceiptNo = (popReceiptNo.CodeValue.ToString() == string.Empty ? "%" : popReceiptNo.CodeValue.ToString());
                string strReceiptDtFr = (dtReceiptDt.uniDateTimeF.Value.ToString() == string.Empty ? "1900-01-01" : dtReceiptDt.uniDateTimeF.Value.ToString());
                string strReceiptDtTo = (dtReceiptDt.uniDateTimeT.Value.ToString() == string.Empty ? "2999-12-31" : dtReceiptDt.uniDateTimeT.Value.ToString());
                string strSerialNo = (popSerialNo.CodeValue.ToString() == string.Empty ? "%" : popSerialNo.CodeValue.ToString());
                string strpReceiptPrn = (popReceiptPrn.CodeValue.ToString() == string.Empty ? "%" : popReceiptPrn.CodeValue.ToString());


                string strFreeYn = (rdoFreeYn.Value.ToString() == string.Empty ? "%" : rdoFreeYn.Value.ToString());
                if (strFreeYn.ToString() == "A")
                {
                    strFreeYn = "%";
                }

                string strCsSts = (popCsSts.CodeValue.ToString() == string.Empty ? "%" : popCsSts.CodeValue.ToString());
                string strCsType = (popCsType.CodeValue.ToString() == string.Empty ? "%" : popCsType.CodeValue.ToString());
                string strRepairType = (popRepairType.CodeValue.ToString() == string.Empty ? "%" : popRepairType.CodeValue.ToString());
                string strRepairType2 = (popRepairType2.CodeValue.ToString() == string.Empty ? "%" : popRepairType2.CodeValue.ToString());

                using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_POP_S3119P1_KO883"))
                {
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@BP_CD", SqlDbType.NVarChar, strBpCd);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@RECEIPT_NO", SqlDbType.NVarChar, strReceiptNo);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@FR_DT", SqlDbType.NVarChar, strReceiptDtFr);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@TO_DT", SqlDbType.NVarChar, strReceiptDtTo);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@SERIAL_NO", SqlDbType.NVarChar, strSerialNo);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@RECEIPT_PERSON", SqlDbType.NVarChar, strpReceiptPrn);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@FREE_YN", SqlDbType.NVarChar, strFreeYn);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@STATUS", SqlDbType.NVarChar, strCsSts);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@RECEIPT_TYPE", SqlDbType.NVarChar, strCsType);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REPAIR_TYPE1", SqlDbType.NVarChar, strRepairType);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REPAIR_TYPE2", SqlDbType.NVarChar, strRepairType2);

                    dsData = uniBase.UDatabase.ExecuteDataSet(iuniCommand);
                }
                if (dsData == null || dsData.Tables.Count == 0 || dsData.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    cqtdsS3119P1_KO883.E_S_CS_USE_ITEM_KO883.Clear();
                    return false;
                }
                else
                {
                    cqtdsS3119P1_KO883.E_S_CS_RECEIPT_KO883.Clear();

                    uniBase.UData.MergeDataTable(cqtdsS3119P1_KO883.E_S_CS_RECEIPT_KO883, dsData.Tables[0], false, MissingSchemaAction.Ignore);

                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                //if (iqtdsTypedDataSet != null) iqtdsTypedDataSet.Dispose();
                //if (iqtdsICondition != null) iqtdsICondition.Dispose();
            }

            return true;
        }

        private bool DBQuery2(string conditionDatas)
        // If conditionDatas is multi :
        //    private bool DBQuery2(params string[] conditionDatas) Or
        //    private bool DBQuery2(string conditionDatas, string conditionDatas2) 
        {
            DataSet dsData = new DataSet();

            try
            {
                string strReceiptNo = (uniGrid1.ActiveRow.Cells["RECEIPT_NO"].Value.ToString() == string.Empty ? "%" : uniGrid1.ActiveRow.Cells["RECEIPT_NO"].Value.ToString());

                using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_POP_S3119P1_KO883_2"))
                {
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@RECEIPT_NO", SqlDbType.NVarChar, strReceiptNo);
                    dsData = uniBase.UDatabase.ExecuteDataSet(iuniCommand);
                }
                if (dsData == null || dsData.Tables.Count == 0 || dsData.Tables[0].Rows.Count == 0)
                {
                    return false;
                }
                else
                {
                    cqtdsS3119P1_KO883.E_S_CS_USE_ITEM_KO883.Clear();
                    uniBase.UData.MergeDataTable(cqtdsS3119P1_KO883.E_S_CS_USE_ITEM_KO883, dsData.Tables[0], false, MissingSchemaAction.Ignore);

                }

            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                //if (iqtdsTypedDataSet != null) iqtdsTypedDataSet.Dispose();
                //if (iqtdsICondition != null) iqtdsICondition.Dispose();
            }

            //callback event fire.
            //uniGrid1_AfterCellActivate(null, null);

            return true;
        }


        #endregion

        #region ■■ 4.3.2 DBDelete(Single)

        #endregion

        #region ■■ 4.3.3 DBSave(Common)

        private bool DBSave()
        {

            return true;

        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        private void btnQuery_Click(object sender, EventArgs e)
        {
            this.uniGrid1.clearSpreadData();                                // clear grid data
            if (base.OnPreFncQuery())
            {
                this.DBQuery();                                                 // Query

            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.OKProcess();                                               // get selected row and retrun to caller
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.ParentForm.Close();                                  // close current popup
        }

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        private void uniGrid1_DoubleClickRow(object sender, DoubleClickRowEventArgs e)
        {
            //if (uniGrid1.Rows.Count < 1)
            //    return;

            //this.OKProcess();
        }

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        #endregion

        #endregion

        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        private void OKProcess()
        {
            base.SetPopupOK();  // enable raise after_popup event;

            base.ResultData.Data = GetSelectedRow();

            this.ParentForm.Close();
        }

        private DataSet GetSelectedRow()
        {
            //wsPB1G041FL.DsBListAutoNumbering.E1_B_AUTO_NUMBERINGDataTable iE1_B_AUTO_NUMBERINGDataTable = cqtdsBListAutoNumbering.E1_B_AUTO_NUMBERING;

            DataSet tempDataSet = new DataSet();

            DataSet iDataSet = null;

            //iDataSet = GetGridSelectedRow(uniGrid1, iE1_B_AUTO_NUMBERINGDataTable);
            //iDataSet = GetGridSelectedRow(uniGrid1, cqtdsS3119P1_KO883.Tables[0]);
            iDataSet = GetGridSelectedRow(uniGrid2, cqtdsS3119P1_KO883.Tables[1]);

            if (iDataSet == null)
            {
                return (GetActiveRow());
            }

            return iDataSet;

        }

        private DataSet GetActiveRow()
        {

            //wsPB1G041FL.DsBListAutoNumbering.E1_B_AUTO_NUMBERINGDataTable iE1_B_AUTO_NUMBERINGDataTable = cqtdsBListAutoNumbering.E1_B_AUTO_NUMBERING;

            DataSet tempDataSet = new DataSet();

            DataSet iDataSet = null;

            //iDataSet = GetGridActiveRow(uniGrid1, iE1_B_AUTO_NUMBERINGDataTable);
            //iDataSet = GetGridActiveRow(uniGrid1, cqtdsS3119P1_KO883.Tables[0]);
            iDataSet = GetGridActiveRow(uniGrid2, cqtdsS3119P1_KO883.Tables[1]);

            return iDataSet;

        }

        // get selected row data in uniGrid

        private DataSet GetGridSelectedRow(uniGrid puniGrid, DataTable pDataTable)
        {

            DataSet iDataSet = new DataSet();

            Infragistics.Win.UltraWinGrid.SelectedRowsCollection selectedRows;

            selectedRows = puniGrid.Selected.Rows;  // Get the selected rows.

            if (selectedRows.Count < 1)                  // If there are no selected rows, return
            {
                return null;
            }

            DataTable iDataTable = pDataTable.Clone();

            for (int i = 0; i < selectedRows.Count; i++)           // Loop through all the selected rows
            {
                Infragistics.Win.UltraWinGrid.UltraGridRow row;

                row = selectedRows[i];

                DataRow iDataRow = iDataTable.NewRow();

                foreach (DataColumn col in pDataTable.Columns)
                {

                    iDataRow[col.ColumnName] = row.Cells[col.ColumnName].Value;

                }

                iDataTable.Rows.Add(iDataRow);

            }

            iDataSet.Tables.Add(iDataTable);
            //dsRef.Merge(iDataSet, false, MissingSchemaAction.Add);


            return iDataSet;

        }

        // get active row data in uniGrid

        private DataSet GetGridActiveRow(uniGrid puniGrid, DataTable pDataTable)
        {

            DataSet iDataSet = new DataSet();

            if (uniGrid1.Rows.Count < 1)
            {
                return null;
            }

            DataTable iDataTable = pDataTable.Clone();

            DataRow iDataRow = iDataTable.NewRow();

            iDataTable.Rows.Add(iDataRow);

            if (puniGrid.ActiveRow != null)
            {

                foreach (DataColumn col in pDataTable.Columns)
                {
                    iDataRow[col.ColumnName] = puniGrid.ActiveRow.Cells[col.ColumnName].Value;

                }
                iDataSet.Tables.Add(iDataTable);
                //dsRef.Tables.Add();
                //dsRef.Merge(iDataSet, false, MissingSchemaAction.Add);
            }
            else
            {
                return null;
            }
            return iDataSet;
        }

        #endregion

        private void uniGrid1_DetailBinding(object sender, uniGrid.DetailBindingEventArgs e)
        {
            //e.DetailDataView.RowFilter = UIDs.B_MAJOR.major_cdColumn.ColumnName + "=" + e.MasterRowCells["SomeFieldName"];
            if (e.DetailDataView.Count == 0 &&
                e.MasterKeyValues[0].ToString() != string.Empty)
                this.DBQuery2(e.MasterKeyValues[0].ToString());
        }


        #endregion

        private void popBpCd_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "고객사 Popup";
            e.PopupPassData.ConditionCaption = "고객사";

            e.PopupPassData.SQLFromStatements = "B_BIZ_PARTNER (NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popBpCd.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "BP_CD";
            e.PopupPassData.GridCellCode[1] = "BP_NM";

            e.PopupPassData.GridCellCaption[0] = "고객사";
            e.PopupPassData.GridCellCaption[1] = "고객사명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popBpCd_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popBpCd.CodeValue = iDataSet.Tables[0].Rows[0]["BP_CD"].ToString();
            popBpCd.CodeName = iDataSet.Tables[0].Rows[0]["BP_NM"].ToString();
        }

        private void popReceiptNo_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "접수번호 Popup";
            e.PopupPassData.ConditionCaption = "접수번호";

            e.PopupPassData.SQLFromStatements = "S_CS_RECEIPT_KO883 A (NOLOCK) LEFT JOIN B_MINOR B (NOLOCK) ON A.CS_STATUS = B.MINOR_CD AND B.MAJOR_CD = 'XCS01'";
            e.PopupPassData.SQLWhereInputCodeValue = popReceiptNo.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[6];
            e.PopupPassData.GridCellCaption = new String[6];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[6];
            e.PopupPassData.GridCellLength = new int[6];

            e.PopupPassData.GridCellCode[0] = "A.RECEIPT_NO";
            e.PopupPassData.GridCellCode[1] = "A.RECEIP_DESC";
            e.PopupPassData.GridCellCode[2] = "A.RECEIPT_DT";
            e.PopupPassData.GridCellCode[3] = "A.CS_STATUS";
            e.PopupPassData.GridCellCode[4] = "B.MINOR_NM";
            e.PopupPassData.GridCellCode[5] = "A.SERIAL_NO";

            e.PopupPassData.GridCellCaption[0] = "접수번호";
            e.PopupPassData.GridCellCaption[1] = "접수내용";
            e.PopupPassData.GridCellCaption[2] = "접수날짜";
            e.PopupPassData.GridCellCaption[3] = "진행상태";
            e.PopupPassData.GridCellCaption[4] = "진행상태명";
            e.PopupPassData.GridCellCaption[5] = "Serial No";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[2] = enumDef.GridCellType.Date;
            e.PopupPassData.GridCellType[3] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[4] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[5] = enumDef.GridCellType.Edit;

            e.PopupPassData.PopupWinHeight = 600;
            e.PopupPassData.PopupWinWidth = 800;

        }

        private void popReceiptNo_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popReceiptNo.CodeValue = iDataSet.Tables[0].Rows[0]["RECEIPT_NO"].ToString();
        }

        private void popReceiptPrn_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "접수자 Popup";
            e.PopupPassData.ConditionCaption = "접수자";

            e.PopupPassData.SQLFromStatements = "HAA010T (NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popReceiptPrn.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "EMP_NO";
            e.PopupPassData.GridCellCode[1] = "NAME";

            e.PopupPassData.GridCellCaption[0] = "접수자";
            e.PopupPassData.GridCellCaption[1] = "접수자명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popReceiptPrn_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popReceiptPrn.CodeValue = iDataSet.Tables[0].Rows[0]["EMP_NO"].ToString();
            popReceiptPrn.CodeName = iDataSet.Tables[0].Rows[0]["NAME"].ToString();
        }

        private void popSerialNo_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "접수유형 Popup";
            e.PopupPassData.ConditionCaption = "접수유형";

            e.PopupPassData.SQLFromStatements = "B_MINOR (NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popCsSts.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD = 'XCS02'";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "접수유형";
            e.PopupPassData.GridCellCaption[1] = "접수유형명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popSerialNo_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popCsType.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popCsType.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }

        private void popCsSts_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "진행상태 Popup";
            e.PopupPassData.ConditionCaption = "진행상태";

            e.PopupPassData.SQLFromStatements = "B_MINOR (NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popCsSts.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD = 'XCS01'";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "진행상태";
            e.PopupPassData.GridCellCaption[1] = "진행상태명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popCsSts_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popCsSts.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popCsSts.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }

        private void popCsType_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "접수유형 Popup";
            e.PopupPassData.ConditionCaption = "접수유형";

            e.PopupPassData.SQLFromStatements = "B_MINOR (NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popCsSts.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD = 'XCS02'";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "접수유형";
            e.PopupPassData.GridCellCaption[1] = "접수유형명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popCsType_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popCsType.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popCsType.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }

        private void popRepairType_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "조치유형(대분류) Popup";
            e.PopupPassData.ConditionCaption = "조치유형(대분류)";

            e.PopupPassData.SQLFromStatements = "B_MINOR (NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popRepairType.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD = 'XCS04'";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "조치유형";
            e.PopupPassData.GridCellCaption[1] = "조치유형명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popRepairType_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popRepairType.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popRepairType.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }

        private void popRepairType2_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.PopupWinTitle = "조치유형(중분류) Popup";
            e.PopupPassData.ConditionCaption = "조치유형(중분류)";

            e.PopupPassData.SQLFromStatements = "B_MINOR (NOLOCK)";
            e.PopupPassData.SQLWhereInputCodeValue = popRepairType2.CodeValue.Trim();
            e.PopupPassData.SQLWhereInputNameValue = "";
            e.PopupPassData.SQLWhereStatements = "MAJOR_CD = 'XCS05'";
            e.PopupPassData.DistinctOrNot = true;

            e.PopupPassData.GridCellCode = new String[2];
            e.PopupPassData.GridCellCaption = new String[2];
            e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
            e.PopupPassData.GridCellLength = new int[2];

            e.PopupPassData.GridCellCode[0] = "MINOR_CD";
            e.PopupPassData.GridCellCode[1] = "MINOR_NM";

            e.PopupPassData.GridCellCaption[0] = "조치유형";
            e.PopupPassData.GridCellCaption[1] = "조치유형명";

            e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
            e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;
        }

        private void popRepairType2_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            popRepairType2.CodeValue = iDataSet.Tables[0].Rows[0]["MINOR_CD"].ToString();
            popRepairType2.CodeName = iDataSet.Tables[0].Rows[0]["MINOR_NM"].ToString();
        }


        private void uniGrid2_DoubleClickRow(object sender, DoubleClickRowEventArgs e)
        {
            if (uniGrid2.Rows.Count < 1)
                return;

            this.OKProcess();
        }




    }
}
