﻿using System.Windows.Forms;

using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

using uniERP.AppFramework.UI.Module;


namespace uniERP.App.UI.POPUP.S3119P1_KO883
{

    public class ModuleInitializer : PopupModule
    {

        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterPopupViewer()
        {
            base.AddModule<PopupViewer>();
        }

    }
    partial class PopupViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance62 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance63 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance64 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance65 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance66 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance68 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance69 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance70 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance71 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance72 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance73 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance74 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance75 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance76 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance77 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance78 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance79 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance80 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance81 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance82 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance83 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance84 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance85 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance86 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem4 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem5 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem6 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance87 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance88 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance45 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnQuery = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnCancel = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnOK = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTableLayoutPanel1 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid2 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.lblBpCd = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popBpCd = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTextBox_Name = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTextBox_Code = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblReceiptNo2 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popReceiptNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblReceiptDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtReceiptDt = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.lblSerialNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popSerialNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_91578d13_e417_4e46_bf50_27c31a759095 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblReceiptPrn = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popReceiptPrn = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblFreeYn = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.rdoFreeYn = new uniERP.AppFramework.UI.Controls.uniRadioButton(this.components);
            this.lblCsSts = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popCsSts = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.popCsType = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.lblCsType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblRepairType1 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popRepairType = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.lblRepairType2 = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popRepairType2 = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTBL_MainCondition.SuspendLayout();
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainReference.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            this.uniTableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.popBpCd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).BeginInit();
            this.popReceiptNo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_b65afb63_8cea_44e4_a541_a93e7c29c824)).BeginInit();
            this.popSerialNo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_91578d13_e417_4e46_bf50_27c31a759095)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac)).BeginInit();
            this.popReceiptPrn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoFreeYn)).BeginInit();
            this.popRepairType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_3c2c6bda_2507_413a_993d_ed1834b2a963)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096)).BeginInit();
            this.popRepairType2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd)).BeginInit();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.Location = new System.Drawing.Point(-5, 0);
            this.uniLabel_Path.Size = new System.Drawing.Size(0, 0);
            this.uniLabel_Path.Visible = false;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.popRepairType2, 3, 4);
            this.uniTBL_MainCondition.Controls.Add(this.lblRepairType2, 2, 4);
            this.uniTBL_MainCondition.Controls.Add(this.popRepairType, 1, 4);
            this.uniTBL_MainCondition.Controls.Add(this.lblRepairType1, 0, 4);
            this.uniTBL_MainCondition.Controls.Add(this.lblCsType, 2, 3);
            this.uniTBL_MainCondition.Controls.Add(this.lblCsSts, 0, 3);
            this.uniTBL_MainCondition.Controls.Add(this.rdoFreeYn, 3, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblFreeYn, 2, 2);
            this.uniTBL_MainCondition.Controls.Add(this.popReceiptPrn, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblReceiptPrn, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.popSerialNo, 3, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblSerialNo, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblBpCd, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popBpCd, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblReceiptNo2, 2, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popReceiptNo, 3, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblReceiptDt, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.dtReceiptDt, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popCsSts, 1, 3);
            this.uniTBL_MainCondition.Controls.Add(this.popCsType, 3, 3);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 40F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 5;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(1194, 130);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 2);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(10, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 5;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(1194, 619);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 1;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 5;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.Controls.Add(this.btnQuery, 0, 0);
            this.uniTBL_MainReference.Controls.Add(this.btnCancel, 4, 0);
            this.uniTBL_MainReference.Controls.Add(this.btnOK, 2, 0);
            this.uniTBL_MainReference.DefaultRowSize = 23;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 591);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(1194, 28);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 3;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnQuery
            // 
            this.btnQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnQuery.AutoPopupID = null;
            this.btnQuery.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnQuery.Location = new System.Drawing.Point(0, 1);
            this.btnQuery.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.PopupID = null;
            this.btnQuery.Size = new System.Drawing.Size(97, 24);
            this.btnQuery.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnQuery.StyleSetName = "uniButton_EasyBase";
            this.btnQuery.TabIndex = 0;
            this.btnQuery.Text = "Query";
            this.btnQuery.UserDefinedText = null;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.AutoPopupID = null;
            this.btnCancel.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCancel.Location = new System.Drawing.Point(1094, 1);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.PopupID = null;
            this.btnCancel.Size = new System.Drawing.Size(97, 24);
            this.btnCancel.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UserDefinedText = null;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.AutoPopupID = null;
            this.btnOK.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnOK.Location = new System.Drawing.Point(986, 1);
            this.btnOK.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnOK.Name = "btnOK";
            this.btnOK.PopupID = null;
            this.btnOK.Size = new System.Drawing.Size(97, 24);
            this.btnOK.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnOK.TabIndex = 2;
            this.btnOK.Text = "OK";
            this.btnOK.UserDefinedText = null;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTBL_MainData.Controls.Add(this.uniTableLayoutPanel1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 139);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(1194, 447);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 4;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTableLayoutPanel1
            // 
            this.uniTableLayoutPanel1.AutoFit = false;
            this.uniTableLayoutPanel1.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel1.AutoFitRowCount = 4;
            this.uniTableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel1.ColumnCount = 1;
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTableLayoutPanel1.Controls.Add(this.uniGrid2, 0, 1);
            this.uniTableLayoutPanel1.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTableLayoutPanel1.DefaultRowSize = 23;
            this.uniTableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTableLayoutPanel1.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.uniTableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel1.Name = "uniTableLayoutPanel1";
            this.uniTableLayoutPanel1.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTableLayoutPanel1.RowCount = 2;
            this.uniTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTableLayoutPanel1.Size = new System.Drawing.Size(1194, 447);
            this.uniTableLayoutPanel1.SizeTD5 = 14F;
            this.uniTableLayoutPanel1.SizeTD6 = 36F;
            this.uniTableLayoutPanel1.TabIndex = 5;
            this.uniTableLayoutPanel1.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel1.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid2
            // 
            this.uniGrid2.AddEmptyRow = false;
            this.uniGrid2.DirectPaste = false;
            appearance57.BackColor = System.Drawing.SystemColors.Window;
            appearance57.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid2.DisplayLayout.Appearance = appearance57;
            this.uniGrid2.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid2.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance58.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance58.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance58.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.GroupByBox.Appearance = appearance58;
            appearance59.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.BandLabelAppearance = appearance59;
            this.uniGrid2.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance60.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance60.BackColor2 = System.Drawing.SystemColors.Control;
            appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance60.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid2.DisplayLayout.GroupByBox.PromptAppearance = appearance60;
            this.uniGrid2.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid2.DisplayLayout.MaxRowScrollRegions = 1;
            appearance61.BackColor = System.Drawing.SystemColors.Window;
            appearance61.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid2.DisplayLayout.Override.ActiveCellAppearance = appearance61;
            this.uniGrid2.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid2.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid2.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance62.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.CardAreaAppearance = appearance62;
            appearance63.BorderColor = System.Drawing.Color.Silver;
            appearance63.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid2.DisplayLayout.Override.CellAppearance = appearance63;
            this.uniGrid2.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid2.DisplayLayout.Override.CellPadding = 0;
            appearance64.BackColor = System.Drawing.SystemColors.Control;
            appearance64.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance64.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance64.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid2.DisplayLayout.Override.GroupByRowAppearance = appearance64;
            appearance65.TextHAlignAsString = "Left";
            this.uniGrid2.DisplayLayout.Override.HeaderAppearance = appearance65;
            this.uniGrid2.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid2.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance66.BackColor = System.Drawing.SystemColors.Window;
            appearance66.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid2.DisplayLayout.Override.RowAppearance = appearance66;
            this.uniGrid2.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance67.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid2.DisplayLayout.Override.TemplateAddRowAppearance = appearance67;
            this.uniGrid2.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid2.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid2.EnableContextMenu = true;
            this.uniGrid2.EnableGridInfoContextMenu = true;
            this.uniGrid2.ExceptInExcel = false;
            this.uniGrid2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid2.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid2.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid2.Location = new System.Drawing.Point(0, 223);
            this.uniGrid2.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid2.Name = "uniGrid2";
            this.uniGrid2.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid2.PopupDeleteMenuVisible = true;
            this.uniGrid2.PopupInsertMenuVisible = true;
            this.uniGrid2.PopupUndoMenuVisible = true;
            this.uniGrid2.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid2.ShowHeaderCheck = true;
            this.uniGrid2.Size = new System.Drawing.Size(1194, 224);
            this.uniGrid2.StyleSetName = "uniGrid_Query";
            this.uniGrid2.TabIndex = 3;
            this.uniGrid2.Text = "uniGrid2";
            this.uniGrid2.UseDynamicFormat = false;
            this.uniGrid2.DoubleClickRow += new Infragistics.Win.UltraWinGrid.DoubleClickRowEventHandler(this.uniGrid2_DoubleClickRow);
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance68.BackColor = System.Drawing.SystemColors.Window;
            appearance68.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance68;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance69.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance69.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance69.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance69;
            appearance70.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance70;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance71.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance71.BackColor2 = System.Drawing.SystemColors.Control;
            appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance71.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance71;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance72.BackColor = System.Drawing.SystemColors.Window;
            appearance72.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance72;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance73.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance73;
            appearance74.BorderColor = System.Drawing.Color.Silver;
            appearance74.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance74;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance75.BackColor = System.Drawing.SystemColors.Control;
            appearance75.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance75.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance75.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance75;
            appearance76.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance76;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance77.BackColor = System.Drawing.SystemColors.Window;
            appearance77.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance77;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance78.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance78;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.AppendDetail;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(1194, 223);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 2;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.DetailBinding += new uniERP.AppFramework.UI.Controls.uniGrid.DetailBindingEventHandler(this.uniGrid1_DetailBinding);
            // 
            // lblBpCd
            // 
            appearance54.TextHAlignAsString = "Left";
            appearance54.TextVAlignAsString = "Middle";
            this.lblBpCd.Appearance = appearance54;
            this.lblBpCd.AutoPopupID = null;
            this.lblBpCd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBpCd.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBpCd.Location = new System.Drawing.Point(15, 6);
            this.lblBpCd.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblBpCd.Name = "lblBpCd";
            this.lblBpCd.Size = new System.Drawing.Size(152, 22);
            this.lblBpCd.StyleSetName = "Default";
            this.lblBpCd.TabIndex = 19;
            this.lblBpCd.Text = "고객사";
            this.lblBpCd.UseMnemonic = false;
            // 
            // popBpCd
            // 
            this.popBpCd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popBpCd.AutoPopupCodeParameter = null;
            this.popBpCd.AutoPopupID = null;
            this.popBpCd.AutoPopupNameParameter = null;
            this.popBpCd.CodeMaxLength = 10;
            this.popBpCd.CodeName = "";
            this.popBpCd.CodeSize = 100;
            this.popBpCd.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBpCd.CodeTextBoxName = null;
            this.popBpCd.CodeValue = "";
            this.popBpCd.Controls.Add(this.uniTextBox_Name);
            this.popBpCd.Controls.Add(this.uniTextBox_Code);
            this.popBpCd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popBpCd.Location = new System.Drawing.Point(167, 7);
            this.popBpCd.LockedField = false;
            this.popBpCd.Margin = new System.Windows.Forms.Padding(0);
            this.popBpCd.Name = "popBpCd";
            this.popBpCd.NameDisplay = true;
            this.popBpCd.NameId = null;
            this.popBpCd.NameMaxLength = 50;
            this.popBpCd.NamePopup = false;
            this.popBpCd.NameSize = 150;
            this.popBpCd.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popBpCd.Parameter = null;
            this.popBpCd.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popBpCd.PopupId = null;
            this.popBpCd.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popBpCd.QueryIfEnterKeyPressed = true;
            this.popBpCd.RequiredField = false;
            this.popBpCd.Size = new System.Drawing.Size(353, 21);
            this.popBpCd.TabIndex = 20;
            this.popBpCd.uniALT = "고객사";
            this.popBpCd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popBpCd.UseDynamicFormat = false;
            this.popBpCd.ValueTextBoxName = null;
            this.popBpCd.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popBpCd_BeforePopupOpen);
            this.popBpCd.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popBpCd_AfterPopupClosed);
            // 
            // uniTextBox_Name
            // 
            this.uniTextBox_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance79.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.Appearance = appearance79;
            this.uniTextBox_Name.AutoSize = false;
            this.uniTextBox_Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Name.Location = new System.Drawing.Point(121, 0);
            this.uniTextBox_Name.LockedField = false;
            this.uniTextBox_Name.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Name.MaxLength = 50;
            this.uniTextBox_Name.Name = "uniTextBox_Name";
            this.uniTextBox_Name.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Name.ReadOnly = true;
            this.uniTextBox_Name.RequiredField = false;
            this.uniTextBox_Name.Size = new System.Drawing.Size(150, 21);
            this.uniTextBox_Name.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Name.StyleSetName = "Lock";
            this.uniTextBox_Name.TabIndex = 0;
            this.uniTextBox_Name.TabStop = false;
            this.uniTextBox_Name.uniALT = null;
            this.uniTextBox_Name.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.uniTextBox_Name.UseDynamicFormat = false;
            this.uniTextBox_Name.WordWrap = false;
            // 
            // uniTextBox_Code
            // 
            this.uniTextBox_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.Appearance = appearance80;
            this.uniTextBox_Code.AutoSize = false;
            this.uniTextBox_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Code.Location = new System.Drawing.Point(0, 0);
            this.uniTextBox_Code.LockedField = false;
            this.uniTextBox_Code.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Code.MaxLength = 10;
            this.uniTextBox_Code.Name = "uniTextBox_Code";
            this.uniTextBox_Code.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Code.RequiredField = false;
            this.uniTextBox_Code.Size = new System.Drawing.Size(100, 21);
            this.uniTextBox_Code.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Code.StyleSetName = "Default";
            this.uniTextBox_Code.TabIndex = 0;
            this.uniTextBox_Code.uniALT = null;
            this.uniTextBox_Code.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.uniTextBox_Code.UseDynamicFormat = false;
            this.uniTextBox_Code.WordWrap = false;
            // 
            // lblReceiptNo2
            // 
            appearance55.TextHAlignAsString = "Left";
            appearance55.TextVAlignAsString = "Middle";
            this.lblReceiptNo2.Appearance = appearance55;
            this.lblReceiptNo2.AutoPopupID = null;
            this.lblReceiptNo2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReceiptNo2.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReceiptNo2.Location = new System.Drawing.Point(611, 6);
            this.lblReceiptNo2.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReceiptNo2.Name = "lblReceiptNo2";
            this.lblReceiptNo2.Size = new System.Drawing.Size(152, 22);
            this.lblReceiptNo2.StyleSetName = "Default";
            this.lblReceiptNo2.TabIndex = 21;
            this.lblReceiptNo2.Text = "접수번호";
            this.lblReceiptNo2.UseMnemonic = false;
            // 
            // popReceiptNo
            // 
            this.popReceiptNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popReceiptNo.AutoPopupCodeParameter = null;
            this.popReceiptNo.AutoPopupID = null;
            this.popReceiptNo.AutoPopupNameParameter = null;
            this.popReceiptNo.CodeMaxLength = 30;
            this.popReceiptNo.CodeName = "";
            this.popReceiptNo.CodeSize = 150;
            this.popReceiptNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReceiptNo.CodeTextBoxName = null;
            this.popReceiptNo.CodeValue = "";
            this.popReceiptNo.Controls.Add(this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2);
            this.popReceiptNo.Controls.Add(this.object_b65afb63_8cea_44e4_a541_a93e7c29c824);
            this.popReceiptNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popReceiptNo.Location = new System.Drawing.Point(763, 7);
            this.popReceiptNo.LockedField = false;
            this.popReceiptNo.Margin = new System.Windows.Forms.Padding(0);
            this.popReceiptNo.Name = "popReceiptNo";
            this.popReceiptNo.NameDisplay = false;
            this.popReceiptNo.NameId = null;
            this.popReceiptNo.NameMaxLength = 50;
            this.popReceiptNo.NamePopup = false;
            this.popReceiptNo.NameSize = 150;
            this.popReceiptNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReceiptNo.Parameter = null;
            this.popReceiptNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popReceiptNo.PopupId = null;
            this.popReceiptNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popReceiptNo.QueryIfEnterKeyPressed = true;
            this.popReceiptNo.RequiredField = false;
            this.popReceiptNo.Size = new System.Drawing.Size(253, 21);
            this.popReceiptNo.TabIndex = 22;
            this.popReceiptNo.uniALT = "접수번호";
            this.popReceiptNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popReceiptNo.UseDynamicFormat = false;
            this.popReceiptNo.ValueTextBoxName = null;
            this.popReceiptNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popReceiptNo_BeforePopupOpen);
            this.popReceiptNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popReceiptNo_AfterPopupClosed);
            // 
            // object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2
            // 
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.Appearance = appearance81;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.AutoSize = false;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.Location = new System.Drawing.Point(171, 0);
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.LockedField = false;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.Margin = new System.Windows.Forms.Padding(0);
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.MaxLength = 50;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.Name = "object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2";
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.QueryIfEnterKeyPressed = true;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.ReadOnly = true;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.RequiredField = false;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.Size = new System.Drawing.Size(0, 21);
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.StyleSetName = "Lock";
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.TabIndex = 0;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.TabStop = false;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.uniALT = null;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.UseDynamicFormat = false;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.Visible = false;
            this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2.WordWrap = false;
            // 
            // object_b65afb63_8cea_44e4_a541_a93e7c29c824
            // 
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance82.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.Appearance = appearance82;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.AutoSize = false;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.Location = new System.Drawing.Point(0, 0);
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.LockedField = false;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.Margin = new System.Windows.Forms.Padding(0);
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.MaxLength = 30;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.Name = "object_b65afb63_8cea_44e4_a541_a93e7c29c824";
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.QueryIfEnterKeyPressed = true;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.RequiredField = false;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.Size = new System.Drawing.Size(150, 21);
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.StyleSetName = "Default";
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.TabIndex = 0;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.uniALT = null;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.UseDynamicFormat = false;
            this.object_b65afb63_8cea_44e4_a541_a93e7c29c824.WordWrap = false;
            // 
            // lblReceiptDt
            // 
            appearance56.TextHAlignAsString = "Left";
            appearance56.TextVAlignAsString = "Middle";
            this.lblReceiptDt.Appearance = appearance56;
            this.lblReceiptDt.AutoPopupID = null;
            this.lblReceiptDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReceiptDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReceiptDt.Location = new System.Drawing.Point(15, 29);
            this.lblReceiptDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReceiptDt.Name = "lblReceiptDt";
            this.lblReceiptDt.Size = new System.Drawing.Size(152, 22);
            this.lblReceiptDt.StyleSetName = "Default";
            this.lblReceiptDt.TabIndex = 27;
            this.lblReceiptDt.Text = "접수일";
            this.lblReceiptDt.UseMnemonic = false;
            // 
            // dtReceiptDt
            // 
            this.dtReceiptDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtReceiptDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.YYYY_MM_DD;
            this.dtReceiptDt.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtReceiptDt.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtReceiptDt.Location = new System.Drawing.Point(167, 30);
            this.dtReceiptDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtReceiptDt.Name = "dtReceiptDt";
            this.dtReceiptDt.Size = new System.Drawing.Size(225, 21);
            this.dtReceiptDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.dtReceiptDt.TabIndex = 28;
            this.dtReceiptDt.uniFromALT = "접수일 From";
            this.dtReceiptDt.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtReceiptDt.uniTabSameValue = false;
            this.dtReceiptDt.uniToALT = "접수일To";
            this.dtReceiptDt.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // lblSerialNo
            // 
            appearance53.TextHAlignAsString = "Left";
            appearance53.TextVAlignAsString = "Middle";
            this.lblSerialNo.Appearance = appearance53;
            this.lblSerialNo.AutoPopupID = null;
            this.lblSerialNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSerialNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblSerialNo.Location = new System.Drawing.Point(611, 29);
            this.lblSerialNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblSerialNo.Name = "lblSerialNo";
            this.lblSerialNo.Size = new System.Drawing.Size(152, 22);
            this.lblSerialNo.StyleSetName = "Default";
            this.lblSerialNo.TabIndex = 29;
            this.lblSerialNo.Text = "Serial NO";
            this.lblSerialNo.UseMnemonic = false;
            // 
            // popSerialNo
            // 
            this.popSerialNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popSerialNo.AutoPopupCodeParameter = null;
            this.popSerialNo.AutoPopupID = null;
            this.popSerialNo.AutoPopupNameParameter = null;
            this.popSerialNo.CodeMaxLength = 10;
            this.popSerialNo.CodeName = "";
            this.popSerialNo.CodeSize = 150;
            this.popSerialNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSerialNo.CodeTextBoxName = null;
            this.popSerialNo.CodeValue = "";
            this.popSerialNo.Controls.Add(this.object_91578d13_e417_4e46_bf50_27c31a759095);
            this.popSerialNo.Controls.Add(this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac);
            this.popSerialNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popSerialNo.Location = new System.Drawing.Point(763, 30);
            this.popSerialNo.LockedField = false;
            this.popSerialNo.Margin = new System.Windows.Forms.Padding(0);
            this.popSerialNo.Name = "popSerialNo";
            this.popSerialNo.NameDisplay = false;
            this.popSerialNo.NameId = null;
            this.popSerialNo.NameMaxLength = 50;
            this.popSerialNo.NamePopup = false;
            this.popSerialNo.NameSize = 100;
            this.popSerialNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popSerialNo.Parameter = null;
            this.popSerialNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popSerialNo.PopupId = null;
            this.popSerialNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popSerialNo.QueryIfEnterKeyPressed = true;
            this.popSerialNo.RequiredField = false;
            this.popSerialNo.Size = new System.Drawing.Size(253, 21);
            this.popSerialNo.TabIndex = 30;
            this.popSerialNo.uniALT = "Serial No";
            this.popSerialNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popSerialNo.UseDynamicFormat = false;
            this.popSerialNo.ValueTextBoxName = null;
            this.popSerialNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popSerialNo_BeforePopupOpen);
            this.popSerialNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popSerialNo_AfterPopupClosed);
            // 
            // object_91578d13_e417_4e46_bf50_27c31a759095
            // 
            this.object_91578d13_e417_4e46_bf50_27c31a759095.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance83.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_91578d13_e417_4e46_bf50_27c31a759095.Appearance = appearance83;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.AutoSize = false;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_91578d13_e417_4e46_bf50_27c31a759095.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.Location = new System.Drawing.Point(171, 0);
            this.object_91578d13_e417_4e46_bf50_27c31a759095.LockedField = false;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.Margin = new System.Windows.Forms.Padding(0);
            this.object_91578d13_e417_4e46_bf50_27c31a759095.MaxLength = 50;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.Name = "object_91578d13_e417_4e46_bf50_27c31a759095";
            this.object_91578d13_e417_4e46_bf50_27c31a759095.QueryIfEnterKeyPressed = true;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.ReadOnly = true;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.RequiredField = false;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.Size = new System.Drawing.Size(0, 21);
            this.object_91578d13_e417_4e46_bf50_27c31a759095.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.StyleSetName = "Lock";
            this.object_91578d13_e417_4e46_bf50_27c31a759095.TabIndex = 0;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.TabStop = false;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.uniALT = null;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.UseDynamicFormat = false;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.Visible = false;
            this.object_91578d13_e417_4e46_bf50_27c31a759095.WordWrap = false;
            // 
            // object_d8326b66_ece0_49a6_b018_a6b1b83854ac
            // 
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.Appearance = appearance84;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.AutoSize = false;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.Location = new System.Drawing.Point(0, 0);
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.LockedField = false;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.Margin = new System.Windows.Forms.Padding(0);
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.MaxLength = 10;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.Name = "object_d8326b66_ece0_49a6_b018_a6b1b83854ac";
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.QueryIfEnterKeyPressed = true;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.RequiredField = false;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.Size = new System.Drawing.Size(150, 21);
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.StyleSetName = "Default";
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.TabIndex = 0;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.uniALT = null;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.UseDynamicFormat = false;
            this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac.WordWrap = false;
            // 
            // lblReceiptPrn
            // 
            appearance52.TextHAlignAsString = "Left";
            appearance52.TextVAlignAsString = "Middle";
            this.lblReceiptPrn.Appearance = appearance52;
            this.lblReceiptPrn.AutoPopupID = null;
            this.lblReceiptPrn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReceiptPrn.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReceiptPrn.Location = new System.Drawing.Point(15, 52);
            this.lblReceiptPrn.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReceiptPrn.Name = "lblReceiptPrn";
            this.lblReceiptPrn.Size = new System.Drawing.Size(152, 22);
            this.lblReceiptPrn.StyleSetName = "Default";
            this.lblReceiptPrn.TabIndex = 31;
            this.lblReceiptPrn.Text = "접수자";
            this.lblReceiptPrn.UseMnemonic = false;
            // 
            // popReceiptPrn
            // 
            this.popReceiptPrn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popReceiptPrn.AutoPopupCodeParameter = null;
            this.popReceiptPrn.AutoPopupID = null;
            this.popReceiptPrn.AutoPopupNameParameter = null;
            this.popReceiptPrn.CodeMaxLength = 20;
            this.popReceiptPrn.CodeName = "";
            this.popReceiptPrn.CodeSize = 100;
            this.popReceiptPrn.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReceiptPrn.CodeTextBoxName = null;
            this.popReceiptPrn.CodeValue = "";
            this.popReceiptPrn.Controls.Add(this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1);
            this.popReceiptPrn.Controls.Add(this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06);
            this.popReceiptPrn.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popReceiptPrn.Location = new System.Drawing.Point(167, 53);
            this.popReceiptPrn.LockedField = false;
            this.popReceiptPrn.Margin = new System.Windows.Forms.Padding(0);
            this.popReceiptPrn.Name = "popReceiptPrn";
            this.popReceiptPrn.NameDisplay = true;
            this.popReceiptPrn.NameId = null;
            this.popReceiptPrn.NameMaxLength = 50;
            this.popReceiptPrn.NamePopup = false;
            this.popReceiptPrn.NameSize = 150;
            this.popReceiptPrn.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popReceiptPrn.Parameter = null;
            this.popReceiptPrn.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popReceiptPrn.PopupId = null;
            this.popReceiptPrn.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popReceiptPrn.QueryIfEnterKeyPressed = true;
            this.popReceiptPrn.RequiredField = false;
            this.popReceiptPrn.Size = new System.Drawing.Size(353, 21);
            this.popReceiptPrn.TabIndex = 32;
            this.popReceiptPrn.uniALT = "접수자";
            this.popReceiptPrn.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popReceiptPrn.UseDynamicFormat = false;
            this.popReceiptPrn.ValueTextBoxName = null;
            this.popReceiptPrn.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popReceiptPrn_BeforePopupOpen);
            this.popReceiptPrn.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popReceiptPrn_AfterPopupClosed);
            // 
            // object_5a1ae121_c273_4805_81bb_3d4b485e42a1
            // 
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance85.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.Appearance = appearance85;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.AutoSize = false;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.Location = new System.Drawing.Point(121, 0);
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.LockedField = false;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.Margin = new System.Windows.Forms.Padding(0);
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.MaxLength = 50;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.Name = "object_5a1ae121_c273_4805_81bb_3d4b485e42a1";
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.QueryIfEnterKeyPressed = true;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.ReadOnly = true;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.RequiredField = false;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.Size = new System.Drawing.Size(150, 21);
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.StyleSetName = "Lock";
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.TabIndex = 0;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.TabStop = false;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.uniALT = null;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.UseDynamicFormat = false;
            this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1.WordWrap = false;
            // 
            // object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06
            // 
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance86.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.Appearance = appearance86;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.AutoSize = false;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.Location = new System.Drawing.Point(0, 0);
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.LockedField = false;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.Margin = new System.Windows.Forms.Padding(0);
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.MaxLength = 20;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.Name = "object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06";
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.QueryIfEnterKeyPressed = true;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.RequiredField = false;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.Size = new System.Drawing.Size(100, 21);
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.StyleSetName = "Default";
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.TabIndex = 0;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.uniALT = null;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.UseDynamicFormat = false;
            this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06.WordWrap = false;
            // 
            // lblFreeYn
            // 
            appearance51.TextHAlignAsString = "Left";
            appearance51.TextVAlignAsString = "Middle";
            this.lblFreeYn.Appearance = appearance51;
            this.lblFreeYn.AutoPopupID = null;
            this.lblFreeYn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFreeYn.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblFreeYn.Location = new System.Drawing.Point(611, 52);
            this.lblFreeYn.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblFreeYn.Name = "lblFreeYn";
            this.lblFreeYn.Size = new System.Drawing.Size(152, 22);
            this.lblFreeYn.StyleSetName = "Default";
            this.lblFreeYn.TabIndex = 33;
            this.lblFreeYn.Text = "유/무상 구분";
            this.lblFreeYn.UseMnemonic = false;
            // 
            // rdoFreeYn
            // 
            this.rdoFreeYn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rdoFreeYn.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.rdoFreeYn.CheckedIndex = 0;
            this.rdoFreeYn.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            valueListItem4.DataValue = "A";
            valueListItem4.DisplayText = "전체";
            valueListItem5.DataValue = "Y";
            valueListItem5.DisplayText = "유상";
            valueListItem6.DataValue = "N";
            valueListItem6.DisplayText = "무상";
            this.rdoFreeYn.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem4,
            valueListItem5,
            valueListItem6});
            this.rdoFreeYn.ItemSpacingHorizontal = 30;
            this.rdoFreeYn.ItemSpacingVertical = 10;
            this.rdoFreeYn.Location = new System.Drawing.Point(763, 55);
            this.rdoFreeYn.LockedField = false;
            this.rdoFreeYn.Margin = new System.Windows.Forms.Padding(0, 4, 1, 0);
            this.rdoFreeYn.Name = "rdoFreeYn";
            this.rdoFreeYn.RequiredField = false;
            this.rdoFreeYn.Size = new System.Drawing.Size(232, 19);
            this.rdoFreeYn.StyleSetName = "Default";
            this.rdoFreeYn.TabIndex = 34;
            this.rdoFreeYn.Text = "전체";
            this.rdoFreeYn.uniALT = "유/무상 구분";
            // 
            // lblCsSts
            // 
            appearance50.TextHAlignAsString = "Left";
            appearance50.TextVAlignAsString = "Middle";
            this.lblCsSts.Appearance = appearance50;
            this.lblCsSts.AutoPopupID = null;
            this.lblCsSts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCsSts.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCsSts.Location = new System.Drawing.Point(15, 75);
            this.lblCsSts.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCsSts.Name = "lblCsSts";
            this.lblCsSts.Size = new System.Drawing.Size(152, 22);
            this.lblCsSts.StyleSetName = "Default";
            this.lblCsSts.TabIndex = 35;
            this.lblCsSts.Text = "진행상태";
            this.lblCsSts.UseMnemonic = false;
            // 
            // popCsSts
            // 
            this.popCsSts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popCsSts.AutoPopupCodeParameter = null;
            this.popCsSts.AutoPopupID = null;
            this.popCsSts.AutoPopupNameParameter = null;
            this.popCsSts.CodeMaxLength = 10;
            this.popCsSts.CodeName = "";
            this.popCsSts.CodeSize = 100;
            this.popCsSts.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCsSts.CodeTextBoxName = null;
            this.popCsSts.CodeValue = "";
            this.popCsSts.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popCsSts.Location = new System.Drawing.Point(167, 76);
            this.popCsSts.LockedField = false;
            this.popCsSts.Margin = new System.Windows.Forms.Padding(0);
            this.popCsSts.Name = "popCsSts";
            this.popCsSts.NameDisplay = true;
            this.popCsSts.NameId = null;
            this.popCsSts.NameMaxLength = 50;
            this.popCsSts.NamePopup = false;
            this.popCsSts.NameSize = 150;
            this.popCsSts.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCsSts.Parameter = null;
            this.popCsSts.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popCsSts.PopupId = null;
            this.popCsSts.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popCsSts.QueryIfEnterKeyPressed = true;
            this.popCsSts.RequiredField = false;
            this.popCsSts.Size = new System.Drawing.Size(353, 21);
            this.popCsSts.TabIndex = 36;
            this.popCsSts.uniALT = "진행상태";
            this.popCsSts.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popCsSts.UseDynamicFormat = false;
            this.popCsSts.ValueTextBoxName = null;
            this.popCsSts.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popCsSts_BeforePopupOpen);
            this.popCsSts.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popCsSts_AfterPopupClosed);
            // 
            // popCsType
            // 
            this.popCsType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popCsType.AutoPopupCodeParameter = null;
            this.popCsType.AutoPopupID = null;
            this.popCsType.AutoPopupNameParameter = null;
            this.popCsType.CodeMaxLength = 10;
            this.popCsType.CodeName = "";
            this.popCsType.CodeSize = 100;
            this.popCsType.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCsType.CodeTextBoxName = null;
            this.popCsType.CodeValue = "";
            this.popCsType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popCsType.Location = new System.Drawing.Point(763, 76);
            this.popCsType.LockedField = false;
            this.popCsType.Margin = new System.Windows.Forms.Padding(0);
            this.popCsType.Name = "popCsType";
            this.popCsType.NameDisplay = true;
            this.popCsType.NameId = null;
            this.popCsType.NameMaxLength = 50;
            this.popCsType.NamePopup = false;
            this.popCsType.NameSize = 150;
            this.popCsType.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popCsType.Parameter = null;
            this.popCsType.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popCsType.PopupId = null;
            this.popCsType.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popCsType.QueryIfEnterKeyPressed = true;
            this.popCsType.RequiredField = false;
            this.popCsType.Size = new System.Drawing.Size(353, 21);
            this.popCsType.TabIndex = 37;
            this.popCsType.uniALT = "접수유형";
            this.popCsType.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popCsType.UseDynamicFormat = false;
            this.popCsType.ValueTextBoxName = null;
            this.popCsType.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popCsType_BeforePopupOpen);
            this.popCsType.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popCsType_AfterPopupClosed);
            // 
            // lblCsType
            // 
            appearance49.TextHAlignAsString = "Left";
            appearance49.TextVAlignAsString = "Middle";
            this.lblCsType.Appearance = appearance49;
            this.lblCsType.AutoPopupID = null;
            this.lblCsType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCsType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblCsType.Location = new System.Drawing.Point(611, 75);
            this.lblCsType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblCsType.Name = "lblCsType";
            this.lblCsType.Size = new System.Drawing.Size(152, 22);
            this.lblCsType.StyleSetName = "Default";
            this.lblCsType.TabIndex = 38;
            this.lblCsType.Text = "접수유형";
            this.lblCsType.UseMnemonic = false;
            // 
            // lblRepairType1
            // 
            appearance48.TextHAlignAsString = "Left";
            appearance48.TextVAlignAsString = "Middle";
            this.lblRepairType1.Appearance = appearance48;
            this.lblRepairType1.AutoPopupID = null;
            this.lblRepairType1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRepairType1.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRepairType1.Location = new System.Drawing.Point(15, 98);
            this.lblRepairType1.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRepairType1.Name = "lblRepairType1";
            this.lblRepairType1.Size = new System.Drawing.Size(152, 22);
            this.lblRepairType1.StyleSetName = "Default";
            this.lblRepairType1.TabIndex = 39;
            this.lblRepairType1.Text = "조치유형(대분류)";
            this.lblRepairType1.UseMnemonic = false;
            // 
            // popRepairType
            // 
            this.popRepairType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popRepairType.AutoPopupCodeParameter = null;
            this.popRepairType.AutoPopupID = null;
            this.popRepairType.AutoPopupNameParameter = null;
            this.popRepairType.CodeMaxLength = 20;
            this.popRepairType.CodeName = "";
            this.popRepairType.CodeSize = 100;
            this.popRepairType.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popRepairType.CodeTextBoxName = null;
            this.popRepairType.CodeValue = "";
            this.popRepairType.Controls.Add(this.object_3c2c6bda_2507_413a_993d_ed1834b2a963);
            this.popRepairType.Controls.Add(this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096);
            this.popRepairType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popRepairType.Location = new System.Drawing.Point(167, 99);
            this.popRepairType.LockedField = false;
            this.popRepairType.Margin = new System.Windows.Forms.Padding(0);
            this.popRepairType.Name = "popRepairType";
            this.popRepairType.NameDisplay = true;
            this.popRepairType.NameId = null;
            this.popRepairType.NameMaxLength = 50;
            this.popRepairType.NamePopup = false;
            this.popRepairType.NameSize = 150;
            this.popRepairType.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popRepairType.Parameter = null;
            this.popRepairType.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popRepairType.PopupId = null;
            this.popRepairType.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popRepairType.QueryIfEnterKeyPressed = true;
            this.popRepairType.RequiredField = false;
            this.popRepairType.Size = new System.Drawing.Size(353, 21);
            this.popRepairType.TabIndex = 40;
            this.popRepairType.uniALT = "조치유형(대분류)";
            this.popRepairType.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popRepairType.UseDynamicFormat = false;
            this.popRepairType.ValueTextBoxName = null;
            this.popRepairType.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popRepairType_BeforePopupOpen);
            this.popRepairType.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popRepairType_AfterPopupClosed);
            // 
            // object_3c2c6bda_2507_413a_993d_ed1834b2a963
            // 
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.Appearance = appearance87;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.AutoSize = false;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.Location = new System.Drawing.Point(121, 0);
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.LockedField = false;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.Margin = new System.Windows.Forms.Padding(0);
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.MaxLength = 50;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.Name = "object_3c2c6bda_2507_413a_993d_ed1834b2a963";
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.QueryIfEnterKeyPressed = true;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.ReadOnly = true;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.RequiredField = false;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.Size = new System.Drawing.Size(150, 21);
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.StyleSetName = "Lock";
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.TabIndex = 0;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.TabStop = false;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.uniALT = null;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.UseDynamicFormat = false;
            this.object_3c2c6bda_2507_413a_993d_ed1834b2a963.WordWrap = false;
            // 
            // object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096
            // 
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance88.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.Appearance = appearance88;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.AutoSize = false;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.Location = new System.Drawing.Point(0, 0);
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.LockedField = false;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.Margin = new System.Windows.Forms.Padding(0);
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.MaxLength = 20;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.Name = "object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096";
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.QueryIfEnterKeyPressed = true;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.RequiredField = false;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.Size = new System.Drawing.Size(100, 21);
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.StyleSetName = "Default";
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.TabIndex = 0;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.uniALT = null;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.UseDynamicFormat = false;
            this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096.WordWrap = false;
            // 
            // lblRepairType2
            // 
            appearance47.TextHAlignAsString = "Left";
            appearance47.TextVAlignAsString = "Middle";
            this.lblRepairType2.Appearance = appearance47;
            this.lblRepairType2.AutoPopupID = null;
            this.lblRepairType2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRepairType2.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRepairType2.Location = new System.Drawing.Point(611, 98);
            this.lblRepairType2.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRepairType2.Name = "lblRepairType2";
            this.lblRepairType2.Size = new System.Drawing.Size(152, 22);
            this.lblRepairType2.StyleSetName = "Default";
            this.lblRepairType2.TabIndex = 41;
            this.lblRepairType2.Text = "조치유형(중분류)";
            this.lblRepairType2.UseMnemonic = false;
            // 
            // popRepairType2
            // 
            this.popRepairType2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popRepairType2.AutoPopupCodeParameter = null;
            this.popRepairType2.AutoPopupID = null;
            this.popRepairType2.AutoPopupNameParameter = null;
            this.popRepairType2.CodeMaxLength = 20;
            this.popRepairType2.CodeName = "";
            this.popRepairType2.CodeSize = 100;
            this.popRepairType2.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popRepairType2.CodeTextBoxName = null;
            this.popRepairType2.CodeValue = "";
            this.popRepairType2.Controls.Add(this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be);
            this.popRepairType2.Controls.Add(this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd);
            this.popRepairType2.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popRepairType2.Location = new System.Drawing.Point(763, 99);
            this.popRepairType2.LockedField = false;
            this.popRepairType2.Margin = new System.Windows.Forms.Padding(0);
            this.popRepairType2.Name = "popRepairType2";
            this.popRepairType2.NameDisplay = true;
            this.popRepairType2.NameId = null;
            this.popRepairType2.NameMaxLength = 50;
            this.popRepairType2.NamePopup = false;
            this.popRepairType2.NameSize = 150;
            this.popRepairType2.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popRepairType2.Parameter = null;
            this.popRepairType2.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popRepairType2.PopupId = null;
            this.popRepairType2.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popRepairType2.QueryIfEnterKeyPressed = true;
            this.popRepairType2.RequiredField = false;
            this.popRepairType2.Size = new System.Drawing.Size(353, 21);
            this.popRepairType2.TabIndex = 42;
            this.popRepairType2.uniALT = "조치유형(중분류)";
            this.popRepairType2.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popRepairType2.UseDynamicFormat = false;
            this.popRepairType2.ValueTextBoxName = null;
            this.popRepairType2.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popRepairType2_BeforePopupOpen);
            this.popRepairType2.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popRepairType2_AfterPopupClosed);
            // 
            // object_cc111cc2_c28b_486b_be23_f78fc72bf4be
            // 
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.Appearance = appearance45;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.AutoSize = false;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.Location = new System.Drawing.Point(121, 0);
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.LockedField = false;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.Margin = new System.Windows.Forms.Padding(0);
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.MaxLength = 50;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.Name = "object_cc111cc2_c28b_486b_be23_f78fc72bf4be";
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.QueryIfEnterKeyPressed = true;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.ReadOnly = true;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.RequiredField = false;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.Size = new System.Drawing.Size(150, 21);
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.StyleSetName = "Lock";
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.TabIndex = 0;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.TabStop = false;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.uniALT = null;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.UseDynamicFormat = false;
            this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be.WordWrap = false;
            // 
            // object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd
            // 
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.Appearance = appearance46;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.AutoSize = false;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.Location = new System.Drawing.Point(0, 0);
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.LockedField = false;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.Margin = new System.Windows.Forms.Padding(0);
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.MaxLength = 20;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.Name = "object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd";
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.QueryIfEnterKeyPressed = true;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.RequiredField = false;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.Size = new System.Drawing.Size(100, 21);
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.StyleSetName = "Default";
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.TabIndex = 0;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.uniALT = null;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.UseDynamicFormat = false;
            this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd.WordWrap = false;
            // 
            // PopupViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "PopupViewer";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Size = new System.Drawing.Size(1214, 639);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainReference.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            this.uniTableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.popBpCd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).EndInit();
            this.popReceiptNo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_b65afb63_8cea_44e4_a541_a93e7c29c824)).EndInit();
            this.popSerialNo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_91578d13_e417_4e46_bf50_27c31a759095)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_d8326b66_ece0_49a6_b018_a6b1b83854ac)).EndInit();
            this.popReceiptPrn.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_5a1ae121_c273_4805_81bb_3d4b485e42a1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoFreeYn)).EndInit();
            this.popRepairType.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_3c2c6bda_2507_413a_993d_ed1834b2a963)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096)).EndInit();
            this.popRepairType2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.object_cc111cc2_c28b_486b_be23_f78fc72bf4be)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        //        private System.Windows.Forms.BindingSource autoNumViewBindingSource;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniButton btnQuery;
        private uniERP.AppFramework.UI.Controls.uniButton btnCancel;
        private uniERP.AppFramework.UI.Controls.uniButton btnOK;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel1;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid2;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBpCd;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popBpCd;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Name;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Code;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReceiptNo2;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popReceiptNo;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_89c1d1e6_79bf_407a_92b0_876bbcca5ff2;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_b65afb63_8cea_44e4_a541_a93e7c29c824;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReceiptDt;
        private uniERP.AppFramework.UI.Controls.uniDateTerm dtReceiptDt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblSerialNo;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popSerialNo;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_91578d13_e417_4e46_bf50_27c31a759095;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_d8326b66_ece0_49a6_b018_a6b1b83854ac;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReceiptPrn;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popReceiptPrn;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_5a1ae121_c273_4805_81bb_3d4b485e42a1;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_85d18bc0_3477_41fa_9885_ab6a1cfe9d06;
        private uniERP.AppFramework.UI.Controls.uniLabel lblFreeYn;
        private uniERP.AppFramework.UI.Controls.uniRadioButton rdoFreeYn;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCsSts;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popCsSts;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popCsType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblCsType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRepairType1;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popRepairType;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_3c2c6bda_2507_413a_993d_ed1834b2a963;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_fc5558f0_36b4_4f1c_b2a7_3163cf5bc096;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRepairType2;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popRepairType2;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_cc111cc2_c28b_486b_be23_f78fc72bf4be;
        private uniERP.AppFramework.UI.Controls.uniTextBox object_38bc62ec_cb20_4b8a_aad0_7b46a9bf75dd;

    }
}
