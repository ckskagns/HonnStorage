                    
--DROP PROCEDURE    dbo.[USP_POP_S3119P1_KO883_2]                    
--Go                    
/************************************************************************************/                    
/*****    PROC NAME   :  [USP_POP_S3119P1_KO883_2]         *****/                    
/*****    ���α׷�    :  S3119P1_KO883_2(CS�������(S))          *****/                    
/*****   Developer   :  IJM            *****/                    
/*****    ���߳�¥    :  2018-06-19            *****/                    
/*****    �ֽż�����¥:  2018-06-19            *****/                    
/*****    ��    ��    :               *****/                    
/************************************************************************************/                    
                    
CREATE PROC [dbo].[USP_POP_S3119P1_KO883_2](                    
                    
   @RECEIPT_NO    NVARCHAR(30)                    
                    
                       
)                        
AS                    
                    
IF(@RECEIPT_NO = '' OR @RECEIPT_NO IS NULL) BEGIN SET @RECEIPT_NO = '%' END                    
                    
                    
                    
    Set Nocount On                    
                     
    SELECT                                                  
 A.RECEIPT_NO,                    
  A.PART_ITEM,                       --Part No                      
  D.ITEM_NM AS PART_ITEM_NM,                    --Part ��                      
  D.SPEC,                         --Part �԰�                      
  D.BASIC_UNIT,                       --����                      
  A.PART_TYPE,                       --Part ����                      
  dbo.ufn_GetCodeName('XCS03', A.PART_TYPE) AS PART_TYPE_NM,            --Part ���и�                      
  A.SUPPLY_TYPE,                       --��/���� ����                      
  A.REPAIR_QTY,                       --����                      
  A.REPAIR_PRICE,                       --�ܰ�                      
  A.REPAIR_AMOUNT,                      --�ݾ�                      
  A.PLANT_CD,                        --����                      
  (SELECT PLANT_NM FROM B_PLANT(NOLOCK) WHERE PLANT_CD = A.PLANT_CD) AS PLANT_NM,       --�����                      
  A.SL_CD,                        --â��                      
  (SELECT SL_NM FROM B_STORAGE_LOCATION(NOLOCK) WHERE SL_CD = A.SL_CD) AS SL_NM       --â����                   
  , B.CS_STATUS                  
  , B.SERIAL_NO                  
  , B.PROJECT_CODE                  
  , B.ITEM_CD                  
  , C.ITEM_NM                  
  , B.TRACKING_NO                  
  , B.LOCATION                  
  , B.BP_CD                  
  , E.BP_NM                  
  , B.RECEIPT_PRN                  
  , F.NAME AS RECEIPT_PRN_NM                  
  , B.RECEIP_DESC                  
  , B.ETC_DESC                  
  , B.REPAIR_DESC                  
 , B.FREE_YN              
 , B.REPAIR_TYPE_1, G.MINOR_NM AS REPAIR_TYPE_1_NM              
 , B.REPAIR_TYPE_2, H.MINOR_NM AS REPAIR_TYPE_2_NM              
 , (SELECT TOP 1 Y.PART_ITEM                     --Model                    
  FROM S_CS_RECEIPT_KO883(NOLOCK) X                                        
  INNER JOIN S_CS_USE_ITEM_KO883 Y ON X.RECEIPT_NO = Y.RECEIPT_NO                               
  WHERE Y.PART_TYPE = '01' AND  X.SERIAL_NO = B.SERIAL_NO    and Y.RECEIPT_NO = b.RECEIPT_NO                               
  ORDER BY Y.INSRT_DT DESC) AS MODEL         
   , (SELECT TOP 1 Z.ITEM_NM                     --Model                    
  FROM S_CS_RECEIPT_KO883(NOLOCK) X                                        
  INNER JOIN S_CS_USE_ITEM_KO883 Y ON X.RECEIPT_NO = Y.RECEIPT_NO    
  LEFT JOIN B_ITEM Z(NOLOCK) ON Y.PART_ITEM = Z.ITEM_CD                                                      
  WHERE Y.PART_TYPE = '01' AND  X.SERIAL_NO = B.SERIAL_NO    and Y.RECEIPT_NO = b.RECEIPT_NO                               
  ORDER BY Y.INSRT_DT DESC) AS MODEL_NM  
  , B.CS_TYPE, B.COMP_FR_TIME, B.COMP_TO_TIME, B.REPAIR_FR_DT, B.REPAIR_TO_DT    
 FROM                      
 S_CS_USE_ITEM_KO883 A(NOLOCK)                    
  LEFT JOIN B_ITEM D(NOLOCK) ON A.PART_ITEM = D.ITEM_CD                      
  INNER JOIN S_CS_RECEIPT_KO883 B(NOLOCK) ON A.RECEIPT_NO = B.RECEIPT_NO                  
  LEFT JOIN B_ITEM C(NOLOCK) ON B.ITEM_CD = C.ITEM_CD                  
  LEFT JOIN B_BIZ_PARTNER E(NOLOCK) ON B.BP_CD = E.BP_CD                  
  LEFT JOIN HAA010T F(NOLOCK) ON B.RECEIPT_PRN = F.EMP_NO              
  LEFT JOIN B_MINOR G(NOLOCK) ON B.REPAIR_TYPE_1 = G.MINOR_CD AND G.MAJOR_CD = 'XCS04'              
  LEFT JOIN B_MINOR H(NOLOCK) ON B.REPAIR_TYPE_2 = H.MINOR_CD AND H.MAJOR_CD = 'XCS05'              
 WHERE                      
  A.RECEIPT_NO = @RECEIPT_NO 