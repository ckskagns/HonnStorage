        
--DROP PROCEDURE    dbo.[USP_POP_S3119P1_KO883]        
--Go        
/************************************************************************************/        
/*****    PROC NAME   :  [USP_POP_S3119P1_KO883]         *****/        
/*****    ���α׷�    :  S3119P1_KO883(CS�������(S))          *****/        
/*****   Developer   :  IJM            *****/        
/*****    ���߳�¥    :  2018-06-19            *****/        
/*****    �ֽż�����¥:  2018-06-19            *****/        
/*****    ��    ��    :               *****/        
/************************************************************************************/        
        
     
   CREATE PROC [dbo].[USP_POP_S3119P1_KO883](        
        
    @BP_CD    NVARCHAR(10)   --����          
   , @RECEIPT_NO  NVARCHAR(30)   --������ȣ          
   , @FR_DT    NVARCHAR(10)   --������FROM          
   , @TO_DT    NVARCHAR(10)   --������TO          
   , @SERIAL_NO   NVARCHAR(50)   --Serial��ȣ          
   , @RECEIPT_PERSON NVARCHAR(20)   --������          
   , @FREE_YN   NVARCHAR(25)   --��/���� ����          
   , @STATUS   NVARCHAR(10)   --�������          
   , @RECEIPT_TYPE  NVARCHAR(10)   --��������          
   , @REPAIR_TYPE1  NVARCHAR(20)   --��ġ����(��з�)          
   , @REPAIR_TYPE2  NVARCHAR(20)   --��ġ����(�ߺз�)          
           
)            
AS        
        
IF(@BP_CD = '' OR @BP_CD IS NULL) BEGIN SET @BP_CD = '%' END          
IF(@RECEIPT_NO = '' OR @RECEIPT_NO IS NULL) BEGIN SET @RECEIPT_NO = '%' END          
IF(@SERIAL_NO = '' OR @SERIAL_NO IS NULL) BEGIN SET @SERIAL_NO = '%' END          
IF(@RECEIPT_PERSON = '' OR @RECEIPT_PERSON IS NULL) BEGIN SET @RECEIPT_PERSON = '%' END          
IF(@STATUS = '' OR @STATUS IS NULL) BEGIN SET @STATUS = '%' END          
IF(@RECEIPT_TYPE = '' OR @RECEIPT_TYPE IS NULL) BEGIN SET @RECEIPT_TYPE = '%' END          
IF(@REPAIR_TYPE1 = '' OR @REPAIR_TYPE1 IS NULL) BEGIN SET @REPAIR_TYPE1 = '%' END          
IF(@REPAIR_TYPE2 = '' OR @REPAIR_TYPE2 IS NULL) BEGIN SET @REPAIR_TYPE2 = '%' END          
IF(@FREE_YN = '0' OR @FR_DT IS NULL) BEGIN SET @FREE_YN = '%' END          
        
        
    Set Nocount On        
         
    SELECT                                      
  A.RECEIPT_NO,                         --������ȣ          
  A.CS_STATUS,                         --�������          
  dbo.ufn_GetCodeName('XCS01', A.CS_STATUS) AS CS_STATUS_NM,               --������¸�          
  A.SERIAL_NO ,                      --Serial No          
  A.PROJECT_CODE,                         --������Ʈ��ȣ          
  (SELECT PROJECT_NM FROM PMS_PROJECT(NOLOCK) WHERE PROJECT_CODE = A.PROJECT_CODE) AS PROJECT_NM,     --������Ʈ��          
  A.ITEM_CD,                          --ǰ���ڵ�          
  C.ITEM_NM,                          --ǰ���ڵ��          
  C.SPEC,                           --�԰�          
  A.TRACKING_NO,                         --Trackin No          
  A.LOCATION,                          --Location          
  A.FREE_YN,                      --��/���󱸺�          
  A.BP_CD,                          --������          
  (SELECT BP_NM FROM B_BIZ_PARTNER(NOLOCK) WHERE BP_CD = A.BP_CD) AS BP_NM,          --�������          
  (SELECT TOP 1 Y.PART_ITEM                     --Model          
  FROM S_CS_RECEIPT_KO883(NOLOCK) X                              
  INNER JOIN S_CS_USE_ITEM_KO883 Y ON X.RECEIPT_NO = Y.RECEIPT_NO                     
  WHERE Y.PART_TYPE = '01' AND  X.SERIAL_NO = A.SERIAL_NO                         
  ORDER BY Y.INSRT_DT DESC) AS MODEL,          
          
  (SELECT TOP 1 Z.ITEM_NM                     --Model          
  FROM S_CS_RECEIPT_KO883(NOLOCK) X                              
  INNER JOIN S_CS_USE_ITEM_KO883 Y ON X.RECEIPT_NO = Y.RECEIPT_NO          
  LEFT JOIN B_ITEM(NOLOCK) Z ON Y.PART_ITEM = Z.ITEM_CD                       
  WHERE Y.PART_TYPE = '01' AND  X.SERIAL_NO = A.SERIAL_NO                         
  ORDER BY Y.INSRT_DT DESC) AS MODEL_NM,                  --Model��          
  A.RECEIPT_PRN,                       --������          
  (SELECT NAME FROM HAA010T(NOLOCK) WHERE EMP_NO = A.RECEIPT_PRN) AS RECEIPT_PRN_NM,   --�����ڸ�          
  A.COMP_FR_TIME,                       --�ҿ�ð�(FROM)          
  A.COMP_TO_TIME,                       --�ҿ�ð�(To)          
  A.RECEIPT_DT,                     --������          
  A.REPAIR_FR_DT,                       --��ġ��(From)          
  A.REPAIR_TO_DT,                       --��ġ��(To)          
  A.RECEIP_DESC,                       --��������          
  A.ETC_DESC,                        --Ư�����          
  A.REPAIR_DESC                       --ó������          
         
 FROM      S_CS_RECEIPT_KO883 A(NOLOCK)          
  LEFT JOIN B_ITEM C(NOLOCK) ON A.ITEM_CD = C.ITEM_CD        
 WHERE          
  A.BP_CD LIKE @BP_CD           
  AND A.RECEIPT_NO LIKE @RECEIPT_NO           
  AND A.RECEIPT_DT BETWEEN @FR_DT AND @TO_DT          
  AND ISNULL(A.SERIAL_NO,'') LIKE @SERIAL_NO           
  AND A.RECEIPT_PRN LIKE @RECEIPT_PERSON          
  AND A.FREE_YN LIKE @FREE_YN          
  AND A.CS_STATUS LIKE @STATUS           
  AND A.CS_TYPE LIKE @RECEIPT_TYPE           
  AND A.REPAIR_TYPE_1 LIKE @REPAIR_TYPE1           
  AND A.REPAIR_TYPE_2 LIKE @REPAIR_TYPE2 