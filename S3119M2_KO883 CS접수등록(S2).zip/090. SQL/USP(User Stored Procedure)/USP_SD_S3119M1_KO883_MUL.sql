      
--DROP PROCEDURE    dbo.[USP_SD_S3119M1_KO883_MUL]      
--Go      
/************************************************************************************/      
/*****    PROC NAME   :  [USP_SD_S3119M1_KO883_MUL]         *****/      
/*****    ���α׷�    :  S3119M1_KO883_MUL(CS�������(S))          *****/      
/*****   Developer   :  IJM            *****/      
/*****    ���߳�¥    :  2018-06-18            *****/      
/*****    �ֽż�����¥:  2018-06-18            *****/      
/*****    ��    ��    :               *****/      
/************************************************************************************/      
      
CREATE PROC [dbo].[USP_SD_S3119M1_KO883_MUL](      
      
   @RECEIPT_NO    NVARCHAR(30)      
)          
AS      
      
IF(@RECEIPT_NO = '' OR @RECEIPT_NO IS NULL) BEGIN SET @RECEIPT_NO = '%' END      
      
      
    Set Nocount On      
       
    SELECT      
        
   A.RECEIPT_NO      
  , A.PART_ITEM, D.ITEM_NM, D.SPEC, D.BASIC_UNIT      
  , A.PART_ITEM_SEQ      
  , A.PART_TYPE, E.MINOR_NM AS PART_TYPE_NM      
  , A.PLANT_CD, F.PLANT_NM      
  , A.SL_CD, G.SL_NM      
  , A.SUPPLY_TYPE      
  , A.REPAIR_QTY      
  , A.REPAIR_PRICE      
  , A.REPAIR_UNIT      
  , A.REPAIR_AMOUNT      
  , B.SERIAL_NO      
  , B.PROJECT_CODE, C.PROJECT_NM      
      
  , B.TRACKING_NO      
 FROM      
  S_CS_USE_ITEM_KO883(NOLOCK) A      
  INNER JOIN S_CS_RECEIPT_KO883(NOLOCK) B ON A.RECEIPT_NO = B.RECEIPT_NO      
  left JOIN PMS_PROJECT(NOLOCK) C ON C.PROJECT_CODE = B.PROJECT_CODE      
  left JOIN B_ITEM(NOLOCK) D ON A.PART_ITEM = D.ITEM_CD      
  left JOIN B_MINOR(NOLOCK) E ON A.PART_TYPE = E.MINOR_CD AND E.MAJOR_CD = 'XCS03'      
  left JOIN B_PLANT(NOLOCK) F ON A.PLANT_CD = F.PLANT_CD      
  left JOIN B_STORAGE_LOCATION(NOLOCK) G ON A.SL_CD = G.SL_CD      
 WHERE      
  A.RECEIPT_NO = @RECEIPT_NO      