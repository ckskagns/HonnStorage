            
--DROP PROCEDURE    dbo.[USP_SD_S3119M2_KO883_SIN]            
--Go            
/************************************************************************************/            
/*****    PROC NAME   :  [USP_SD_S3119M1_KO883_SIN]         *****/            
/*****    ���α׷�    :  S3119M1_KO883_SIN(CS�������(S))          *****/            
/*****   Developer   :  IJM            *****/            
/*****    ���߳�¥    :  2018-06-18            *****/            
/*****    �ֽż�����¥:  2018-06-18            *****/            
/*****    ��    ��    :               *****/            
/************************************************************************************/            
            
ALTER PROC [dbo].[USP_SD_S3119M2_KO883_SIN](            
            
   @RECEIPT_NO    NVARCHAR(30)            
)                
AS            
            
IF(@RECEIPT_NO = '' OR @RECEIPT_NO IS NULL) BEGIN SET @RECEIPT_NO = '%' END            
            
    Set Nocount On            
             
    SELECT            
   A.RECEIPT_NO            
  , A.CS_STATUS            
  , A.CS_TYPE            
  , A.SERIAL_NO            
  , A.SERIAL_SUB
  , A.PROJECT_CODE            
  , A.ITEM_CD        , I.ITEM_NM    
  , A.TRACKING_NO            
  , A.LOCATION            
  , A.FREE_YN            
  , A.BP_CD, E.BP_NM            
  , A.RECEIPT_PRN, F.NAME AS RECEIPT_PRN_NM            
  , A.RECEIPT_DT            
  , A.REPAIR_FR_DT            
  , A.REPAIR_TO_DT            
  , A.COMP_FR_TIME            
  , A.COMP_TO_TIME            
  , A.REPAIR_TYPE_1, G.MINOR_NM AS REPAIR_TYPE_1_NM            
  , A.REPAIR_TYPE_2, H.MINOR_NM AS REPAIR_TYPE_2_NM            
  , A.RECEIP_DESC   
  , A.RECEIP_DESC_1    
  , A.RECEIP_DESC_2    
  , A.RECEIP_DESC_3    
  , A.RECEIP_DESC_4    
  , A.RECEIP_DESC_5             
  , A.ETC_DESC            
  , A.REPAIR_DESC         
  , (SELECT TOP 1 Y.PART_ITEM                     --Model                  
  FROM S_CS_RECEIPT_KO883(NOLOCK) X                                      
  INNER JOIN S_CS_USE_ITEM_KO883 Y ON X.RECEIPT_NO = Y.RECEIPT_NO                             
  WHERE Y.PART_TYPE = '01' AND  X.SERIAL_NO = A.SERIAL_NO AND  Y.RECEIPT_NO = A.RECEIPT_NO                            
  ORDER BY Y.INSRT_DT DESC) AS MODEL        
  , (SELECT TOP 1 Z.ITEM_NM                     --Model                  
  FROM S_CS_RECEIPT_KO883(NOLOCK) X                                      
  INNER JOIN S_CS_USE_ITEM_KO883 Y ON X.RECEIPT_NO = Y.RECEIPT_NO    
  LEFT JOIN B_ITEM Z(NOLOCK) ON Y.PART_ITEM = Z.ITEM_CD                             
  WHERE Y.PART_TYPE = '01' AND  X.SERIAL_NO = A.SERIAL_NO AND  Y.RECEIPT_NO = A.RECEIPT_NO                            
  ORDER BY Y.INSRT_DT DESC) AS MODEL_NM                 
  , a.RECEIPT_NM --20190515 �߰�    
   , ISNULL((SELECT APPROVAL_RTN FROM ERP_IF_APPROVAL WHERE DOC_NO = RECEIPT_NO),'F') as APPROVAL_RTNCD ,     --20190521 ��������߰�    
   --dbo.ufn_GetCodeName('SM003', (SELECT APPROVAL_RTN FROM ERP_IF_APPROVAL WHERE DOC_NO = RECEIPT_NO))     as APPROVAL_RTN      
   dbo.ufn_GetCodeName('SM003', isnull((SELECT APPROVAL_RTN FROM ERP_IF_APPROVAL WHERE DOC_NO = RECEIPT_NO),'F')  )    as APPROVAL_RTN     
   , A.APP_REQ_EMP_NO                  --20190521 �����û���߰�    
   , APP_REQ_NAME = (select name from haa010t where haa010t.emp_no = A.APP_REQ_EMP_NO)    
 FROM            
  S_CS_RECEIPT_KO883(NOLOCK) A            
  LEFT JOIN B_ITEM I(NOLOCK) ON A.ITEM_CD = I.ITEM_CD    
  --INNER JOIN B_MINOR B(NOLOCK) ON A.CS_STATUS = B.MINOR_CD AND B.MAJOR_CD = 'XCS01' --�������            
  LEFT JOIN B_MINOR C(NOLOCK) ON A.CS_TYPE = C.MINOR_CD AND C.MAJOR_CD = 'XCS02' --��������            
  --INNER JOIN B_CONFIGURATION D(NOLOCK) ON A.CS_TYPE = C.MINOR_CD AND C.MAJOR_CD = 'XCS02' --��������            
  LEFT JOIN B_BIZ_PARTNER E(NOLOCK) ON A.BP_CD = E.BP_CD --������            
  LEFT JOIN HAA010T F(NOLOCK) ON A.RECEIPT_PRN = F.EMP_NO --������            
  LEFT JOIN B_MINOR G(NOLOCK) ON A.REPAIR_TYPE_1 = G.MINOR_CD AND G.MAJOR_CD = 'XCS04'            
  LEFT JOIN B_MINOR H(NOLOCK) ON A.REPAIR_TYPE_2 = H.MINOR_CD AND H.MAJOR_CD = 'XCS05'            
            
 WHERE            
  A.RECEIPT_NO = @RECEIPT_NO 