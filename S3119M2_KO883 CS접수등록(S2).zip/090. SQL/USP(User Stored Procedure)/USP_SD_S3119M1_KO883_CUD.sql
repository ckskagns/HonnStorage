              
/*                
--�������ν����� ���̴� �ӽ� ���̺� , ó�� �� ���ν����� ������ ���̺��� ������ �켱 ���� �� �Ŀ� �����ؾ��մϴ�.              
              
DROP PROCEDURE    dbo.USP_SD_S3119M1_KO883_CUD              
Go              
DROP TYPE dbo.SD_S3119M1_KO883_SING              
Go              
DROP TYPE dbo.SD_S3119M1_KO883_MUL              
Go              
--SELECT * FROM ���������̺�              
CREATE TYPE DBO.SD_S3119M1_KO883_SING AS TABLE              
(              
 RECEIPT_NO  NVARCHAR(30)              
 ,CS_STATUS  NVARCHAR(20)              
 ,CS_TYPE   NVARCHAR(20)              
 ,SERIAL_NO  NVARCHAR(50)              
 ,PROJECT_CODE NVARCHAR(25)              
 ,ITEM_CD   NVARCHAR(50)              
 ,ITEM_NM   NVARCHAR(100)              
 ,TRACKING_NO  NVARCHAR(50)              
 ,LOCATION  NVARCHAR(50)              
 ,FREE_YN   NVARCHAR(25)              
 ,BP_CD   NVARCHAR(10)              
 ,BP_NM   NVARCHAR(50)              
 ,RECEIPT_PRN  NVARCHAR(20)              
 ,RECEIPT_PRN_NM NVARCHAR(30)              
 ,RECEIPT_DT  DATETIME              
 ,REPAIR_FR_DT DATETIME              
 ,REPAIR_TO_DT DATETIME              
 ,COMP_FR_TIME DATETIME              
 ,COMP_TO_TIME DATETIME              
 ,REPAIR_TYPE_1  NVARCHAR(20)              
 ,REPAIR_TYPE_1_NM NVARCHAR(200)              
 ,REPAIR_TYPE_2  NVARCHAR(20)              
 ,REPAIR_TYPE_2_NM NVARCHAR(200)              
 ,RECEIP_DESC  NVARCHAR(1024)              
 ,ETC_DESC  NVARCHAR(1024)              
 ,REPAIR_DESC  NVARCHAR(1024)              
 ,CUD_CHAR  NCHAR(01)              
 ,ROW_NUM   INT    
 ,model  NVARCHAR(50)  
 ,model_nm NVARCHAR(100)             
)              
GO              
CREATE TYPE dbo.SD_S3119M1_KO883_MUL AS TABLE              
(              
 SERIAL_NO   NVARCHAR(30)              
 ,PROJECT_CODE  NVARCHAR(25)              
 ,PROJECT_NM   NVARCHAR(205)              
 ,TRACKING_NO   NVARCHAR(50)              
 ,PART_ITEM_SEQ  NUMERIC(5,2)              
 ,PART_ITEM   NVARCHAR(50)              
 ,ITEM_NM    NVARCHAR(100)              
 ,SPEC    NVARCHAR(100)              
 ,BASIC_UNIT   NVARCHAR(3)              
 ,PART_TYPE   NVARCHAR(20)              
 ,PART_TYPE_NM  NVARCHAR(200)              
 ,SUPPLY_TYPE   NCHAR(02)              
 ,REPAIR_QTY   NUMERIC(18,6)              
 ,REPAIR_PRICE  NUMERIC(18,6)              
 ,REPAIR_AMOUNT  NUMERIC(18,2)              
 ,PLANT_CD   NVARCHAR(4)              
 ,PLANT_NM   NVARCHAR(40)              
 ,SL_CD    NVARCHAR(10)              
 ,SL_NM    NVARCHAR(40)              
 ,CUD_CHAR   NCHAR(01)              
 ,ROW_NUM    INT              
 ,RECEIPT_NO  NVARCHAR(30)              
)              
GO              
*/              
              
/************************************************************************************/              
/*****    PROC NAME   :  [USP_SD_S3119M1_KO883_CUD]        *****/              
/*****    ���α׷�    :  S3119M1_KO883(���α׷���)          *****/              
/*****   Developer   :  �������̸�            *****/              
/*****    ���߳�¥    :  2016-04-01            *****/              
/*****    �ֽż�����¥:  2016-04-01            *****/              
/*****    ��    ��    :               *****/              
/************************************************************************************/              
              
CREATE PROCEDURE [dbo].[USP_SD_S3119M1_KO883_CUD]              
(              
  @TBL_GRID1    SD_S3119M1_KO883_SING    ReadOnly              
 , @TBL_GRID2    SD_S3119M1_KO883_MUL    ReadOnly              
 ,   @PARAM_USER_ID           NVARCHAR(13)              
 , @MSG_CD             NVARCHAR(06)  OUTPUT              
 , @MESSAGE            NVARCHAR(200)  OUTPUT              
)              
AS              
              
BEGIN               
 SET NOCOUNT ON               
              
 BEGIN TRY                 
 BEGIN TRANSACTION              
              
              
 --declare @row_count int              
              
 --select @row_count = count(SERIAL_NO) from @TBL_GRID2              
              
              
------------------------------------------------------------------------------------------              
 DELETE A              
 FROM S_CS_RECEIPT_KO883 A INNER JOIN @TBL_GRID1 B ON A.RECEIPT_NO = B.RECEIPT_NO              
 WHERE B.CUD_CHAR = 'D'              
------------------------------------------------------------------------------------------              
               
 --if(@row_count > 0)              
              
 DELETE A              
 FROM S_CS_USE_ITEM_KO883 A INNER JOIN @TBL_GRID2 B ON A.RECEIPT_NO = B.RECEIPT_NO AND A.PART_ITEM = B.PART_ITEM AND A.PART_ITEM_SEQ = B.PART_ITEM_SEQ              
 WHERE B.CUD_CHAR = 'D'              
------------------------------------------------------------------------------------------               
 INSERT INTO S_CS_RECEIPT_KO883              
 (               
   RECEIPT_NO, CS_STATUS, CS_TYPE, SERIAL_NO              
  , PROJECT_CODE, ITEM_CD, TRACKING_NO, LOCATION              
  , FREE_YN, BP_CD, RECEIPT_PRN, RECEIPT_DT              
  , REPAIR_FR_DT, REPAIR_TO_DT, COMP_FR_TIME, COMP_TO_TIME              
  , REPAIR_TYPE_1, REPAIR_TYPE_2, RECEIP_DESC, ETC_DESC              
  , REPAIR_DESC, INSRT_USER_ID, INSRT_DT              
  , UPDT_USER_ID, UPDT_DT              
 )              
 SELECT              
   RECEIPT_NO, CS_STATUS, CS_TYPE, SERIAL_NO              
  , PROJECT_CODE, ITEM_CD, TRACKING_NO, LOCATION              
  , FREE_YN, BP_CD, RECEIPT_PRN, RECEIPT_DT              
  , REPAIR_FR_DT, REPAIR_TO_DT, COMP_FR_TIME, COMP_TO_TIME              
  , REPAIR_TYPE_1, REPAIR_TYPE_2, RECEIP_DESC, ETC_DESC              
  , REPAIR_DESC, @PARAM_USER_ID, GETDATE()              
  , @PARAM_USER_ID,  GETDATE()              
 FROM @TBL_GRID1              
 WHERE CUD_CHAR = 'C'              
------------------------------------------------------------------------------------------               
 --if(@row_count > 0)              
 INSERT INTO S_CS_USE_ITEM_KO883              
 (               
   RECEIPT_NO, PART_ITEM, PART_ITEM_SEQ, PART_TYPE              
  , PLANT_CD, SL_CD, SUPPLY_TYPE, REPAIR_QTY              
  , REPAIR_PRICE, REPAIR_AMOUNT, INSRT_USER_ID, INSRT_DT              
  , UPDT_USER_ID, UPDT_DT              
 )              
 SELECT              
   B.RECEIPT_NO, B.PART_ITEM               
  -- ,(SELECT TOP 1 ISNULL(MAX(A.PART_ITEM_SEQ),0)+1 FROM S_CS_USE_ITEM_KO883 A WHERE A.RECEIPT_NO = B.RECEIPT_NO AND A.PART_ITEM = B.PART_ITEM)              
  , b.part_item_seq      
  , B.PART_TYPE              
  , B.PLANT_CD, B.SL_CD, B.SUPPLY_TYPE, B.REPAIR_QTY              
  , B.REPAIR_PRICE, B.REPAIR_AMOUNT, @PARAM_USER_ID, GETDATE()              
  , @PARAM_USER_ID,  GETDATE()              
 FROM @TBL_GRID2   B           
 WHERE B.CUD_CHAR = 'C'              
------------------------------------------------------------------------------------------              
               
 UPDATE A              
 SET                
    A.CS_STATUS  = B.CS_STATUS                
   , A.CS_TYPE  = B.CS_TYPE                
   , A.SERIAL_NO  = B.SERIAL_NO                
   , A.PROJECT_CODE = B.PROJECT_CODE               
   , A.ITEM_CD  = B.ITEM_CD                
   , A.TRACKING_NO = B.TRACKING_NO               
   , A.LOCATION  = B.LOCATION                
   , A.FREE_YN  = B.FREE_YN                
   , A.BP_CD   = B.BP_CD                 
   , A.RECEIPT_PRN = B.RECEIPT_PRN               
   , A.RECEIPT_DT = B.RECEIPT_DT               
   , A.REPAIR_FR_DT = B.REPAIR_FR_DT               
   , A.REPAIR_TO_DT = B.REPAIR_TO_DT               
   , A.COMP_FR_TIME = B.COMP_FR_TIME               
   , A.COMP_TO_TIME = B.COMP_TO_TIME               
   , A.REPAIR_TYPE_1 = B.REPAIR_TYPE_1               
   , A.REPAIR_TYPE_2 = B.REPAIR_TYPE_2               
   , A.RECEIP_DESC = B.RECEIP_DESC               
   , A.ETC_DESC  = B.ETC_DESC                
   , A.REPAIR_DESC = B.REPAIR_DESC               
   , A.UPDT_USER_ID  = @PARAM_USER_ID                
   , A.UPDT_DT   = GETDATE()              
 FROM S_CS_RECEIPT_KO883 A INNER JOIN @TBL_GRID1 B ON A.RECEIPT_NO = B.RECEIPT_NO              
 WHERE B.CUD_CHAR = 'U'              
              
------------------------------------------------------------------------------------------                
 --if(@row_count > 0)              
 UPDATE A              
 SET                
   A.PART_TYPE   = B.PART_TYPE              
  , A.PLANT_CD   = B.PLANT_CD              
  , A.SL_CD    = B.SL_CD              
  , A.SUPPLY_TYPE  = B.SUPPLY_TYPE              
  , A.REPAIR_QTY  = B.REPAIR_QTY              
  , A.REPAIR_PRICE  = B.REPAIR_PRICE              
  , A.REPAIR_AMOUNT  = B.REPAIR_AMOUNT              
  , A.UPDT_USER_ID  = @PARAM_USER_ID                
  , A.UPDT_DT   = GETDATE()              
 FROM S_CS_USE_ITEM_KO883 A INNER JOIN @TBL_GRID2 B ON A.RECEIPT_NO = B.RECEIPT_NO AND A.PART_ITEM = B.PART_ITEM AND A.PART_ITEM_SEQ = B.PART_ITEM_SEQ              
 WHERE B.CUD_CHAR = 'U'          
              
------------------------------------------------------------------------------------------                
               
               
 COMMIT TRANSACTION              
 RETURN 1              
 END TRY              
               
 BEGIN CATCH              
  SET @MSG_CD = 'DT9999'              
  SET @MESSAGE = ERROR_MESSAGE()              
  ROLLBACK TRANSACTION              
  RETURN -1              
 END CATCH              
END 