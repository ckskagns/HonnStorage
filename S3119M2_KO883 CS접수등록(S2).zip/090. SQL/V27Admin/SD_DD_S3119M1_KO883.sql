﻿
SET NOCOUNT ON;
---------------------------------------------------------------------------------------------------------------------------
--	FILE NAME	: SD_INS_Z_POPUP_MASTER_INFO_20180619_user.sql
--	MODULE		: SD
--	DATE		: 2018-06-19
--	Modifier	: user
---------------------------------------------------------------------------------------------------------------------------

DELETE
FROM
	Z_POPUP_MASTER_INFO
WHERE
	PARENTPID LIKE '%S3119M1_KO883%'
---------------------------------------------------------------------------------------------------------------------------

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'popBpCd'	,N''	,''	,''
	,'Y'	,'N'	,N'GE'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'popReceiptNo'	,N''	,''	,''
	,'Y'	,'N'	,N'GE'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'popReceiptPrn'	,N''	,''	,''
	,'Y'	,'N'	,N'GE'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'popRepairType'	,N''	,''	,''
	,'Y'	,'N'	,N'GE'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'popRepairType2'	,N''	,''	,''
	,'Y'	,'N'	,N'GE'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'popSerialNo'	,N''	,''	,''
	,'Y'	,'N'	,N'GE'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'uniGrid1'	,N'part_item'	,''	,'s3112pa101_ko883'
	,'Y'	,'N'	,N'  '	,N'Y'	,''
	,''	,'N'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'uniGrid1'	,N'part_type'	,''	,''
	,'Y'	,'N'	,N'GE'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'uniGrid1'	,N'plant_cd'	,''	,''
	,'Y'	,'N'	,N'GE'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)

INSERT INTO Z_POPUP_MASTER_INFO
(
	ParentPId	,ParentCId	,CodeField	,NameField	,StatementId
	,AutoShowPopup	,AsyncTransfer	,Operator	,AutoQuery	,RedirectPopupID
	,ParentColumnID	,IsCommonPopup	,TopValue	,DefaultFocus	,Width
	,Height	,AutoCommonPopupID	,IgnoreSQLWhere	,PopupPassWhere
)
VALUES
(
	N'uniERP.App.UI.SD.S3119M1_KO883'	,N'uniGrid1'	,N'plant_nm'	,''	,''
	,'Y'	,'N'	,N'GE'	,N'Y'	,''
	,''	,'Y'	,100	,N'C'	,0
	,0	,N''	,N'0'	,N''
)