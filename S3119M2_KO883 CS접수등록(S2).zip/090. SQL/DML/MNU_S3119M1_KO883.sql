
/************************************************************************************/
/*****    PROGRAM ID    :  S3119M1_KO883(CS�������(S))								*****/
/*****	  Developer	  :  IJM										*****/
/*****    ���߳�¥    :  2018-06-18											*****/
/************************************************************************************/


DECLARE             @MNU_ID          NVARCHAR(15)
                 ,  @MNU_TYPE        NCHAR(01)
                 ,  @CALLED_FRM_ID   NVARCHAR(15)
                 ,  @USE_YN          NCHAR(01)
                 ,  @UPPER_MNU_ID    NVARCHAR(15)
                 ,  @UPPER_MNU_TYPE  NCHAR(01)
                 ,  @INSRT_USER_ID   NVARCHAR(13)
                 ,  @INSRT_DT        DATETIME
                 ,  @UPDT_USER_ID    NVARCHAR(13)
                 ,  @UPDT_DT         DATETIME
                 ,  @ModuleInitial   NVARCHAR(10)
                 ,  @SYS_LVL         NCHAR(01)
                 ,  @MNU_SEQ         NVARCHAR(10)
DECLARE             @TBL_LANG        TABLE   (LANG_CD NVARCHAR(03), MNU_NM NVARCHAR(100))

SET         @MNU_ID            = N'S3119M1_KO883'
SET         @CALLED_FRM_ID     = N'S3119M1_KO883'
SET         @ModuleInitial     = N'SD'
SET         @UPPER_MNU_ID      = N'S3'
SET         @MNU_SEQ           = N'62'
SET         @SYS_LVL           = N'3'

INSERT  INTO       @TBL_LANG        VALUES                 (                N'KO'      ,                N'CS�������(S)'                  )
INSERT  INTO       @TBL_LANG        VALUES                 (                N'VN'      ,                N'CS�������(S)'                  )
INSERT  INTO       @TBL_LANG        VALUES                 (                N'CN'      ,                N'CS�������(S)'                  )
INSERT  INTO       @TBL_LANG        VALUES                 (                N'EN'      ,                N'CS�������(S)'					)

SET         @MNU_TYPE              =              N'P'
SET         @USE_YN                =              N'1'
SET         @UPPER_MNU_TYPE        =              N'M'
SET         @INSRT_USER_ID         =              N'unierp'
SET         @INSRT_DT              =              GETDATE()
SET         @UPDT_USER_ID          =              N'unierp'
SET         @UPDT_DT               =              GETDATE()
				 

				 IF NOT EXISTS (SELECT * 
               FROM   z_co_mast_mnu 
               WHERE  mnu_id = @MNU_ID 
                      AND mnu_type = @MNU_TYPE) 
  INSERT INTO z_co_mast_mnu 
              (mnu_id, 
               mnu_type, 
               called_frm_id, 
               use_yn, 
               upper_mnu_id, 
               upper_mnu_type, 
               insrt_user_id, 
               insrt_dt, 
               updt_user_id, 
               updt_dt, 
               moduleinitial) 
  VALUES      ( @MNU_ID, 
                @MNU_TYPE, 
                @CALLED_FRM_ID, 
                @USE_YN, 
                @UPPER_MNU_ID, 
                @UPPER_MNU_TYPE, 
                @INSRT_USER_ID, 
                @INSRT_DT, 
                @UPDT_USER_ID, 
                @UPDT_DT, 
                @ModuleInitial ) 

IF NOT EXISTS (SELECT * 
               FROM   z_co_mnu 
               WHERE  upper_mnu_id = @UPPER_MNU_ID 
                      AND upper_mnu_type = @UPPER_MNU_TYPE 
                      AND mnu_id = @MNU_ID 
                      AND mnu_type = @MNU_TYPE) 
  INSERT INTO z_co_mnu 
              (upper_mnu_id, 
               upper_mnu_type, 
               mnu_id, 
               mnu_type, 
               sys_lvl, 
               mnu_seq, 
               use_yn, 
               insrt_user_id, 
               insrt_dt, 
               updt_user_id, 
               updt_dt) 
  VALUES      ( @UPPER_MNU_ID, 
                @UPPER_MNU_TYPE, 
                @MNU_ID, 
                @MNU_TYPE, 
                @SYS_LVL, 
                @MNU_SEQ, 
                @USE_YN, 
                @INSRT_USER_ID, 
                @INSRT_DT, 
                @UPDT_USER_ID, 
                @UPDT_DT ) 

INSERT INTO z_lang_co_mast_mnu 
            (lang_cd, 
             mnu_id, 
             mnu_type, 
             mnu_nm, 
             insrt_user_id, 
             insrt_dt, 
             updt_user_id, 
             updt_dt) 
SELECT lang_cd, 
       @MNU_ID, 
       @MNU_TYPE, 
       mnu_nm, 
       @INSRT_USER_ID, 
       @INSRT_DT, 
       @UPDT_USER_ID, 
       @UPDT_DT 
FROM   @TBL_LANG A 
WHERE  NOT EXISTS (SELECT * 
                   FROM   z_lang_co_mast_mnu R 
                   WHERE  R. lang_cd = A.lang_cd 
                          AND R .mnu_id = @MNU_ID 
                          AND R .mnu_type = @MNU_TYPE) 
       AND A .lang_cd != N'EN' 

IF EXISTS (SELECT mnu_nm 
           FROM   @TBL_LANG 
           WHERE  lang_cd = N'EN') 
  UPDATE z_lang_co_mast_mnu 
  SET    mnu_nm = Isnull((SELECT mnu_nm 
                          FROM   @TBL_LANG 
                          WHERE  lang_cd = N'EN'), mnu_nm) 
  WHERE  lang_cd = N'EN' 
         AND mnu_id = @MNU_ID 

IF NOT EXISTS (SELECT * 
               FROM   z_usr_role_mnu_authztn_asso 
               WHERE  usr_role_id = 'BIZAUTH' 
                      AND mnu_id = @MNU_ID 
                      AND mnu_type = @MNU_TYPE 
                      AND action_id = 'A') 
  INSERT INTO z_usr_role_mnu_authztn_asso 
              (usr_role_id, 
               mnu_id, 
               mnu_type, 
               action_id, 
               insrt_user_id, 
               insrt_dt, 
               updt_user_id, 
               updt_dt) 
  VALUES      ( N'BIZAUTH', 
                @MNU_ID, 
                @MNU_TYPE, 
                N'A', 
                N'uniERP', 
                Getdate(), 
                N'uniERP', 
                Getdate() ) 

IF NOT EXISTS (SELECT * 
               FROM   z_co_mast_mnu_service_kind 
               WHERE  service_kind = 'SC' 
                      AND mnu_id = @MNU_ID 
                      AND mnu_type = @MNU_TYPE) 
  INSERT INTO z_co_mast_mnu_service_kind 
              (mnu_id, 
               mnu_type, 
               service_kind, 
               insrt_user_id, 
               insrt_dt, 
               updt_user_id, 
               updt_dt) 
  SELECT @MNU_ID, 
         @MNU_TYPE, 
         'SC', 
         @INSRT_USER_ID, 
         @INSRT_DT, 
         @UPDT_USER_ID, 
         @UPDT_DT   

