﻿
--DROP PROCEDURE    dbo.[USP_HR_H4006M3_KO883_H]
--Go
/************************************************************************************/
/*****    PROC NAME   :  [USP_HR_H4006M3_KO883_H]									*****/
/*****    프로그램    :  H4006M3_KO883_H(근태신청등록(S))										*****/
/*****	  Developer	  :  MSK												*****/
/*****    개발날짜    :  2018-07-19												*****/
/*****    최신수정날짜:  2018-07-19												*****/
/*****    내    용    :															*****/
/************************************************************************************/

CREATE PROC [dbo].[USP_HR_H4006M3_KO883_H](

			@DILIG_REQ_NO				NVARCHAR(20)	
)    
AS


    Set	Nocount	On
	
    SELECT
		A.REMARK,
		A.DILIG_TYPE,
		A.REPORT_TYPE,
		A.ISRT_DT,
		A.REF_NO,
		ISNULL(B.APPROVAL_RTN,'F') AS APPROVAL_RTN

	FROM
		H4006M3_H_KO883 A(NOLOCK)
		LEFT JOIN ERP_IF_APPROVAL B (NOLOCK) ON A.DILIG_REQ_NO = B.DOC_NO

	WHERE
		A.DILIG_REQ_NO = @DILIG_REQ_NO


GO
