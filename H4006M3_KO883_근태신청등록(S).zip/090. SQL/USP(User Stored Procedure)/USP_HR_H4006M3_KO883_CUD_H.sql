﻿          
/*            
--저장프로시저에 쓰이는 임시 테이블 , 처음 이 프로시저를 생성시 테이블을 생성을 우선 먼저 한 후에 진행해야합니다.          
          
DROP PROCEDURE    dbo.USP_HR_H4006M3_KO883_CUD_H        
Go          
    
    
    
    
CREATE TYPE dbo.HR_H4006M3_KO883 AS TABLE          
(          
   dilig_emp_no   nvarchar(13)      
 , name   nvarchar(50)       
 , dilig_cd    nvarchar(13)          
 , dilig_dt_fr   datetime          
 , dilig_fr    nvarchar(4)          
 , dilig_dt_to   datetime          
 , dilig_to    nvarchar(4)          
 , dilig_time   nvarchar(4)          
 , cont     nvarchar(50)          
 , CUD_CHAR    nvarchar(01)          
 , ROW_NUM    int           
)          
GO     
*/          
          
/************************************************************************************/          
/*****    PROC NAME   :  [USP_HR_H4006M3_KO883_CUD_H]       *****/          
/*****    프로그램    :  H4006M3_KO883(근태신청등록(S))       *****/          
/*****   Developer   :  MSK                *****/          
/*****    개발날짜    :  2018-07-19            *****/          
/*****    최신수정날짜:  2018-07-19            *****/          
/*****    내    용    :               *****/          
/************************************************************************************/          
          
CREATE PROCEDURE [dbo].[USP_HR_H4006M3_KO883_CUD_H]          
(          
  @TBL_GRID    HR_H4006M3_KO883    ReadOnly              
 , @CUD_CHAR               NVARCHAR(1)          
 , @DILIG_REQ_NO              NVARCHAR(20)          
 , @REMARK                NVARCHAR(40)          
 , @REF_NO                NVARCHAR(20)  
 , @REQ_EMP_NO            NVARCHAR(20)
 , @DILIG_TYPE               NVARCHAR(1)          
 , @REPORT_TYPE              NVARCHAR(1)          
 ,   @PARAM_USER_ID           NVARCHAR(13)          
 , @MSG_CD             NVARCHAR(06)  OUTPUT          
 , @MESSAGE            NVARCHAR(200)  OUTPUT          
)          
AS          
          
BEGIN           
 SET NOCOUNT ON           
          
 BEGIN TRY             
 BEGIN TRANSACTION          
------------------------------------------------------------------------------------------          
 DELETE A          
 FROM H4006M3_H_KO883 A           
 WHERE @CUD_CHAR = 'D' AND A.DILIG_REQ_NO = @DILIG_REQ_NO          
  DELETE B          
 FROM H4006M3_D_KO883 B           
 WHERE @CUD_CHAR = 'D' AND B.DILIG_REQ_NO = @DILIG_REQ_NO       
  DELETE A          
 FROM H4006M3_D_KO883 A INNER JOIN @TBL_GRID B ON DILIG_REQ_NO = @DILIG_REQ_NO AND A.DILIG_EMP_NO = B.DILIG_EMP_NO          
              AND A.DILIG_CD = B.DILIG_CD  AND A.DILIG_DT_FR = B.DILIG_DT_FR          
 WHERE B.CUD_CHAR = 'D'          
       
------------------------------------------------------------------------------------------           
 IF(@CUD_CHAR = 'C')          
 BEGIN           
 INSERT INTO H4006M3_H_KO883          
 ( DILIG_REQ_NO,   DILIG_TYPE,     REPORT_TYPE,    REMARK,   REF_NO,     REQ_EMP_NO,  
  ISRT_DT,  ISRT_EMP_NO, UPDT_DT,   UPDT_EMP_NO     )          
 VALUES          
 ( @DILIG_REQ_NO,  @DILIG_TYPE,    @REPORT_TYPE,   @REMARK,  @REF_NO,    @REQ_EMP_NO,   
  GETDATE(), @PARAM_USER_ID,    GETDATE(),    @PARAM_USER_ID  )          
    END          
    
 INSERT INTO H4006M3_D_KO883          
 ( DILIG_REQ_NO,  DILIG_EMP_NO,  DILIG_CD,            DILIG_DT_FR,       DILIG_HH_FR,            DILIG_MM_FR,             
  DILIG_DT_TO,    DILIG_HH_TO,                        DILIG_MM_TO,       DILIG_HH,             
  DILIG_MM,       CONT,              
  REF_NO,      ISRT_EMP_NO,     ISRT_DT ,            UPDT_EMP_NO,       UPDT_DT               )          
 SELECT                                                 
  @DILIG_REQ_NO,  DILIG_EMP_NO,  DILIG_CD,            DILIG_DT_FR,       convert(numeric,(LEFT(isnull(DILIG_FR,0),2)+'.00')),  convert(numeric,(RIGHT(isnull(DILIG_FR,0),2)+'.00')),             
  DILIG_DT_TO,    convert(numeric,(LEFT(isnull(DILIG_TO,0),2)+'.00')),   convert(numeric,(RIGHT(isnull(DILIG_TO,0),2)+'.00')),    convert(numeric,(LEFT(isnull(DILIG_TIME,0),2)+'.00')),         
  convert(numeric,(RIGHT(isnull(DILIG_TIME,0),2)+'.00')),      CONT,              
  @REF_NO,    @PARAM_USER_ID,  GETDATE(), @PARAM_USER_ID,    GETDATE()          
 FROM @TBL_GRID          
 WHERE CUD_CHAR = 'C'          
------------------------------------------------------------------------------------------          
           
 UPDATE H4006M3_H_KO883          
 SET            
   DILIG_TYPE  = @DILIG_TYPE          
  , REPORT_TYPE  = @REPORT_TYPE          
  , REMARK   = @REMARK           
  , REF_NO   = @REF_NO    
  , REQ_EMP_NO = @REQ_EMP_NO      
  , UPDT_EMP_NO  = @PARAM_USER_ID          
  , UPDT_DT   = GETDATE()          
 WHERE @CUD_CHAR = 'U'    AND  DILIG_REQ_NO=@DILIG_REQ_NO      
    
 UPDATE A          
 SET            
   A.DILIG_REQ_NO   = @DILIG_REQ_NO          
  , A.DILIG_EMP_NO  = B.DILIG_EMP_NO          
  , A.DILIG_CD      = B.DILIG_CD          
  , A.DILIG_DT_FR   = B.DILIG_DT_FR          
  , A.DILIG_HH_FR   = convert(numeric,(LEFT(isnull(DILIG_FR,0),2)+'.00'))          
  , A.DILIG_MM_FR   = convert(numeric,(RIGHT(isnull(DILIG_FR,0),2)+'.00'))          
  , A.DILIG_DT_TO   = B.DILIG_DT_TO          
  , A.DILIG_HH_TO   = convert(numeric,(LEFT(isnull(DILIG_TO,0),2)+'.00'))         
  , A.DILIG_MM_TO   = convert(numeric,(RIGHT(isnull(DILIG_TO,0),2)+'.00'))          
  , A.DILIG_HH      = convert(numeric,(LEFT(isnull(DILIG_TIME,0),2)+'.00'))         
  ,   A.DILIG_MM    = convert(numeric,(RIGHT(isnull(DILIG_TIME,0),2)+'.00'))         
  ,   A.CONT     = B.CONT          
  , A.UPDT_EMP_NO      = @PARAM_USER_ID            
  , A.UPDT_DT       = GETDATE()          
 FROM H4006M3_D_KO883 A INNER JOIN @TBL_GRID B ON A.DILIG_REQ_NO = @DILIG_REQ_NO AND A.DILIG_EMP_NO = B.DILIG_EMP_NO          
        AND A.DILIG_CD = B.DILIG_CD    AND A.DILIG_DT_FR = B.DILIG_DT_FR          
          
 WHERE B.CUD_CHAR = 'U'          
          
------------------------------------------------------------------------------------------            
           
 COMMIT TRANSACTION          
 RETURN 1          
 END TRY          
           
 BEGIN CATCH          
  SET @MSG_CD = 'DT9999'          
  SET @MESSAGE = ERROR_MESSAGE()          
  ROLLBACK TRANSACTION          
  RETURN -1          
 END CATCH          
END 