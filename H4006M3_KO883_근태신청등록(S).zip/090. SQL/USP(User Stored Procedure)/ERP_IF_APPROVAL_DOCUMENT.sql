﻿DELETE ERP_IF_APPROVAL_DOCUMENT_MAPPING WHERE AP_ITEM = 'H1'

INSERT INTO ERP_IF_APPROVAL_DOCUMENT_MAPPING 
VALUES('HR','H4006M3_KO883','H1','H4006M3_KO883','N', '','','unierp',GETDATE(), 'unierp',GETDATE())

DELETE ERP_IF_APPROVAL_DOCUMENT WHERE DOC_ID='H4006M3_KO883' and AP_ITEM = 'H1'

INSERT INTO ERP_IF_APPROVAL_DOCUMENT
values('H4006M3_KO883', '', 'H1',
 '
 <html>
<head>
<title> ##DILIG_TPYE_NM## ##REPORT_TYPE_NM##서 </title>
<style type=''text/css''>
      th, td {font-size:8pt; font-family:Arial Unicode MS; padding:0px; }  table {padding:0; border-spacing:0px; border:0; border-collapse:collapse;}        .td_0002 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:0px;     border-top-width:0px;     border-right-width:0px;     border-bottom-width:1px;     vertical-align:middle;  }     .td_0040 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:0px;     border-top-width:1px;     border-right-width:0px;     border-bottom-width:1px;     vertical-align:middle;  }       .td_0022 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:0px;     border-top-width:0px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }       .td_1001 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:1px;     border-top-width:0px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_1002 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:1px;     border-top-width:0px;     border-right-width:0px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_1012 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:1px;     border-top-width:0px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_1201 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:1px;     border-top-width:1px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_1202 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:1px;     border-top-width:1px;     border-right-width:0px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_1222 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:1px;     border-top-width:1px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_2022 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:1px;     border-top-width:0px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_2201 {     border-style: solid;     border-width: 1px;     border-color: black;       border-left-width:1px;     border-top-width:1px;     border-right-width:0px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_1221 {     border-style: solid;     border-width: 1px;     border-color: black;     border-left-width:1px;     border-top-width:1px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_2001{     border-style: solid;     border-width: 1px;     border-color: black;     border-left-width:1px;     border-top-width:0px;     border-right-width:0px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_1021 {     border-style: solid;     border-width: 1px;     border-color: black;     border-left-width:1px;     border-top-width:0px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_2002 {     border-style: solid;     border-width: 1px;     border-color: black;     border-left-width:1px;     border-top-width:0px;     border-right-width:0px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_1022 {     border-style: solid;     border-width: 1px;     border-color: black;     border-left-width:1px;     border-top-width:0px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_2221 {     border-style: solid;     border-width: 1px;     border-color: black;     border-left-width:1px;     border-top-width:1px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }  .td_2021 {     border-style: solid;     border-width: 1px;     border-color: black;     border-left-width:1px;     border-top-width:0px;     border-right-width:1px;     border-bottom-width:1px;     vertical-align:middle;  }
</style>
</head>
<meta http-equiv="CONTENT-TYPE" content="TEXT/HTML; CHARSET=UTF-8">
<body>
<h1 align=''center''><strong>##DILIG_TPYE_NM## ##REPORT_TYPE_NM##서</strong></h1>
<br/><br/><br/>
<table width=''950''>
<tr>
       <td>
             
              <tr height=''28''>
                     <td>
                           <table width=''950'' height=''100%''>
                           <tr height=''28''>
                                  <td class=''td_2201'' bgcolor=''dcdcdc'' width=''5%'' align=''center''>
                                          &nbsp;<strong>성명</strong>
                                  </td>
                                  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''10%'' align=''center''>
                                          &nbsp;<strong>부서</strong>
                                  </td>
                                  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''5%'' align=''center''>
                                          &nbsp;<strong>직위</strong>
                                  </td>
                                  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''10%'' align=''center''>
                                          &nbsp;<strong>근태</strong>
                                  </td>
                                  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''8%'' align=''center''>
                                          &nbsp;<strong>시작일</strong>
                                  </td>
                                  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''5%'' align=''center''>
                                          &nbsp;<strong>시간</strong>
                                  </td>
                                  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''8%'' align=''center''>
                                          &nbsp;<strong>종료일</strong>
                                  </td>
                                  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''5%'' align=''center''>
                                          &nbsp;<strong>시간</strong>
                                  </td>
								  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''8%'' align=''center''>
                                          &nbsp;<strong>신청시간</strong>
                                  </td>
								  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''8%'' align=''center''>
                                          &nbsp;<strong>결과시간</strong>
                                  </td>
								  <td class=''td_1201'' bgcolor=''dcdcdc'' width=''28%'' align=''center''>
                                          &nbsp;<strong>비고</strong>
                                  </td>
                           </tr>
                           ##CONTENT_DTL##
                           <tr height=''40''>
                           </tr>
                           </table>
                     </td>
              </tr>
              </table>
       </td>
</tr>
      <p align=''center''>
              <strong>위와  같이  신청하오니  결재하여  주시기  바랍니다.</strong>
       </p>
       </body>

       </html>
'
,'', '','unierp', getdate(),'unierp', getdate())