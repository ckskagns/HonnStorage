﻿CREATE procedure [dbo].[USP_IF_APPROVAL_H4006M3_KO883_3](                                 
     @doc_no NVARCHAR(32),                                
     @system_code NVARCHAR(10),                                     
     @ap_form NVARCHAR(32),                                
     @ap_item NVARCHAR(20),                                
     @ref_no NVARCHAR(32),                                
     @doc_user_id  NVARCHAR(20),                                 
     @user_id  NVARCHAR(20),                                 
     @MSG_CD  [nvarchar](8)  OUTPUT,                                
     @msg_text NVARCHAR(200) OUTPUT ) AS                                
                              
                                     
SET NOCOUNT ON                                
                                
BEGIN                                 
                                
                            
 ------------------------------------                                
 -- GET 양식                                
 ------------------------------------                                
                     
                              
 DECLARE @DOC_CONTENTS  NVARCHAR(MAX)                                  
 SELECT @DOC_CONTENTS = A.DOCUMENT                                
 FROM ERP_IF_APPROVAL_DOCUMENT A                                
 INNER JOIN ERP_IF_APPROVAL_DOCUMENT_MAPPING B ON A.DOC_ID = B.DOC_ID AND A.AP_ITEM = B.AP_ITEM                                
 WHERE B.MODULE_ID = LEFT(@SYSTEM_CODE,3)                                
 AND B.MNU_ID = @AP_FORM                                
 AND B.AP_ITEM = @AP_ITEM                         
                   
 DECLARE                       
    @DEPT_NM            nvarchar(50)                    
  , @ROLL_PSTN_NM       nvarchar(50)                    
  , @NAME    nvarchar(30)                    
  , @DILIG_NM   NVARCHAR(50)      
  , @DILIG_DT   NVARCHAR(40)      
  , @DAY    NVARCHAR(10)     
  , @DILIG_FR   NVARCHAR(12)      
  , @DILIG_TO   NVARCHAR(12)      
  , @CONT    NVARCHAR(50)      
  , @TODAY       NVARCHAR(20)    
  , @DILIG_EMP_NO NVARCHAR(13)  
  , @DILIG_DT_FR NVARCHAR(10)  
  , @DILIG_DT_TO NVARCHAR(10)  
  , @DILIG_CD NVARCHAR(2)
                  
 SELECT                   
   @DEPT_NM          = Z.DEPT_NM                  
 , @ROLL_PSTN_NM     = Z.ROLL_PSTN_NM                  
 , @NAME    = Z.NAME                  
 , @DILIG_NM   = Z.DILIG_NM         
 , @DILIG_DT   = Z.DILIG_DT      
-- , @DAY     = Z.DAY          
 , @CONT    = Z.CONT      
 , @TODAY    = Z.TODAY       
 , @DILIG_EMP_NO = Z.DILIG_EMP_NO         
 , @DILIG_FR = Z.DILIG_DT_FR  
 , @DILIG_TO= Z.DILIG_DT_TO   
 , @DILIG_CD = Z.DILIG_CD         
            
 FROM                  
  ( SELECT     
     DEPT.DEPT_NM,     
     DBO.UFN_GETCODENAME('H0002', H.ROLL_PSTN) AS ROLL_PSTN_NM,    
  A.DILIG_EMP_NO,  
     H.NAME,      
     B.DILIG_NM,    
    ( (CONVERT(NVARCHAR(4),DATEPART(YYYY, A.DILIG_DT_FR))+' 년 '+CONVERT(NVARCHAR(2),DATEPART(MM,A.DILIG_DT_FR))+' 월 '    
     +CONVERT(NVARCHAR(2),DATEPART(DD,A.DILIG_DT_FR))+' 일 ') +'   ~   '+    
     (CONVERT(NVARCHAR(4),DATEPART(YYYY,A.DILIG_DT_TO))+' 년 '+CONVERT(NVARCHAR(2),DATEPART(MM,A.DILIG_DT_TO))+' 월 '    
      +CONVERT(NVARCHAR(2),DATEPART(DD,A.DILIG_DT_TO))+' 일 ') ) AS  DILIG_DT,    
     A.CONT,    
    ( (CONVERT(NVARCHAR(4),DATEPART(YYYY, GETDATE()))+' 년 '+CONVERT(NVARCHAR(2),DATEPART(MM ,GETDATE()))+' 월 '    
     +CONVERT(NVARCHAR(2),DATEPART(DD, GETDATE()))) )+' 일 ' AS TODAY     
     , CONVERT(NVARCHAR,A.DILIG_DT_FR,23) AS DILIG_DT_FR, CONVERT(NVARCHAR,A.DILIG_DT_TO,23) AS DILIG_DT_TO  
	 , A.DILIG_CD

      FROM H4006M3_D_KO883 A(NOLOCK)      
     INNER JOIN HCA010T B(NOLOCK) ON A.DILIG_CD = B.DILIG_CD    
           INNER JOIN HAA010T H(NOLOCK) ON A.DILIG_EMP_NO = H.EMP_NO      
           INNER JOIN B_BIZ_AREA D(NOLOCK) ON H.BIZ_AREA_CD = D.BIZ_AREA_CD      
           INNER JOIN DBO.UFN_H_GETDEPTDATA(GETDATE()) DEPT ON A.DILIG_EMP_NO = DEPT.EMP_NO      
           LEFT JOIN ERP_IF_APPROVAL E(NOLOCK) ON A.DILIG_REQ_NO = E.DOC_NO      
     WHERE A.DILIG_REQ_NO = @doc_no)Z             
    
         
SELECT @DAY = '( '+(CASE WHEN @DILIG_CD='02'  OR @DILIG_CD='03' THEN '0.5' ELSE (CONVERT(NVARCHAR(3),(DATEDIFF ( day , @DILIG_FR, @DILIG_TO)+1)-COUNT(DATE))) END)+' ) 일간'  
FROM haa010t a(NOLOCK) left outer join hca040t b(NOLOCK)  on (a.emp_no = b.emp_no) inner join hca020t c(NOLOCK)  on (b.WK_TYPE = c.WK_TYPE)   
WHERE (a.retire_dt >= getdate()  or  a.retire_dt is null )  
      and b.chang_dt = (select max(chang_dt) from hca040t where emp_no=a.emp_no and chang_dt <= getdate() )  
      and c.HOLI_TYPE NOT IN ('D')   
      and b.emp_no = @DILIG_EMP_NO  
   AND CONVERT(NVARCHAR,C.DATE,23) BETWEEN @DILIG_FR AND @DILIG_TO  
                              
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##DEPT_NM##',  @DEPT_NM)                    
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##ROLL_PSTN_NM##', @ROLL_PSTN_NM)                     
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##NAME##', @NAME )        
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##DILIG_NM##', @DILIG_NM)             
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##DILIG_DT##',@DILIG_DT)         
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##DAY##',@DAY)         
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##CONT##',@CONT)       
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##TODAY##',@TODAY)       
    
 If (@DOC_CONTENTS IS NULL or @DOC_CONTENTS = '')                                
 Begin                                
  SET @MSG_CD ='WC0007'                                
  RETURN -1                                
 End                                
                                 
 ---------------------------------------                                
                                
 --set @DOC_CONTENTS = '<html><head></head><meta http-equiv="CONTENT-TYPE" content="TEXT/HTML; CHARSET=UTF-8"><body>zzzz</body></html>'                                
 --SET @DOC_CONTENTS = '<html> <body>테스트</body> </html>'                                
                               
                              
 DELETE  ERP_IF_APPROVAL WHERE DOC_NO=@doc_no     
                                 
 INSERT INTO ERP_IF_APPROVAL ( DOC_NO,   AP_ITEM, SYSTEM_CODE, MNU_ID,   REF_NO,                                 
     DOC_TITLE,  DOC_CONTENTS, DOC_USER_ID,                                 
     APPROVAL_API_RTN, APPROVAL_RTN, APPROVAL_RESULT_RTN, APPROVAL_RESULT_DATE,                                
     INSRT_USER_ID,  INSRT_DT, UPDT_USER_ID,  UPDT_DT )                                
                             
 VALUES (  @doc_no, @ap_item,  @system_code, @ap_form, @doc_no                         
   , '[일반근태신청서] '+' ( '+(SELECT REMARK FROM H4006M3_H_KO883 WHERE DILIG_REQ_NO = @doc_no) + ' )'                         
   ,@DOC_CONTENTS, @doc_user_id , '',  'F',  '', GETDATE()                                
   , @user_id, getdate(), @user_id, getdate() )                                
                                
 If (@@ERROR <> 0)                                
 Begin                                
  SET @MSG_CD = 'WC0007'                                
  RETURN -1                                
 End                                
                                 
 ----------------------------------                                
 -- GET PATH                                
 ----------------------------------                                
                                 
 --DECLARE  @MANAGER nvarchar(13)                                
 -- , @PDEPT nvarchar(10)                                
                                  
 --SELECT @MANAGER = MANAGER,                                
 -- @PDEPT = PDEPT                                
 --FROM HORG_MAS (nolock)                                
 --WHERE DEPT = (select dept_cd from HAA010T where EMP_NO = @doc_user_id)                                
                                
 --WHILE (@MANAGER IS NULL AND (@PDEPT IS NOT NULL OR @PDEPT <> ''))                                
 --BEGIN                                
 -- SELECT @MANAGER = MANAGER,                                
 --  @PDEPT = PDEPT                                
 -- FROM HORG_MAS (nolock)                                
 -- WHERE DEPT = @PDEPT                                
 --END                                
                                 
 --If (@MANAGER IS NULL or @MANAGER = '')                                
 --Begin                                
 -- SET @MSG_CD = 'WC0007'                                
 -- RETURN -1           
 --End                                
                                 
 --INSERT INTO ERP_IF_APPROVAL_PATH ( DOC_NO, DOC_SEQ, APPROVAL_USER_ID, APPROVAL_CD, USER_YN,                              
 --     INSRT_USER_ID, INSRT_DT, UPDT_USER_ID, UPDT_DT )                                
                                 
 --VALUES (  @DOC_NO, 1, @MANAGER, 'D', 'Y'                                
 --  , @user_id, getdate(), @user_id, getdate() )                                
                                 
                               
 DELETE FROM A FROM ERP_IF_APPROVAL_PATH A                                
 WHERE DOC_NO = @DOC_NO                                
                                
                                
 INSERT INTO ERP_IF_APPROVAL_PATH ( DOC_NO, DOC_SEQ, APPROVAL_USER_ID, APPROVAL_CD, USER_YN,                                 
      INSRT_USER_ID, INSRT_DT, UPDT_USER_ID, UPDT_DT )                                
 SELECT @DOC_NO, A.*, @USER_ID, GETDATE(), @USER_ID, GETDATE()                                 
 FROM  DBO.UFN_GET_APPROVAL_PATH(@AP_FORM, @ap_item,'0', '', @DOC_USER_ID) A                                 
                                
 If (@@ERROR <> 0)                                
 Begin                
  SET @MSG_CD = 'WC0007'                                
  RETURN -1                                
 End                                
                                 
 --ufn_get_approval_path                                
                                 
 RETURN 1                                
                                
END 