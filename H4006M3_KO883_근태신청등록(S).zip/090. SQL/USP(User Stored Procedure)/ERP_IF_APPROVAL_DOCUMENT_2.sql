﻿
DELETE ERP_IF_APPROVAL_DOCUMENT_MAPPING WHERE DOC_ID ='H4006M3_KO883' AND AP_ITEM = 'H2'

INSERT INTO ERP_IF_APPROVAL_DOCUMENT_MAPPING VALUES('HR','H4006M3_KO883','H2','H4006M3_KO883','N', '','','unierp',GETDATE(), 'unierp',GETDATE())
 
 DELETE ERP_IF_APPROVAL_DOCUMENT WHERE DOC_ID ='H4006M3_KO883' AND AP_ITEM = 'H2'

INSERT INTO ERP_IF_APPROVAL_DOCUMENT
values('H4006M3_KO883', '휴가신청서', 'H2',
'<html>
    <head>
        <title>휴가 신청서</title>
        <style type=''text/css''>
            td,
            th {
                font-size: 8pt;
                font-family: Arial Unicode MS;
                padding: 0;
            }
            table {
                padding: 0;
                border-spacing: 0;
                border: 0;
                border-collapse: collapse;
            }
            .td_0002 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 0;
                border-top-width: 0;
                border-right-width: 0;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_0040 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 0;
                border-top-width: 1px;
                border-right-width: 0;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_0022 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 0;
                border-top-width: 0;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_1001 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 0;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_1002 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 0;
                border-right-width: 0;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_1012 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 0;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_1201 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 1px;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }

            .td_1202 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 1px;
                border-right-width: 0;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_1222 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 1px;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_2022 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 0;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_2201 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 1px;
                border-right-width: 0;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_1221 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 1px;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_2001 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 0;
                border-right-width: 0;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_1021 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 0;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_2002 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 0;
                border-right-width: 0;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_1022 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 0;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_2221 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 1px;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
            .td_2021 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 0;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
            }
			.td_2022 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 0;
                border-top-width: 1px;
                border-right-width: 1px;
                border-bottom-width: 1px;
                vertical-align: middle;
				font-size: 9pt;
            }
			.td_2023 {
                border-style: solid;
                border-width: 1px;
                border-color: black;
                border-left-width: 1px;
                border-top-width: 1px;
                border-right-width: 0;
                border-bottom-width: 1px;
                vertical-align: middle;
				font-size: 9pt;
            }
        </style>
    </head>
    <meta http-equiv="CONTENT-TYPE" content="TEXT/HTML; CHARSET=UTF-8">
    <body>
        <h1 align=''center''>
            <strong>휴가 신청서</strong>
        </h1>
        <br/><br/><br/>
        <table width=''1000''>
            <tr>
                <td>
                                <tr height=''28''>
                                    <td class=''td_1201'' bgcolor=''dcdcdc'' width=''20%'' align=''center''>
                                        <strong> 부서</strong>
                                    </td>
                                    <td class=''td_1201'' width=''80%'' align=''center''>
                                        ##DEPT_NM##
                                    </td>
                                </tr>
                                <tr height=''28''>
                                    <td class=''td_1201'' bgcolor=''dcdcdc'' width=''20%'' align=''center''>
                                        <strong>직위</strong>
                                    </td>
                                    <td class=''td_1201'' width=''80%'' align=''center''>
                                        ##ROLL_PSTN_NM##
                                    </td>
                                </tr>
                                <tr height=''28''>
                                    <td class=''td_1201'' bgcolor=''dcdcdc'' width=''20%'' align=''center''>
                                        <strong>성명</strong>
                                    </td>
                                    <td class=''td_1201'' width=''80%'' align=''center''>
                                        ##NAME##
                                    </td>
                                </tr>
								<tr height=''28''>
                                    <td class=''td_1201'' bgcolor=''dcdcdc'' width=''20%'' align=''center''>
                                        <strong>근태종류</strong>
                                    </td>
                                    <td class=''td_1201'' width=''80%'' align=''center''>
                                        ##DILIG_NM##
                                    </td>
                                </tr>
								  <tr height=''28''>
                                    <td class=''td_1201'' bgcolor=''dcdcdc'' width=''20%'' align=''center'' >
                                        <strong>기간</strong>
                                    </td>
                                    <td class=''td_1201'' width=''80%'' align=''center''>
                                        ##DILIG_DT##  ##DAY## 
                                    </td>
                                </tr>
								   <tr height=''28''>
                                    <td class=''td_1201'' bgcolor=''dcdcdc'' width=''20%'' align=''center''>
                                        <strong>사유</strong>
                                    </td>
                                    <td class=''td_1201'' width=''80%'' align=''center''>
                                        ##CONT##
                                    </td>
                                </tr>
								   <tr height=''70''>
								   <td class=''td_2023'' width=''20%'' align=''center'' >
								   </td>
                                    <td class=''td_2022'' width=''80%'' align=''center'' >
									    <br/>
										<br/>
										<br/>
                                        <P1><strong>위와  같이  신청하오니  결재하여  주시기  바랍니다.</strong></P1>
										<br/>
										<br/>
										<br/>
										<br/>
										<strong>##TODAY##</strong>
										<br/>
										<br/>
										<br/>
										<br/>
										<br/>
										<br/>
										<strong>* 첨부서류 : 휴가신청사유를 증명할 수 있는 서류 1본 - 경영지원팀 제출</strong>
										<br/>
										<br/>
										<br/>
										<br/>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr height=''2''/>
    </table>
	<br/>
</body>
</html>'
,'', '','unierp', getdate(),'unierp', getdate())
