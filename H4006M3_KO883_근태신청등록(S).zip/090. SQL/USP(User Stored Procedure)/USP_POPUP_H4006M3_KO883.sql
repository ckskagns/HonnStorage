﻿                    
--DROP PROCEDURE    dbo.[USP_POPUP_H4006M3_KO883]                    
--Go                    
/************************************************************************************/                    
/*****    PROC NAME   :  [USP_POPUP_H4006M3_KO883]        *****/                    
/*****    프로그램    :  H4006P3_KO883(근태신청등록)       *****/                    
/*****   Developer   :  MSK            *****/                    
/*****    개발날짜    :  2018-07-18            *****/                    
/*****    최신수정날짜:  2018-07-18            *****/                    
/*****    내    용    :               *****/                    
/************************************************************************************/                    
                    
CREATE PROC [dbo].[USP_POPUP_H4006M3_KO883](                    
                    
   @DILIG_REQ_NO    NVARCHAR(20),                      
   @ISRTDT_FR     NVARCHAR(10),                      
   @ISRTDT_TO        NVARCHAR(10),                       
   @REMARK         NVARCHAR(40),                    
   @APPROVAL_RTN       NVARCHAR(1),                    
   @DILIG_TYPE        NVARCHAR(1),                    
   @REPORT_TYPE       NVARCHAR(1),                    
   @INSRT_USER_ID       NVARCHAR(13),        
   @USR_ID    NVARCHAR(13)                       
)                        
AS                    
                    
    Set Nocount On                   
   IF(@APPROVAL_RTN='%')            
   BEGIN              
  SELECT                    
  A.DILIG_REQ_NO,                    
  A.ISRT_DT,                    
   B.MINOR_NM AS DILIG_TYPE_NM,                    
  C.MINOR_NM AS REPORT_TYPE_NM,                    
  A.ISRT_EMP_NO,                    
  A.REQ_EMP_NO AS insrt_user_id,                    
  E.NAME,                
  ISNULL(D.APPROVAL_RTN,'F')   AS APPROVAL_RTN,              
  ISNULL((SELECT ISNULL(MINOR_NM,'미진행') FROM B_MINOR WHERE MINOR_CD=D.APPROVAL_RTN AND MAJOR_CD='SM003'),'미진행') AS APPROVAL_RTN_NM,                    
  A.REMARK,        
  E.dept_cd,         
  E.dept_nm        
                    
 FROM                    
  H4006M3_H_KO883 A(NOLOCK)                     
  LEFT JOIN B_MINOR B(NOLOCK) ON A.DILIG_TYPE = B.MINOR_CD AND B.MAJOR_CD ='XH002'                    
  LEFT JOIN B_MINOR C(NOLOCK) ON A.REPORT_TYPE = C.MINOR_CD AND C.MAJOR_CD ='XH003'                    
  LEFT JOIN ERP_IF_APPROVAL D(NOLOCK) ON A.DILIG_REQ_NO = D.DOC_NO                    
  LEFT JOIN HAA010T E(NOLOCK) ON A.REQ_EMP_NO = E.EMP_NO             
  INNER JOIN dbo.Ufn_authinternalcd_byusrid(@USR_ID) auth  ON auth.internal_cd = E.internal_cd         
  INNER JOIN dbo.Ufn_h_getdeptdata(GETDATE()) dept ON E.emp_no = dept.emp_no           
 WHERE                    
  ISNULL(A.DILIG_REQ_NO,'') LIKE '%'+@DILIG_REQ_NO                    
  AND CONVERT(VARCHAR,A.ISRT_DT,23) BETWEEN @ISRTDT_FR AND @ISRTDT_TO                    
  AND A.DILIG_TYPE LIKE @DILIG_TYPE                    
  AND A.REPORT_TYPE LIKE @REPORT_TYPE                          
  AND ISNULL(A.REQ_EMP_NO,'') LIKE @INSRT_USER_ID               
  AND ISNULL(A.REMARK,'') LIKE '%'+@REMARK+'%'              
  END            
  ELSE            
  BEGIN            
    SELECT                    
  A.DILIG_REQ_NO,                    
  A.ISRT_DT,                    
   B.MINOR_NM AS DILIG_TYPE_NM,                    
  C.MINOR_NM AS REPORT_TYPE_NM,                    
  A.ISRT_EMP_NO,                    
  A.REQ_EMP_NO AS insrt_user_id,                    
  E.NAME,                
  ISNULL(D.APPROVAL_RTN,'F')   AS APPROVAL_RTN,              
  ISNULL((SELECT ISNULL(MINOR_NM,'미진행') FROM B_MINOR WHERE MINOR_CD=D.APPROVAL_RTN AND MAJOR_CD='SM003'),'미진행') AS APPROVAL_RTN_NM,                    
  A.REMARK,        
  E.dept_cd,         
  E.dept_nm                     
                    
 FROM                    
  H4006M3_H_KO883 A(NOLOCK)                     
  LEFT JOIN B_MINOR B(NOLOCK) ON A.DILIG_TYPE = B.MINOR_CD AND B.MAJOR_CD ='XH002'                    
  LEFT JOIN B_MINOR C(NOLOCK) ON A.REPORT_TYPE = C.MINOR_CD AND C.MAJOR_CD ='XH003'                    
  LEFT JOIN ERP_IF_APPROVAL D(NOLOCK) ON A.DILIG_REQ_NO = D.DOC_NO                    
  LEFT JOIN HAA010T E(NOLOCK) ON A.REQ_EMP_NO = E.EMP_NO             
  INNER JOIN dbo.Ufn_authinternalcd_byusrid(@USR_ID) auth  ON auth.internal_cd = E.internal_cd         
  INNER JOIN dbo.Ufn_h_getdeptdata(GETDATE()) dept ON E.emp_no = dept.emp_no                    
 WHERE                    
  ISNULL(A.DILIG_REQ_NO,'') LIKE '%'+@DILIG_REQ_NO                    
  AND CONVERT(VARCHAR,A.ISRT_DT,23) BETWEEN @ISRTDT_FR AND @ISRTDT_TO                    
  AND A.DILIG_TYPE LIKE @DILIG_TYPE                    
  AND A.REPORT_TYPE LIKE @REPORT_TYPE                    
  AND ISNULL(D.APPROVAL_RTN,'F') LIKE @APPROVAL_RTN                    
  AND ISNULL(A.REQ_EMP_NO,'') LIKE @INSRT_USER_ID               
  AND ISNULL(A.REMARK,'') LIKE '%'+@REMARK   +'%'           
  END