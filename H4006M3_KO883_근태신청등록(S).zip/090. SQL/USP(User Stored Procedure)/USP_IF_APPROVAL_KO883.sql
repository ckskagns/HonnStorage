﻿                           
CREATE  procedure [dbo].[USP_IF_APPROVAL_KO883](                           
     @doc_no NVARCHAR(32 ),                             
     @system_code NVARCHAR(10 ),                              
     @ap_form NVARCHAR(32 ),                             
     @ref_no NVARCHAR(32 ),                             
     @doc_user_id  NVARCHAR(20 ),  -- 상신자                             
                                   
     @key_val1 nvarchar(20) = NULL, -- 예비키1                             
     @key_val2 nvarchar(20) = NULL, -- 예비키2                             
     @key_val3 nvarchar(20) = NULL, -- 예비키3                             
     @key_val4 nvarchar(20) = NULL, -- 예비키4                             
     @key_val5 nvarchar(20) = NULL, -- 예비키5                             
     @key_val6 nvarchar(100) = NULL, -- 예비키6                             
                                  
     @user_id  NVARCHAR(20 ),                              
     @MSG_CD  [nvarchar](8)  OUTPUT,                             
     @msg_text NVARCHAR(200) OUTPUT ) AS                             
                             
                             
BEGIN                             
                             
SET NOCOUNT ON                             
SET TRANSACTION ISOLATION LEVEL READ COMMITTED                              
                             
DECLARE @RTN_VALUE INTEGER                              
                             
DECLARE @GW_FLG CHAR(1)                             
                             
DECLARE @AP_ITEM NVARCHAR(20)                             
                         
                     
----------------------------------------------------------------------------                             
-- INIT 환경등록                              
--   1. 스마트인터페이스 사용여부 SM001 MINOR_CD ='00', SEQ 1 Y/N                             
--   2. 스마트전자결제 사용여부 SM001 MINOR_CD ='00', SEQ 2 Y/N                             
--   3. 전결규정 사용여부 SM001 MINOR_CD ='00', SEQ 3 1(전결규정사용), 2(사용안함)                             
                             
-- 결재 상태 Return값 (상신:9, 승인:1, 부결:0)                             
-- 상신취소 8, 재상신 7                             
                             
----------------------------------------------------------------------------                             
-- kwh - BIZENTRO                             
----------------------------------------------------------------------------                             
-- 이 SP 에서도 SITE 버젼의 프로그램을 개발하여 사용할수 있게                              
-- 아래부분에 USP_IF_APPROVAL_SITE01 을 호출하도록 하였습니다.                             
-- USP_IF_APPROVAL_SITE01 은 SITE 버젼으로 프로그램 개발시                              
-- 문서양식을 생성 + ERP_IF_APPROVAL + ERP_IF_APPROVAL_PATH 를 생성하는 SP 를 작성하시어                              
-- USP_IF_APPROVAL_SITE01 에 추가하시면 됩니다.                             
----------------------------------------------------------------------------                             
                                 
 SET @GW_FLG = 'Y'                             
 SELECT top 1 @GW_FLG = isnull(reference,'')                               
 fROM B_CONFIGURATION WHERE MAJOR_CD ='SM001' and MINOR_CD ='00' and SEQ_NO IN (1,2) and reference = 'N'                             
                              
 IF  @GW_FLG <> 'Y'                              
 BEGIN                             
  ---------- TO LIST 에 넣고 나가기.                             
  SET @MSG_CD = 'SM1000' --스마트매니지먼트 환경설정을 확인 바랍니다. [SM001, 00]                             
  SET @msg_text = '[SM001, 00]'                             
  return -1                             
                             
 END                             
                             
                             
 IF (@GW_FLG = 'Y') -- GW 연결                             
 BEGIN                              
                                
                               
  If (@SYSTEM_CODE = 'MM' AND @ap_form = 'M3111MA1')                             
   SET @AP_ITEM = 'M1'  -- AP ITEM 은 모듈, 화면에서 더 분개되어 사용할시 해당의 값을 알맞게 변경하시어 사용하면 됨                             
  Else If (@SYSTEM_CODE = 'SD' AND @ap_form = 'S3111MA1')                   
   SET @AP_ITEM = 'S1'  -- AP ITEM 은 모듈, 화면에서 더 분개되어 사용할시 해당의 값을 알맞게 변경하시어 사용하면 됨                             
  /*Else  If (@SYSTEM_CODE = 'FI' )                             
   BEGIN                              
                                   
   select TOP 1 @AP_ITEM = AP_ITEM from ERP_IF_APPROVAL WHERE DOC_NO =@DOC_NO                              
                                
   END                              
  */                  
                
  -- 팸텍 프로젝트진행요청서(통합-S) : Y7204M1_KO883                           
  Else if (@SYSTEM_CODE = 'PS' AND @ap_form = 'Y7204M1_KO883')                             
   SET @AP_ITEM = 'P1'            -- ELSE   SET  @AP_ITEM = ''                   
                
  -- 팸텍 지출결의서(통합-S) : A5101M1_KO883                           
  Else if (@SYSTEM_CODE = 'FI' AND @ap_form = 'A5101M1_KO883')                             
   SET @AP_ITEM = 'F1'                             
        
		
	  -- 팸텍 근태신청등록서(통합-S) : H4006M3_KO883                           
  Else if (@SYSTEM_CODE = 'HR' AND @ap_form = 'H4006M3_KO883' AND (@key_val2='1'OR @key_val2='2') )                             
   SET @AP_ITEM = 'H1'   	  
              
        
  -- 팸텍 근태신청등록서(통합-S) : H4006M3_KO883                           
  Else if (@SYSTEM_CODE = 'HR' AND @ap_form = 'H4006M3_KO883' AND @key_val2 ='3')                             
   SET @AP_ITEM = 'H2'            
                                
  IF EXISTS ( SELECT TOP 1 1                             
     FROM ERP_IF_APPROVAL A                             
     WHERE SYSTEM_CODE = @system_code AND MNU_ID = @ap_form AND AP_ITEM = @AP_ITEM AND DOC_NO = @DOC_NO AND ISNULL(APPROVAL_RTN ,'') IN ('F','8') )                             
  BEGIN                             
   DELETE FROM A                             
   FROM ERP_IF_APPROVAL A                             
   WHERE SYSTEM_CODE = @system_code AND MNU_ID = @ap_form AND AP_ITEM = @AP_ITEM AND DOC_NO = @DOC_NO                             
                                
  END                             
                                
  -- check start                             
  -- 승인완료 (0 부결일시 재상신 하여 처리함)                        
  IF EXISTS( SELECT TOP 1 1                             
    FROM ERP_IF_APPROVAL A                         
    WHERE DOC_NO =@DOC_NO AND ISNULL(APPROVAL_RTN ,'') in ('1')  )                            
  BEGIN                               
   SET @MSG_CD = 'SM1006' --해당건은 이미 결재완료 되었거나 부결되었습니다.                             
   RETURN -1                             
   --GOTO ERROR_RETURN                               
  END                             
                               
  IF EXISTS( SELECT TOP 1 1                             
    FROM ERP_IF_APPROVAL A                             
    WHERE DOC_NO =@DOC_NO AND ISNULL(APPROVAL_RTN ,'') NOT IN ('F', '8', '0')  ) -- 최초, 상신취소, 부결                             
  BEGIN                             
   SET @MSG_CD = 'SM1005' --해당건은 이미 결재처리중 입니다                             
   RETURN -1                             
   --GOTO ERROR_RETURN                               
  END                             
  -- check end                             
                             
 /* IF  ( @system_code = 'FI' )                              
  BEGIN                             
   EXEC @RTN_VALUE = USP_IF_APPROVAL_FI01 @doc_no,@system_code,@ap_form,@ref_no,@doc_user_id,@user_id,@MSG_CD,@msg_text                             
                             
   IF (@RTN_VALUE < 1 OR @@ERROR <> 0)                             
   RETURN -1                             
  END                              
  ELSE If (@SYSTEM_CODE = 'MM' AND @ap_form = 'M3111MA1' AND @AP_ITEM = 'M1')                             
  BEGIN                             
   EXEC @RTN_VALUE = USP_IF_APPROVAL_MM01 @DOC_NO, @SYSTEM_CODE, @AP_FORM, @AP_ITEM, @REF_NO, @DOC_USER_ID, @USER_ID, @MSG_CD output, @MSG_TEXT output                             
                             
   IF (@RTN_VALUE < 1 OR @@ERROR <> 0)                             
   RETURN -1                             
  END                             
 ELSE IF (@SYSTEM_CODE = 'SD' AND @ap_form = 'S3111MA1' AND @AP_ITEM = 'S1')                             
  BEGIN                             
   EXEC @RTN_VALUE = USP_IF_APPROVAL_SD01 @doc_no, @system_code, @AP_FORM, @AP_ITEM, @ref_no, @doc_user_id, @user_id, @MSG_CD output, @msg_text output                               
                             
   IF (@RTN_VALUE < 1 OR @@ERROR <> 0)                             
   RETURN -1                             
  END                             
   */                          
                      
                             
  -- 팸텍 지출결의서 : A5101M1_KO883                          
   IF (@SYSTEM_CODE = 'FI' AND @ap_form = 'A5101M1_KO883' AND @AP_ITEM = 'F1')                             
  BEGIN                             
   EXEC @RTN_VALUE = USP_IF_APPROVAL_A5101M1_KO883 @doc_no, @system_code, @AP_FORM, @AP_ITEM, @ref_no, @doc_user_id, @user_id, @MSG_CD output, @msg_text output                               
    IF (@RTN_VALUE < 1 OR @@ERROR <> 0)                             
    RETURN -1                             
  END                         
                  
    -- 팸텍 지출결의서 : Y7204M1_KO883                          
   IF (@SYSTEM_CODE = 'PS' AND @ap_form = 'Y7204M1_KO883' AND @AP_ITEM = 'P1')                             
  BEGIN                             
   EXEC @RTN_VALUE = USP_IF_APPROVAL_Y7204M1_KO883 @doc_no, @system_code, @AP_FORM, @AP_ITEM, @ref_no, @doc_user_id, @user_id, @MSG_CD output, @msg_text output                               
    IF (@RTN_VALUE < 1 OR @@ERROR <> 0)                             
    RETURN -1                             
  END                      
                
   -- 팸텍 근태신청등록서 : H4006M3_KO883                        
   IF (@SYSTEM_CODE = 'HR' AND @ap_form = 'H4006M3_KO883' AND @AP_ITEM = 'H1' AND @key_val1 ='1' AND (@key_val2='1'OR @key_val2='2') )                             
  BEGIN                             
   EXEC @RTN_VALUE = USP_IF_APPROVAL_H4006M3_KO883_1 @doc_no, @system_code, @AP_FORM, @AP_ITEM, @ref_no, @doc_user_id, @user_id, @MSG_CD output, @msg_text output                               
    IF (@RTN_VALUE < 1 OR @@ERROR <> 0)                             
    RETURN -1                             
  END       

     -- 팸텍 일반근태신청서 : H4006M3_KO883                        
   IF (@SYSTEM_CODE = 'HR' AND @ap_form = 'H4006M3_KO883' AND @AP_ITEM = 'H2' AND @key_val1 ='1' AND @key_val2='3')                          
  BEGIN                             
   EXEC @RTN_VALUE = USP_IF_APPROVAL_H4006M3_KO883_3 @doc_no, @system_code, @AP_FORM, @AP_ITEM, @ref_no, @doc_user_id, @user_id, @MSG_CD output, @msg_text output                               
    IF (@RTN_VALUE < 1 OR @@ERROR <> 0)                             
    RETURN -1                             
  END  
  
     -- 팸텍 근태신청등록서 : H4006M3_KO883                        
   IF (@SYSTEM_CODE = 'HR' AND @ap_form = 'H4006M3_KO883' AND @AP_ITEM = 'H1' AND @key_val1 ='2' AND (@key_val2='1'OR @key_val2='2') )                             
  BEGIN                             
   EXEC @RTN_VALUE = USP_IF_APPROVAL_H4006M3_KO883_2 @doc_no, @system_code, @AP_FORM, @AP_ITEM, @ref_no, @doc_user_id, @user_id, @MSG_CD output, @msg_text output                               
    IF (@RTN_VALUE < 1 OR @@ERROR <> 0)                             
    RETURN -1                             
  END       

 
                              
  ELSE                             
  BEGIN                             
   -- USP_IF_APPROVAL_FI01, USP_IF_APPROVAL_MM01 등을 참조하여                               
   -- SITE에서 사용하는 문서양식 생성 + ERP_IF_APPROVAL + ERP_IF_APPROVAL_PATH 를 생성하는 SP 를 작성하시고                             
   -- USP_IF_APPROVAL_SITE01 SP 안에 추가하여 주세요.                                
   EXEC @RTN_VALUE = USP_IF_APPROVAL_SITE01 @doc_no, @system_code, @AP_FORM, @ref_no, @doc_user_id,                              
              @key_val1, @key_val2, @key_val3, @key_val4, @key_val5, @key_val6,                             
              @user_id, @MSG_CD output, @msg_text output                               
                             
   IF (@RTN_VALUE < 1 OR @@ERROR <> 0)                             
   RETURN -1                             
  END                             
                              
 END                             
                             
 RETURN 1                   
                             
 ERROR_RETURN:                             
 BEGIN                             
                             
 INSERT A_ACCT_SP_ERROR (BATCH_NO, MSG_CD)                             
 VALUES (@DOC_NO +''+ convert(varchar(20),GETDATE()) , @MSG_CD)                            
 RETURN -1                             
 END                             
                             
                    
END