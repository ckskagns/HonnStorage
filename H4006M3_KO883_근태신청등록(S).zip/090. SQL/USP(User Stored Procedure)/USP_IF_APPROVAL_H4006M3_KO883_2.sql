﻿CREATE procedure [dbo].[USP_IF_APPROVAL_H4006M3_KO883_2](                    
     @doc_no NVARCHAR(32),                    
     @system_code NVARCHAR(10),                    
     @ap_form NVARCHAR(32),                    
     @ap_item NVARCHAR(20),                    
     @ref_no NVARCHAR(32),                    
     @doc_user_id  NVARCHAR(20),                    
     @user_id  NVARCHAR(20),                    
     @MSG_CD  [nvarchar](8)  OUTPUT,                    
     @msg_text NVARCHAR(200) OUTPUT ) AS                    
                    
SET NOCOUNT ON                    
                    
BEGIN                    
                    
 ------------------------------------                    
 -- GET 양식                    
 ------------------------------------                    
                    
 declare @CONTENT_DTL nvarchar(max)                    
 SET @CONTENT_DTL = ''                    
                    
 SELECT @CONTENT_DTL =  @CONTENT_DTL + '<TR height = ''25''>'                  
 + '<TD class = ''td_1001'' align = ''center''>' +'&nbsp; '+ A.NAME + '</TD>'                    
 + '<TD class = ''td_1001'' align = ''center''>' + '&nbsp;'+ A.DEPT_NM + '</TD>'                    
 + '<TD class = ''td_1001'' align = ''center''>' + '&nbsp;'+ A.ROLL_PSTN + '</TD>'                    
 + '<TD class = ''td_1001'' align = ''center''>' + '&nbsp;'+ A.DILIG_NM +'</TD>'                    
 + '<TD class = ''td_1001'' align = ''center''>' + '&nbsp;'+ ISNULL(A.DILIG_DT_FR,'')+'</TD>'                    
 + '<TD class = ''td_1001'' align = ''center''>' + '&nbsp;'+ ISNULL(A.DILIG_FR,'') +'</TD>'                    
 + '<TD class = ''td_1001'' align = ''center''>' + '&nbsp;'+ ISNULL(A.DILIG_DT_TO,'') +'</TD>'                    
 + '<TD class = ''td_1001'' align = ''center''>' + '&nbsp;'+ ISNULL(A.DILIG_TO,'') +'</TD>'                    
 + '<TD class = ''td_1001'' align = ''center''>' + '&nbsp;'+ ISNULL(A.DILIG_TIME_FR,'') +'</TD>'                  
 + '<TD class = ''td_1001'' align = ''center''>' + '&nbsp;'+ ISNULL(A.DILIG_TIME_TO,'') +'</TD>'                    
 + '<TD class = ''td_1001'' >' +'&nbsp;'+  A.CONT + '</TD></TR>'                    
FROM         
 (      
( SELECT      
 B.NAME             
,B.DEPT_NM                 
,dbo.ufn_getcodename('H0002',B.ROLL_PSTN)   AS ROLL_PSTN      
,C.DILIG_NM                   
,CONVERT(VARCHAR,A.DILIG_DT_FR,23)     AS DILIG_DT_FR      
,RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_FR)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_FR)),2) AS DILIG_FR      
,CONVERT(VARCHAR,A.DILIG_DT_TO,23)              AS DILIG_DT_TO      
,RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_TO)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_TO)),2)  AS DILIG_TO                  
,CASE WHEN @ref_no IS NULL THEN '' ELSE  (RIGHT('00'+CONVERT(NVARCHAR,convert(int,D.DILIG_HH)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,D.DILIG_MM)),2) ) END    AS DILIG_TIME_FR      
, RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM)),2)      AS DILIG_TIME_TO      
,  A.CONT               
FROM         
  H4006M3_D_KO883 A(NOLOCK)          
  INNER JOIN HAA010T B(NOLOCK) ON A.DILIG_EMP_NO = B.EMP_NO          
  INNER JOIN HCA010T C(NOLOCK) ON A.DILIG_CD = C.DILIG_CD             
  LEFT JOIN  H4006M3_D_KO883 D(NOLOCK) ON A.DILIG_EMP_NO= D.DILIG_EMP_NO AND D.DILIG_REQ_NO = @ref_no      
 where A.DILIG_REQ_NO = @doc_no )                 
      
 UNION       
(      
 SELECT B.*      
 FROM       
 (      
 SELECT      
 B.NAME             
,B.DEPT_NM                 
,dbo.ufn_getcodename('H0002',B.ROLL_PSTN)   AS ROLL_PSTN      
,C.DILIG_NM                   
,CONVERT(VARCHAR,A.DILIG_DT_FR,23)     AS DILIG_DT_FR      
,RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_FR)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_FR)),2) AS DILIG_FR      
,CONVERT(VARCHAR,A.DILIG_DT_TO,23)              AS DILIG_DT_TO      
,RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_TO)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_TO)),2)  AS DILIG_TO                  
,''     AS DILIG_TIME_FR      
, RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM)),2)      AS DILIG_TIME_TO      
,  A.CONT               
FROM         
  H4006M3_D_KO883 A(NOLOCK)          
  INNER JOIN HAA010T B(NOLOCK) ON A.DILIG_EMP_NO = B.EMP_NO          
  INNER JOIN HCA010T C(NOLOCK) ON A.DILIG_CD = C.DILIG_CD                 
 where A.DILIG_REQ_NO = @doc_no                  
 ) A      
 RIGHT JOIN       
 ( SELECT      
 B.NAME             
,B.DEPT_NM                 
,dbo.ufn_getcodename('H0002',B.ROLL_PSTN)   AS ROLL_PSTN      
,C.DILIG_NM                   
,CONVERT(VARCHAR,A.DILIG_DT_FR,23)     AS DILIG_DT_FR      
,RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_FR)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_FR)),2) AS DILIG_FR      
,CONVERT(VARCHAR,A.DILIG_DT_TO,23)              AS DILIG_DT_TO      
,RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_TO)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_TO)),2)  AS DILIG_TO                  
,RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH)),2)+ ' : '+RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM)),2)  AS DILIG_TIME_FR      
, ''     AS DILIG_TIME_TO      
,  A.CONT               
FROM         
  H4006M3_D_KO883 A(NOLOCK)          
  INNER JOIN HAA010T B(NOLOCK) ON A.DILIG_EMP_NO = B.EMP_NO          
  INNER JOIN HCA010T C(NOLOCK) ON A.DILIG_CD = C.DILIG_CD                 
 where A.DILIG_REQ_NO = @ref_no       
                    
)B  ON A.NAME = B.NAME      
      
WHERE A.NAME IS NULL      
)       
)A      
         
                    
                    
 If (@CONTENT_DTL IS NULL OR @CONTENT_DTL = '')                    
 Begin                    
  SET @MSG_CD ='173200'                    
  RETURN -1                    
 End                    
                    
 SET @CONTENT_DTL = @CONTENT_DTL                    
                    
 DECLARE @DOC_CONTENTS   NVARCHAR(MAX)                    
                    
                    
 SELECT @DOC_CONTENTS = A.DOCUMENT                    
 FROM ERP_IF_APPROVAL_DOCUMENT A                    
 INNER JOIN ERP_IF_APPROVAL_DOCUMENT_MAPPING B ON A.DOC_ID = B.DOC_ID AND A.AP_ITEM = B.AP_ITEM                    
 WHERE B.MODULE_ID = LEFT(@SYSTEM_CODE,3)                   
 AND B.AP_ITEM = @AP_ITEM                    
                    
                    
                    
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##DILIG_TPYE_NM##'        
     ,(SELECT B.MINOR_NM  FROM H4006M3_H_KO883 A(NOLOCK)         
          INNER JOIN B_MINOR B(NOLOCK) ON A.DILIG_TYPE = B.MINOR_CD AND B.MAJOR_CD='XH002'        
       WHERE A.DILIG_REQ_NO = @doc_no))                    
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##REPORT_TYPE_NM##'        
     ,(SELECT B.MINOR_NM  FROM H4006M3_H_KO883 A(NOLOCK)         
          INNER JOIN B_MINOR B(NOLOCK) ON A.REPORT_TYPE = B.MINOR_CD        
       WHERE A.DILIG_REQ_NO = @doc_no AND B.MAJOR_CD='XH003'))                    
             
 set @DOC_CONTENTS = replace(@DOC_CONTENTS,'##CONTENT_DTL##',@CONTENT_DTL)                    
                    
 If (@DOC_CONTENTS IS NULL or @DOC_CONTENTS = '')                    
 Begin                    
  SET @MSG_CD ='WC0007'                    
  RETURN -1                    
 End                    
                    
 ---------------------------------------                  
                    
 --set @DOC_CONTENTS = '<html><head></head><meta http-equiv="CONTENT-TYPE" content="TEXT/HTML; CHARSET=UTF-8"><body>zzzz</body></html>'                    
--SET @DOC_CONTENTS = '<html> <body>테스트</body> </html>'                    
  DELETE  ERP_IF_APPROVAL WHERE DOC_NO=@doc_no              
              
 INSERT INTO ERP_IF_APPROVAL ( DOC_NO,   AP_ITEM, SYSTEM_CODE, MNU_ID,   REF_NO,                    
     DOC_TITLE,  DOC_CONTENTS, DOC_USER_ID,                    
     APPROVAL_API_RTN, APPROVAL_RTN, APPROVAL_RESULT_RTN, APPROVAL_RESULT_DATE,                    
     INSRT_USER_ID,  INSRT_DT, UPDT_USER_ID,  UPDT_DT )                    
                    
 VALUES (  @doc_no, @ap_item,  @system_code, @ap_form, @ref_no                    
   , ('['+(SELECT B.MINOR_NM  FROM H4006M3_H_KO883 A(NOLOCK)         
          INNER JOIN B_MINOR B(NOLOCK) ON A.DILIG_TYPE = B.MINOR_CD AND B.MAJOR_CD='XH002'        
       WHERE A.DILIG_REQ_NO = @doc_no)        
  +'_'+        
  (SELECT B.MINOR_NM  FROM H4006M3_H_KO883 A(NOLOCK)         
          INNER JOIN B_MINOR B(NOLOCK) ON A.REPORT_TYPE = B.MINOR_CD        
       WHERE A.DILIG_REQ_NO = @doc_no AND B.MAJOR_CD='XH003')        
+']  '+@doc_no+' '+ (select REMARK from H4006M3_H_KO883 where DILIG_REQ_NO = @doc_no))        
       , @DOC_CONTENTS, @doc_user_id , '',  'F',  '', GETDATE()                    
   , @user_id, getdate(), @user_id, getdate() )                 
              
                    
 If (@@ERROR <> 0)                    
 Begin                    
  SET @MSG_CD = 'WC0007'                    
  RETURN -1                    
 End                    
                  
              
                    
 DELETE ERP_IF_APPROVAL_PATH                   
 WHERE DOC_NO = @DOC_NO                   
                    
 INSERT INTO ERP_IF_APPROVAL_PATH ( DOC_NO, DOC_SEQ, APPROVAL_USER_ID, APPROVAL_CD, USER_YN,                    
      INSRT_USER_ID, INSRT_DT, UPDT_USER_ID, UPDT_DT )                    
 SELECT @DOC_NO, A.*, @USER_ID, GETDATE(), @USER_ID, GETDATE()                    
 FROM  DBO.UFN_GET_APPROVAL_PATH(@AP_FORM, @ap_item,'0', '',  @DOC_USER_ID) A                    
                     
 If (@@ERROR <> 0)                    
 Begin                    
  SET @MSG_CD = 'WC0007'                    
  RETURN -1                    
 End                    
                    
 RETURN 1                    
                    
END 