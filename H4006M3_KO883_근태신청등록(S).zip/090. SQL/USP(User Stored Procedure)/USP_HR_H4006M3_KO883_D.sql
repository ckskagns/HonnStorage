﻿    
--DROP PROCEDURE    dbo.[USP_HR_H4006M3_KO883_D]
--Go    
/************************************************************************************/    
/*****    PROC NAME   :  [USP_HR_H4006M3_KO883_D]         *****/    
/*****    프로그램    :  H4006M3_KO883_H(근태신청등록(S))          *****/    
/*****   Developer   :  MSK            *****/    
/*****    개발날짜    :  2018-07-19            *****/    
/*****    최신수정날짜:  2018-07-19            *****/    
/*****    내    용    :               *****/    
/************************************************************************************/    
    
CREATE PROC [dbo].[USP_HR_H4006M3_KO883_D](    
    
   @DILIG_REQ_NO    NVARCHAR(20)     
)        
AS    
    
    
    Set Nocount On    
     
    SELECT    
  A.DILIG_EMP_NO,    
  B.NAME,    
  A.DILIG_CD,    
  C.DILIG_NM,    
  A.DILIG_DT_FR,    
  CASE WHEN (RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_FR)),2)+ RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_FR)),2))='0000'THEN '' ELSE (RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_FR)),2)+ RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_FR)),2)) END  AS DILIG_FR,    
  A.DILIG_DT_TO,    
  CASE WHEN (RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_TO)),2)+ RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_TO)),2))='0000'THEN '' ELSE (RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH_TO)),2)+ RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM_TO)),2)) END  AS DILIG_TO,    
   CASE WHEN (RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH)),2)+ RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM)),2))='0000'THEN ''  ELSE (RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_HH)),2)+ RIGHT('00'+CONVERT(NVARCHAR,convert(int,A.DILIG_MM)),2)) END AS DILIG_TIME,    
  A.CONT    
 FROM    
  H4006M3_D_KO883 A(NOLOCK)    
  INNER JOIN HAA010T B(NOLOCK) ON A.DILIG_EMP_NO = B.EMP_NO    
  INNER JOIN HCA010T C(NOLOCK) ON A.DILIG_CD = C.DILIG_CD    
    
 WHERE    
  DILIG_REQ_NO = @DILIG_REQ_NO    
    