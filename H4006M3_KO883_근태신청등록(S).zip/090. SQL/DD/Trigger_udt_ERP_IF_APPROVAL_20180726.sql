  
alter TRIGGER [dbo].[udt_ERP_IF_APPROVAL]    
ON dbo.ERP_IF_APPROVAL   
FOR UPDATE AS    
  
/*  
-- PROC NAME : udt_ERP_IF_APPROVAL  
-- PROC DESC : ���½�û ���� ���� ���� ó�� �� ���½�û���̺� ���� ����  
      ���ϱ���, �Ⱓ���µ�� �ڵ�ó��  
  
-- MAKE NAME : integerii  
-- MAKE DATE : 2018.07.26
*/  
  
IF UPDATE(APPROVAL_RESULT_RTN)  
  
DECLARE @APPROVAL_RESULT_RTN NCHAR(1)  
      , @DOC_NO NVARCHAR(50)  
      , @GW_DOC_NO NVARCHAR(100)  
  
  SELECT @APPROVAL_RESULT_RTN = APPROVAL_RESULT_RTN  
       , @DOC_NO              = DOC_NO  
       , @GW_DOC_NO     = GW_DOC_NO  
   FROM inserted  
  WHERE 1=1  
   AND AP_ITEM = 'H1'  --������ ���  
  
--SELECT @APPROVAL_RESULT_RTN  
  
----���½�û���̺� UPDATE  
--  UPDATE A  
--	 SET A.GW_CONF_STATUS = @APPROVAL_RESULT_RTN  
--	FROM E5010M1_H_KO843 A  
--   WHERE 1=1  
--     AND A.DILIG_REQ_NO = @DOC_NO  
  
  
--���»���  
IF UPDATE(APPROVAL_RESULT_RTN)  
BEGIN    
  
 IF @APPROVAL_RESULT_RTN = '1'  
 BEGIN   
  --exec usp_E5010M1_KO843 @DOC_NO  
  
  declare @DILIG_EMP_NO nvarchar(50)  
     , @DILIG_CD  nvarchar(2)  
     , @DILIG_DT_FR datetime  
     , @DILIG_DT_TO datetime  
     , @DILIG_HH  numeric(5)  
     , @DILIG_MM  numeric(5)  
     , @REAL_DAY  int  
     , @CONT   nvarchar(50)  
     , @HOLIDAY_APPLY nvarchar(1)  
     , @DILIG_TYPE  nvarchar(1)  
	 , @DAY_TIME  nvarchar(1)  
  
  declare cur_01 cursor for  
    select a.DILIG_EMP_NO  
      , a.DILIG_CD  
      , a.DILIG_DT_FR  
      , a.DILIG_DT_TO  
      , a.DILIG_HH  
      , a.DILIG_MM  
      , 0 AS REAL_DAY  
      , a.CONT  
      , c.HOLIDAY_APPLY  
      , c.DILIG_TYPE
	  , c.DAY_TIME   
   from H4006M3_D_KO883 a  
     inner join H4006M3_H_KO883 b on b.DILIG_REQ_NO = a.DILIG_REQ_NO  
     inner join hca010t c on c.DILIG_CD = a.DILIG_CD  
  where 1=1  
    and b.DILIG_REQ_NO = @DOC_NO  
	AND b.DILIG_TYPE = '3'					--�Ϲݱ����� ���~~

  for read only  
  
  open cur_01  
  
  begin tran  
  
  fetch next from cur_01 into @DILIG_EMP_NO, @DILIG_CD, @DILIG_DT_FR, @DILIG_DT_TO, @DILIG_HH, @DILIG_MM,   
         @REAL_DAY, @CONT, @HOLIDAY_APPLY, @DILIG_TYPE , @DAY_TIME 
  
  while @@FETCH_STATUS = 0  
  begin   
  
  --0. �ߺ�üũ  
  --������ �ߺ�  
  if exists (   select *   
      from HCA050T  
        where 1=1  
       and DILIG_CD = @DILIG_CD  
       and EMP_NO   = @DILIG_EMP_NO  
       and dilig_strt_dt between @DILIG_DT_FR and @DILIG_DT_TO)  
  begin   
    --close cur_01  
    --deallocate cur_01  
    --rollback tran  
    break  
  
  end  
  
  --������ �ߺ�  
  if exists (   select *   
      from HCA050T  
        where 1=1  
       and DILIG_CD = @DILIG_CD  
       and EMP_NO   = @DILIG_EMP_NO  
       and dilig_end_dt between @DILIG_DT_FR and @DILIG_DT_TO)  
  begin   
    --close cur_01  
    --deallocate cur_01  
    --rollback tran  
    break  
  end  
  
  

  if @DAY_TIME = 1  --�ϼ������� ��츸 ����
  begin     
  --1. �Ⱓ���� ���    
   INSERT INTO HCA050T   
   ( emp_no,   dilig_cd,  dilig_strt_dt,          dilig_end_dt,          remark,    
     ext1_txt, ext2_txt, ext3_txt, ext4_txt,     
     ext1_amt, ext2_amt, ext1_dt, ext2_dt,   
     Isrt_emp_no, Isrt_dt, Updt_emp_no, Updt_dt )       
     VALUES  
   ( @DILIG_EMP_NO, @DILIG_CD, @DILIG_DT_FR, @DILIG_DT_TO, @CONT,   
    N'', N'', N'', N'',   
    0, 0, null, null,   
    @DILIG_EMP_NO ,GETDATE(), @DILIG_EMP_NO ,GETDATE()  
   )   
   --IF @@ERROR <> 0  
   --begin  
   -- close cur_01  
   -- deallocate cur_01  
   -- rollback tran  
   -- break  
   --end  
  end
  
  if @DAY_TIME <> 1  
  begin   
  --2. ���ϱ��� ���  
  --�Ⱓ ��ŭ ���� ����  
   INSERT INTO HCA060T   
   ( emp_no,       dilig_dt,       dilig_cd,  dilig_cnt,         
     dilig_hh,       dilig_mm,                         
     Isrt_emp_no, Isrt_dt, Updt_emp_no, Updt_dt,  
     ext1_txt, ext2_txt, ext3_txt, ext4_txt,    
     ext1_amt, ext2_amt, ext1_dt, ext2_dt                       
   )  
    select @DILIG_EMP_NO, a.DATE,  @DILIG_CD, 1  
      , @DILIG_HH, @DILIG_MM  
      , @DILIG_EMP_NO ,GETDATE(), @DILIG_EMP_NO,GETDATE()  
      , @CONT, N'', N'', N''  
      , 0, 0, null, null   
   from hca020t a  
     where 1=1  
    and a.date between @DILIG_DT_FR and @DILIG_DT_TO  
    and a.HOLI_TYPE LIKE (case when @HOLIDAY_APPLY = 'Y' THEN '%' ELSE 'D' END)  
  
   --IF @@ERROR <> 0  
   --begin  
   -- close cur_01  
   -- deallocate cur_01  
   -- rollback tran  
   -- break  
   --end  
  
  end  
  
   fetch next from cur_01 into @DILIG_EMP_NO, @DILIG_CD, @DILIG_DT_FR, @DILIG_DT_TO, @DILIG_HH, @DILIG_MM,   
          @REAL_DAY, @CONT, @HOLIDAY_APPLY, @DILIG_TYPE  , @DAY_TIME
  end  
  
  close cur_01  
  deallocate cur_01  
  
  commit tran  
   
 END  
END   