﻿namespace uniERP.App.UI.POPUP.H4006P3_KO883
{


    public partial class TDSPOPUP_DILIGREQNO
    {
    }
}
namespace uniERP.App.UI.POPUP.H4006P3_KO883.TDSPOPUP_DILIGREQNOTableAdapters
{


    public partial class TDSPOPUP_DILIGREQNO
    {
    }
}
