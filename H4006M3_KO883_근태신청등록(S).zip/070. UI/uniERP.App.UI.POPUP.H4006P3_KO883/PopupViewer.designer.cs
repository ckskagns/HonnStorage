﻿using System.Windows.Forms;

using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

using uniERP.AppFramework.UI.Module;


namespace uniERP.App.UI.POPUP.H4006P3_KO883
{

    public class ModuleInitializer : PopupModule
    {

        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterPopupViewer()
        {
           base.AddModule<PopupViewer>();
        }

    }
    partial class PopupViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblIsrtDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDiligType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblRemark = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblIsrtUserId = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblApprovalRtn = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblReportType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtIsrtDt = new uniERP.AppFramework.UI.Controls.uniDateTerm();
            this.cboApprovalRtn = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.txtRemark = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.popInsrtUserId = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.cboDiligType = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.cboReportType = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnQuery = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnCancel = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.btnOK = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTBL_MainCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboApprovalRtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDiligType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboReportType)).BeginInit();
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainReference.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.Location = new System.Drawing.Point(-5, 0);
            this.uniLabel_Path.Size = new System.Drawing.Size(0, 0);
            this.uniLabel_Path.Visible = false;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.lblIsrtDt, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblDiligType, 2, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblRemark, 0, 1);
            this.uniTBL_MainCondition.Controls.Add(this.lblIsrtUserId, 0, 2);
            this.uniTBL_MainCondition.Controls.Add(this.lblApprovalRtn, 2, 0);
            this.uniTBL_MainCondition.Controls.Add(this.lblReportType, 2, 2);
            this.uniTBL_MainCondition.Controls.Add(this.dtIsrtDt, 1, 0);
            this.uniTBL_MainCondition.Controls.Add(this.cboApprovalRtn, 3, 0);
            this.uniTBL_MainCondition.Controls.Add(this.txtRemark, 1, 1);
            this.uniTBL_MainCondition.Controls.Add(this.popInsrtUserId, 1, 2);
            this.uniTBL_MainCondition.Controls.Add(this.cboDiligType, 3, 1);
            this.uniTBL_MainCondition.Controls.Add(this.cboReportType, 3, 2);
            this.uniTBL_MainCondition.DefaultRowSize = 23;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 40F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 9F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 3;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(888, 84);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblIsrtDt
            // 
            appearance1.TextHAlignAsString = "Left";
            appearance1.TextVAlignAsString = "Middle";
            this.lblIsrtDt.Appearance = appearance1;
            this.lblIsrtDt.AutoPopupID = null;
            this.lblIsrtDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIsrtDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblIsrtDt.Location = new System.Drawing.Point(15, 6);
            this.lblIsrtDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblIsrtDt.Name = "lblIsrtDt";
            this.lblIsrtDt.Size = new System.Drawing.Size(109, 22);
            this.lblIsrtDt.StyleSetName = "Default";
            this.lblIsrtDt.TabIndex = 0;
            this.lblIsrtDt.Text = "작성일자";
            this.lblIsrtDt.UseMnemonic = false;
            // 
            // lblDiligType
            // 
            appearance2.TextHAlignAsString = "Left";
            appearance2.TextVAlignAsString = "Middle";
            this.lblDiligType.Appearance = appearance2;
            this.lblDiligType.AutoPopupID = null;
            this.lblDiligType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDiligType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDiligType.Location = new System.Drawing.Point(458, 29);
            this.lblDiligType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDiligType.Name = "lblDiligType";
            this.lblDiligType.Size = new System.Drawing.Size(109, 22);
            this.lblDiligType.StyleSetName = "Default";
            this.lblDiligType.TabIndex = 4;
            this.lblDiligType.Text = "근태구분";
            this.lblDiligType.UseMnemonic = false;
            // 
            // lblRemark
            // 
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.lblRemark.Appearance = appearance3;
            this.lblRemark.AutoPopupID = null;
            this.lblRemark.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRemark.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRemark.Location = new System.Drawing.Point(15, 29);
            this.lblRemark.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(109, 22);
            this.lblRemark.StyleSetName = "Default";
            this.lblRemark.TabIndex = 1;
            this.lblRemark.Text = "비고";
            this.lblRemark.UseMnemonic = false;
            // 
            // lblIsrtUserId
            // 
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.lblIsrtUserId.Appearance = appearance4;
            this.lblIsrtUserId.AutoPopupID = null;
            this.lblIsrtUserId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIsrtUserId.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblIsrtUserId.Location = new System.Drawing.Point(15, 52);
            this.lblIsrtUserId.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblIsrtUserId.Name = "lblIsrtUserId";
            this.lblIsrtUserId.Size = new System.Drawing.Size(109, 22);
            this.lblIsrtUserId.StyleSetName = "Default";
            this.lblIsrtUserId.TabIndex = 2;
            this.lblIsrtUserId.Text = "기안자사번";
            this.lblIsrtUserId.UseMnemonic = false;
            // 
            // lblApprovalRtn
            // 
            appearance5.TextHAlignAsString = "Left";
            appearance5.TextVAlignAsString = "Middle";
            this.lblApprovalRtn.Appearance = appearance5;
            this.lblApprovalRtn.AutoPopupID = null;
            this.lblApprovalRtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblApprovalRtn.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblApprovalRtn.Location = new System.Drawing.Point(458, 6);
            this.lblApprovalRtn.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblApprovalRtn.Name = "lblApprovalRtn";
            this.lblApprovalRtn.Size = new System.Drawing.Size(109, 22);
            this.lblApprovalRtn.StyleSetName = "Default";
            this.lblApprovalRtn.TabIndex = 3;
            this.lblApprovalRtn.Text = "승인상태";
            this.lblApprovalRtn.UseMnemonic = false;
            // 
            // lblReportType
            // 
            appearance6.TextHAlignAsString = "Left";
            appearance6.TextVAlignAsString = "Middle";
            this.lblReportType.Appearance = appearance6;
            this.lblReportType.AutoPopupID = null;
            this.lblReportType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReportType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReportType.Location = new System.Drawing.Point(458, 52);
            this.lblReportType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReportType.Name = "lblReportType";
            this.lblReportType.Size = new System.Drawing.Size(109, 22);
            this.lblReportType.StyleSetName = "Default";
            this.lblReportType.TabIndex = 5;
            this.lblReportType.Text = "보고구분";
            this.lblReportType.UseMnemonic = false;
            // 
            // dtIsrtDt
            // 
            this.dtIsrtDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtIsrtDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.YYYY_MM_DD;
            this.dtIsrtDt.FieldTypeFrom = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtIsrtDt.FieldTypeTo = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.dtIsrtDt.Location = new System.Drawing.Point(124, 7);
            this.dtIsrtDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtIsrtDt.Name = "dtIsrtDt";
            this.dtIsrtDt.Size = new System.Drawing.Size(225, 21);
            this.dtIsrtDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.dtIsrtDt.TabIndex = 6;
            this.dtIsrtDt.uniFromALT = "작성일자 From";
            this.dtIsrtDt.uniFromValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            this.dtIsrtDt.uniTabSameValue = false;
            this.dtIsrtDt.uniToALT = "작성일자 To";
            this.dtIsrtDt.uniToValue = new System.DateTime(2007, 8, 18, 0, 0, 0, 0);
            // 
            // cboApprovalRtn
            // 
            this.cboApprovalRtn.AddEmptyRow = true;
            this.cboApprovalRtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboApprovalRtn.ComboFrom = "";
            this.cboApprovalRtn.ComboMajorCd = "SM003";
            this.cboApprovalRtn.ComboSelect = "";
            this.cboApprovalRtn.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboApprovalRtn.ComboWhere = "";
            this.cboApprovalRtn.DropDownListWidth = -1;
            this.cboApprovalRtn.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboApprovalRtn.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.cboApprovalRtn.Location = new System.Drawing.Point(567, 7);
            this.cboApprovalRtn.LockedField = false;
            this.cboApprovalRtn.Margin = new System.Windows.Forms.Padding(0);
            this.cboApprovalRtn.Name = "cboApprovalRtn";
            this.cboApprovalRtn.RequiredField = false;
            this.cboApprovalRtn.Size = new System.Drawing.Size(116, 21);
            this.cboApprovalRtn.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboApprovalRtn.StyleSetName = "Default";
            this.cboApprovalRtn.TabIndex = 7;
            this.cboApprovalRtn.uniALT = "승인상태";
            // 
            // txtRemark
            // 
            this.txtRemark.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance7.TextVAlignAsString = "Bottom";
            this.txtRemark.Appearance = appearance7;
            this.txtRemark.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtRemark.Location = new System.Drawing.Point(124, 30);
            this.txtRemark.LockedField = false;
            this.txtRemark.Margin = new System.Windows.Forms.Padding(0);
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.QueryIfEnterKeyPressed = true;
            this.txtRemark.RequiredField = false;
            this.txtRemark.Size = new System.Drawing.Size(225, 21);
            this.txtRemark.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtRemark.StyleSetName = "Default";
            this.txtRemark.TabIndex = 8;
            this.txtRemark.uniALT = "고비";
            this.txtRemark.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtRemark.UseDynamicFormat = false;
            // 
            // popInsrtUserId
            // 
            this.popInsrtUserId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popInsrtUserId.AutoPopupCodeParameter = null;
            this.popInsrtUserId.AutoPopupID = null;
            this.popInsrtUserId.AutoPopupNameParameter = null;
            this.popInsrtUserId.CodeMaxLength = 13;
            this.popInsrtUserId.CodeName = "";
            this.popInsrtUserId.CodeSize = 100;
            this.popInsrtUserId.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popInsrtUserId.CodeTextBoxName = null;
            this.popInsrtUserId.CodeValue = "";
            this.popInsrtUserId.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.popInsrtUserId.Location = new System.Drawing.Point(124, 53);
            this.popInsrtUserId.LockedField = false;
            this.popInsrtUserId.Margin = new System.Windows.Forms.Padding(0);
            this.popInsrtUserId.Name = "popInsrtUserId";
            this.popInsrtUserId.NameDisplay = true;
            this.popInsrtUserId.NameId = null;
            this.popInsrtUserId.NameMaxLength = 50;
            this.popInsrtUserId.NamePopup = false;
            this.popInsrtUserId.NameSize = 150;
            this.popInsrtUserId.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popInsrtUserId.Parameter = null;
            this.popInsrtUserId.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popInsrtUserId.PopupId = null;
            this.popInsrtUserId.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popInsrtUserId.QueryIfEnterKeyPressed = true;
            this.popInsrtUserId.RequiredField = false;
            this.popInsrtUserId.Size = new System.Drawing.Size(225, 21);
            this.popInsrtUserId.TabIndex = 10;
            this.popInsrtUserId.uniALT = "기안자사번";
            this.popInsrtUserId.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popInsrtUserId.UseDynamicFormat = false;
            this.popInsrtUserId.ValueTextBoxName = null;
            this.popInsrtUserId.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popInsrtUserId_BeforePopupOpen);
            this.popInsrtUserId.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popInsrtUserId_AfterPopupClosed);
            this.popInsrtUserId.OnChange += new System.EventHandler(this.popInsrtUserId_OnChange);
            // 
            // cboDiligType
            // 
            this.cboDiligType.AddEmptyRow = true;
            this.cboDiligType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboDiligType.ComboFrom = "B_MINOR";
            this.cboDiligType.ComboMajorCd = "";
            this.cboDiligType.ComboSelect = "MINOR_CD AS CODE, MINOR_NM AS NAME";
            this.cboDiligType.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.Query;
            this.cboDiligType.ComboWhere = "MAJOR_CD = \'XH002\'";
            this.cboDiligType.DropDownListWidth = -1;
            this.cboDiligType.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboDiligType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.cboDiligType.Location = new System.Drawing.Point(567, 30);
            this.cboDiligType.LockedField = false;
            this.cboDiligType.Margin = new System.Windows.Forms.Padding(0);
            this.cboDiligType.Name = "cboDiligType";
            this.cboDiligType.RequiredField = false;
            this.cboDiligType.Size = new System.Drawing.Size(116, 21);
            this.cboDiligType.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboDiligType.StyleSetName = "Default";
            this.cboDiligType.TabIndex = 11;
            this.cboDiligType.uniALT = "근태구분";
            // 
            // cboReportType
            // 
            this.cboReportType.AddEmptyRow = true;
            this.cboReportType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboReportType.ComboFrom = "";
            this.cboReportType.ComboMajorCd = "XH003";
            this.cboReportType.ComboSelect = "";
            this.cboReportType.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboReportType.ComboWhere = "";
            this.cboReportType.DropDownListWidth = -1;
            this.cboReportType.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboReportType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.cboReportType.Location = new System.Drawing.Point(567, 53);
            this.cboReportType.LockedField = false;
            this.cboReportType.Margin = new System.Windows.Forms.Padding(0);
            this.cboReportType.Name = "cboReportType";
            this.cboReportType.RequiredField = false;
            this.cboReportType.Size = new System.Drawing.Size(116, 21);
            this.cboReportType.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboReportType.StyleSetName = "Default";
            this.cboReportType.TabIndex = 12;
            this.cboReportType.uniALT = "보고구분";
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 4);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 2);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(10, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 5;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 84F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(888, 503);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 1;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 5;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainReference.Controls.Add(this.btnQuery, 0, 0);
            this.uniTBL_MainReference.Controls.Add(this.btnCancel, 4, 0);
            this.uniTBL_MainReference.Controls.Add(this.btnOK, 2, 0);
            this.uniTBL_MainReference.DefaultRowSize = 23;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 475);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(888, 28);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 3;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnQuery
            // 
            this.btnQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnQuery.AutoPopupID = null;
            this.btnQuery.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnQuery.Location = new System.Drawing.Point(0, 1);
            this.btnQuery.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.PopupID = null;
            this.btnQuery.Size = new System.Drawing.Size(97, 24);
            this.btnQuery.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnQuery.StyleSetName = "uniButton_EasyBase";
            this.btnQuery.TabIndex = 0;
            this.btnQuery.Text = "조회";
            this.btnQuery.UserDefinedText = null;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.AutoPopupID = null;
            this.btnCancel.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCancel.Location = new System.Drawing.Point(788, 1);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.PopupID = null;
            this.btnCancel.Size = new System.Drawing.Size(97, 24);
            this.btnCancel.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "취소";
            this.btnCancel.UserDefinedText = null;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.AutoPopupID = null;
            this.btnOK.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnOK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnOK.Location = new System.Drawing.Point(680, 1);
            this.btnOK.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnOK.Name = "btnOK";
            this.btnOK.PopupID = null;
            this.btnOK.Size = new System.Drawing.Size(97, 24);
            this.btnOK.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnOK.TabIndex = 2;
            this.btnOK.Text = "확인";
            this.btnOK.UserDefinedText = null;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 0);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 6F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 1F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 93);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 1;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(888, 377);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 4;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance8.BackColor = System.Drawing.SystemColors.Window;
            appearance8.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance8;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance9.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance9.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance9;
            appearance10.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance10;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance11.BackColor2 = System.Drawing.SystemColors.Control;
            appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance11.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance11;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance12.BackColor = System.Drawing.SystemColors.Window;
            appearance12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance12;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance13.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance13;
            appearance14.BorderColor = System.Drawing.Color.Silver;
            appearance14.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance14;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance15.BackColor = System.Drawing.SystemColors.Control;
            appearance15.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance15.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance15.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance15;
            appearance16.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance16;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance17.BackColor = System.Drawing.SystemColors.Window;
            appearance17.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance17;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance18.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance18;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 0);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(888, 377);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 2;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.DoubleClickRow += new Infragistics.Win.UltraWinGrid.DoubleClickRowEventHandler(this.uniGrid1_DoubleClickRow);
            // 
            // PopupViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "PopupViewer";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Size = new System.Drawing.Size(908, 523);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainCondition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboApprovalRtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDiligType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboReportType)).EndInit();
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainReference.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        //        private System.Windows.Forms.BindingSource autoNumViewBindingSource;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniButton btnQuery;
        private uniERP.AppFramework.UI.Controls.uniButton btnCancel;
        private uniERP.AppFramework.UI.Controls.uniButton btnOK;
        private uniERP.AppFramework.UI.Controls.uniLabel lblIsrtDt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDiligType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRemark;
        private uniERP.AppFramework.UI.Controls.uniLabel lblIsrtUserId;
        private uniERP.AppFramework.UI.Controls.uniLabel lblApprovalRtn;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReportType;
        private uniERP.AppFramework.UI.Controls.uniDateTerm dtIsrtDt;
        private uniERP.AppFramework.UI.Controls.uniCombo cboApprovalRtn;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtRemark;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popInsrtUserId;
        private uniERP.AppFramework.UI.Controls.uniCombo cboDiligType;
        private uniERP.AppFramework.UI.Controls.uniCombo cboReportType;

    }
}
