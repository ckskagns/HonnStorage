﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Library.UI;

using Infragistics.Win.UltraWinGrid;

using Microsoft.Practices.CompositeUI.SmartParts;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.Commands;


using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Controls.Popup;
using uniERP.AppFramework.UI.Providers;
using uniERP.AppFramework.UI.Common.Exceptions;
using uniERP.AppFramework.DataBridge;
#endregion


namespace uniERP.App.UI.POPUP.H4006P3_KO883
{

    [Microsoft.Practices.CompositeUI.SmartParts.SmartPart]
    public partial class PopupViewer : PopupViewBase
    {
        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①uniERP.App.UI.POPUP.H4006P3_KO883</NameSpace>
        /// <Module>②POPUP </Module>
        /// <Class>③PopupViewer</Class>
        /// <Desc>④
        ///   근태신청등록의 신청번호POPUP
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="MSK" Date="2018-07-18">근태신청등록의 신청번호POPUP …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        private string strDiligReqNo = string.Empty;
        private bool _isEmpChange = false;
        private string strReportType = string.Empty;

        #endregion

        #region ■ 1.4 Class global constants (grid)

        #endregion

        #region ■ 1.5 Class global variables (grid)

        // change your code
        private TDSPOPUP_DILIGREQNO cstdsILIGREQNO = new TDSPOPUP_DILIGREQNO();

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public PopupViewer()
        {
            InitializeComponent();

            SetLayoutBasePanel(uniTBL_OuterMost);  // Outer most TableLayout Panel Name

        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(this.cstdsILIGREQNO);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T02_Multi | enumDef.ViewType.TA1_UserPopup);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Query, enumDef.ModuleInformation.PersonnelPayRollManagement);      // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                                   // Load custom numeric format

        }

        protected override void Form_Load_Completed()
        {
            string[] Temp = (string[])base.ParentData.Data;
            if (Temp != null)
            {
                strDiligReqNo = Temp[0].ToString().Trim();
                strReportType = Temp[1].ToString().Trim();
            }
            dtIsrtDt.uniDateTimeF.Value = uniBase.UDate.GetDBServerDateTime().AddMonths(-1);
            dtIsrtDt.uniDateTimeT.Value = uniBase.UDate.GetDBServerDateTime();
            cboApprovalRtn.Value = null;
            cboReportType.Value = null;
            cboDiligType.Value = null;
            if (strReportType == "REF")
            {
                cboReportType.Value = "1";
            }
            DBQuery();
        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {

        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            
            dtIsrtDt.uniDateTimeF.Value = uniBase.UDate.GetDBServerDateTime().AddMonths(-1);
            dtIsrtDt.uniDateTimeT.Value = uniBase.UDate.GetDBServerDateTime();

            cboReportType.Value = null;
            cboDiligType.Value = null;
            cboApprovalRtn.Value = null;
            if (strReportType == "REF")
            {
                cboReportType.Value = "1";
                uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                cboReportType.FieldType = enumDef.FieldType.ReadOnly;
            }
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Normal);
                cboReportType.FieldType = enumDef.FieldType.Default;

            }
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringCode)

        protected override void GatheringComboData()
        {

        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆

            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            TDSPOPUP_DILIGREQNO.E_POPUP_DILIGREQNODataTable uniGridTB1 = cstdsILIGREQNO.E_POPUP_DILIGREQNO;

            this.uniGrid1.SSSetEdit(uniGridTB1.dilig_req_noColumn.ColumnName, "신청번호", 100, enumDef.FieldType.ReadOnly, enumDef.CharCase.Upper, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetDate(uniGridTB1.isrt_dtColumn.ColumnName, "작성일자", 100, enumDef.FieldType.ReadOnly, CommonVariable.gDateFormat, enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.dilig_type_nmColumn.ColumnName, "근태구분", 100, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.report_type_nmColumn.ColumnName, "구분", 80, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.isrt_emp_noColumn.ColumnName, "작성자ID", 100, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.insrt_user_idColumn.ColumnName, "기안자사번", 80, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.nameColumn.ColumnName, "기안자명", 100, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.dept_cdColumn.ColumnName, "부서코드", 80, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.dept_nmColumn.ColumnName, "부서명", 100, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.approval_rtn_nmColumn.ColumnName, "승인상태", 100, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Center);
            this.uniGrid1.SSSetEdit(uniGridTB1.remarkColumn.ColumnName, "비고", 200, enumDef.FieldType.ReadOnly, enumDef.CharCase.Default, false, enumDef.HAlign.Left);




            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.Yes, enumDef.IsSearch.Yes);

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            //this.uniGrid1.SSSetColHidden(uniGridTB1.cmb_colColumn.ColumnName);
            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {

        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
        }
        #endregion

        #region ■ 3.4 initControlBinding
        protected override void InitControlBinding()
        {
            // Grid binding with global dataset variable.
            this.InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(this.cstdsILIGREQNO.E_POPUP_DILIGREQNO);
        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 FncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {
            //TO-DO : code business oriented logic

            return DBQuery();

        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)
        protected override bool OnFncSave()
        {
            //TO-DO : code business oriented logic
            return DBSave();
        }
        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {

            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)
        protected override bool OnFncCopy()
        {
            return true;
        }
        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)
        protected override bool OnFncPrev()
        {
            return true;
        }
        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)
        protected override bool OnFncNext()
        {
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 FncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic

            return true;
        }
        #endregion

        #region ■■ 4.3.2 FncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.3 FncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopyRow)
        protected override bool OnFncCopyRow()
        {
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.3 Db function group

        #region ■■ 4.3.1 DBQuery(Common)

        private bool DBQuery()
        {
            DataSet dsQuery = null;
            try
            {
                using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_POPUP_H4006M3_KO883"))
                {
                    string strApprovalRtn = (cboApprovalRtn.Value == null || cboApprovalRtn.Value.ToString() == "") ? "%" : cboApprovalRtn.Value.ToString();
                    string strDiligType = (cboDiligType.Value == null || cboDiligType.Value.ToString() == "") ? "%" : cboDiligType.Value.ToString();
                    string strReportType = (cboReportType.Value == null || cboReportType.Value.ToString() == "") ? "%" : cboReportType.Value.ToString();
                    string strInsrtUserId = (popInsrtUserId.CodeValue.ToString() == "") ? "%" : popInsrtUserId.CodeValue.ToString();
                    string strRemark = (txtRemark.Text.Trim() == "") ? "%" : txtRemark.Text;
               
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@DILIG_REQ_NO", SqlDbType.NVarChar, strDiligReqNo);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@ISRTDT_FR", SqlDbType.NVarChar, dtIsrtDt.uniDateTimeF.uniValue.ToString("yyyy-MM-dd"));
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@ISRTDT_TO", SqlDbType.NVarChar, dtIsrtDt.uniDateTimeT.uniValue.ToString("yyyy-MM-dd"));
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REMARK", SqlDbType.NVarChar, strRemark);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@APPROVAL_RTN", SqlDbType.NVarChar, strApprovalRtn);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@DILIG_TYPE", SqlDbType.NVarChar, strDiligType);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REPORT_TYPE", SqlDbType.NVarChar, strReportType);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@INSRT_USER_ID", SqlDbType.NVarChar, strInsrtUserId);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@USR_ID", SqlDbType.NVarChar, CommonVariable.gUsrID);


                    dsQuery = uniBase.UDatabase.ExecuteDataSet(iuniCommand);
                }
                if (dsQuery == null || dsQuery.Tables.Count == 0 || dsQuery.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    strDiligReqNo = "";
                    return false;
                }
                else
                {
                    uniBase.UData.MergeDataTable(cstdsILIGREQNO.E_POPUP_DILIGREQNO, dsQuery.Tables[0], false, MissingSchemaAction.Ignore);
                    strDiligReqNo = "";
                    if (strReportType == "REF")
                    {
                        for (int i = 0; i < uniGrid1.Rows.Count; i++)
                        {
                            DataSet DsRef = uniBase.UDataAccess.CommonQueryRs("DISTINCT DILIG_REQ_NO, REF_NO ", " H4006M3_H_KO883(NOLOCK) ",
                                                "REF_NO=" + uniBase.UCommon.FilterVariable(uniGrid1.Rows[i].Cells["dilig_req_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));
                            if (DsRef.Tables[0].Rows.Count > 0)
                            {
                                if (DsRef.Tables[0].Rows[0]["DILIG_REQ_NO"].ToString() == "")
                                {
                                    if (uniGrid1.Rows.Count > 0)
                                    {
                                        uniGrid1.SpreadLock(0, i, 8, i);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                if (cstdsILIGREQNO != null) cstdsILIGREQNO.Dispose();
            }
            return true;
        }

        #endregion

        #region ■■ 4.3.2 DBDelete(Single)

        #endregion

        #region ■■ 4.3.3 DBSave(Common)

        private bool DBSave()
        {

            return true;

        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group

        private void btnQuery_Click(object sender, EventArgs e)
        {
            this.uniGrid1.clearSpreadData();                                // clear grid data
            this.DBQuery();                                                 // Query
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.OKProcess();                                               // get selected row and retrun to caller
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.ParentForm.Close();                                  // close current popup
        }

        #endregion

        #region ■ 5.2 Grid   control event implementation group

        private void uniGrid1_DoubleClickRow(object sender, DoubleClickRowEventArgs e)
        {
            if (strReportType == "REF")
            {
                if (uniGrid1.Rows.Count < 1)
                    return;
                DataSet DsRef = uniBase.UDataAccess.CommonQueryRs("DISTINCT DILIG_REQ_NO, REF_NO ", " H4006M3_H_KO883(NOLOCK) ",
                                       "REF_NO=" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["dilig_req_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));
                if (DsRef.Tables[0].Rows.Count > 0)
                {
                    string strMessage = "이미 " + DsRef.Tables[0].Rows[0]["DILIG_REQ_NO"].ToString() + "에서 참고하고 있습니다.";
                    uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, strMessage);
                    return;
                }
            }

            this.OKProcess();
        }

        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group


        private void popInsrtUserId_BeforePopupOpen(object sender, BeforePopupOpenEventArgs e)
        {

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup";
            e.PopupPassData.PopupWinTitle = "Employee PopUp";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;

            string dt = string.Empty;
            if (dtIsrtDt.uniDateTimeF.uniValue.Year.ToString().Equals("1"))
                dt = uniBase.UDate.GetDBServerDateTime().ToString(CommonVariable.CDT_YYYY_MM_DD);

            else
                dt = uniBase.UDate.DateTimeToString(dtIsrtDt.uniDateTimeF, "1900-01-01", CommonVariable.CDT_YYYY_MM_DD, false);

            //e.PopupPassData.Data = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName, uniBase.UDate.DateTimeToString(dtValidDt, "1900-01-01", CommonVariable.CDT_YYYY_MM_DD, false), "1", cboBizAreaCd.SelectedItem.DataValue.ToString(), "", txtFrInternalCd.Text, txtToInternalCd.Text };
            e.PopupPassData.Data = new string[] { popInsrtUserId.CodeValue, "", dt, "1", "" };

            e.PopupPassData.UserParameters = new string[4];   // 2013.11.12 STATEMENTS에 들어가 값들
            e.PopupPassData.UserParameters[0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[1] = uniBase.UCommon.FilterVariable(dt, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[2] = uniBase.UCommon.FilterVariable(popInsrtUserId.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            e.PopupPassData.UserParameters[3] = uniBase.UCommon.FilterVariable(popInsrtUserId.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);

        }

        private void popInsrtUserId_AfterPopupClosed(object sender, AfterPopupCloseEventArgs e)
        {
            this._isEmpChange = true;
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popInsrtUserId.CodeValue = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
            popInsrtUserId.CodeName = iDataSet.Tables[0].Rows[0]["name"].ToString();
            this._isEmpChange = false;
        }

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        #endregion

        #endregion

        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group

        private void OKProcess()
        {
            base.SetPopupOK();  // enable raise after_popup event;

            base.ResultData.Data = GetSelectedRow();

            this.ParentForm.Close();
        }

        private DataSet GetSelectedRow()
        {
            DataSet iDataSet = null;

            iDataSet = uniGrid1.GetGridSelectedRows(cstdsILIGREQNO.Tables[0]);     // developer must change the table info.

            if (iDataSet == null)
            {
                return (GetActiveRow());
            }

            return iDataSet;

        }

        private DataSet GetActiveRow()
        {

            DataSet iDataSet = null;

            iDataSet = uniGrid1.GetGridActiveRow(cstdsILIGREQNO.Tables[0]);     // developer must change the table info.

            return iDataSet;

            //iDataSet = GetGridActiveRow(uniGrid1, iE1_B_AUTO_NUMBERINGDataTable);
           // iDataSet = GetGridActiveRow(uniGrid1, cstdsILIGREQNO.Tables[0]);

           // return iDataSet;

        }

        // get selected row data in uniGrid

        private DataSet GetGridSelectedRow(uniGrid puniGrid, DataTable pDataTable)
        {

            DataSet iDataSet = new DataSet();

            Infragistics.Win.UltraWinGrid.SelectedRowsCollection selectedRows;

            selectedRows = puniGrid.Selected.Rows;  // Get the selected rows.

            if (selectedRows.Count < 1)                  // If there are no selected rows, return
            {
                return null;
            }

            DataTable iDataTable = pDataTable.Clone();

            for (int i = 0; i < selectedRows.Count; i++)           // Loop through all the selected rows
            {
                Infragistics.Win.UltraWinGrid.UltraGridRow row;

                row = selectedRows[i];

                DataRow iDataRow = iDataTable.NewRow();

                foreach (DataColumn col in pDataTable.Columns)
                {

                    iDataRow[col.ColumnName] = row.Cells[col.ColumnName].Value;

                }

                iDataTable.Rows.Add(iDataRow);

            }

            iDataSet.Tables.Add(iDataTable);

            return iDataSet;

        }

        // get active row data in uniGrid

        private DataSet GetGridActiveRow(uniGrid puniGrid, DataTable pDataTable)
        {

            DataSet iDataSet = new DataSet();

            if (uniGrid1.Rows.Count < 1)
            {
                return null;
            }

            DataTable iDataTable = pDataTable.Clone();

            DataRow iDataRow = iDataTable.NewRow();

            iDataTable.Rows.Add(iDataRow);

            if (puniGrid.ActiveRow != null)
            {

                foreach (DataColumn col in pDataTable.Columns)
                {
                    iDataRow[col.ColumnName] = puniGrid.ActiveRow.Cells[col.ColumnName].Value;

                }
                iDataSet.Tables.Add(iDataTable);
            }
            else
            {
                return null;
            }
            return iDataSet;
        }

        #endregion

        private void popInsrtUserId_OnChange(object sender, EventArgs e)
        {
            if (popInsrtUserId.CodeValue == "")
            {
                popInsrtUserId.CodeName = "";
                return;
            }

            string[] UNISqlId = new string[] { "ZN_HR_EMP_NM2" };
            string[][] UNIValue = new string[1][];
            UNIValue[0] = new string[5];

            // 0: USER ID 
            // 1: DATE(IF '' DEFAULT GETDATE) 
            // 2: EMP NO
            // 3: ADDITIONAL CONDITION
            UNIValue[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][1] = "''";
            UNIValue[0][2] = uniBase.UCommon.FilterVariable(popInsrtUserId.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][3] = uniBase.UCommon.FilterVariable(popInsrtUserId.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][4] = " ";

            DataSet pDataSet = null;

            try
            {
                pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("800048", MessageBoxButtons.OK);
                    this.popInsrtUserId.CodeValue = "";
                    popInsrtUserId.CodeName = "";
                    popInsrtUserId.uniButton_Click(null, null);

                    //popEmpNo.Focus();

                    return;
                }
                else if (pDataSet.Tables[0].Rows.Count >= 2)
                {
                    this.popInsrtUserId.uniButton_Click(null, null);
                    if (string.IsNullOrEmpty(this.popInsrtUserId.CodeName.ToString())) //
                    {
                        this.popInsrtUserId.CodeValue = "";
                    }

                    return;
                }

                else
                {
                    popInsrtUserId.CodeValue = pDataSet.Tables[0].Rows[0]["emp_no"].ToString();
                    popInsrtUserId.CodeName = pDataSet.Tables[0].Rows[0]["name"].ToString();
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
        }

        #endregion




    }
}
