﻿namespace uniERP.App.UI.HR.H4006M3_KO883
{


    public partial class TdsH_DILIG
    {
    }
}
