﻿#region ● Namespace declaration

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Web.Services.Protocols;

using Microsoft.Practices.CompositeUI.SmartParts;

using Infragistics.Shared;
using Infragistics.Win;
using Infragistics.Win.UltraWinGrid;

using uniERP.AppFramework.UI.Common;
using uniERP.AppFramework.UI.Controls;
using uniERP.AppFramework.UI.Module;
using uniERP.AppFramework.UI.Variables;
using uniERP.AppFramework.UI.Common.Exceptions;
using uniERP.AppFramework.DataBridge;

#endregion

namespace uniERP.App.UI.HR.H4006M3_KO883
{
    [SmartPart]
    public partial class ModuleViewer : ViewBase
    {

        #region ▶ 1. Declaration part

        #region ■ 1.1 Program information
        /// <TemplateVersion>0.0.1.0</TemplateVersion>
        /// <NameSpace>①uniERP.App.UI.HR.H4006M3_KO883</NameSpace>
        /// <Module>②HR(인사관리)> 인사급여> 근태관리</Module>
        /// <Class>③ModuleViewer</Class>
        /// <Desc>④
        ///   근태신청등록(S) 근태 신청과 결과를 결재상신
        /// </Desc>
        /// <History>⑤
        ///   <FirstCreated>
        ///     <history name="MSK" Date="2018-07-17">근태신청등록(S) …</history>
        ///   </FirstCreated>
        ///   <Lastmodified>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///     <history name="modifier"  Date="modified date"> contents </history>
        ///   </Lastmodified>
        /// </History>
        /// <Remarks>⑥
        ///   <remark name="modifier"  Date="modified date">… </remark>
        ///   <remark name="modifier"  Date="modified date">… </remark>
        /// </Remarks>

        #endregion

        #region ■ 1.2. Class global constants (common)

        #endregion

        #region ■ 1.3. Class global variables (common)

        // change your code
        private TdsH_DILIG cstdsDILIG = new TdsH_DILIG();
        private string strRefNo = string.Empty;
        private string strReportType = string.Empty;
        private string strDiligReqNo = string.Empty;
        private string strdilig = string.Empty;
        private string strreport = string.Empty;
        private string strapproval = string.Empty;
        private string strquery = string.Empty;
        private string strreportvalue = string.Empty;

        private string diligtype = string.Empty;
        private string reporttype = string.Empty;
        private string remark = string.Empty;
        private string refno = string.Empty;
        private string strAPPROVAL = string.Empty;

        #endregion

        #region ■ 1.4 Class global constants (grid)

        #endregion

        #region ■ 1.5 Class global variables (grid)

        #endregion

        #endregion

        #region ▶ 2. Initialization part

        #region ■ 2.1 Constructor(common)

        public ModuleViewer()
        {
            InitializeComponent();
        }

        #endregion

        #region ■ 2.2 Form_Load(common)

        protected override void Form_Load()
        {
            uniBase.UData.SetWorkingDataSet(this.cstdsDILIG);
            uniBase.UCommon.SetViewType(enumDef.ViewType.T03_SingleMulti);

            uniBase.UCommon.LoadInfTB19029(enumDef.FormType.Input, enumDef.ModuleInformation.Common);  // Load company numeric format. I: Input Program, *: All Module
            this.LoadCustomInfTB19029();                                                   // Load custoqm numeric format

        }

        protected override void Form_Load_Completed()
        {
            popDiligReqNo.Focus();                // Set focus

        }

        #endregion

        #region ■ 2.3 Initializatize local global variables

        protected override void InitLocalVariables()
        {
            // init OperationMode is Create Mode
          base.viewDBSaveMode = enumDef.DBSaveMode.CreateMode;
          cstdsDILIG.Clear();

        }

        #endregion

        #region ■ 2.4 Set local global default variables

        protected override void SetLocalDefaultValue()
        {
            // init Dataset 1 Row  : change your code
           // cstdsDILIG.E_H_DILIG.Rows.Add(cstdsDILIG.E_H_DILIG.NewTableNameRow());

            // TO-DO: Assign default value to controls
            dtIsrtDt.Value = uniBase.UDate.GetDBServerDateTime();
            cboDiligType.Value = "1";
            cboReportType.Value = "2";
            uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
            cboReportType.FieldType = enumDef.FieldType.ReadOnly;
            cboErpIfRtn.Value = "F";
            dtBaseDt.Value = uniBase.UDate.GetDBServerDateTime();


            return;
        }

        #endregion

        #region ■ 2.5 Gathering combo data(GatheringComboData)

        protected override void GatheringComboData()
        {
            // Example: Set ComboBox List (Column Name, Select, From, Where)
            //uniBase.UData.ComboMajorAdd("TaxPolicy", "B0004");
            //uniBase.UData.ComboCustomAdd("MSG_TYPE", "MINOR_CD , MINOR_NM ", "B_MINOR", "MAJOR_CD='A1001'");

        }
        #endregion

        #region ■ 2.6 Define user defined numeric info

        public void LoadCustomInfTB19029()
        {

            #region User Define Numeric Format Data Setting  ☆
            //base.viewTB19029.ggUserDefined6.DecPoint = 0;
            //base.viewTB19029.ggUserDefined6.Integeral = 15;
            #endregion
        }

        #endregion

        #endregion

        #region ▶ 3. Grid method part

        #region ■ 3.1 Initialize Grid (InitSpreadSheet)

        private void InitSpreadSheet()
        {
            #region ■■ 3.1.1 Pre-setting grid information

            TdsH_DILIG.E_H_DILIG_DDataTable uniGridTB1 = this.cstdsDILIG.E_H_DILIG_D;

            this.uniGrid1.SSSetEdit(uniGridTB1.dilig_emp_noColumn.ColumnName, "사번", 100, enumDef.FieldType.Primary, enumDef.CharCase.Upper, true, enumDef.HAlign.Left, 13);
            this.uniGrid1.SSSetEdit(uniGridTB1.nameColumn.ColumnName, "성명", 100, enumDef.FieldType.ReadOnly);
            this.uniGrid1.SSSetEdit(uniGridTB1.dilig_cdColumn.ColumnName, "근태번호", 100, enumDef.FieldType.Primary, enumDef.CharCase.Upper, true, enumDef.HAlign.Left, 13);
            this.uniGrid1.SSSetEdit(uniGridTB1.dilig_nmColumn.ColumnName, "근태", 100, enumDef.FieldType.ReadOnly);

            this.uniGrid1.SSSetDate(uniGridTB1.dilig_dt_frColumn.ColumnName, "시작일", 100, enumDef.FieldType.Primary, CommonVariable.gDateFormat, enumDef.HAlign.Center);
            //this.uniGrid1.SSSetTime(uniGridTB1.dilig_frColumn.ColumnName, "시간", 80, enumDef.FieldType.Default, enumDef.Time24Hour.Yes, enumDef.TimeSeconds.No, enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.dilig_frColumn.ColumnName, "시간", 80, enumDef.FieldType.Default, "##:##", enumDef.HAlign.Center); 

            this.uniGrid1.SSSetDate(uniGridTB1.dilig_dt_toColumn.ColumnName, "종료일", 100, enumDef.FieldType.NotNull, CommonVariable.gDateFormat, enumDef.HAlign.Center);
            //this.uniGrid1.SSSetTime(uniGridTB1.dilig_toColumn.ColumnName, "시간", 80, enumDef.FieldType.Default, enumDef.Time24Hour.Yes, enumDef.TimeSeconds.No, enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.dilig_toColumn.ColumnName, "시간", 80, enumDef.FieldType.Default, "##:##", enumDef.HAlign.Center);

            //this.uniGrid1.SSSetTime(uniGridTB1.dilig_timeColumn.ColumnName, "근무시간", 80, enumDef.FieldType.ReadOnly, enumDef.Time24Hour.Yes, enumDef.TimeSeconds.No, enumDef.HAlign.Center);
            this.uniGrid1.SSSetMask(uniGridTB1.dilig_timeColumn.ColumnName, "근무시간", 80, enumDef.FieldType.ReadOnly, "##:##", enumDef.HAlign.Center);

            this.uniGrid1.SSSetEdit(uniGridTB1.contColumn.ColumnName, "비고", 500, enumDef.FieldType.Default, enumDef.CharCase.Upper, false, enumDef.HAlign.Left, 50);



            #endregion

            #region ■■ 3.1.2 Formatting grid information

            this.uniGrid1.InitializeGrid(enumDef.IsOutlookGroupBy.No, enumDef.IsSearch.No);

            #endregion

            #region ■■ 3.1.3 Setting etc grid

            // Hidden Column Setting
            //this.uniGrid1.SSSetColHidden(uniGridTB1.cmb_colColumn.ColumnName);

            #endregion
        }
        #endregion

        #region ■ 3.2 InitData

        private void InitData()
        {
            // TO-DO: 컨트롤을 초기화(또는 초기값)할때 할일 
            // SetDefaultVal과의 차이점은 전자는 Form_Load 시점에 콘트롤에 초기값을 세팅하는것이고
            // 후자는 특정 시점(조회후 또는 행추가후 등 특정이벤트)에서 초기값을 셋팅한다.
        }

        #endregion

        #region ■ 3.3 SetSpreadColor

        private void SetSpreadColor(int pvStartRow, int pvEndRow)
        {
            // TO-DO: InsertRow후 그리드 컬러 변경
            //uniGrid1.SSSetProtected(gridCol.LastNum, pvStartRow, pvEndRow);
        }
        #endregion

        #region ■ 3.4 InitControlBinding
        protected override void InitControlBinding()
        {
            TdsH_DILIG.E_H_DILIG_HDataTable uniSingTB1 = this.cstdsDILIG.E_H_DILIG_H;

                uniBase.UData.addDataBinding(txtRemark, uniSingTB1.remarkColumn);
                uniBase.UData.addDataBinding(cboDiligType,  uniSingTB1.dilig_typeColumn);
                uniBase.UData.addDataBinding(cboReportType,  uniSingTB1.report_typeColumn);
                uniBase.UData.addDataBinding(cboErpIfRtn,  uniSingTB1.approval_rtnColumn);
                uniBase.UData.addDataBinding(dtIsrtDt,  uniSingTB1.isrt_dtColumn);
                uniBase.UData.addDataBinding(txtRefNo,  uniSingTB1.ref_noColumn);

            // Grid binding with global dataset variable.
            this.InitSpreadSheet();
            this.uniGrid1.uniGridSetDataBinding(this.cstdsDILIG.E_H_DILIG_D);

        }
        #endregion

        #endregion

        #region ▶ 4. Toolbar method part

        #region ■ 4.1 Common Fnction group

        #region ■■ 4.1.1 OnFncQuery(old:FncQuery)

        protected override bool OnFncQuery()
        {

            return DBQuery();
        }

        protected override bool OnPostFncQuery()
        {
            if (strRefNo != "")
            {
                popDiligReqNo.CodeValue = "";
                this.dtIsrtDt.uniValue = uniBase.UDate.GetDBServerDateTime();
            }

            return base.OnPostFncQuery();
        }

        #endregion

        #region ■■ 4.1.2 OnFncSave(old:FncSave)
        protected override bool OnPreFncSave()
        {
            //strreportvalue = rdoReportType.Value.ToString();
            if (strRefNo != "")
            {
                txtRemark.Value = txtRemark.Text + " ";
            }

            diligtype = cboDiligType.Value.ToString();
            reporttype = cboReportType.Value.ToString();
            remark = txtRemark.Text;
            refno = txtRefNo.Text;

            return base.OnPreFncSave();
        }
        protected override bool OnFncSave()
        {
            

            //TO-DO : code business oriented logic
            //if (rdoReportType.Value != null)
            //{
            //    strreportvalue = rdoReportType.Value.ToString();
            //}
            return DBSave();
        }
        #endregion

        #endregion

        #region ■ 4.2 Single Fnction group

        #region ■■ 4.2.1 OnFncNew(old:FncNew)

        protected override bool OnFncNew()
        {
            //TO-DO : code business oriented logic
            cboReportType.Value = "1";
            cboDiligType.Value = "1";
            dtIsrtDt.Value = uniBase.UDate.GetDBServerDateTime();
            uniBase.UCommon.ChangeFieldLockAttribute(this.txtRemark, enumDef.FieldLockAttribute.Normal);
            txtRemark.FieldType = enumDef.FieldType.Default;
            dtBaseDt.Value = uniBase.UDate.GetDBServerDateTime();
            uniBase.UCommon.ChangeFieldLockAttribute(dtBaseDt, enumDef.FieldLockAttribute.Normal);
            dtBaseDt.FieldType = enumDef.FieldType.Default;
            uniBase.UCommon.ChangeFieldLockAttribute(cboDiligType, enumDef.FieldLockAttribute.Required);
            cboDiligType.FieldType = enumDef.FieldType.NotNull;
             uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Required);
            cboReportType.FieldType = enumDef.FieldType.NotNull;
            uniBase.UCommon.ChangeFieldLockAttribute(popEmpNo, enumDef.FieldLockAttribute.Required );
            popEmpNo.FieldType = enumDef.FieldType.NotNull;
            uniBase.UCommon.DisableButton(this.btnApproval, true);//*
            uniBase.UCommon.SetToolBarAll(true);
            //txtRemark.FieldType = enumDef.FieldType.Default;
            cboReportType.Value = "2";
            uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
            cboReportType.FieldType = enumDef.FieldType.ReadOnly;

            
            return true;
        }

        #endregion

        #region ■■ 4.2.2 OnFncDelete(old:FncDelete)

        protected override bool OnFncDelete()
        {
            //TO-DO : code business oriented logic

            return DBDelete(); 
        }

        #endregion

        #region ■■ 4.2.3 OnFncCopy(old:FncCopy)

        protected override bool OnFncCopy()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.4 OnFncFirst(No implementation)

        #endregion

        #region ■■ 4.2.5 OnFncPrev(old:FncPrev)

        protected override bool OnFncPrev()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.6 OnFncNext(old:FncNext)

        protected override bool OnFncNext()
        {
            //TO-DO : code business oriented logic
            return true;
        }

        #endregion

        #region ■■ 4.2.7 OnFncLast(No implementation)

        #endregion

        #endregion

        #region ■ 4.3 Grid Fnction group

        #region ■■ 4.3.1 OnFncInsertRow(old:FncInsertRow)
        protected override bool OnFncInsertRow()
        {
            //TO-DO : code business oriented logic
            this.uniGrid1.Focus();
            
            uniBase.UCommon.ChangeFieldLockAttribute(cboDiligType, enumDef.FieldLockAttribute.Protected);
            cboDiligType.FieldType = enumDef.FieldType.ReadOnly;
            //uniBase.UCommon.ChangeFieldLockAttribute(rdoReportType, enumDef.FieldLockAttribute.Protected);
            //rdoReportType.FieldType = enumDef.FieldType.ReadOnly;
            if (dtBaseDt.Value != null)
            {
                uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value = dtBaseDt.Value;
                uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value = dtBaseDt.Value;

            }
            else
            {
                uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value = uniBase.UDate.GetDBServerDateTime();
                uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value = uniBase.UDate.GetDBServerDateTime();
            }
            uniGrid1.ActiveRow.Cells["cont"].Value = txtRemark.Text;

            uniGrid1.setFocusCell("dilig_emp_no", uniGrid1.ActiveRow.Index);

        

            if (cboDiligType.Value.ToString() == "3")
            {
                uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                cboReportType.FieldType = enumDef.FieldType.ReadOnly;
                if (uniGrid1.Rows.Count > 0)
                {
                    uniGrid1.SpreadLock("dilig_fr");
                    uniGrid1.SpreadLock("dilig_to");
                }
                if (uniGrid1.Rows.Count > 1)
                {
                    uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK,"근태구분이 일반근태일 경우 한 건만 등록이 가능합니다.");
                    uniGrid1.deleteRow(1,1);
                    return false;
                }
            }
            else if (cboDiligType.Value.ToString() == "1")
            {
                cboReportType.Value = "2";
                uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                cboReportType.FieldType = enumDef.FieldType.ReadOnly;               
            } 
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Required);
                cboReportType.FieldType = enumDef.FieldType.NotNull;
            }
            
        

            return true;
        }
        #endregion

        #region ■■ 4.3.2 OnFncDeleteRow(old:FncDeleteRow)
        protected override bool OnFncDeleteRow()
        {
            //TO-DO : code business oriented logic
            
            if (uniGrid1.Rows.Count == 0)
            {
                uniBase.UCommon.ChangeFieldLockAttribute(cboDiligType, enumDef.FieldLockAttribute.Required);
                cboDiligType.FieldType = enumDef.FieldType.NotNull;
                if (txtRefNo.Text == "")
                {
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Required);
                    cboReportType.FieldType = enumDef.FieldType.NotNull;
                }
            }
            return true;
        }
        #endregion

        #region ■■ 4.3.3 OnFncCancel(old:FncCancel)
        protected override bool OnFncCancel()
        {
            
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #region ■■ 4.3.4 OnFncCopyRow(old:FncCopy)
        protected override bool OnFncCopyRow()
        {
            //TO-DO : code business oriented logic
            return true;
        }
        #endregion

        #endregion

        #region ■ 4.4 Db function group

        #region ■■ 4.4.1 DBQuery(Common)

        private bool DBQuery()
        {
            
            cstdsDILIG.Clear();

            DataSet dsQuery_h = null;
            DataSet dsQuery = null;
            try
            {
                using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_HR_H4006M3_KO883_H"))
                {
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@DILIG_REQ_NO", SqlDbType.NVarChar, 20, popDiligReqNo.CodeValue.ToString().Trim());
                    dsQuery_h = uniBase.UDatabase.ExecuteDataSet(iuniCommand);
                }
                if (dsQuery_h == null || dsQuery_h.Tables.Count == 0 || dsQuery_h.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                    return false;
                }
                else
                {
                    
                    
                    
                    uniBase.UData.MergeDataTable(cstdsDILIG.E_H_DILIG_H, dsQuery_h.Tables[0], false, MissingSchemaAction.Ignore);

                    if (strRefNo != "")
                    {

                        cstdsDILIG.E_H_DILIG_H.Rows[0]["report_type"] = "2";
                        cstdsDILIG.E_H_DILIG_H.Rows[0]["ref_no"] = strRefNo;
                        cstdsDILIG.E_H_DILIG_H.Rows[0]["isrt_dt"] = uniBase.UDate.GetDBServerDateTime();
                        cstdsDILIG.E_H_DILIG_H.Rows[0]["approval_rtn"] = "F";
                        strdilig = cstdsDILIG.E_H_DILIG_H.Rows[0]["dilig_type"].ToString();
                        strreport = cstdsDILIG.E_H_DILIG_H.Rows[0]["report_type"].ToString();
                        strapproval = cstdsDILIG.E_H_DILIG_H.Rows[0]["approval_rtn"].ToString();
                        strRefNo = strRefNo.ToString();
                        uniBase.UCommon.ChangeFieldLockAttribute(cboDiligType, enumDef.FieldLockAttribute.Protected);
                        cboDiligType.FieldType = enumDef.FieldType.ReadOnly;
                        uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                        cboReportType.FieldType = enumDef.FieldType.ReadOnly;
                    }
                    

                    cboReportType.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["report_type"].ToString();
                    cboDiligType.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["dilig_type"].ToString();
                    txtRemark.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["remark"].ToString();
                    dtIsrtDt.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["isrt_dt"].ToString();
                    txtRefNo.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["ref_no"].ToString();

                    strquery = cboDiligType.Value.ToString();

                    if (cstdsDILIG.E_H_DILIG_H.Rows[0]["approval_rtn"].ToString() == "" )
                    {
                        cboErpIfRtn.Value = "F";
                    }
                    else
                    {
                        cboErpIfRtn.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["approval_rtn"].ToString();
                    }

                   
                    
                    

                    //  GRID 조회부분
                    using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_HR_H4006M3_KO883_D"))
                    
                    {
                        uniBase.UDatabase.AddInParameter(iuniCommand, "@DILIG_REQ_NO", SqlDbType.NVarChar, 20, popDiligReqNo.CodeValue.ToString().Trim());
                        dsQuery = uniBase.UDatabase.ExecuteDataSet(iuniCommand);
                    }
                    if (dsQuery == null || dsQuery.Tables.Count == 0 || dsQuery.Tables[0].Rows.Count == 0)
                    {
                        uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                        return false;
                    }
                    else
                    {

                        uniBase.UData.MergeDataTable(cstdsDILIG.E_H_DILIG_D, dsQuery.Tables[0], false, MissingSchemaAction.Ignore);

                        

                        for(int i=0 ; i<uniGrid1.Rows.Count ; i++)
                        {
                          uniGrid1.Rows[i].Cells["dilig_fr"].Value = cstdsDILIG.E_H_DILIG_D.Rows[i]["dilig_fr"].ToString();
                          uniGrid1.Rows[i].Cells["dilig_to"].Value = cstdsDILIG.E_H_DILIG_D.Rows[i]["dilig_to"].ToString();
                          uniGrid1.Rows[i].Cells["dilig_time"].Value = cstdsDILIG.E_H_DILIG_D.Rows[i]["dilig_time"].ToString();
                        }

                        strReportType = cstdsDILIG.E_H_DILIG_H.Rows[0]["report_type"].ToString();

                        if (strRefNo != "")
                        
                        {
                            popDiligReqNo.CodeValue = "";
                            if (uniGrid1.Rows.Count > 0)
                            {
                                uniGrid1.SpreadUnLock(5, 0, 9, uniGrid1.Rows.Count - 1);
                                uniGrid1.SSSetRequired("dilig_dt_to", 0, uniGrid1.Rows.Count - 1);
                                uniGrid1.SpreadLock("dilig_time", 0, uniGrid1.Rows.Count - 1);
                            }

                            uniBase.UCommon.ChangeFieldLockAttribute(cboDiligType, enumDef.FieldLockAttribute.Protected);
                            cboDiligType.FieldType = enumDef.FieldType.ReadOnly;
                            uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                            cboReportType.FieldType = enumDef.FieldType.ReadOnly;
                            uniBase.UCommon.ChangeFieldLockAttribute(popEmpNo, enumDef.FieldLockAttribute.Required);
                            popEmpNo.FieldType = enumDef.FieldType.NotNull;
                            uniBase.UCommon.DisableButton(this.btnApproval, true);//*
                            uniBase.UCommon.SetToolBarAll(true);
                            uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Normal);
                            txtRemark.FieldType = enumDef.FieldType.Default;
                            dtBaseDt.Value = uniBase.UDate.GetDBServerDateTime();
                            uniBase.UCommon.ChangeFieldLockAttribute(dtBaseDt, enumDef.FieldLockAttribute.Normal);
                            dtBaseDt.FieldType = enumDef.FieldType.Default;
                        }
                        else
                        {
                         

                            //결재된 상태인 경우 보고구분을 제외한 모두 LOCK
                            if ((cboErpIfRtn.Value.ToString() == "F" || cboErpIfRtn.Value.ToString() == "8" || cboErpIfRtn.Value.ToString() == "0").Equals(false))
                            {
                                if (uniGrid1.Rows.Count > 0)
                                {
                                    uniGrid1.SpreadLock(0, 0, 9, uniGrid1.Rows.Count - 1);
                                }

                                uniBase.UCommon.ChangeFieldLockAttribute(cboDiligType, enumDef.FieldLockAttribute.Protected);
                                cboDiligType.FieldType = enumDef.FieldType.ReadOnly;
                                uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Protected);
                                txtRemark.FieldType = enumDef.FieldType.ReadOnly;
                                dtBaseDt.Value = uniBase.UDate.GetDBServerDateTime();
                                uniBase.UCommon.ChangeFieldLockAttribute(dtBaseDt, enumDef.FieldLockAttribute.Protected);
                                dtBaseDt.FieldType = enumDef.FieldType.ReadOnly;
                                uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                                cboReportType.FieldType = enumDef.FieldType.ReadOnly;
                                uniBase.UCommon.ChangeFieldLockAttribute(popEmpNo, enumDef.FieldLockAttribute.Protected);
                                popEmpNo.FieldType = enumDef.FieldType.ReadOnly;
                                uniBase.UCommon.DisableButton(this.btnApproval, false); //*
                                uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, false);
                                uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Delete, false);
                                uniBase.UCommon.SetToolBarMultiAll(false);


                            }
                            //결재상신된 상태가 아니면 근태구분은 LOCK 나머지는 UNLOCK
                            else
                            {
                                if (uniGrid1.Rows.Count > 0)
                                {
                                    uniGrid1.SpreadUnLock(0, 0, 9, uniGrid1.Rows.Count - 1);
                                    uniGrid1.SpreadLock("dilig_emp_no", 0, uniGrid1.Rows.Count - 1);
                                    uniGrid1.SpreadLock("dilig_cd", 0, uniGrid1.Rows.Count - 1);
                                    uniGrid1.SpreadLock("dilig_dt_fr", 0, uniGrid1.Rows.Count - 1);
                                    uniGrid1.SSSetRequired("dilig_dt_to", 0, uniGrid1.Rows.Count - 1);
                                    uniGrid1.SpreadLock("dilig_time", 0, uniGrid1.Rows.Count - 1);
                                    uniGrid1.SpreadLock("name", 0, uniGrid1.Rows.Count - 1);
                                    uniGrid1.SpreadLock("dilig_nm", 0, uniGrid1.Rows.Count - 1);
                                    if (cboDiligType.Value.ToString() == "3")
                                    {
                                        uniGrid1.SpreadLock("dilig_fr", 0, uniGrid1.Rows.Count - 1);
                                        uniGrid1.SpreadLock("dilig_to", 0, uniGrid1.Rows.Count - 1);
                                    }
                                }
                                uniBase.UCommon.DisableButton(this.btnApproval, true); //*
                                if (cboDiligType.Value.ToString() == "3" || cboDiligType.Value.ToString() == "1")
                                {
                                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                                    cboReportType.FieldType = enumDef.FieldType.ReadOnly;
                                }
                                else
                                {
                                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Required);
                                    cboReportType.FieldType = enumDef.FieldType.NotNull;
                                }
                                uniBase.UCommon.ChangeFieldLockAttribute(cboDiligType, enumDef.FieldLockAttribute.Protected);
                                cboDiligType.FieldType = enumDef.FieldType.ReadOnly;
                                uniBase.UCommon.ChangeFieldLockAttribute(popEmpNo, enumDef.FieldLockAttribute.Required);
                                popEmpNo.FieldType = enumDef.FieldType.NotNull;
                                uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Normal);
                                txtRemark.FieldType = enumDef.FieldType.Default;
                                dtBaseDt.Value = uniBase.UDate.GetDBServerDateTime();
                                uniBase.UCommon.ChangeFieldLockAttribute(dtBaseDt, enumDef.FieldLockAttribute.Normal);
                                dtBaseDt.FieldType = enumDef.FieldType.Default;
                                uniBase.UCommon.SetToolBarAll(true);
                              
                               
                            }
                        }                
                    
                  }

                    
                }


                DataSet DSDrafter = uniBase.UDataAccess.CommonQueryRs("DISTINCT A.REQ_EMP_NO AS REQ_EMP_NO, B.NAME AS NAME", " H4006M3_H_KO883 A(NOLOCK) INNER JOIN HAA010T B ON A.REQ_EMP_NO = B.EMP_NO ",
                                    "A.DILIG_REQ_NO=" + uniBase.UCommon.FilterVariable(popDiligReqNo.CodeValue.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));
                if (DSDrafter.Tables[0].Rows.Count > 0)
                {
                    if (DSDrafter.Tables[0].Rows[0]["REQ_EMP_NO"].ToString() != "")
                    {
                        popEmpNo.CodeValue = DSDrafter.Tables[0].Rows[0]["REQ_EMP_NO"].ToString();
                        popEmpNo.CodeName = DSDrafter.Tables[0].Rows[0]["NAME"].ToString();
                    }
                }
                else
                {
                    popEmpNo.CodeValue = string.Empty;
                    popEmpNo.CodeName = string.Empty;
                }



                DataSet DsRef = uniBase.UDataAccess.CommonQueryRs("DISTINCT REF_NO "," H4006M3_H_KO883(NOLOCK) ",
                                    "REF_NO=" + uniBase.UCommon.FilterVariable(popDiligReqNo.CodeValue.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));
                if (DsRef.Tables[0].Rows.Count > 0)
                {
                    if (DsRef.Tables[0].Rows[0]["REF_NO"].ToString() != "")
                    {
                        if (uniGrid1.Rows.Count > 0)
                        {
                            uniGrid1.SpreadLock(0, 0, 9, uniGrid1.Rows.Count - 1);
                        }
                        uniBase.UCommon.ChangeFieldLockAttribute(txtRemark, enumDef.FieldLockAttribute.Protected);
                        txtRemark.FieldType = enumDef.FieldType.ReadOnly;
                        dtBaseDt.Value = uniBase.UDate.GetDBServerDateTime();
                        uniBase.UCommon.ChangeFieldLockAttribute(dtBaseDt, enumDef.FieldLockAttribute.Protected);
                        dtBaseDt.FieldType = enumDef.FieldType.ReadOnly;
                        uniBase.UCommon.ChangeFieldLockAttribute(cboDiligType, enumDef.FieldLockAttribute.Protected);
                        cboDiligType.FieldType = enumDef.FieldType.ReadOnly;
                        uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                        cboReportType.FieldType = enumDef.FieldType.ReadOnly;
                        uniBase.UCommon.SetToolBarCommon(enumDef.ToolBitCommon.Save, false);
                        uniBase.UCommon.SetToolBarSingle(enumDef.ToolBitSingle.Delete, false);
                        uniBase.UCommon.SetToolBarMultiAll(false);
                    }
                }
                
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {
                if (cstdsDILIG != null) cstdsDILIG.Dispose();
            }
          
            if(strRefNo != "")
            {
                popDiligReqNo.CodeValue = "";
                strreportvalue = "2";
            }
            
            cboReportType.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["report_type"].ToString();
            cboDiligType.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["dilig_type"].ToString();
            txtRemark.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["remark"].ToString();
            dtIsrtDt.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["isrt_dt"].ToString();
            txtRefNo.Value = cstdsDILIG.E_H_DILIG_H.Rows[0]["ref_no"].ToString();
            if (strRefNo == "")
            {
                strdilig = "";
                strreport = "";
                strapproval = "";
            }
            
            
            return true;
        }

        #endregion

        #region ■■ 4.4.2 DBDelete(Single)

        private bool DBDelete()
        {
            //wsMyBizFL.TypedDataSet isettdsTypedDataSet = new wsMyBizFL.TypedDataSet();

            try
            {
                string istrCommandSend = "D";

                using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("dbo.USP_HR_H4006M3_KO883_CUD_H"))
                {


                    uniBase.UDatabase.AddInParameter(iuniCommand, "@CUD_CHAR", SqlDbType.NVarChar, 1, istrCommandSend.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@DILIG_REQ_NO", SqlDbType.NVarChar, 20, popDiligReqNo.CodeValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REMARK", SqlDbType.NVarChar, 40, txtRemark.Text.ToString());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REF_NO", SqlDbType.NVarChar, 20, txtRefNo.Text.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REQ_EMP_NO", SqlDbType.NVarChar, popEmpNo.CodeValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@DILIG_TYPE", SqlDbType.NVarChar, 1, cboDiligType.Value.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REPORT_TYPE", SqlDbType.NVarChar, 1, cboReportType.Value.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PARAM_USER_ID", SqlDbType.NVarChar, 13, CommonVariable.gUsrID);
                    uniBase.UDatabase.AddOutParameter(iuniCommand, "@MSG_CD", SqlDbType.NVarChar, 6);
                    uniBase.UDatabase.AddOutParameter(iuniCommand, "@MESSAGE", SqlDbType.NVarChar, 200);
                    uniBase.UDatabase.AddReturnParameter(iuniCommand, "RETURN_VALUE", SqlDbType.Int, 1);
                    uniBase.UDatabase.ExecuteNonQuery(iuniCommand, false);
                    int iReturn = (int)uniBase.UDatabase.GetParameterValue(iuniCommand, "RETURN_VALUE");
                    if (iReturn < 0)
                    {
                        string sMsgCd = uniBase.UDatabase.GetParameterValue(iuniCommand, "@MSG_CD") as string;
                        string sMessage = uniBase.UDatabase.GetParameterValue(iuniCommand, "@MESSAGE") as string;
                        if (string.IsNullOrEmpty(sMsgCd)) sMsgCd = "DT9999";
                        uniBase.UMessage.DisplayMessageBox(sMsgCd, MessageBoxButtons.OK, sMessage);
                    }
                }
            }
            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }
            return true;

        }

        #endregion

        #region ■■ 4.4.3 DBSave(Common)

        private bool DBSave()
        {
            if (strAPPROVAL == "Y")
            {
                cboReportType.Value = cboReportType.Value;
                cboDiligType.Value = cboDiligType.Value;
                diligtype = cboDiligType.Value.ToString();
                reporttype = cboReportType.Value.ToString();
            }
            else
            {
                cboReportType.Value = reporttype;
                cboDiligType.Value = diligtype;
            }
           
            if (uniGrid1.Rows.Count <= 0)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "저장할 근태사항이 존재하지 않습니다.");
                return false;

            }

            if (popEmpNo.CodeValue.ToString().Trim() == "" || popEmpNo.CodeValue.ToString().Trim() == null)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK,"등록자/기안자를 확인하세요.");
                return false;
            }

            DataSet ds = uniBase.UDataAccess.CommonQuerySQL(string.Format(@"
                            select top 1 emp_no from HAA010T (nolock)
                            where emp_no = {0}"
                       , uniBase.UCommon.FilterVariable(popEmpNo.CodeValue.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));

            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "등록자/기안자를 확인하세요.");
                return false;
            }


            DataTable dtchk = null;

            dtchk = cstdsDILIG.E_H_DILIG_D;

            DataTable dtchkAfter = dtchk.DefaultView.ToTable(true, "dilig_cd", "dilig_emp_no","dilig_dt_fr");
            if (dtchk.Rows.Count > dtchkAfter.Rows.Count)
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "중복된 DATA가 존재합니다.");
                return false;
            }

            //시간계산
            for (int iRow = 0; iRow < uniGrid1.Rows.Count; iRow++)
            {
                if (uniGrid1.Rows[iRow].Cells["dilig_fr"].Text.Replace(":", "").Trim() != "" && uniGrid1.Rows[iRow].Cells["dilig_to"].Text.Replace(":", "").Trim() != ""
                    && uniGrid1.Rows[iRow].Cells["dilig_fr"].Text.Replace(":", "").Trim() != "____" && uniGrid1.Rows[iRow].Cells["dilig_to"].Text.Replace(":", "").Trim() != "____")
                {
                    string dilig_dt_fr = uniGrid1.Rows[iRow].Cells["dilig_dt_fr"].Text.ToString().Replace("-", "").Substring(0, 8);
                    string dilig_dt_to = uniGrid1.Rows[iRow].Cells["dilig_dt_to"].Text.ToString().Replace("-", "").Substring(0, 8);
                    string dilig_f = uniGrid1.Rows[iRow].Cells["dilig_fr"].Value.ToString().Replace(":", "").Substring(0, 4);
                    string dilig_t = uniGrid1.Rows[iRow].Cells["dilig_to"].Value.ToString().Replace(":", "").Substring(0, 4);
                    string dilig_from = dilig_dt_fr + dilig_f;
                    string dilig_to = dilig_dt_to + dilig_t;
                    DateTime dtDiligFr = DateTime.ParseExact(dilig_from, "yyyyMMddHHmm", System.Globalization.CultureInfo.InvariantCulture);
                    DateTime dtDiligTo = DateTime.ParseExact(dilig_to, "yyyyMMddHHmm", System.Globalization.CultureInfo.InvariantCulture);

                    TimeSpan result = new TimeSpan(0, 24, 0);
                    result = (dtDiligTo - dtDiligFr);

                    uniGrid1.Rows[iRow].Cells["dilig_time"].Value = result.ToString().Replace(":", "").Substring(0, 4);
                    uniGrid1.Rows[iRow].Cells["dilig_fr"].Value = dilig_f;
                    uniGrid1.Rows[iRow].Cells["dilig_to"].Value = dilig_t;

                }
                else
                {
                    uniGrid1.ActiveRow.Cells["dilig_time"].Value = "";
                }
                if (uniGrid1.Rows[iRow].Cells["dilig_fr"].Text.Replace(":", "").Trim() != "" && uniGrid1.Rows[iRow].Cells["dilig_fr"].Text.Replace(":", "").Trim() != "____")
                {
                    uniGrid1.Rows[iRow].Cells["dilig_fr"].Value = uniGrid1.Rows[iRow].Cells["dilig_fr"].Value.ToString().Replace(":", "").Substring(0, 4);
                }
                if (uniGrid1.Rows[iRow].Cells["dilig_to"].Text.Replace(":", "").Trim() != "" && uniGrid1.Rows[iRow].Cells["dilig_to"].Text.Replace(":", "").Trim() != "____")
                {
                    uniGrid1.Rows[iRow].Cells["dilig_to"].Value = uniGrid1.Rows[iRow].Cells["dilig_to"].Value.ToString().Replace(":", "").Substring(0, 4);
                }

                DataSet dsTemp = null;
                string sbSQL2 = string.Format(@"
                                                    SELECT A.DILIG_CD, A.DILIG_NM, DAY_TIME, HOLIDAY_APPLY
                                                    FROM HCA010T A 
                                                    WHERE  A.dilig_cd = {0}
                                                    "
                     , uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_cd"].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));
                dsTemp = uniBase.UDataAccess.CommonQuerySQL(sbSQL2.ToString());
                if (dsTemp.Tables[0].Rows.Count > 0)
                {
                    switch (dsTemp.Tables[0].Rows[0]["DAY_TIME"].ToString())
                    {
                        case "1":
                            this.uniGrid1.Rows[iRow].Cells["dilig_time"].Value = "0000";
                            break;

                        case "2":
                            //this.uniGrid1.Rows[iRow].Cells["dilig_time"].Value = "0000";
                            break;

                        default:
                            this.uniGrid1.Rows[iRow].Cells["dilig_time"].Value = "0400";
                            break;
                    }
                }
            }


            
            for (int iRow = 0; iRow < uniGrid1.Rows.Count; iRow++)
            {
                // 휴무여부 체크
                DataSet dsChk = null;
                DataSet dsChk2 = null;
                DataSet dsChk3 = null;
                DataSet dsChk4 = null;
                DataSet dsHoli = null;
                DataSet dsHoli2 = null;

                if (cboDiligType.Value.ToString() == "3" || cboDiligType.Value.ToString() == "1")
                {
                    if (uniGrid1.Rows[iRow].Cells["dilig_dt_fr"].Value != null)
                    {
                        string strSQL = string.Format(@" 
                                              SELECT c.HOLI_TYPE 
                                              FROM haa010t a(NOLOCK) left outer join hca040t b(NOLOCK)  on (a.emp_no = b.emp_no) inner join hca020t c(NOLOCK)  on (b.WK_TYPE = c.WK_TYPE) 
                                              WHERE (a.retire_dt >= getdate()  or  a.retire_dt is null )
                                                    and b.chang_dt = (select max(chang_dt) from hca040t where emp_no=a.emp_no and chang_dt <= getdate() )
                                                    and c.HOLI_TYPE NOT IN ('D') 
                                                    and b.emp_no = {0}
                                                    and c.DATE = {1} "
                             , uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                             , uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_dt_fr"].Value.ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)

                                                    );
                        dsChk = uniBase.UDataAccess.CommonQuerySQL(strSQL);
                    }
                    
                    if ((dsChk != null) && (uniGrid1.Rows[iRow].Cells["dilig_cd"].Value.ToString().Trim() != ""))
                    {
                        if (dsChk.Tables[0].Rows.Count > 0)
                        {
                            dsChk2 = uniBase.UDataAccess.CommonQueryRs(" HOLIDAY_APPLY ", "HCA010T",
                                            " DILIG_CD = "
                                            + uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_cd"].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                                           );
                            if (dsChk2.Tables[0].Rows[0]["HOLIDAY_APPLY"].ToString().ToUpper().Trim() == "N")
                            {
                                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, uniGrid1.Rows[iRow].Cells["name"].Value.ToString() + " 의 "+
                                    uniGrid1.Rows[iRow].Cells["dilig_nm"].Value.ToString() + "는 휴일등록이 불가능합니다.");

                                return false;
                            }
                        }

                    }

//                    if (uniGrid1.Rows[iRow].Cells["dilig_dt_to"].Value != null)
//                    {
//                        string strSQL = string.Format(@" 
//                                              SELECT c.HOLI_TYPE 
//                                              FROM haa010t a(NOLOCK) left outer join hca040t b(NOLOCK)  on (a.emp_no = b.emp_no) inner join hca020t c(NOLOCK)  on (b.WK_TYPE = c.WK_TYPE) 
//                                              WHERE (a.retire_dt >= getdate()  or  a.retire_dt is null )
//                                                    and b.chang_dt = (select max(chang_dt) from hca040t where emp_no=a.emp_no and chang_dt <= getdate() )
//                                                    and c.HOLI_TYPE NOT IN ('D') 
//                                                    and b.emp_no = {0}
//                                                    and c.DATE = {1} "
//                             , uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
//                             , uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_dt_to"].Value.ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)

//                                                    );
//                        dsChk3 = uniBase.UDataAccess.CommonQuerySQL(strSQL);
//                    }

//                    if ((dsChk3 != null) && (uniGrid1.Rows[iRow].Cells["dilig_cd"].Value.ToString().Trim() != ""))
//                    {
//                        if (dsChk3.Tables[0].Rows.Count > 0)
//                        {
//                            dsChk4 = uniBase.UDataAccess.CommonQueryRs(" HOLIDAY_APPLY ", "HCA010T",
//                                            " DILIG_CD = "
//                                            + uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_cd"].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
//                                           );
//                            if (dsChk4.Tables[0].Rows[0]["HOLIDAY_APPLY"].ToString().ToUpper().Trim() == "N")
//                            {
//                                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, uniGrid1.Rows[iRow].Cells["name"].Value.ToString() + " 의 " +
//                                                                   uniGrid1.Rows[iRow].Cells["dilig_nm"].Value.ToString() + "는 휴일등록이 불가능합니다.");
//                                return false;
//                            }
//                        }

//                    }

                }
                if (cboDiligType.Value.ToString() == "2")
                {
                    if (uniGrid1.Rows[iRow].Cells["dilig_dt_fr"].Value != null)
                    {
                        if (cboDiligType.Value.ToString() == "2")
                        {
                            dsHoli = uniBase.UDataAccess.CommonQueryRs(" c.HOLI_TYPE",
                                                                        " haa010t a left outer join hca040t b on a.emp_no = b.emp_no " +
                                                                        "inner join hca020t c on b.WK_TYPE = c.WK_TYPE",
                                                                        "(a.retire_dt >= getdate()  or  a.retire_dt is null ) " +
                                                                        " and b.chang_dt = (select max(chang_dt) from hca040t where emp_no=a.emp_no and chang_dt <= getdate() )" +
                                                                        " and b.emp_no like " + uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                                        " and c.DATE = " + uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_dt_fr"].Value.ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                                        " and c.HOLI_TYPE NOT IN ('D') "
                                                                       );
                        }
                    }
                    if (dsHoli == null)
                    {
                        uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, uniGrid1.Rows[iRow].Cells["name"].Value.ToString() + " 의 시작일이 휴일이 아닙니다.");
                        return false;
                    }
                    else
                    {
                        if (dsHoli.Tables[0].Rows.Count <= 0)
                        {
                            uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, uniGrid1.Rows[iRow].Cells["name"].Value.ToString() + " 의 시작일이 휴일이 아닙니다.");
                            return false;
                        }
                    }

                    //if (uniGrid1.Rows[iRow].Cells["dilig_dt_to"].Value != null)
                    //{
                    //    if (cboDiligType.Value.ToString() == "2")
                    //    {
                    //        dsHoli2 = uniBase.UDataAccess.CommonQueryRs(" c.HOLI_TYPE",
                    //                                                    " haa010t a left outer join hca040t b on a.emp_no = b.emp_no " +
                    //                                                    "inner join hca020t c on b.WK_TYPE = c.WK_TYPE",
                    //                                                    "(a.retire_dt >= getdate()  or  a.retire_dt is null ) " +
                    //                                                    " and b.chang_dt = (select max(chang_dt) from hca040t where emp_no=a.emp_no and chang_dt <= getdate() )" +
                    //                                                    " and b.emp_no like " + uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                    //                                                    " and c.DATE = " + uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_dt_to"].Value.ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                    //                                                    " and c.HOLI_TYPE NOT IN ('D') "
                    //                                                   );
                    //    }
                    //}
                    //if (dsHoli2 == null)
                    //{
                    //    uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, uniGrid1.Rows[iRow].Cells["name"].Value.ToString() + " 의 종료일이 휴일이 아닙니다.");
                    //    return false;
                    //}
                    //else
                    //{
                    //    if (dsHoli2.Tables[0].Rows.Count <= 0)
                    //    {
                    //        uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, uniGrid1.Rows[iRow].Cells["name"].Value.ToString() + " 의 종료일이 휴일이 아닙니다.");
                    //        return false;
                    //    }
                    //}
                }




                //근태코드가 근태구분에 있는 것이 맞는지 체크
                DataSet dsDilig = uniBase.UDataAccess.CommonQueryRs(" A.REFERENCE ", " B_CONFIGURATION A(nolock) INNER JOIN HCA010T B ON A.REFERENCE = B.DILIG_CD AND A.MAJOR_CD='XH002' ",
                                                                    " A.MINOR_CD = " +  uniBase.UCommon.FilterVariable(diligtype, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                                    " AND DILIG_CD = " + uniBase.UCommon.FilterVariable(uniGrid1.Rows[iRow].Cells["dilig_cd"].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                                                                   );
                if (dsDilig.Tables[0].Rows.Count <= 0)
                {
                    string strMessage = uniGrid1.Rows[iRow].Cells["dilig_nm"].Value.ToString() + "은(는) 근태구분과 맞지않는 근태입니다.";
                    uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, strMessage);
                    return  false;
                }
            }

          

/*
            //자동채번2018-07-19 msk 년도(2자리)+월+일+000*
            if (popDiligReqNo.CodeValue.ToString().Trim() == ""|| strdilig !="")
            {
                 DateTime dtTemp = uniBase.UDate.GetDBServerDateTime();
                string strDate = dtTemp.ToString(CommonVariable.CDT_YYYYMMDD).Substring(2, 6);

                DataSet dsChg = uniBase.UDataAccess.CommonQueryRs(" * ", " H4006M3_H_KO883(nolock) ", " DILIG_REQ_NO = " + "'AT'+'" + strDate + "'" + "+" + "'0001'");

                if (dsChg != null && dsChg.Tables[0].Rows.Count > 0)
                {
                    DataSet dsTemp_Qry = new DataSet();

                    string strSQL = string.Format(@"
                                                 SELECT TOP 1 Right('0000' + RTrim(( SELECT substring((select MAX (DILIG_REQ_NO) 
                                                                                      from H4006M3_H_KO883 WHERE DILIG_REQ_NO LIKE 'AT'+ '" + strDate + "'" + "+'%'),5,8) +1)),4) AS REQ_NO"
                                                   + " FROM H4006M3_H_KO883");
                    dsTemp_Qry = uniBase.UDataAccess.CommonQuerySQL(strSQL);
                    popDiligReqNo.CodeValue = "AT" + strDate + dsTemp_Qry.Tables[0].Rows[0]["REQ_NO"].ToString().Trim();
                    strDiligReqNo = "AT" + strDate + dsTemp_Qry.Tables[0].Rows[0]["REQ_NO"].ToString().Trim();
                }
                else
                {
                    popDiligReqNo.CodeValue = "AT"+strDate + "0001";

                }
            }
*/

            string istrCommandSend = null;

            switch (base.viewDBSaveMode)
            {
                case enumDef.DBSaveMode.CreateMode:
                    istrCommandSend = "C";
                    break;
                case enumDef.DBSaveMode.UpdateMode:
                    istrCommandSend = "U";
                    break;
                default:
                    istrCommandSend = "";
                    break;
            }

            this.uniGrid1.UpdateData();
            DataTable dtis = new DataTable();


            if (strdilig != "")
            {
                istrCommandSend = "C";
            }

            dtis.Merge(cstdsDILIG.I_H_DILIG, false, MissingSchemaAction.Add);
            dtis.Merge(cstdsDILIG.E_H_DILIG_D, false, MissingSchemaAction.Ignore);
            if (strdilig != "")
            {
                for (int i = 0; i < dtis.Rows.Count; i++)
                {
                    if (dtis.Rows[i]["cud_char"].ToString() == "" || strdilig != "")
                    {
                        if (dtis.Rows[i]["cud_char"].ToString() != "D")
                        {
                            dtis.Rows[i]["cud_char"] = "C";
                        }
                        else
                        {
                            dtis.Rows[i]["cud_char"] = "";
                        }

                    }
                    dtis.Rows[i]["dilig_fr"] = dtis.Rows[i]["dilig_fr"].ToString().Replace(":", "");
                    dtis.Rows[i]["dilig_to"] = dtis.Rows[i]["dilig_to"].ToString().Replace(":", "");
                }
                cstdsDILIG.AcceptChanges();
            }

            if (dtis.Select("cud_char = 'D'").Length == dtis.Rows.Count)
            {
                istrCommandSend ="D";
        
            }

            if (istrCommandSend == "C")
            {
                // MSK 2018-08-16 자동채번
                string strDiligReqNo = string.Empty;
                wsPB0C001FL.DsBTransAutoNumber L10_b_auto_numbering = new uniERP.App.UI.HR.H4006M3_KO883.wsPB0C001FL.DsBTransAutoNumber();
                L10_b_auto_numbering.IB_AUTO_NUMBERING.Rows.Add();
                L10_b_auto_numbering.IB_AUTO_NUMBERING[0].auto_no_type = "AT";
                L10_b_auto_numbering.IB_AUTO_NUMBERING[0].effect_from_dt = dtBaseDt.uniValue;
                L10_b_auto_numbering.IB_AUTO_NUMBERING[0].auto_no = null;

                if (popDiligReqNo.CodeValue.ToString().Trim() == "")
                {

                    using (wsPB0C001FL.PB0C001FL iwsPB0C001FL = (wsPB0C001FL.PB0C001FL)
                        uniBase.UConfig.SetWebServiceProxyEnv(new wsPB0C001FL.PB0C001FL()))  // create web method
                    {
                        strDiligReqNo =
                            iwsPB0C001FL.CB0C001_B_TRANS_AUTO_NUMBER(CommonVariable.gStrGlobalCollection, L10_b_auto_numbering);
                    }

                    popDiligReqNo.CodeValue = strDiligReqNo;
                }
                else
                {
                    if (popDiligReqNo.Text.ToString().Length > 0)
                    {
                        if (popDiligReqNo.Text.ToString().ToUpper().Substring(0, 2) == "AT")
                        {
                            //%1 자동채번정보의 prefix값과 같습니다. 수동채번시에는 다른 prefix값을 사용하십시오.
                            uniBase.UMessage.DisplayMessageBox("120714", MessageBoxButtons.OK, popDiligReqNo.uniALT);
                            return false;
                        }
                    }
                }

            }



            try
            {
                //기존 있는 자료인지 체크
                for (int iRow = 0; iRow < dtis.Rows.Count; iRow++)
                {
                    if (dtis.Rows[iRow]["cud_char"].ToString().ToUpper() != "D")
                    {
                        DataSet dsDilig = null;
                        if (cboDiligType.Value.ToString() == "3")
                        {
                            dsDilig = uniBase.UDataAccess.CommonQueryRs(" A.DILIG_REQ_NO ", " H4006M3_D_KO883 A(nolock) INNER JOIN H4006M3_H_KO883 B(NOLOCK) ON A.DILIG_REQ_NO = B.DILIG_REQ_NO ", " DILIG_EMP_NO = "
                                                    + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_emp_no"].ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                    " AND A.DILIG_CD = " + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_cd"].ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                    " AND( CONVERT(NVARCHAR,A.DILIG_DT_FR,23) BETWEEN " + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_dt_fr"].ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                    " AND " + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_dt_to"].ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                    " OR CONVERT(NVARCHAR,A.DILIG_DT_TO,23) BETWEEN " + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_dt_fr"].ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                    " AND " + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_dt_to"].ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +")" +
                                                    " AND A.DILIG_REQ_NO NOT IN (" + uniBase.UCommon.FilterVariable(popDiligReqNo.CodeValue.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " )"
                                                    );

                        }
                        else
                        {
                            dsDilig = uniBase.UDataAccess.CommonQueryRs(" A.DILIG_REQ_NO ", " H4006M3_D_KO883 A(nolock) INNER JOIN H4006M3_H_KO883 B(NOLOCK) ON A.DILIG_REQ_NO = B.DILIG_REQ_NO ", " DILIG_EMP_NO = "
                                                                        + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_emp_no"].ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                                        " AND A.DILIG_CD = " + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_cd"].ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                                        " AND B.REPORT_TYPE = " + uniBase.UCommon.FilterVariable(reporttype, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                                        " AND (CONVERT(NVARCHAR,A.DILIG_DT_FR,23) BETWEEN  " + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_dt_fr"].ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +
                                                                        " AND " + uniBase.UCommon.FilterVariable(dtis.Rows[iRow]["dilig_dt_to"].ToString().Substring(0, 10), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) +")"
                                                                        + " AND A.DILIG_CD NOT IN ('02')"
                                                                        + " AND A.DILIG_REQ_NO NOT IN ( " + uniBase.UCommon.FilterVariable(popDiligReqNo.CodeValue.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " )"
                                                                        );
                        }
                        if (dsDilig != null && dsDilig.Tables[0].Rows.Count > 0)
                        {
                            string strMessage = "이미 " + dtis.Rows[iRow]["name"].ToString() + "은(는) " +
                                                dsDilig.Tables[0].Rows[0]["DILIG_REQ_NO"] + " 로 신청을 하였습니다.";

                            uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, strMessage);
                            
                            return false;
                        }
                    }
                }

                using (uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("dbo.USP_HR_H4006M3_KO883_CUD_H"))
                {
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@TBL_GRID", SqlDbType.Structured, dtis);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@CUD_CHAR", SqlDbType.NVarChar, 1, istrCommandSend.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REMARK", SqlDbType.NVarChar, 40, remark);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REF_NO", SqlDbType.NVarChar, 20, refno);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REQ_EMP_NO", SqlDbType.NVarChar, popEmpNo.CodeValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@DILIG_TYPE", SqlDbType.NVarChar, 1, diligtype);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@REPORT_TYPE", SqlDbType.NVarChar, 1, reporttype);
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@DILIG_REQ_NO", SqlDbType.NVarChar, 20, popDiligReqNo.CodeValue.ToString().Trim());
                    uniBase.UDatabase.AddInParameter(iuniCommand, "@PARAM_USER_ID", SqlDbType.NVarChar, 13, CommonVariable.gUsrID);
                    uniBase.UDatabase.AddOutParameter(iuniCommand, "@MSG_CD", SqlDbType.NVarChar, 6);
                    uniBase.UDatabase.AddOutParameter(iuniCommand, "@MESSAGE", SqlDbType.NVarChar, 200);
                    uniBase.UDatabase.AddReturnParameter(iuniCommand, "RETURN_VALUE", SqlDbType.Int, 1);
                    uniBase.UDatabase.ExecuteNonQuery(iuniCommand, false);
                    int iReturn = (int)uniBase.UDatabase.GetParameterValue(iuniCommand, "RETURN_VALUE");
                    if (iReturn < 0)
                    {
                        string sMsgCd = uniBase.UDatabase.GetParameterValue(iuniCommand, "@MSG_CD") as string;
                        string sMessage = uniBase.UDatabase.GetParameterValue(iuniCommand, "@MESSAGE") as string;
                        if (string.IsNullOrEmpty(sMsgCd)) sMsgCd = "DT9999";
                        uniBase.UMessage.DisplayMessageBox(sMsgCd, MessageBoxButtons.OK, sMessage);
                        return false;
                    }
                    else
                    {
                        strDiligReqNo = popDiligReqNo.CodeValue;
                        if (istrCommandSend == "C" || istrCommandSend == "U")
                        {
                            popDiligReqNo.CodeValue = strDiligReqNo;
                        }
                        else
                        {
                            strDiligReqNo = "";
                            cstdsDILIG.Clear();
                        }
                        popDiligReqNo.CodeValue = strDiligReqNo;
                        strRefNo = "";


            }
                }
            }

            catch (Exception ex)
            {
                bool reThrow = ExceptionControler.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return false;
            }
            finally
            {

            }

            strdilig = "";
            strreport = "";
            strapproval = "";
            

            return true;


        }

        #endregion

        #endregion

        #endregion

        #region ▶ 5. Event method part

        #region ■ 5.1 Single control event implementation group



        #endregion

        #region ■ 5.2 Grid   control event implementation group


        #region ▶ Click >>> AfterCellActivate | AfterRowActivate | AfterSelectChange
        /// <summary>
        /// 기존의 Context메뉴를 보여주기 위해 fpSpread의 MouseDown이벤트와 Click이벤트에서 처리하던 일련의 코드들은
        /// UltraGrid에서는 MouseDown이벤트에서 처리합니다.
        /// fpSpread의 Click이벤트는 UltraGrid의 
        /// AfterCellActivate | AfterRowActivate | AfterSelectChange 이벤트로 변경 하실 수 있습니다.
        /// AfterCellActivate   : isSearch=No (에디터모드)에서 CellSelect모드에서 한 Cell을 클릭했을때 발생하는 이벤트입니다.
        /// AfterRowActivate    : isSearch=Yes (조회전용모드)에서 RowSelect모드에서 한 Row를 클릭했을때 발생하는 이벤트입니다.
        /// AfterSelectChange   : 셀또는 Row를 하나 이상 선택시 발생하는 이벤트입니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_AfterSelectChange(object sender, AfterSelectChangeEventArgs e)
        {
            Debug.WriteLine("AfterSelectChange Event Fired");

            // Check the type to find out whether rows, columns or cells were selected.
            // 그리드가 읽기 전용 일경우는 e.Type은 UltraGridRow이며
            // 그렇지 않을 경우는 e.Type은 UltraGridCell을 반환합니다.
            if (typeof(UltraGridGroupByRow) == e.Type)
            {
                // The activeRow can be a group-by row 
                // Item type is a group-by-row so use Rows property off the Selected to access those items. 
                if (this.uniGrid1.Selected.Rows.Count == 0)
                    Debug.WriteLine("No group-by rows selected.");
                else
                {
                    Debug.WriteLine(this.uniGrid1.Selected.Rows.Count + " group-by rows selected.");
                    Debug.WriteLine("Group by row activated. Description : " + uniGrid1.ActiveRow.Description);
                }
                 
            }
            else if (typeof(UltraGridRow) == e.Type)
            {
                // Item type is a row so use Rows property off the Selected to access those items. 
                if (this.uniGrid1.Selected.Rows.Count == 0)
                    Debug.WriteLine("No rows selected.");
                else
                {
                    Debug.WriteLine(this.uniGrid1.Selected.Rows.Count + " rows selected.");
                    Debug.WriteLine(uniGrid1.ActiveRow.Index.ToString());
                    Debug.WriteLine(uniGrid1.ActiveRow.ListIndex.ToString());
                    // 참고 : 특정컬럼을 기준으로 그룹화 되었을 경우
                    // ActiveRow.Index와 ActiveRow.ListIndex는 서로 다른 값을 반환합니다.
                    // uniGrid1.ActiveRow = uniGrid1.Rows.GetRowWithListIndex(5);
                }
              
            }
            else if (typeof(UltraGridColumn) == e.Type)
            {
                // Item type is a column so use Columns property off the Selected to access those items. 
                if (this.uniGrid1.Selected.Columns.Count == 0)
                    Debug.WriteLine("Columns are being unselected.");
                else
                    Debug.WriteLine(this.uniGrid1.Selected.Columns.Count + " columns are being selected.");
              
            }
            else if (typeof(UltraGridCell) == e.Type)
            {
                // Item type is a cell so use Cells property off the Selected to access those items. 
                if (this.uniGrid1.Selected.Cells.Count == 0)
                    Debug.WriteLine("Columns are being unselected.");
                else
                {
                    Debug.WriteLine(this.uniGrid1.Selected.Cells.Count + " cells are being selected.");
                    Debug.WriteLine("Index of the new active row is  " + this.uniGrid1.ActiveCell.Row.Index.ToString());
                    Debug.WriteLine("Key of the new active col is  " + this.uniGrid1.ActiveCell.Column.Key.ToString());
                }
             
            }
        }

        private void uniGrid1_AfterCellActivate(object sender, EventArgs e)
        {
            Debug.WriteLine("AfterCellActivate Event Fired");
            Debug.WriteLine("Index of the new active row is  " + uniGrid1.ActiveCell.Row.Index.ToString());
            Debug.WriteLine("Key of the new active col is  " + uniGrid1.ActiveCell.Column.Key.ToString());
        
        }

        private void uniGrid1_AfterRowActivate(object sender, EventArgs e)
        {
            Debug.WriteLine("AfterRowActivate Event Fired");
            Debug.WriteLine("Index of the new active row is  " + uniGrid1.ActiveRow.Index.ToString());
          
        }
        #endregion ▶ Click >>> AfterSelectChange

        #region ▶ DblClick >>> DoubleClickCell
        /// <summary>
        /// fpSpread의 DblClick이벤트는 UltraGrid의 DoubleClickCell이벤트로 변경 하실 수 있습니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
            Debug.WriteLine("DoubleClickCell Event Fired");
            Debug.WriteLine("Index of the new active row is  " + e.Cell.Row.Index.ToString());
            Debug.WriteLine("Key of the new active col is  " + e.Cell.Column.Key);
        
        }
        #endregion ▶ DblClick >>> DoubleClickCell

        #region ▶ MouseDown >>> MouseDown
        /// <summary>
        /// 마우스 우측 버튼 클릭시 Context메뉴를 보여주는 일련의 작업들을 이 이벤트에서 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
                return;

            UltraGrid grid = (UltraGrid)sender;
            UIElement element = grid.DisplayLayout.UIElement.ElementFromPoint(new Point(e.X, e.Y));
            UltraGridCell cell = element.GetContext(typeof(UltraGridCell)) as UltraGridCell;

            if (cell != null)
            {
                Debug.WriteLine("MouseDown Event Fired");
                Debug.WriteLine("Index of the right mouse click row is  " + cell.Row.Index.ToString());
                Debug.WriteLine("Key of the right mouse click col is  " + cell.Column.Key);
             

                // 컨텍스트 메뉴를 보여주기 위한 코드 작성 시작
                //SetPopUpMenuItemInf("1101111111")
                // 컨텍스트 메뉴를 보여주기 위한 코드 작성 끝
            }
        }
        #endregion ▶ MouseDown >>> MouseDown

        #region ▶ ScriptLeaveCell >>> BeforeCellDeactivate
        /// <summary>
        /// fpSpread의 ScripLeaveCell 이벤트는 UltraGrid의 
        /// BeforeCellDeactivate 이벤트와 AfterCellActivate 이벤트를 겸해서 사용합니다.
        /// BeforeCellDeactivate    : 기존Cell에서 새로운 Cell로 이동하기 전에 기존Cell위치에서 처리 할 일련의 작업들을 기술합니다.
        /// AfterCellActivate       : 새로운 Cell로 이동해서 처리할 일련의 작업들을 기술합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeCellDeactivate(object sender, CancelEventArgs e)
        {
            Debug.WriteLine("Before Cell Row is  " + uniGrid1.ActiveCell.Row.Index.ToString());
            Debug.WriteLine("Before Cell Col is  " + uniGrid1.ActiveCell.Column.Key.ToString());
          

            // 새로운 Cell로 이동하기전에 기존 Cell에서 처리할 작업들 수행 코드 시작

            // Validation 체크해서 새로운 Cell로 이동하는 것을 취소
            // e.Cancel = true;

            // 새로운 Cell로 이동하기전에 기존 Cell에서 처리할 작업들 수행 코드 종료



            // 새로운 Cell에 대한 작업은 AfterCellActivate 이벤트에서 처리합니다.
        }
        #endregion ▶ ScriptLeaveCell >>> BeforeCellDeactivate

        #region ▶ ButtonClicked >>> ClickCellButton
        /// <summary>
        /// Cell 내의 버튼을 클릭했을때의 일련작업들을 수행합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_ClickCellButton(object sender, CellEventArgs e)
        {
            Debug.WriteLine("ClickCellButton Event Fired");
            Debug.WriteLine("Index of the new active row is  " + e.Cell.Row.Index.ToString());
            Debug.WriteLine("Key of the new active col is  " + e.Cell.Column.Key);
           
            // 버튼클릭 시 수행 할 코드 작성 시작
            //switch (e.Cell.Column.Key)
            //{
            //    case "C_AcctPopUp":
            //        OpenPopUp(e.Cell.Row.Cells["AAA"].Value);
            //        break;
            //    case "C_deptPopup":
            //        OpenPopUp(e.Cell.Row.Cells["BBB"].Value);
            //        break;
            //    case "C_DocCurPopup":
            //        OpenPopUp(e.Cell.Row.Cells["CCC"].Value);
            //        break;
            //    default:
            //}
            // 버튼클릭 시 수행 할 코드 작성 끝
        }
        #endregion ▶ ButtonClicked >>> ClickCellButton

        #region ▶ ComboSelChange >>> CellListSelect
        /// <summary>
        /// Cell 내의 콤보박스의 Item을 선택 변경했을때 이벤트가 발생합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_CellListSelect(object sender, CellEventArgs e)
        {
            if (null != e.Cell.Column.ValueList)
            {
                int itemIndex = e.Cell.Column.ValueList.SelectedItemIndex;
               
                Debug.WriteLine("Selected Item Index = " + itemIndex);
                Debug.WriteLine("Selected Item Value = " + e.Cell.Column.ValueList.GetValue(itemIndex).ToString());
                Debug.WriteLine("Selected Item Text = " + e.Cell.Column.ValueList.GetText(itemIndex).ToString());
                Debug.WriteLine("Index of the new active row is  " + e.Cell.Row.Index.ToString());
                Debug.WriteLine("Key of the new active col is  " + e.Cell.Column.Key);
              
                //switch (e.Cell.Column.Key)
                //{
                //    case "AAA":
                //        break;
                //    case "BBB":
                //        break;
                //    case "CCC":
                //        break;
                //    default:
                //        break;
                //}
            }
        }
        #endregion ▶ ComboSelChange >>> CellListSelect

        #region ▶ Change >>> CellChange
        /// <summary>
        /// fpSpread의 Change 이벤트는 UltraGrid의 BeforeExitEditMode 또는 AfterExitEditMode 이벤트로 대체됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uniGrid1_BeforeExitEditMode(object sender, Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs e)
        {
            // If the user is canceling the modifications (for example by hitting Escape  
            // key, then just return because the cell will revert to its original value 
            // in this case and not commit the user‘s input. 
            if (e.CancellingEditOperation)
                return;

            switch (uniGrid1.ActiveCell.Column.Key)
            {
                case "AAA":
                    break;
                case "BBB":
                    break;
                case "CCC":
                    break;
                default:
                    break;
            }
        }

        private void uniGrid1_AfterExitEditMode(object sender, EventArgs e)
        {

            if (uniGrid1.ActiveRow == null || uniGrid1.ActiveCell == null)
            {
                return;
            }
            string columnName = uniGrid1.ActiveCell.Column.Key.ToUpper();
            switch (columnName)
            {
                case "DILIG_EMP_NO":
                    DataSet dsChg = uniBase.UDataAccess.CommonQueryRs(" haa010t.EMP_NO, haa010t.NAME ",
                       " haa010t ", " (haa010t.emp_no like '%'+" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["dilig_emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                       + " +'%' OR haa010t.NAME LIKE '%' +" + uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["dilig_emp_no"].Value.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + " +'%')"
                       );
                    if (uniGrid1.ActiveRow.Cells["dilig_emp_no"].Value.ToString().Trim() != "")
                    {
                        if (dsChg != null && dsChg.Tables.Count > 0 && dsChg.Tables[0].Rows.Count > 0)
                        {
                            if (dsChg.Tables[0].Rows.Count == 1)
                            {
                                uniGrid1.ActiveRow.Cells["dilig_emp_no"].Value = dsChg.Tables[0].Rows[0]["emp_no"].ToString().Trim();
                                uniGrid1.ActiveRow.Cells["name"].Value = dsChg.Tables[0].Rows[0]["name"].ToString().Trim();
                            }
                            else
                            {

                                uniGrid1.BeforePopupOpenEvent();

                            }
                        }
                        else
                        {
                            uniGrid1.ActiveRow.Cells["dilig_emp_no"].Value = string.Empty;
                            uniGrid1.ActiveRow.Cells["name"].Value = string.Empty;

                            return;
                        }
                    }
                    else
                    {
                        uniGrid1.ActiveRow.Cells["dilig_emp_no"].Value = string.Empty;
                        uniGrid1.ActiveRow.Cells["name"].Value = string.Empty;

                        return;
                    }
                    break;


                case "DILIG_CD":
              
                    DataSet dsTemp = null;
                    string sbSQL2 = string.Format(@"
                                                    SELECT A.DILIG_CD, A.DILIG_NM, DAY_TIME, HOLIDAY_APPLY
                                                    FROM HCA010T A 
                                                    WHERE  A.dilig_cd = {0}
                                                    "
                         , uniBase.UCommon.FilterVariable(uniGrid1.ActiveRow.Cells["dilig_cd"].Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true));
                    dsTemp = uniBase.UDataAccess.CommonQuerySQL(sbSQL2.ToString());
                    if (dsTemp.Tables[0].Rows.Count > 0)
                    {
                        switch (dsTemp.Tables[0].Rows[0]["DAY_TIME"].ToString())
                        {
                            case "1":
                                this.uniGrid1.ActiveRow.Cells["dilig_time"].Value = "0000";
                                this.uniGrid1.SpreadLock(cstdsDILIG.E_H_DILIG_D.dilig_timeColumn.ColumnName);

                                break;

                            case "2":
                               // this.uniGrid1.ActiveRow.Cells["dilig_time"].Value = "0000";
                                this.uniGrid1.SpreadLock(cstdsDILIG.E_H_DILIG_D.dilig_timeColumn.ColumnName);
                                break;

                            default:
                                this.uniGrid1.ActiveRow.Cells["dilig_time"].Value = "0400";

                                this.uniGrid1.SpreadLock(cstdsDILIG.E_H_DILIG_D.dilig_timeColumn.ColumnName);

                                break;
                        }
                    }
                    break;


                case "DILIG_DT_FR":



                    if ((uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value != null ) && ( uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value != null ))
                    {
                        if ((uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value.ToString().Trim() != "") && (uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value.ToString().Trim() != ""))
                        {
                            //시작일과 종료일 비교
                            if (Convert.ToDateTime(uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value.ToString()) > Convert.ToDateTime(uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value.ToString()))
                            {
                                uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value = uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value.ToString();
                                return;
                            }
                        }
                        else
                        {
                            uniGrid1.ActiveRow.Cells["dilig_time"].Value = "";
                        }
                    }
                    else
                    {
                        uniGrid1.ActiveRow.Cells["dilig_time"].Value = "";
                    }

                    break;

                case "DILIG_DT_TO":

                    if ((uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value != null) && (uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value != null))
                    {
                        if ((uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value.ToString().Trim() != "") && (uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value.ToString().Trim() != ""))
                        {
                            //시작일과 종료일 비교
                            if (Convert.ToDateTime(uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value.ToString()) > Convert.ToDateTime(uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value.ToString()))
                            {
                                uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value = uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value.ToString();
                                return;

                            }
                        }
                        else
                        {
                            uniGrid1.ActiveRow.Cells["dilig_time"].Value = "";
                        }

                    }
                    else
                    {
                        uniGrid1.ActiveRow.Cells["dilig_time"].Value = "";
                    }

                    break;

                case "DILIG_FR":
                case "DILIG_TO":
                    if (uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value.ToString().Trim() != "" && uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value.ToString().Trim() != "")
                    {
                        if (uniGrid1.ActiveRow.Cells["dilig_to"].Value != null)
                        {
                            if (uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value != null && uniGrid1.ActiveRow.Cells["dilig_dt_to"].Value.ToString().Substring(0, 10) != "1900-01-01"
                                && uniGrid1.ActiveRow.Cells["dilig_fr"].Value != null && uniGrid1.ActiveRow.Cells["dilig_to"].Text.ToString().Trim().Replace(":", "") != "____"
                                && uniGrid1.ActiveRow.Cells["dilig_to"].Text.ToString().Trim().Replace(":", "") != "")
                            {
                                if (uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value.ToString().Substring(0, 10) != "1900-01-01" && uniGrid1.ActiveRow.Cells["dilig_fr"].Text.ToString().Trim().Replace(":", "") != "____"
                                   && uniGrid1.ActiveRow.Cells["dilig_fr"].Text.ToString().Trim().Replace(":", "") != "")
                                {
                                    string dilig_dt_fr = uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Text.ToString().Replace("-", "");
                                    string dilig_dt_to = uniGrid1.ActiveRow.Cells["dilig_dt_to"].Text.ToString().Replace("-", "");
                                    string dilig_f = uniGrid1.ActiveRow.Cells["dilig_fr"].Value.ToString().Replace(":", "");
                                    string dilig_t = uniGrid1.ActiveRow.Cells["dilig_to"].Value.ToString().Replace(":", "");
                                    string dilig_from = dilig_dt_fr + dilig_f;
                                    string dilig_to = dilig_dt_to + dilig_t;
                                    DateTime dtDiligFr = DateTime.ParseExact(dilig_from, "yyyyMMddHHmm", System.Globalization.CultureInfo.InvariantCulture);
                                    DateTime dtDiligTo = DateTime.ParseExact(dilig_to, "yyyyMMddHHmm", System.Globalization.CultureInfo.InvariantCulture);

                                    TimeSpan result = new TimeSpan(0, 24, 0);
                                    result = (dtDiligTo - dtDiligFr);

                                    uniGrid1.ActiveRow.Cells["dilig_time"].Value = result.ToString().Substring(0, 5).Replace(":", "");
                                }
                                else
                                {
                                    uniGrid1.ActiveRow.Cells["dilig_time"].Value = "";
                                }
                            }
                            else
                            {
                                uniGrid1.ActiveRow.Cells["dilig_time"].Value = "";
                            }
                        }
                        else
                        {
                            uniGrid1.ActiveRow.Cells["dilig_time"].Value = "";
                        }
                    }
                    else
                    {
                        uniGrid1.ActiveRow.Cells["dilig_time"].Value = "";
                    }
                    break;

            }


        }
        #endregion ▶ Change >>> CellChange


        #endregion

        #region ■ 5.3 TAB    control event implementation group
        #endregion

        #endregion

        #region ▶ 6. Popup method part

        #region ■ 6.1 Common popup implementation group

        #endregion

        #region ■ 6.2 User-defined popup implementation group

        private void OpenNumberingType(string iWhere)
        {
            #region ▶▶▶ 10.1.2.1 Popup Constructors
            //CommonPopup cp = new CommonUtil.CommonPopup(PopupType.AutoNumbering);

            //string[] arrRet = cp.showModalDialog(InputParam1);

            #endregion

            #region ▶▶▶ 10.1.2.2 Setting Returned Data

            //if (iWhere) 
            //{
            //    txtMinor.value = arrRet[0];
            //    txtMinorNm.value = arrRet[1];
            //}
            //else
            //{
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingCd].value = arrRet[0];
            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.NumberingNm].value = arrRet[1];

            //    if (arrRet[2].Length > 0) 
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = arrRet[2];
            //    else
            //        uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.MaxLen].value = "18";

            //    uniGrid1.Rows[uniGrid1.ActiveRow][gridCol.PrefixCd].value = arrRet[0];

            //}

            #endregion

            //CommonVariable.lgBlnFlgChgValue = true;  // 사용자 액션 발생 알림
        }

        #endregion

        private void popDiligReqNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.H4006P3_KO883";
            e.PopupPassData.PopupWinTitle = "신청번호 POPUP";
            e.PopupPassData.PopupWinWidth = 920;
            e.PopupPassData.PopupWinHeight = 800;
            e.PopupPassData.Data = new string[] { "","" };
        }

        private void popDiligReqNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popDiligReqNo.CodeValue = iDataSet.Tables[0].Rows[0]["dilig_req_no"].ToString();
            strRefNo = "";
        }


        private void popEmpNo_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup";
            e.PopupPassData.PopupWinTitle = "Employee PopUp";
            e.PopupPassData.PopupWinWidth = 800;
            e.PopupPassData.PopupWinHeight = 700;

            e.PopupPassData.Data = new string[] { popEmpNo.CodeValue, popEmpNo.CodeName, "", "1" };
        }

        private void popEmpNo_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popEmpNo.CodeValue = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
            popEmpNo.CodeName = iDataSet.Tables[0].Rows[0]["name"].ToString();
        }

        private void popEmpNo_OnChange(object sender, EventArgs e)
        {
            if (popEmpNo.CodeValue == "")
            {
                popEmpNo.CodeName = "";
                return;
            }

            string[] UNISqlId = new string[] { "ZN_HR_EMP_NM2" };
            string[][] UNIValue = new string[1][];
            UNIValue[0] = new string[5];

            // 0: USER ID 
            // 1: DATE(IF '' DEFAULT GETDATE) 
            // 2: EMP NO
            // 3: ADDITIONAL CONDITION
            UNIValue[0][0] = uniBase.UCommon.FilterVariable(CommonVariable.gUsrID, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][1] = "''";
            UNIValue[0][2] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][3] = uniBase.UCommon.FilterVariable(popEmpNo.CodeValue, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true);
            UNIValue[0][4] = " ";

            DataSet pDataSet = null;

            try
            {
                pDataSet = uniBase.UDataAccess.DBAgentQryRS(UNISqlId, UNIValue);

                if (pDataSet == null || pDataSet.Tables[0].Rows.Count == 0)
                {
                    uniBase.UMessage.DisplayMessageBox("800048", MessageBoxButtons.OK);
                    this.popEmpNo.CodeValue = "";
                    popEmpNo.CodeName = "";
                    popEmpNo.uniButton_Click(null, null);

                    //popEmpNo.Focus();

                    return;
                }
                else if (pDataSet.Tables[0].Rows.Count >= 2)
                {
                    this.popEmpNo.uniButton_Click(null, null);
                    if (string.IsNullOrEmpty(this.popEmpNo.CodeName.ToString())) //
                    {
                        this.popEmpNo.CodeValue = "";
                    }

                    return;
                }

                else
                {
                    popEmpNo.CodeValue = pDataSet.Tables[0].Rows[0]["emp_no"].ToString();
                    popEmpNo.CodeName = pDataSet.Tables[0].Rows[0]["name"].ToString();
                }
            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                return;
            }
        }

        #endregion

        private void btnApproval_Click(object sender, EventArgs e)
        {

            if (this.viewDBSaveMode == enumDef.DBSaveMode.CreateMode)
            {
                // 조회를 먼저 하십시오.
                uniBase.UMessage.DisplayMessageBox("900002", MessageBoxButtons.OK);
                return;
            }


            if (uniGrid1.Rows.Count == 0)
            {
                // 승인할 DATA가 없습니다.
                uniBase.UMessage.DisplayMessageBox("187738", MessageBoxButtons.OK);
                return;
            }

            if (popEmpNo.CodeValue.ToString().Trim() == "" || popEmpNo.CodeValue.ToString().Trim() == null)
            {//사번을 확인하십시요
                uniBase.UMessage.DisplayMessageBox("800478", MessageBoxButtons.OK);
                return;
            }

            DataSet ds = uniBase.UDataAccess.CommonQuerySQL(string.Format(@"
                            select top 1 emp_no from HAA010T (nolock)
                            where emp_no = {0}"
                       , uniBase.UCommon.FilterVariable(popEmpNo.CodeValue.ToString().Trim(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)));

            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
            {//사번을 확인하십시요
                uniBase.UMessage.DisplayMessageBox("800478", MessageBoxButtons.OK);
                return;
            }

            txtRemark.Text = txtRemark.Text + " ";
            cboDiligType.Value = cboDiligType.Value;
            cboReportType.Value = cboReportType.Value;
            strAPPROVAL = "Y";

            DBSave();

            if (uniBase.UMessage.DisplayMessageBox("900018", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                return;
            }

            uniBase.UProcess.DisplayProgressBar();

            try
            {
                uniCommand iuniCommand = uniBase.UDatabase.GetStoredProcCommand("USP_IF_APPROVAL_KO883");

                uniBase.UDatabase.AddInParameter(iuniCommand, "@doc_no", SqlDbType.NVarChar, popDiligReqNo.CodeValue.ToString().Trim());
                uniBase.UDatabase.AddInParameter(iuniCommand, "@system_code", SqlDbType.NVarChar, "HR");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@ap_form", SqlDbType.NVarChar, "H4006M3_KO883");
                uniBase.UDatabase.AddInParameter(iuniCommand, "@ref_no", SqlDbType.NVarChar, txtRefNo.Text);
                uniBase.UDatabase.AddInParameter(iuniCommand, "@doc_user_id", SqlDbType.NVarChar, popEmpNo.CodeValue.ToString());
                uniBase.UDatabase.AddInParameter(iuniCommand, "@user_id", SqlDbType.NVarChar, popEmpNo.CodeValue.ToString());
                uniBase.UDatabase.AddInParameter(iuniCommand, "@key_val1", SqlDbType.NVarChar, cboReportType.Value.ToString());
                uniBase.UDatabase.AddInParameter(iuniCommand, "@key_val2", SqlDbType.NVarChar, cboDiligType.Value.ToString());

                uniBase.UDatabase.AddOutParameter(iuniCommand, "@msg_cd", SqlDbType.NVarChar, 6);
                uniBase.UDatabase.AddOutParameter(iuniCommand, "@msg_text", SqlDbType.NVarChar, 200);

                uniBase.UDatabase.AddReturnParameter(iuniCommand, "RETURN_VALUE", SqlDbType.Int, 4);

                uniBase.UDatabase.ExecuteNonQuery(iuniCommand);

                int iretVal = (int)uniBase.UDatabase.GetParameterValue(iuniCommand, "RETURN_VALUE");

                if (iretVal != 1)
                {
                    string istrMsgCd = uniBase.UDatabase.GetParameterValue(iuniCommand, "@msg_cd").ToString();
                    string istrMsgText = uniBase.UDatabase.GetParameterValue(iuniCommand, "@msg_text").ToString();
                    uniBase.UMessage.DisplayMessageBox(istrMsgCd, MessageBoxButtons.OK, istrMsgText);
                    this.Presenter.ProgressBarController.HideProgressBar();
                    return;
                }

                // --결재창 OPEN
                uniERP.AppFramework.UI.Controls.Popup.PopupRunningInfo popupRunninginfo = new uniERP.AppFramework.UI.Controls.Popup.PopupRunningInfo();

                string callPopupID = "uniERP.App.UI.Popup.SMES";

                popupRunninginfo.ParentData.CalledPopupID = callPopupID;
                popupRunninginfo.ParentData.PopupWinTitle = "전자결재";

                popupRunninginfo.ParentData.Data = popDiligReqNo.CodeValue.ToString().Trim();  // 팝업 데이타 전달
                popupRunninginfo.ParentView = this;
                popupRunninginfo.ReturnPopup = (uniERP.AppFramework.UI.Controls.uniControls.IOpenPopup)this.btnApproval;
                popupRunninginfo.ParentColumnID = "";

                popupRunninginfo.ParentData.PopupWinWidth = 1500;
                popupRunninginfo.ParentData.PopupWinHeight = 1500;

                ControlManager.PopupLoad(callPopupID, popupRunninginfo, this.Presenter.WorkItem);

                //


            }
            catch (Exception ex)
            {
                bool reThrow = uniBase.UExceptionController.AutoProcessException(ex);
                if (reThrow)
                    throw;
                this.Presenter.ProgressBarController.HideProgressBar();
                return;
            }

            this.Presenter.ProgressBarController.HideProgressBar();


            OnPostFncSave();
            cstdsDILIG.Clear();
            DBQuery();

            StringBuilder strSQL = new StringBuilder();
            string strApItem;
            if (cboDiligType.Value.ToString().Equals("3"))
            {
                strApItem = "H2";
            }
            else
            {
                strApItem = "H1";
            }

            strSQL.AppendFormat(@"
UPDATE ERP_IF_APPROVAL
   SET APPROVAL_RTN = 'T'

WHERE
DOC_NO={0} AND 
AP_ITEM={1} AND 
MNU_ID='H4006M3_KO883'"
                   , uniBase.UCommon.FilterVariable(popDiligReqNo.CodeValue.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                   , uniBase.UCommon.FilterVariable(strApItem.ToUpper(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                   );
            uniCommand uniCmd = uniBase.UDatabase.GetSqlStringCommand(strSQL.ToString());
            uniBase.UDatabase.ExecuteNonQuery(uniCmd, false);

            OnPostFncSave();
            cstdsDILIG.Clear();
            DBQuery();
        }

        private void uniGrid1_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            switch (this.uniGrid1.ActiveCell.Column.Key)
            {
                case "dilig_emp_no":
                    string emp = uniGrid1.ActiveRow.Cells["dilig_emp_no"].Value.ToString();
                    string name = uniGrid1.ActiveRow.Cells["name"].Value.ToString();
                    string dt = string.Empty;
                    if (uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value.ToString().Trim() == "")
                    {
                        dt = uniBase.UDate.GetDBServerDateTime().ToShortDateString();
                    }
                    else
                    {
                        dt = Convert.ToDateTime(uniGrid1.ActiveRow.Cells["dilig_dt_fr"].Value).ToString(CommonVariable.CDT_YYYY_MM_DD);//Convert.ToDateTime(uniGrid1.ActiveRow.Cells[cqtdsHListDailyAttendance.E_HCA060T.dilig_dtColumn.ColumnName].Value);
                    }
                    e.PopupPassData.CalledPopupID = "uniERP.App.UI.Popup.EmpPopup";
                    e.PopupPassData.PopupWinTitle = "사번 Popup";
                    e.PopupPassData.PopupWinWidth = 800;
                    e.PopupPassData.PopupWinHeight = 700;
                    e.PopupPassData.Data = new string[] { emp, name, dt, "1" };

                    break;

                case "dilig_cd":
                    e.PopupPassData.PopupWinTitle = "근태Popup";
                    e.PopupPassData.ConditionCaption = "근태코드 ";
                    e.PopupPassData.SQLFromStatements = "B_CONFIGURATION A INNER JOIN HCA010T B ON B.DILIG_CD = A.REFERENCE ";
                    e.PopupPassData.SQLWhereStatements = " 1=1 AND MAJOR_CD = 'XH002' AND  MINOR_CD = " + uniBase.UCommon.FilterVariable(cboDiligType.Value.ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true) + "";
                    e.PopupPassData.SQLWhereInputCodeValue = this.uniGrid1.ActiveRow.Cells["dilig_cd"].Text;
                    e.PopupPassData.SQLWhereInputNameValue = "";
                    e.PopupPassData.DistinctOrNot = true;
                    e.PopupPassData.PopupWinWidth = 500;
                    e.PopupPassData.PopupWinHeight = 400;

                    e.PopupPassData.GridCellCode = new string[2];
                    e.PopupPassData.GridCellCodeAlias = new String[2];
                    e.PopupPassData.GridCellCaption = new string[2];
                    e.PopupPassData.GridCellType = new enumDef.GridCellType[2];
                    e.PopupPassData.GridCellLength = new int[2];

                    e.PopupPassData.GridCellCode[0] = "REFERENCE";
                    e.PopupPassData.GridCellCode[1] = "DILIG_NM";

                    e.PopupPassData.GridCellCodeAlias[0] = "dilig_cd";
                    e.PopupPassData.GridCellCodeAlias[1] = "dilig_nm";

                    e.PopupPassData.GridCellCaption[0] = "근태코드";
                    e.PopupPassData.GridCellCaption[1] = "근태명";

                    e.PopupPassData.GridCellType[0] = enumDef.GridCellType.Edit;
                    e.PopupPassData.GridCellType[1] = enumDef.GridCellType.Edit;

                    e.PopupPassData.GridCellLength[0] = 100;
                    e.PopupPassData.GridCellLength[1] = 150;

                    break;
            }

        }



        private void uniGrid1_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {

            DataSet iDataSet = new DataSet();

            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;

            switch (this.uniGrid1.ActiveCell.Column.Key)
            {
                case "dilig_emp_no":
                    this.uniGrid1.ActiveRow.Cells["dilig_emp_no"].Value = iDataSet.Tables[0].Rows[0]["emp_no"].ToString();
                    this.uniGrid1.ActiveRow.Cells["name"].Value = iDataSet.Tables[0].Rows[0]["name"].ToString();

                    break;

                case "dilig_cd":

                    this.uniGrid1.ActiveRow.Cells["dilig_cd"].Value = iDataSet.Tables[0].Rows[0]["dilig_cd"].ToString();
                    this.uniGrid1.ActiveRow.Cells["dilig_nm"].Value = iDataSet.Tables[0].Rows[0]["dilig_nm"].ToString();

                    break;
            }
        }




        #region ▶ 7. User-defined method part

        #region ■ 7.1 User-defined function group


        private bool SubCheckHoliday(DataRow drSender)
        {
            int flg = 0;
            string iCnt = string.Empty;
            string strFg = string.Empty;
            string strType = string.Empty;
            string strOrgId = string.Empty;
            string strHoli_type = string.Empty;
            string strHoliday_apply = string.Empty;
            string f_gazet_dt = string.Empty;
            string f_emp_no = string.Empty;


            DataSet dsTemp = null;
            StringBuilder sbSQL = new StringBuilder();
            f_gazet_dt = drSender["dilig_dt_fr"].ToString().Substring(0, 10);
            f_emp_no = drSender["dilig_emp_no"].ToString();

            string sbSQL0 = string.Format(@"
SELECT wk_type
FROM hca040t
WHERE emp_no ={0}
and chang_dt = (select max(chang_dt) from hca040t where emp_no ={0} and chang_dt <={1})"
           , uniBase.UCommon.FilterVariable(drSender["dilig_emp_no"], "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
           , uniBase.UCommon.FilterVariable(f_gazet_dt, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
           );
            dsTemp = uniBase.UDataAccess.CommonQuerySQL(sbSQL0.ToString());
            if (dsTemp.Tables == null || dsTemp.Tables[0].Rows == null || dsTemp.Tables[0].Rows.Count <= 0)
            {
                uniBase.UMessage.DisplayMessageBox("800177", MessageBoxButtons.OK);

                return false;
            }

            strType = dsTemp.Tables[0].Rows[0]["wk_type"].ToString();

            if (strType == "X" || strType == "")
            {
                strType = "0";
            }



            string sbSQL1 = string.Format(@"
SELECT holi_type 
FROM    HCA020t
where
           wk_type ={0}
        and date ={1}"
                , uniBase.UCommon.FilterVariable(strType, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                , uniBase.UCommon.FilterVariable(f_gazet_dt, "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)
                );
            dsTemp = uniBase.UDataAccess.CommonQuerySQL(sbSQL1.ToString());
            if (dsTemp.Tables == null || dsTemp.Tables[0].Rows == null || dsTemp.Tables[0].Rows.Count <= 0)  // 13.07.19
            {
                uniBase.UMessage.DisplayMessageBox("800453", MessageBoxButtons.OK);

                return false;
            }


            strFg = dsTemp.Tables[0].Rows[0]["holi_type"].ToString();

            if (string.IsNullOrEmpty(strFg) || strFg == "X") //800453
            {
                uniBase.UMessage.DisplayMessageBox("800453", MessageBoxButtons.OK);

                return false;

            }
            else
                strHoli_type = strFg;



            //--'근태코드에서 일수/시간 판별 

            string sbSQL2 = string.Format(@"
SELECT  
    A.DILIG_CD, A.DILIG_NM, DAY_TIME, HOLIDAY_APPLY
FROM HCA010T A 
WHERE  A.dilig_cd = {0}
"
                , uniBase.UCommon.FilterVariable(drSender["dilig_cd"].ToString(), "''", enumDef.FilterVarType.BraceWithSingleQuotation, true)

                );
            dsTemp = uniBase.UDataAccess.CommonQuerySQL(sbSQL2.ToString());
            if (dsTemp.Tables == null || dsTemp.Tables[0].Rows == null || dsTemp.Tables[0].Rows.Count <= 0)
            {
                uniBase.UMessage.DisplayMessageBox("900014", MessageBoxButtons.OK);
                return false;
            }

            strFg = dsTemp.Tables[0].Rows[0]["day_time"].ToString();
            strHoliday_apply = dsTemp.Tables[0].Rows[0]["holiday_apply"].ToString();

            string dilg = dsTemp.Tables[0].Rows[0]["dilig_cd"].ToString();

            // 휴일적용여부가 'N'이고 해당일이 휴일이면 등록 불가 
            if (strHoliday_apply == "N" && strHoli_type == "H" && drSender["cud_char"].ToString().ToUpper() != "D")
            {
                string msgtest = f_emp_no + " 사번에 근태코드 : " + dilg;
                uniBase.UMessage.DisplayMessageBox("800505", MessageBoxButtons.OK, msgtest);
                return false;

            }

            return true;

        }

        #endregion

        #endregion

        private void uniGrid1_AfterRowsDeleted(object sender, EventArgs e)
        {
            if (uniGrid1.Rows.Count.ToString() == "0")
            {
                //uniBase.UCommon.ChangeFieldLockAttribute(rdoDiligType, enumDef.FieldLockAttribute.Normal);
                //uniBase.UCommon.ChangeFieldLockAttribute(rdoReportType, enumDef.FieldLockAttribute.Normal);
            }

        }

        private void lblDiligRef_BeforePopupOpen(object sender, uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventArgs e)
        {
            if (cboReportType.Value.ToString() == "1")
            {
                uniBase.UMessage.DisplayMessageBox("DT9999", MessageBoxButtons.OK, "보고구분이 결과일 때만 참조가 가능합니다.");
                e.Cancel = true;
                return;
            }

            e.PopupPassData.CalledPopupID = "uniERP.App.UI.POPUP.H4006P3_KO883";
            e.PopupPassData.PopupWinTitle = "신청번호 POPUP";
            e.PopupPassData.PopupWinWidth = 920;
            e.PopupPassData.PopupWinHeight = 800;
            e.PopupPassData.Data = new string[] { "", "REF" };
        }

        private void lblDiligRef_AfterPopupClosed(object sender, uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventArgs e)
        {
            DataSet iDataSet = new DataSet();
            if (e.ResultData.Data == null)
                return;

            iDataSet = (DataSet)e.ResultData.Data;
            popDiligReqNo.CodeValue = iDataSet.Tables[0].Rows[0]["dilig_req_no"].ToString();

            strRefNo = popDiligReqNo.CodeValue.ToString();

            DBQuery();
            OnPostFncQuery();
        }

        private void cboDiligType_AfterExitEditMode(object sender, EventArgs e)
        {
            if (cboDiligType.Value.ToString() == "3" || cboDiligType.Value.ToString() == "1")
            {
                cboReportType.Value = "1";
                uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                cboReportType.FieldType = enumDef.FieldType.ReadOnly;

            }
            else
            {
                uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Required);
                cboReportType.FieldType = enumDef.FieldType.NotNull;
            } 
        }

        private void cboDiligType_MouseLeave(object sender, EventArgs e)
        {
            if (cboErpIfRtn.Value.ToString() == "F" || cboErpIfRtn.Value.ToString() == "8" || cboErpIfRtn.Value.ToString() == "0")
            {
                if (cboDiligType.Value.ToString() == "3")
                {
                    cboReportType.Value = "1";
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                    cboReportType.FieldType = enumDef.FieldType.ReadOnly;

                }
                else if (cboDiligType.Value.ToString() == "1")
                {
                    cboReportType.Value = "2";
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                    cboReportType.FieldType = enumDef.FieldType.ReadOnly;

                }
                else
                {
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Required);
                    cboReportType.FieldType = enumDef.FieldType.NotNull;
                }
            }
        }

        private void cboReportType_MouseLeave(object sender, EventArgs e)
        {
            if (cboErpIfRtn.Value.ToString() == "F" || cboErpIfRtn.Value.ToString() == "8" || cboErpIfRtn.Value.ToString() == "0")
            {
                if (cboDiligType.Value.ToString() == "3")
                {
                    cboReportType.Value = "1";
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                    cboReportType.FieldType = enumDef.FieldType.ReadOnly;

                }
                else if (cboDiligType.Value.ToString() == "1")
                {
                    cboReportType.Value = "2";
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                    cboReportType.FieldType = enumDef.FieldType.ReadOnly;

                }
                else
                {
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Required);
                    cboReportType.FieldType = enumDef.FieldType.NotNull;
                }
            }
        }

        private void cboDiligType_Leave(object sender, EventArgs e)
        {
            if (cboErpIfRtn.Value.ToString() == "F" || cboErpIfRtn.Value.ToString() == "8" || cboErpIfRtn.Value.ToString() == "0")
            {
                if (cboDiligType.Value.ToString() == "3")
                {
                    cboReportType.Value = "1";
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                    cboReportType.FieldType = enumDef.FieldType.ReadOnly;

                }
                else if (cboDiligType.Value.ToString() == "1")
                {
                    cboReportType.Value = "2";
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                    cboReportType.FieldType = enumDef.FieldType.ReadOnly;

                }
                else
                {
                    uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Required);
                    cboReportType.FieldType = enumDef.FieldType.NotNull;
                }
            }
        }

        private void cboDiligType_SelectionChanged(object sender, EventArgs e)
        {
            switch (cboDiligType.SelectedIndex)
              {
           case 0:
                      cboReportType.Value = "2";
                      uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
                      cboReportType.FieldType = enumDef.FieldType.ReadOnly;
                      break;
           case 1:
                      uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Required);
                      cboReportType.FieldType = enumDef.FieldType.NotNull;
                      break;
           case 2:
               cboReportType.Value = "1";
               uniBase.UCommon.ChangeFieldLockAttribute(cboReportType, enumDef.FieldLockAttribute.Protected);
               cboReportType.FieldType = enumDef.FieldType.ReadOnly;
               break;
             }

        }

  


    }
}