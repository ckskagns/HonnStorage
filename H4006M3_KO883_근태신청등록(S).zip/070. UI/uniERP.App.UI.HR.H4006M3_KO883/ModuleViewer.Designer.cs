﻿using uniERP.AppFramework.UI.Module;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace uniERP.App.UI.HR.H4006M3_KO883
{

    public class ModuleInitializer : uniERP.AppFramework.UI.Module.Module
    {
        [InjectionConstructor]
        public ModuleInitializer([ServiceDependency] WorkItem rootWorkItem)
            : base(rootWorkItem) { }

        protected override void RegisterModureViewer()
        {
            base.AddModule<ModuleViewer>();
        }
    }

    partial class ModuleViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance37 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance38 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance39 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance40 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance41 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance42 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance43 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance44 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance45 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            this.uniTBL_OuterMost = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainCondition = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblDiligReqNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.popDiligReqNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTBL_MainReference = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblDiligRef = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTBL_MainBatch = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_MainData = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.uniTBL_Single = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblRemark = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblErpIfRtn = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblIsrtDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblRefNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblReportType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.lblDiligType = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.txtRemark = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.dtIsrtDt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.txtRefNo = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.cboErpIfRtn = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.cboDiligType = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.cboReportType = new uniERP.AppFramework.UI.Controls.uniCombo(this.components);
            this.uniGrid1 = new uniERP.AppFramework.UI.Controls.uniGrid(this.components);
            this.uniTableLayoutPanel1 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.lblBaseDt = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.dtBaseDt = new uniERP.AppFramework.UI.Controls.uniDateTime(this.components);
            this.lblEmpNo = new uniERP.AppFramework.UI.Controls.uniLabel(this.components);
            this.uniTableLayoutPanel2 = new uniERP.AppFramework.UI.Controls.uniTableLayoutPanel(this.components);
            this.btnApproval = new uniERP.AppFramework.UI.Controls.uniButton(this.components);
            this.popEmpNo = new uniERP.AppFramework.UI.Controls.uniOpenPopup();
            this.uniTextBox_Name = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTextBox_Code = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTextBox1 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTextBox2 = new uniERP.AppFramework.UI.Controls.uniTextBox(this.components);
            this.uniTBL_OuterMost.SuspendLayout();
            this.uniTBL_MainCondition.SuspendLayout();
            this.uniTBL_MainReference.SuspendLayout();
            this.uniTBL_MainData.SuspendLayout();
            this.uniTBL_Single.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtIsrtDt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRefNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboErpIfRtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDiligType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboReportType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).BeginInit();
            this.uniTableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtBaseDt)).BeginInit();
            this.uniTableLayoutPanel2.SuspendLayout();
            this.popEmpNo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // uniLabel_Path
            // 
            this.uniLabel_Path.Size = new System.Drawing.Size(500, 14);
            // 
            // uniTBL_OuterMost
            // 
            this.uniTBL_OuterMost.AutoFit = false;
            this.uniTBL_OuterMost.AutoFitColumnCount = 4;
            this.uniTBL_OuterMost.AutoFitRowCount = 4;
            this.uniTBL_OuterMost.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_OuterMost.ColumnCount = 1;
            this.uniTBL_OuterMost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainCondition, 0, 2);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainReference, 0, 0);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainBatch, 0, 6);
            this.uniTBL_OuterMost.Controls.Add(this.uniTBL_MainData, 0, 4);
            this.uniTBL_OuterMost.DefaultRowSize = 23;
            this.uniTBL_OuterMost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_OuterMost.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_OuterMost.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_01_CONDITION = 30F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_03_BOTTOM = 31F;
            this.uniTBL_OuterMost.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_OuterMost.Location = new System.Drawing.Point(1, 10);
            this.uniTBL_OuterMost.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_OuterMost.Name = "uniTBL_OuterMost";
            this.uniTBL_OuterMost.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_OuterMost.RowCount = 8;
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 6F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTBL_OuterMost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.uniTBL_OuterMost.Size = new System.Drawing.Size(833, 697);
            this.uniTBL_OuterMost.SizeTD5 = 14F;
            this.uniTBL_OuterMost.SizeTD6 = 36F;
            this.uniTBL_OuterMost.TabIndex = 0;
            this.uniTBL_OuterMost.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_OuterMost.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainCondition
            // 
            this.uniTBL_MainCondition.AutoFit = false;
            this.uniTBL_MainCondition.AutoFitColumnCount = 4;
            this.uniTBL_MainCondition.AutoFitRowCount = 4;
            this.uniTBL_MainCondition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(248)))));
            this.uniTBL_MainCondition.ColumnCount = 4;
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_MainCondition.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_MainCondition.Controls.Add(this.lblDiligReqNo, 0, 0);
            this.uniTBL_MainCondition.Controls.Add(this.popDiligReqNo, 1, 0);
            this.uniTBL_MainCondition.DefaultRowSize = 25;
            this.uniTBL_MainCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainCondition.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainCondition.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainCondition.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainCondition.Location = new System.Drawing.Point(0, 27);
            this.uniTBL_MainCondition.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainCondition.Name = "uniTBL_MainCondition";
            this.uniTBL_MainCondition.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_MainCondition.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Condition;
            this.uniTBL_MainCondition.RowCount = 1;
            this.uniTBL_MainCondition.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainCondition.Size = new System.Drawing.Size(833, 38);
            this.uniTBL_MainCondition.SizeTD5 = 14F;
            this.uniTBL_MainCondition.SizeTD6 = 36F;
            this.uniTBL_MainCondition.TabIndex = 1;
            this.uniTBL_MainCondition.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainCondition.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblDiligReqNo
            // 
            appearance50.TextHAlignAsString = "Left";
            appearance50.TextVAlignAsString = "Middle";
            this.lblDiligReqNo.Appearance = appearance50;
            this.lblDiligReqNo.AutoPopupID = null;
            this.lblDiligReqNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDiligReqNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDiligReqNo.Location = new System.Drawing.Point(15, 6);
            this.lblDiligReqNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDiligReqNo.Name = "lblDiligReqNo";
            this.lblDiligReqNo.Size = new System.Drawing.Size(101, 22);
            this.lblDiligReqNo.StyleSetName = "Default";
            this.lblDiligReqNo.TabIndex = 0;
            this.lblDiligReqNo.Text = "신청번호";
            this.lblDiligReqNo.UseMnemonic = false;
            // 
            // popDiligReqNo
            // 
            this.popDiligReqNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popDiligReqNo.AutoPopupCodeParameter = null;
            this.popDiligReqNo.AutoPopupID = null;
            this.popDiligReqNo.AutoPopupNameParameter = null;
            this.popDiligReqNo.CodeMaxLength = 20;
            this.popDiligReqNo.CodeName = "";
            this.popDiligReqNo.CodeSize = 150;
            this.popDiligReqNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDiligReqNo.CodeTextBoxName = null;
            this.popDiligReqNo.CodeValue = "";
            this.popDiligReqNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popDiligReqNo.Location = new System.Drawing.Point(116, 7);
            this.popDiligReqNo.LockedField = false;
            this.popDiligReqNo.Margin = new System.Windows.Forms.Padding(0);
            this.popDiligReqNo.Name = "popDiligReqNo";
            this.popDiligReqNo.NameDisplay = false;
            this.popDiligReqNo.NameId = null;
            this.popDiligReqNo.NameMaxLength = 50;
            this.popDiligReqNo.NamePopup = false;
            this.popDiligReqNo.NameSize = 100;
            this.popDiligReqNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.popDiligReqNo.Parameter = null;
            this.popDiligReqNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popDiligReqNo.PopupId = null;
            this.popDiligReqNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popDiligReqNo.QueryIfEnterKeyPressed = true;
            this.popDiligReqNo.RequiredField = false;
            this.popDiligReqNo.Size = new System.Drawing.Size(171, 21);
            this.popDiligReqNo.TabIndex = 1;
            this.popDiligReqNo.uniALT = "신청번호";
            this.popDiligReqNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.popDiligReqNo.UseDynamicFormat = false;
            this.popDiligReqNo.ValueTextBoxName = null;
            this.popDiligReqNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popDiligReqNo_BeforePopupOpen);
            this.popDiligReqNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popDiligReqNo_AfterPopupClosed);
            // 
            // uniTBL_MainReference
            // 
            this.uniTBL_MainReference.AutoFit = false;
            this.uniTBL_MainReference.AutoFitColumnCount = 4;
            this.uniTBL_MainReference.AutoFitRowCount = 4;
            this.uniTBL_MainReference.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainReference.ColumnCount = 3;
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.uniTBL_MainReference.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.uniTBL_MainReference.Controls.Add(this.lblDiligRef, 2, 0);
            this.uniTBL_MainReference.DefaultRowSize = 25;
            this.uniTBL_MainReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainReference.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainReference.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainReference.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainReference.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainReference.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainReference.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_MainReference.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainReference.Name = "uniTBL_MainReference";
            this.uniTBL_MainReference.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainReference.RowCount = 1;
            this.uniTBL_MainReference.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainReference.Size = new System.Drawing.Size(833, 21);
            this.uniTBL_MainReference.SizeTD5 = 14F;
            this.uniTBL_MainReference.SizeTD6 = 36F;
            this.uniTBL_MainReference.TabIndex = 2;
            this.uniTBL_MainReference.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainReference.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblDiligRef
            // 
            appearance51.TextHAlignAsString = "Left";
            appearance51.TextVAlignAsString = "Middle";
            this.lblDiligRef.Appearance = appearance51;
            this.lblDiligRef.AutoPopupID = null;
            this.lblDiligRef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDiligRef.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Reference;
            this.lblDiligRef.Location = new System.Drawing.Point(712, 3);
            this.lblDiligRef.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.lblDiligRef.Name = "lblDiligRef";
            this.lblDiligRef.Size = new System.Drawing.Size(121, 15);
            this.lblDiligRef.StyleSetName = "uniLabel_Reference";
            this.lblDiligRef.TabIndex = 0;
            this.lblDiligRef.Text = "[근태신청참조]";
            this.lblDiligRef.UseMnemonic = false;
            this.lblDiligRef.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.lblDiligRef_BeforePopupOpen);
            this.lblDiligRef.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.lblDiligRef_AfterPopupClosed);
            // 
            // uniTBL_MainBatch
            // 
            this.uniTBL_MainBatch.AutoFit = false;
            this.uniTBL_MainBatch.AutoFitColumnCount = 4;
            this.uniTBL_MainBatch.AutoFitRowCount = 4;
            this.uniTBL_MainBatch.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainBatch.ColumnCount = 5;
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 231F));
            this.uniTBL_MainBatch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.uniTBL_MainBatch.DefaultRowSize = 23;
            this.uniTBL_MainBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainBatch.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainBatch.HEIGHT_TYPE_00_REFERENCE = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_01_CONDITION = 29F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02 = 5F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03 = 3F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_03_BOTTOM = 32F;
            this.uniTBL_MainBatch.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainBatch.Location = new System.Drawing.Point(0, 668);
            this.uniTBL_MainBatch.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainBatch.Name = "uniTBL_MainBatch";
            this.uniTBL_MainBatch.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_MainBatch.RowCount = 1;
            this.uniTBL_MainBatch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainBatch.Size = new System.Drawing.Size(833, 28);
            this.uniTBL_MainBatch.SizeTD5 = 14F;
            this.uniTBL_MainBatch.SizeTD6 = 36F;
            this.uniTBL_MainBatch.TabIndex = 3;
            this.uniTBL_MainBatch.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainBatch.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_MainData
            // 
            this.uniTBL_MainData.AutoFit = false;
            this.uniTBL_MainData.AutoFitColumnCount = 4;
            this.uniTBL_MainData.AutoFitRowCount = 4;
            this.uniTBL_MainData.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_MainData.ColumnCount = 1;
            this.uniTBL_MainData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Controls.Add(this.uniTBL_Single, 0, 0);
            this.uniTBL_MainData.Controls.Add(this.uniGrid1, 0, 2);
            this.uniTBL_MainData.Controls.Add(this.uniTableLayoutPanel1, 0, 1);
            this.uniTBL_MainData.DefaultRowSize = 23;
            this.uniTBL_MainData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_MainData.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_MainData.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_MainData.HEIGHT_TYPE_01 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_01_CONDITION = 40F;
            this.uniTBL_MainData.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_MainData.HEIGHT_TYPE_03 = 9F;
            this.uniTBL_MainData.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.uniTBL_MainData.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_MainData.Location = new System.Drawing.Point(0, 74);
            this.uniTBL_MainData.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_MainData.Name = "uniTBL_MainData";
            this.uniTBL_MainData.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Data;
            this.uniTBL_MainData.RowCount = 3;
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 106F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.uniTBL_MainData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_MainData.Size = new System.Drawing.Size(833, 591);
            this.uniTBL_MainData.SizeTD5 = 14F;
            this.uniTBL_MainData.SizeTD6 = 36F;
            this.uniTBL_MainData.TabIndex = 4;
            this.uniTBL_MainData.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_MainData.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // uniTBL_Single
            // 
            this.uniTBL_Single.AutoFit = false;
            this.uniTBL_Single.AutoFitColumnCount = 4;
            this.uniTBL_Single.AutoFitRowCount = 4;
            this.uniTBL_Single.BackColor = System.Drawing.Color.Transparent;
            this.uniTBL_Single.ColumnCount = 4;
            this.uniTBL_Single.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_Single.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_Single.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTBL_Single.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTBL_Single.Controls.Add(this.lblRemark, 0, 0);
            this.uniTBL_Single.Controls.Add(this.lblErpIfRtn, 0, 1);
            this.uniTBL_Single.Controls.Add(this.lblIsrtDt, 0, 2);
            this.uniTBL_Single.Controls.Add(this.lblRefNo, 0, 3);
            this.uniTBL_Single.Controls.Add(this.lblReportType, 2, 2);
            this.uniTBL_Single.Controls.Add(this.lblDiligType, 2, 1);
            this.uniTBL_Single.Controls.Add(this.txtRemark, 1, 0);
            this.uniTBL_Single.Controls.Add(this.dtIsrtDt, 1, 2);
            this.uniTBL_Single.Controls.Add(this.txtRefNo, 1, 3);
            this.uniTBL_Single.Controls.Add(this.cboErpIfRtn, 1, 1);
            this.uniTBL_Single.Controls.Add(this.cboDiligType, 3, 1);
            this.uniTBL_Single.Controls.Add(this.cboReportType, 3, 2);
            this.uniTBL_Single.DefaultRowSize = 23;
            this.uniTBL_Single.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTBL_Single.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTBL_Single.HEIGHT_TYPE_00_REFERENCE = 25F;
            this.uniTBL_Single.HEIGHT_TYPE_01 = 9F;
            this.uniTBL_Single.HEIGHT_TYPE_01_CONDITION = 40F;
            this.uniTBL_Single.HEIGHT_TYPE_02 = 9F;
            this.uniTBL_Single.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTBL_Single.HEIGHT_TYPE_03 = 9F;
            this.uniTBL_Single.HEIGHT_TYPE_03_BOTTOM = 25F;
            this.uniTBL_Single.HEIGHT_TYPE_04 = 3F;
            this.uniTBL_Single.Location = new System.Drawing.Point(0, 0);
            this.uniTBL_Single.Margin = new System.Windows.Forms.Padding(0);
            this.uniTBL_Single.Name = "uniTBL_Single";
            this.uniTBL_Single.Padding = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.uniTBL_Single.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTBL_Single.RowCount = 3;
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.uniTBL_Single.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTBL_Single.Size = new System.Drawing.Size(833, 106);
            this.uniTBL_Single.SizeTD5 = 14F;
            this.uniTBL_Single.SizeTD6 = 36F;
            this.uniTBL_Single.TabIndex = 0;
            this.uniTBL_Single.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTBL_Single.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblRemark
            // 
            appearance30.TextHAlignAsString = "Left";
            appearance30.TextVAlignAsString = "Middle";
            this.lblRemark.Appearance = appearance30;
            this.lblRemark.AutoPopupID = null;
            this.lblRemark.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRemark.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRemark.Location = new System.Drawing.Point(15, 6);
            this.lblRemark.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(101, 22);
            this.lblRemark.StyleSetName = "Default";
            this.lblRemark.TabIndex = 0;
            this.lblRemark.Text = "비고";
            this.lblRemark.UseMnemonic = false;
            // 
            // lblErpIfRtn
            // 
            appearance31.TextHAlignAsString = "Left";
            appearance31.TextVAlignAsString = "Middle";
            this.lblErpIfRtn.Appearance = appearance31;
            this.lblErpIfRtn.AutoPopupID = null;
            this.lblErpIfRtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblErpIfRtn.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblErpIfRtn.Location = new System.Drawing.Point(15, 29);
            this.lblErpIfRtn.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblErpIfRtn.Name = "lblErpIfRtn";
            this.lblErpIfRtn.Size = new System.Drawing.Size(101, 22);
            this.lblErpIfRtn.StyleSetName = "Default";
            this.lblErpIfRtn.TabIndex = 1;
            this.lblErpIfRtn.Text = "승인상태";
            this.lblErpIfRtn.UseMnemonic = false;
            // 
            // lblIsrtDt
            // 
            appearance32.TextHAlignAsString = "Left";
            appearance32.TextVAlignAsString = "Middle";
            this.lblIsrtDt.Appearance = appearance32;
            this.lblIsrtDt.AutoPopupID = null;
            this.lblIsrtDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIsrtDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblIsrtDt.Location = new System.Drawing.Point(15, 52);
            this.lblIsrtDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblIsrtDt.Name = "lblIsrtDt";
            this.lblIsrtDt.Size = new System.Drawing.Size(101, 22);
            this.lblIsrtDt.StyleSetName = "Default";
            this.lblIsrtDt.TabIndex = 2;
            this.lblIsrtDt.Text = "작성일자";
            this.lblIsrtDt.UseMnemonic = false;
            // 
            // lblRefNo
            // 
            appearance33.TextHAlignAsString = "Left";
            appearance33.TextVAlignAsString = "Middle";
            this.lblRefNo.Appearance = appearance33;
            this.lblRefNo.AutoPopupID = null;
            this.lblRefNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRefNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblRefNo.Location = new System.Drawing.Point(15, 75);
            this.lblRefNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblRefNo.Name = "lblRefNo";
            this.lblRefNo.Size = new System.Drawing.Size(101, 17);
            this.lblRefNo.StyleSetName = "Default";
            this.lblRefNo.TabIndex = 3;
            this.lblRefNo.Text = "참조번호";
            this.lblRefNo.UseMnemonic = false;
            // 
            // lblReportType
            // 
            appearance34.TextHAlignAsString = "Left";
            appearance34.TextVAlignAsString = "Middle";
            this.lblReportType.Appearance = appearance34;
            this.lblReportType.AutoPopupID = null;
            this.lblReportType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReportType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblReportType.Location = new System.Drawing.Point(430, 52);
            this.lblReportType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblReportType.Name = "lblReportType";
            this.lblReportType.Size = new System.Drawing.Size(101, 22);
            this.lblReportType.StyleSetName = "Default";
            this.lblReportType.TabIndex = 5;
            this.lblReportType.Text = "보고구분";
            this.lblReportType.UseMnemonic = false;
            // 
            // lblDiligType
            // 
            appearance35.TextHAlignAsString = "Left";
            appearance35.TextVAlignAsString = "Middle";
            this.lblDiligType.Appearance = appearance35;
            this.lblDiligType.AutoPopupID = null;
            this.lblDiligType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDiligType.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblDiligType.Location = new System.Drawing.Point(430, 29);
            this.lblDiligType.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblDiligType.Name = "lblDiligType";
            this.lblDiligType.Size = new System.Drawing.Size(101, 22);
            this.lblDiligType.StyleSetName = "Default";
            this.lblDiligType.TabIndex = 4;
            this.lblDiligType.Text = "근태구분";
            this.lblDiligType.UseMnemonic = false;
            // 
            // txtRemark
            // 
            this.txtRemark.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance36.TextVAlignAsString = "Bottom";
            this.txtRemark.Appearance = appearance36;
            this.uniTBL_Single.SetColumnSpan(this.txtRemark, 3);
            this.txtRemark.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.txtRemark.Location = new System.Drawing.Point(116, 7);
            this.txtRemark.LockedField = false;
            this.txtRemark.Margin = new System.Windows.Forms.Padding(0);
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.QueryIfEnterKeyPressed = true;
            this.txtRemark.RequiredField = false;
            this.txtRemark.Size = new System.Drawing.Size(405, 21);
            this.txtRemark.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtRemark.StyleSetName = "Default";
            this.txtRemark.TabIndex = 6;
            this.txtRemark.uniALT = "비고";
            this.txtRemark.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtRemark.UseDynamicFormat = false;
            // 
            // dtIsrtDt
            // 
            this.dtIsrtDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance37.TextHAlignAsString = "Center";
            this.dtIsrtDt.Appearance = appearance37;
            this.dtIsrtDt.DateTime = new System.DateTime(2018, 7, 17, 0, 0, 0, 0);
            this.dtIsrtDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.YYYY_MM_DD;
            this.dtIsrtDt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtIsrtDt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.dtIsrtDt.Location = new System.Drawing.Point(116, 53);
            this.dtIsrtDt.LockedField = false;
            this.dtIsrtDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtIsrtDt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtIsrtDt.Name = "dtIsrtDt";
            this.dtIsrtDt.QueryIfEnterKeyPressed = true;
            this.dtIsrtDt.RequiredField = false;
            this.dtIsrtDt.Size = new System.Drawing.Size(100, 21);
            this.dtIsrtDt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtIsrtDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.dtIsrtDt.StyleSetName = "Default";
            this.dtIsrtDt.TabIndex = 10;
            this.dtIsrtDt.uniALT = "작성일자";
            this.dtIsrtDt.uniValue = new System.DateTime(2018, 7, 17, 0, 0, 0, 0);
            this.dtIsrtDt.Value = new System.DateTime(2018, 7, 17, 0, 0, 0, 0);
            // 
            // txtRefNo
            // 
            this.txtRefNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance38.TextVAlignAsString = "Bottom";
            this.txtRefNo.Appearance = appearance38;
            this.txtRefNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.txtRefNo.Location = new System.Drawing.Point(116, 74);
            this.txtRefNo.LockedField = false;
            this.txtRefNo.Margin = new System.Windows.Forms.Padding(0);
            this.txtRefNo.Name = "txtRefNo";
            this.txtRefNo.QueryIfEnterKeyPressed = true;
            this.txtRefNo.RequiredField = false;
            this.txtRefNo.Size = new System.Drawing.Size(157, 21);
            this.txtRefNo.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.txtRefNo.StyleSetName = "Default";
            this.txtRefNo.TabIndex = 11;
            this.txtRefNo.uniALT = "참조번호";
            this.txtRefNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtRefNo.UseDynamicFormat = false;
            // 
            // cboErpIfRtn
            // 
            this.cboErpIfRtn.AddEmptyRow = false;
            this.cboErpIfRtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboErpIfRtn.ComboFrom = "";
            this.cboErpIfRtn.ComboMajorCd = "SM003";
            this.cboErpIfRtn.ComboSelect = "";
            this.cboErpIfRtn.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboErpIfRtn.ComboWhere = "";
            this.cboErpIfRtn.DropDownListWidth = -1;
            this.cboErpIfRtn.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboErpIfRtn.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.ReadOnly;
            this.cboErpIfRtn.Location = new System.Drawing.Point(116, 30);
            this.cboErpIfRtn.LockedField = false;
            this.cboErpIfRtn.Margin = new System.Windows.Forms.Padding(0);
            this.cboErpIfRtn.Name = "cboErpIfRtn";
            this.cboErpIfRtn.RequiredField = false;
            this.cboErpIfRtn.Size = new System.Drawing.Size(100, 21);
            this.cboErpIfRtn.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboErpIfRtn.StyleSetName = "Default";
            this.cboErpIfRtn.TabIndex = 12;
            this.cboErpIfRtn.uniALT = "승인상태";
            // 
            // cboDiligType
            // 
            this.cboDiligType.AddEmptyRow = false;
            this.cboDiligType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboDiligType.ComboFrom = "";
            this.cboDiligType.ComboMajorCd = "XH002";
            this.cboDiligType.ComboSelect = "";
            this.cboDiligType.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboDiligType.ComboWhere = "";
            this.cboDiligType.DropDownListWidth = -1;
            this.cboDiligType.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboDiligType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.cboDiligType.Location = new System.Drawing.Point(531, 30);
            this.cboDiligType.LockedField = false;
            this.cboDiligType.Margin = new System.Windows.Forms.Padding(0);
            this.cboDiligType.Name = "cboDiligType";
            this.cboDiligType.RequiredField = false;
            this.cboDiligType.Size = new System.Drawing.Size(119, 21);
            this.cboDiligType.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboDiligType.StyleSetName = "Default";
            this.cboDiligType.TabIndex = 13;
            this.cboDiligType.uniALT = "근태구분";
            this.cboDiligType.SelectionChanged += new System.EventHandler(this.cboDiligType_SelectionChanged);
            this.cboDiligType.Leave += new System.EventHandler(this.cboDiligType_Leave);
            this.cboDiligType.AfterExitEditMode += new System.EventHandler(this.cboDiligType_AfterExitEditMode);
            this.cboDiligType.MouseLeave += new System.EventHandler(this.cboDiligType_MouseLeave);
            // 
            // cboReportType
            // 
            this.cboReportType.AddEmptyRow = false;
            this.cboReportType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboReportType.ComboFrom = "";
            this.cboReportType.ComboMajorCd = "XH003";
            this.cboReportType.ComboSelect = "";
            this.cboReportType.ComboType = uniERP.AppFramework.UI.Variables.enumDef.ComboType.MajorCode;
            this.cboReportType.ComboWhere = "";
            this.cboReportType.DropDownListWidth = -1;
            this.cboReportType.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboReportType.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.cboReportType.Location = new System.Drawing.Point(531, 53);
            this.cboReportType.LockedField = false;
            this.cboReportType.Margin = new System.Windows.Forms.Padding(0);
            this.cboReportType.Name = "cboReportType";
            this.cboReportType.RequiredField = false;
            this.cboReportType.Size = new System.Drawing.Size(119, 21);
            this.cboReportType.Style = uniERP.AppFramework.UI.Controls.Combo_Style.Default;
            this.cboReportType.StyleSetName = "Default";
            this.cboReportType.TabIndex = 14;
            this.cboReportType.uniALT = "보고구분";
            this.cboReportType.MouseLeave += new System.EventHandler(this.cboReportType_MouseLeave);
            // 
            // uniGrid1
            // 
            this.uniGrid1.AddEmptyRow = false;
            this.uniGrid1.DirectPaste = false;
            appearance39.BackColor = System.Drawing.SystemColors.Window;
            appearance39.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.uniGrid1.DisplayLayout.Appearance = appearance39;
            this.uniGrid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.uniGrid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance40.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance40.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance40.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.GroupByBox.Appearance = appearance40;
            appearance41.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance41;
            this.uniGrid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance42.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance42.BackColor2 = System.Drawing.SystemColors.Control;
            appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance42.ForeColor = System.Drawing.SystemColors.GrayText;
            this.uniGrid1.DisplayLayout.GroupByBox.PromptAppearance = appearance42;
            this.uniGrid1.DisplayLayout.MaxColScrollRegions = 1;
            this.uniGrid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance43.BackColor = System.Drawing.SystemColors.Window;
            appearance43.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uniGrid1.DisplayLayout.Override.ActiveCellAppearance = appearance43;
            this.uniGrid1.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.uniGrid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.uniGrid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance44.BackColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.CardAreaAppearance = appearance44;
            appearance45.BorderColor = System.Drawing.Color.Silver;
            appearance45.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.uniGrid1.DisplayLayout.Override.CellAppearance = appearance45;
            this.uniGrid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.CellSelect;
            this.uniGrid1.DisplayLayout.Override.CellPadding = 0;
            appearance46.BackColor = System.Drawing.SystemColors.Control;
            appearance46.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance46.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance46.BorderColor = System.Drawing.SystemColors.Window;
            this.uniGrid1.DisplayLayout.Override.GroupByRowAppearance = appearance46;
            appearance47.TextHAlignAsString = "Left";
            this.uniGrid1.DisplayLayout.Override.HeaderAppearance = appearance47;
            this.uniGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.uniGrid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance48.BackColor = System.Drawing.SystemColors.Window;
            appearance48.BorderColor = System.Drawing.Color.Silver;
            this.uniGrid1.DisplayLayout.Override.RowAppearance = appearance48;
            this.uniGrid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance49.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uniGrid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance49;
            this.uniGrid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.uniGrid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.uniGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniGrid1.EnableContextMenu = true;
            this.uniGrid1.EnableGridInfoContextMenu = true;
            this.uniGrid1.ExceptInExcel = false;
            this.uniGrid1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uniGrid1.gComNumDec = uniERP.AppFramework.UI.Variables.enumDef.ComDec.Decimal;
            this.uniGrid1.GridStyle = uniERP.AppFramework.UI.Variables.enumDef.GridStyle.Master;
            this.uniGrid1.Location = new System.Drawing.Point(0, 165);
            this.uniGrid1.Margin = new System.Windows.Forms.Padding(0, 9, 0, 0);
            this.uniGrid1.Name = "uniGrid1";
            this.uniGrid1.OutlookGroupBy = uniERP.AppFramework.UI.Variables.enumDef.IsOutlookGroupBy.No;
            this.uniGrid1.PopupDeleteMenuVisible = true;
            this.uniGrid1.PopupInsertMenuVisible = true;
            this.uniGrid1.PopupUndoMenuVisible = true;
            this.uniGrid1.Search = uniERP.AppFramework.UI.Variables.enumDef.IsSearch.Yes;
            this.uniGrid1.ShowHeaderCheck = true;
            this.uniGrid1.Size = new System.Drawing.Size(833, 426);
            this.uniGrid1.StyleSetName = "uniGrid_Query";
            this.uniGrid1.TabIndex = 1;
            this.uniGrid1.Text = "uniGrid1";
            this.uniGrid1.UseDynamicFormat = false;
            this.uniGrid1.AfterExitEditMode += new System.EventHandler(this.uniGrid1_AfterExitEditMode);
            this.uniGrid1.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.uniGrid1_BeforePopupOpen);
            this.uniGrid1.AfterRowsDeleted += new System.EventHandler(this.uniGrid1_AfterRowsDeleted);
            this.uniGrid1.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.uniGrid1_AfterPopupClosed);
            // 
            // uniTableLayoutPanel1
            // 
            this.uniTableLayoutPanel1.AutoFit = false;
            this.uniTableLayoutPanel1.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel1.AutoFitRowCount = 4;
            this.uniTableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel1.ColumnCount = 4;
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.uniTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.uniTableLayoutPanel1.Controls.Add(this.lblBaseDt, 0, 1);
            this.uniTableLayoutPanel1.Controls.Add(this.dtBaseDt, 1, 1);
            this.uniTableLayoutPanel1.Controls.Add(this.lblEmpNo, 0, 0);
            this.uniTableLayoutPanel1.Controls.Add(this.uniTableLayoutPanel2, 1, 0);
            this.uniTableLayoutPanel1.DefaultRowSize = 23;
            this.uniTableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uniTableLayoutPanel1.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel1.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel1.Location = new System.Drawing.Point(0, 106);
            this.uniTableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel1.Name = "uniTableLayoutPanel1";
            this.uniTableLayoutPanel1.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTableLayoutPanel1.RowCount = 2;
            this.uniTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.uniTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTableLayoutPanel1.Size = new System.Drawing.Size(833, 50);
            this.uniTableLayoutPanel1.SizeTD5 = 14F;
            this.uniTableLayoutPanel1.SizeTD6 = 36F;
            this.uniTableLayoutPanel1.TabIndex = 2;
            this.uniTableLayoutPanel1.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel1.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // lblBaseDt
            // 
            appearance52.TextHAlignAsString = "Left";
            appearance52.TextVAlignAsString = "Middle";
            this.lblBaseDt.Appearance = appearance52;
            this.lblBaseDt.AutoPopupID = null;
            this.lblBaseDt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBaseDt.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblBaseDt.Location = new System.Drawing.Point(15, 29);
            this.lblBaseDt.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblBaseDt.Name = "lblBaseDt";
            this.lblBaseDt.Size = new System.Drawing.Size(101, 21);
            this.lblBaseDt.StyleSetName = "Default";
            this.lblBaseDt.TabIndex = 0;
            this.lblBaseDt.Text = "기준일자";
            this.lblBaseDt.UseMnemonic = false;
            // 
            // dtBaseDt
            // 
            this.dtBaseDt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance53.TextHAlignAsString = "Center";
            this.dtBaseDt.Appearance = appearance53;
            this.dtBaseDt.DateTime = new System.DateTime(2018, 8, 14, 0, 0, 0, 0);
            this.dtBaseDt.DateType = uniERP.AppFramework.UI.Variables.enumDef.DateType.YYYY_MM_DD;
            this.dtBaseDt.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Never;
            this.dtBaseDt.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.dtBaseDt.Location = new System.Drawing.Point(116, 29);
            this.dtBaseDt.LockedField = false;
            this.dtBaseDt.Margin = new System.Windows.Forms.Padding(0);
            this.dtBaseDt.MaxDate = new System.DateTime(9998, 1, 1, 0, 0, 0, 0);
            this.dtBaseDt.Name = "dtBaseDt";
            this.dtBaseDt.QueryIfEnterKeyPressed = true;
            this.dtBaseDt.RequiredField = false;
            this.dtBaseDt.Size = new System.Drawing.Size(100, 21);
            this.dtBaseDt.SpinButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.Always;
            this.dtBaseDt.Style = uniERP.AppFramework.UI.Controls.DateTime_Style.YYYYMMDD;
            this.dtBaseDt.StyleSetName = "Default";
            this.dtBaseDt.TabIndex = 1;
            this.dtBaseDt.uniALT = "기준일자";
            this.dtBaseDt.uniValue = new System.DateTime(2018, 8, 14, 0, 0, 0, 0);
            this.dtBaseDt.Value = new System.DateTime(2018, 8, 14, 0, 0, 0, 0);
            // 
            // lblEmpNo
            // 
            appearance54.TextHAlignAsString = "Left";
            appearance54.TextVAlignAsString = "Middle";
            this.lblEmpNo.Appearance = appearance54;
            this.lblEmpNo.AutoPopupID = null;
            this.lblEmpNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmpNo.LabelType = uniERP.AppFramework.UI.Variables.enumDef.LabelType.Title;
            this.lblEmpNo.Location = new System.Drawing.Point(15, 1);
            this.lblEmpNo.Margin = new System.Windows.Forms.Padding(15, 1, 0, 0);
            this.lblEmpNo.Name = "lblEmpNo";
            this.lblEmpNo.Size = new System.Drawing.Size(101, 27);
            this.lblEmpNo.StyleSetName = "Default";
            this.lblEmpNo.TabIndex = 19;
            this.lblEmpNo.Text = "등록자/기안자 :";
            this.lblEmpNo.UseMnemonic = false;
            // 
            // uniTableLayoutPanel2
            // 
            this.uniTableLayoutPanel2.AutoFit = false;
            this.uniTableLayoutPanel2.AutoFitColumnCount = 4;
            this.uniTableLayoutPanel2.AutoFitRowCount = 4;
            this.uniTableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.uniTableLayoutPanel2.ColumnCount = 2;
            this.uniTableLayoutPanel1.SetColumnSpan(this.uniTableLayoutPanel2, 2);
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.55952F));
            this.uniTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.44048F));
            this.uniTableLayoutPanel2.Controls.Add(this.btnApproval, 1, 0);
            this.uniTableLayoutPanel2.Controls.Add(this.popEmpNo, 0, 0);
            this.uniTableLayoutPanel2.DefaultRowSize = 23;
            this.uniTableLayoutPanel2.EasyBaseBatchType = uniERP.AppFramework.UI.Controls.EasyBaseTBType.NONE;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_00_REFERENCE = 21F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_01 = 6F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_01_CONDITION = 38F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_02 = 9F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_02_DATA = 0F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_03 = 3F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_03_BOTTOM = 28F;
            this.uniTableLayoutPanel2.HEIGHT_TYPE_04 = 1F;
            this.uniTableLayoutPanel2.Location = new System.Drawing.Point(116, 0);
            this.uniTableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.uniTableLayoutPanel2.Name = "uniTableLayoutPanel2";
            this.uniTableLayoutPanel2.PanelType = uniERP.AppFramework.UI.Variables.enumDef.PanelType.Default;
            this.uniTableLayoutPanel2.RowCount = 1;
            this.uniTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uniTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uniTableLayoutPanel2.Size = new System.Drawing.Size(346, 28);
            this.uniTableLayoutPanel2.SizeTD5 = 14F;
            this.uniTableLayoutPanel2.SizeTD6 = 36F;
            this.uniTableLayoutPanel2.TabIndex = 20;
            this.uniTableLayoutPanel2.uniERPTableLayout = uniERP.AppFramework.UI.Controls.uniERPTableLayOutStyle.DefaultTableLayout;
            this.uniTableLayoutPanel2.uniLR_SPACE_TYPE = uniERP.AppFramework.UI.Controls.LR_SPACE_TYPE.LR_SPACE_TYPE_00;
            // 
            // btnApproval
            // 
            this.btnApproval.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnApproval.AutoPopupID = null;
            this.btnApproval.ButtonText = uniERP.AppFramework.UI.Variables.enumDef.ButtonText.UserDefined;
            this.btnApproval.Location = new System.Drawing.Point(233, 1);
            this.btnApproval.Margin = new System.Windows.Forms.Padding(0, 1, 3, 3);
            this.btnApproval.Name = "btnApproval";
            this.btnApproval.PopupID = null;
            this.btnApproval.Size = new System.Drawing.Size(97, 24);
            this.btnApproval.Style = uniERP.AppFramework.UI.Controls.Button_Style.Default;
            this.btnApproval.TabIndex = 15;
            this.btnApproval.Text = "결재상신";
            this.btnApproval.UserDefinedText = null;
            this.btnApproval.Click += new System.EventHandler(this.btnApproval_Click);
            // 
            // popEmpNo
            // 
            this.popEmpNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.popEmpNo.AutoPopupCodeParameter = null;
            this.popEmpNo.AutoPopupID = null;
            this.popEmpNo.AutoPopupNameParameter = null;
            this.popEmpNo.CodeMaxLength = 13;
            this.popEmpNo.CodeName = "";
            this.popEmpNo.CodeSize = 100;
            this.popEmpNo.CodeStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeValue;
            this.popEmpNo.CodeTextBoxName = null;
            this.popEmpNo.CodeValue = "";
            this.popEmpNo.Controls.Add(this.uniTextBox_Name);
            this.popEmpNo.Controls.Add(this.uniTextBox_Code);
            this.popEmpNo.Controls.Add(this.uniTextBox1);
            this.popEmpNo.Controls.Add(this.uniTextBox2);
            this.popEmpNo.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.NotNull;
            this.popEmpNo.Location = new System.Drawing.Point(0, 7);
            this.popEmpNo.LockedField = false;
            this.popEmpNo.Margin = new System.Windows.Forms.Padding(0);
            this.popEmpNo.Name = "popEmpNo";
            this.popEmpNo.NameDisplay = true;
            this.popEmpNo.NameId = null;
            this.popEmpNo.NameMaxLength = 50;
            this.popEmpNo.NamePopup = false;
            this.popEmpNo.NameSize = 150;
            this.popEmpNo.NameStyle = uniERP.AppFramework.UI.Controls.TextBox_Style.CodeName;
            this.popEmpNo.Parameter = null;
            this.popEmpNo.PopupButtonEnable = uniERP.AppFramework.UI.Variables.enumDef.uniOpenPopupButton.Enable;
            this.popEmpNo.PopupId = null;
            this.popEmpNo.PopupType = uniERP.AppFramework.UI.Variables.enumDef.PopupType.CommonPopup;
            this.popEmpNo.QueryIfEnterKeyPressed = true;
            this.popEmpNo.RequiredField = false;
            this.popEmpNo.Size = new System.Drawing.Size(223, 21);
            this.popEmpNo.TabIndex = 19;
            this.popEmpNo.uniALT = "등록자/기안자";
            this.popEmpNo.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.popEmpNo.UseDynamicFormat = false;
            this.popEmpNo.ValueTextBoxName = null;
            this.popEmpNo.BeforePopupOpen += new uniERP.AppFramework.UI.Controls.Popup.BeforePopupOpenEventHandler(this.popEmpNo_BeforePopupOpen);
            this.popEmpNo.AfterPopupClosed += new uniERP.AppFramework.UI.Controls.Popup.AfterPopupCloseEventHandler(this.popEmpNo_AfterPopupClosed);
            this.popEmpNo.OnChange += new System.EventHandler(this.popEmpNo_OnChange);
            // 
            // uniTextBox_Name
            // 
            this.uniTextBox_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.Appearance = appearance55;
            this.uniTextBox_Name.AutoSize = false;
            this.uniTextBox_Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Name.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Name.Location = new System.Drawing.Point(121, 0);
            this.uniTextBox_Name.LockedField = false;
            this.uniTextBox_Name.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Name.MaxLength = 50;
            this.uniTextBox_Name.Name = "uniTextBox_Name";
            this.uniTextBox_Name.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Name.ReadOnly = true;
            this.uniTextBox_Name.RequiredField = false;
            this.uniTextBox_Name.Size = new System.Drawing.Size(93, 21);
            this.uniTextBox_Name.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Name.StyleSetName = "Lock";
            this.uniTextBox_Name.TabIndex = 0;
            this.uniTextBox_Name.TabStop = false;
            this.uniTextBox_Name.uniALT = null;
            this.uniTextBox_Name.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.uniTextBox_Name.UseDynamicFormat = false;
            this.uniTextBox_Name.WordWrap = false;
            // 
            // uniTextBox_Code
            // 
            this.uniTextBox_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.Appearance = appearance56;
            this.uniTextBox_Code.AutoSize = false;
            this.uniTextBox_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox_Code.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox_Code.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox_Code.Location = new System.Drawing.Point(0, 0);
            this.uniTextBox_Code.LockedField = false;
            this.uniTextBox_Code.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox_Code.MaxLength = 13;
            this.uniTextBox_Code.Name = "uniTextBox_Code";
            this.uniTextBox_Code.QueryIfEnterKeyPressed = true;
            this.uniTextBox_Code.RequiredField = false;
            this.uniTextBox_Code.Size = new System.Drawing.Size(100, 21);
            this.uniTextBox_Code.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox_Code.StyleSetName = "Default";
            this.uniTextBox_Code.TabIndex = 0;
            this.uniTextBox_Code.uniALT = null;
            this.uniTextBox_Code.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox_Code.UseDynamicFormat = false;
            this.uniTextBox_Code.WordWrap = false;
            // 
            // uniTextBox1
            // 
            this.uniTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox1.Appearance = appearance57;
            this.uniTextBox1.AutoSize = false;
            this.uniTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox1.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox1.Location = new System.Drawing.Point(121, 0);
            this.uniTextBox1.LockedField = false;
            this.uniTextBox1.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox1.MaxLength = 50;
            this.uniTextBox1.Name = "uniTextBox1";
            this.uniTextBox1.QueryIfEnterKeyPressed = true;
            this.uniTextBox1.ReadOnly = true;
            this.uniTextBox1.RequiredField = false;
            this.uniTextBox1.Size = new System.Drawing.Size(132, 21);
            this.uniTextBox1.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox1.StyleSetName = "Lock";
            this.uniTextBox1.TabIndex = 0;
            this.uniTextBox1.TabStop = false;
            this.uniTextBox1.uniALT = null;
            this.uniTextBox1.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.uniTextBox1.UseDynamicFormat = false;
            this.uniTextBox1.WordWrap = false;
            // 
            // uniTextBox2
            // 
            this.uniTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            appearance58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox2.Appearance = appearance58;
            this.uniTextBox2.AutoSize = false;
            this.uniTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.uniTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox2.FieldType = uniERP.AppFramework.UI.Variables.enumDef.FieldType.Default;
            this.uniTextBox2.Location = new System.Drawing.Point(0, 0);
            this.uniTextBox2.LockedField = false;
            this.uniTextBox2.Margin = new System.Windows.Forms.Padding(0);
            this.uniTextBox2.MaxLength = 13;
            this.uniTextBox2.Name = "uniTextBox2";
            this.uniTextBox2.QueryIfEnterKeyPressed = true;
            this.uniTextBox2.RequiredField = false;
            this.uniTextBox2.Size = new System.Drawing.Size(100, 21);
            this.uniTextBox2.Style = uniERP.AppFramework.UI.Controls.TextBox_Style.Default;
            this.uniTextBox2.StyleSetName = "Default";
            this.uniTextBox2.TabIndex = 0;
            this.uniTextBox2.uniALT = null;
            this.uniTextBox2.uniCharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.uniTextBox2.UseDynamicFormat = false;
            this.uniTextBox2.WordWrap = false;
            // 
            // ModuleViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uniTBL_OuterMost);
            this.MinimumSize = new System.Drawing.Size(0, 0);
            this.Name = "ModuleViewer";
            this.Size = new System.Drawing.Size(844, 717);
            this.Controls.SetChildIndex(this.uniTBL_OuterMost, 0);
            this.Controls.SetChildIndex(this.uniLabel_Path, 0);
            this.uniTBL_OuterMost.ResumeLayout(false);
            this.uniTBL_MainCondition.ResumeLayout(false);
            this.uniTBL_MainReference.ResumeLayout(false);
            this.uniTBL_MainData.ResumeLayout(false);
            this.uniTBL_Single.ResumeLayout(false);
            this.uniTBL_Single.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtRemark)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtIsrtDt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRefNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboErpIfRtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDiligType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboReportType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniGrid1)).EndInit();
            this.uniTableLayoutPanel1.ResumeLayout(false);
            this.uniTableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtBaseDt)).EndInit();
            this.uniTableLayoutPanel2.ResumeLayout(false);
            this.popEmpNo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox_Code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniTextBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_OuterMost;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainCondition;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainReference;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainBatch;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_MainData;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTBL_Single;
        private uniERP.AppFramework.UI.Controls.uniGrid uniGrid1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDiligReqNo;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popDiligReqNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRemark;
        private uniERP.AppFramework.UI.Controls.uniLabel lblErpIfRtn;
        private uniERP.AppFramework.UI.Controls.uniLabel lblIsrtDt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblRefNo;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDiligType;
        private uniERP.AppFramework.UI.Controls.uniLabel lblReportType;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtRemark;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtIsrtDt;
        private uniERP.AppFramework.UI.Controls.uniTextBox txtRefNo;
        private uniERP.AppFramework.UI.Controls.uniCombo cboErpIfRtn;
        private uniERP.AppFramework.UI.Controls.uniButton btnApproval;
        private uniERP.AppFramework.UI.Controls.uniLabel lblDiligRef;
        private uniERP.AppFramework.UI.Controls.uniCombo cboDiligType;
        private uniERP.AppFramework.UI.Controls.uniCombo cboReportType;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel1;
        private uniERP.AppFramework.UI.Controls.uniLabel lblBaseDt;
        private uniERP.AppFramework.UI.Controls.uniDateTime dtBaseDt;
        private uniERP.AppFramework.UI.Controls.uniLabel lblEmpNo;
        private uniERP.AppFramework.UI.Controls.uniTableLayoutPanel uniTableLayoutPanel2;
        private uniERP.AppFramework.UI.Controls.uniOpenPopup popEmpNo;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Name;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox_Code;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox1;
        private uniERP.AppFramework.UI.Controls.uniTextBox uniTextBox2;

    }
}
